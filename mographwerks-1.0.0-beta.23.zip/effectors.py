"""The effector stack, and the field stack each effector carries.

⚠ EFFECTORS ARE MODIFIERS. They ARE the list — there is no parallel PropertyGroup to keep
in sync, so reorder, mute and rename come free from the modifier stack.

⚠ THEY COMPOSE THROUGH THE GEOMETRY STREAM. Each takes geometry in and hands transformed
geometry out, so stacking is just chaining modifiers. The old design had every effector
write named attributes for a sibling to read back, which cost a FLAT ~0.3 ms per effector
regardless of clone count — 100 cloners x 3 effectors was about 11 fps.
"""

import re

import bpy

from . import cloner, fields, ng, props

EFFECTOR_NG = "MG_Effector"

# ⚠ Slot 1 is the BASE and has no blend mode — the others fold into it in order.
SLOTS = ("Field", "Field 2", "Field 3", "Field 4")
BLENDS = (None, "Blend 2", "Blend 3", "Blend 4")


def stack(obj):
    """Effector modifiers in stack order."""
    if obj is None:
        return []
    return [m for m in obj.modifiers
            if m.type == 'NODES' and m.node_group is not None
            and m.node_group.name == EFFECTOR_NG]


def rows(mod):
    """(slot name, blend name or None, field object or None) per slot, in order."""
    out = []
    for i, slot in enumerate(SLOTS):
        if props.holder(mod, slot) is None:
            break
        out.append((slot, BLENDS[i], props.get(mod, slot)))
    return out


def clone_positions(car, undisplaced=True):
    """Where the clones sit, so a new field can be fitted to them.

    ⚠ MEASURE THEM UNDISPLACED. Fitting to where the clones currently ARE means fitting to
    a moving target: the effectors have already shifted them, so a field created on a stack
    with an offset lands centred on the displaced cloud and reads nothing. Mute the stack,
    measure the distribution, put it back exactly as it was.
    """
    import bpy as _b
    muted = []
    if undisplaced:
        for m in stack(car):
            if m.show_viewport:
                muted.append(m)
                m.show_viewport = False
    try:
        car.update_tag()
        _b.context.view_layer.update()
        dg = _b.context.evaluated_depsgraph_get()
        return [i.matrix_world.translation.copy() for i in dg.object_instances
                if i.is_instance and i.parent is not None and i.parent.original is car]
    finally:
        for m in muted:
            m.show_viewport = True
        car.update_tag()
        _b.context.view_layer.update()


def first_empty(mod):
    """The first free slot, 1-based, or 0 if the stack is full."""
    for i, slot in enumerate(SLOTS):
        h = props.holder(mod, slot)
        if h is not None and props.get(mod, slot) is None:
            return i + 1
    return 0


# ------------------------------------------------------------------------------ sharing
# ⚠⚠ MEASURED BOUNDARY, and it is what shapes this whole feature. Of MG_Effector's inputs,
# TWENTY accept a driver and EIGHT refuse:
#
#     drivable   Offset Rotation Scale Strength Seed Spread Ease Iterations Radius
#                Use Clone Size, Uniform Scale, Progress, and the Field* fallbacks
#     refuses    Type (menu) · Field, Field 2-4 (object pointers) · Blend 2-4 (menus)
#
# The eight that refuse are exactly the STRUCTURAL choices — what kind of effector, and which
# fields. So: values are DRIVEN (live, and they keep working under animation), structure is
# COPIED and then mirrored on change. Mirroring is the same derive-on-change pattern the field
# type already uses, writing only when the value differs so it converges in one pass.
#
# ⚠ PROGRESS IS DELIBERATELY NOT LINKED — Rob's call. Timing stays per-cloner so a Motionwerks
# cue can bind any member of a linked set independently and the cue contract is untouched. A
# driven Progress on a follower would make keying it silently do nothing, which is exactly the
# class of defect this codebase keeps paying for.
STRUCTURE = ("Type", "Field", "Field 2", "Field 3", "Field 4",
             "Blend 2", "Blend 3", "Blend 4")
NEVER_LINK = ("Progress",)


def link_master(mod):
    """The (object, modifier) this effector follows, or (None, None).

    ⚠⚠ THE DRIVERS **ARE** THE LINK — there is no separate bookkeeping. A modifier cannot
    carry custom properties at all ("this type doesn't support IDProperties"), which is what
    ruled out storing a pointer on it; and deriving the master from the drivers turns out to be
    strictly better anyway. There is one source of truth, it cannot go stale, and removing the
    drivers IS unlinking. A stored pointer that disagreed with the drivers would be exactly the
    silent-desync this codebase keeps paying for.
    """
    if mod is None:
        return None, None
    ad = mod.id_data.animation_data
    if ad is None:
        return None, None
    prefix = 'modifiers["%s"]' % mod.name
    for fc in ad.drivers:
        if not fc.data_path.startswith(prefix) or not fc.driver.variables:
            continue
        t = fc.driver.variables[0].targets[0]
        hit = re.match(r'modifiers\["([^"]+)"\]', t.data_path or "")
        if t.id is None or hit is None:
            continue
        src = t.id.modifiers.get(hit.group(1))
        if src is not None and not (t.id is mod.id_data and src is mod):
            return t.id, src
    return None, None


def _linkable(mod):
    """Socket names worth linking: drivable, not Geometry, not Progress, not structural."""
    grp = mod.node_group
    out = []
    for s in grp.interface.items_tree:
        if getattr(s, "in_out", "") != 'INPUT':
            continue
        if s.socket_type == 'NodeSocketGeometry' or s.name in NEVER_LINK or s.name in STRUCTURE:
            continue
        out.append(s.name)
    return out


def mirror_structure(follower, master):
    """Copy the eight non-drivable sockets across, writing only what differs.

    ⚠ WRITE ONLY ON DIFFERENCE. This runs from the depsgraph handler, and an unconditional
    write would re-trigger it forever. Comparing first makes it converge in one pass — the
    same rule the field-type derivation already follows.
    """
    changed = False
    for nm in STRUCTURE:
        try:
            a, b = props.get(master, nm), props.get(follower, nm)
        except Exception:
            continue
        if a != b:
            props.set(follower, nm, a)
            changed = True
    return changed


def link_effector(follower, master_obj, master_mod):
    """Drive `follower`'s values from `master_mod`, and copy its structure."""
    unlink_effector(follower)
    for nm in _linkable(follower):
        hf = props.holder(follower, nm)
        hm = props.holder(master_mod, nm)
        if hf is None or hm is None:
            continue
        try:
            v = hf.value
            n = len(v) if hasattr(v, "__len__") else 0
        except Exception:
            continue
        # ⚠ a VECTOR needs one driver PER COMPONENT — `driver_add("value")` on a vector
        # returns a list and the targets have to be wired per index anyway.
        idxs = range(n) if n else (None,)
        for i in idxs:
            try:
                fc = hf.driver_add("value", i) if i is not None else hf.driver_add("value")
            except Exception:
                continue
            d = fc.driver
            d.type = 'AVERAGE'
            for old in list(d.variables):
                d.variables.remove(old)
            var = d.variables.new()
            var.name = "src"
            var.targets[0].id_type = 'OBJECT'
            var.targets[0].id = master_obj
            path = hm.path_from_id("value")
            var.targets[0].data_path = path + ("[%d]" % i if i is not None else "")
    mirror_structure(follower, master_mod)


def unlink_effector(mod, bake=True):
    """Drop the drivers, KEEPING the values the effector was actually showing.

    ⚠⚠ A DRIVEN SOCKET STILL REPORTS ITS OLD STORED VALUE. `props.get` on a linked follower
    returns what it had BEFORE the link (measured: master Offset 3.0, follower still reading
    its default 2.0) while the clones correctly evaluate at the master's value. So simply
    deleting the drivers snaps the effector back to a value the user has never seen — work
    silently lost. Copy the master's values in FIRST, then remove the drivers.

    ⚠ My own test passed this before the fix, by coincidence: the numbers at that moment
    happened to match. "The assertion held" is not "the behaviour is right".
    """
    if bake:
        mobj, mmod = link_master(mod)
        if mmod is not None:
            for nm in _linkable(mod):
                try:
                    props.set(mod, nm, props.get(mmod, nm))
                except Exception:
                    pass
    obj = mod.id_data
    ad = obj.animation_data
    if ad:
        prefix = 'modifiers["%s"]' % mod.name
        for fc in [f for f in ad.drivers if f.data_path.startswith(prefix)]:
            ad.drivers.remove(fc)


class MG_OT_link_effector(bpy.types.Operator):
    """Share this effector with the other selected cloners"""
    bl_idname = "mographwerks.link_effector"
    bl_label = "Share Effector"
    bl_description = ("Give every other SELECTED cloner a copy of this effector, driven by "
                      "this one. Values stay in step; Progress stays per-cloner so each can "
                      "still be cue-driven on its own")
    bl_options = {'REGISTER', 'UNDO'}
    mod_name: bpy.props.StringProperty()

    def execute(self, context):
        car = cloner.active(context)
        master = car.modifiers.get(self.mod_name) if car else None
        if master is None:
            return {'CANCELLED'}
        # ⚠ ACTIVE IS THE SOURCE, SELECTED ARE THE TARGETS — Blender's own "copy to selected"
        # idiom, so it needs no explaining.
        targets = [o for o in context.selected_objects
                   if o is not car and cloner.cloner_mod(o) is not None]
        if not targets:
            self.report({'WARNING'},
                        "Select the cloners to share with, and make this one active")
            return {'CANCELLED'}
        group = master.node_group
        n = 0
        for t in targets:
            m = t.modifiers.new(master.name, 'NODES')
            m.node_group = group
            link_effector(m, car, master)
            cloner.focus_gizmos(t)
            n += 1
        self.report({'INFO'}, "Shared with %d cloner%s" % (n, "" if n == 1 else "s"))
        return {'FINISHED'}


class MG_OT_unlink_effector(bpy.types.Operator):
    """Stop following, keeping the current values"""
    bl_idname = "mographwerks.unlink_effector"
    bl_label = "Unlink Effector"
    bl_description = "Stop following the shared effector. The values it has now are kept"
    bl_options = {'REGISTER', 'UNDO'}
    mod_name: bpy.props.StringProperty()

    def execute(self, context):
        car = cloner.active(context)
        mod = car.modifiers.get(self.mod_name) if car else None
        if mod is None:
            return {'CANCELLED'}
        unlink_effector(mod)
        return {'FINISHED'}


def _surface_node(nt):
    """The node feeding the material output, or None.

    ⚠⚠ COMPARE NODES BY **NAME**, NEVER WITH `is`. bpy wrappers are recreated on each access,
    so `link.to_node is out` is False even for the very node you just found — this returned
    None on a material whose Principled BSDF was demonstrably linked to the output, and the
    Set Up Material button silently added an Attribute node and connected nothing.
    ⚠ This is the FOURTH time this trap has bitten in one session and the first time it
    reached shipping code rather than a test.
    """
    out = next((n for n in nt.nodes if n.bl_idname == 'ShaderNodeOutputMaterial'), None)
    if out is None:
        return None
    for l in nt.links:
        if l.to_node.name == out.name and l.to_socket.name == "Surface":
            return l.from_node
    return None


def wire_color_material(obj, style='COLOR', stops=None):
    """Wire `obj`'s material to read this effector.

    `style='COLOR'` reads `mg_color` straight into Base Color — the simple two-colour path.
    `style='RAMP'`  reads the raw factor `mg_fac` through a **Color Ramp**, which is where a
    ramp has to live: a ColorRamp is node STATE, not a socket, and MG_Effector is ONE group
    shared by every effector in the scene, so a ramp inside it would be one ramp for the whole
    scene. In the material you get unlimited stops, Blender's interpolation modes and its own
    presets, and we maintain none of it.

    Returns (material name, what happened) so the operator can report honestly.

    ⚠ IDEMPOTENT. Pressing the button twice must not stack up Attribute nodes — an existing
    one with the right name and type is reused.
    ⚠ IT WILL NOT OVERWRITE AN EXISTING BASE COLOR LINK. Silently unplugging someone's texture
    to wire in a colour ramp is worse than doing nothing: the node is created and left ready,
    and the operator SAYS it did not connect. Destroying work to make a button look successful
    is the wrong trade.
    """
    made = []
    if not obj.data.materials or obj.data.materials[0] is None:
        mat = bpy.data.materials.new(obj.name + " Clones")
        if obj.data.materials:
            obj.data.materials[0] = mat
        else:
            obj.data.materials.append(mat)
        made.append("created a material")
    else:
        mat = obj.data.materials[0]
    if not mat.use_nodes:
        mat.use_nodes = True
        made.append("switched it to nodes")
    nt = mat.node_tree

    want = ng.FAC_ATTR if style == 'RAMP' else ng.COLOR_ATTR
    attr = next((n for n in nt.nodes
                 if n.bl_idname == 'ShaderNodeAttribute'
                 and n.attribute_name == want
                 and n.attribute_type == 'INSTANCER'), None)
    if attr is None:
        attr = nt.nodes.new('ShaderNodeAttribute')
        # ⚠ INSTANCER. `GEOMETRY` reads the SOURCE mesh, finds nothing, and renders flat with
        # no error at all — the single most likely way to conclude this feature is broken.
        attr.attribute_type = 'INSTANCER'
        attr.attribute_name = want
        made.append("added the Attribute node")

    ramp = None
    if style == 'RAMP':
        # ⚠ REUSE an existing ramp fed by this attribute rather than stacking a second one.
        ramp = next((l.to_node for l in nt.links
                     if l.from_node.name == attr.name
                     and l.to_node.bl_idname == 'ShaderNodeValToRGB'), None)
        if ramp is None:
            ramp = nt.nodes.new('ShaderNodeValToRGB')
            nt.links.new(attr.outputs["Fac"], ramp.inputs["Fac"])
            # ⚠ SEED THE STOPS FROM THE EFFECTOR'S OWN COLOURS, so pressing the button is a
            # starting point rather than a grey ramp you then have to build from scratch.
            if stops:
                ramp.color_ramp.elements[0].color = stops[0]
                ramp.color_ramp.elements[1].color = stops[1]
            made.append("added a Color Ramp")

    surf = _surface_node(nt)
    if surf is None:
        return mat.name, "added the Attribute node, but this material has no surface shader "\
                         "to connect it to"
    base = surf.inputs.get("Base Color") or surf.inputs.get("Color")
    if base is None:
        return mat.name, "; ".join(made) + " — no Base Color on %s, connect it by hand" % surf.name
    src_node = ramp if ramp is not None else attr
    attr.location = (surf.location.x - (620 if ramp else 320), surf.location.y - 120)
    if ramp is not None:
        ramp.location = (surf.location.x - 320, surf.location.y - 120)
    if base.is_linked:
        return mat.name, ("; ".join(made) or "already set up") + \
            " — left Base Color alone, it is already connected"
    nt.links.new(src_node.outputs["Color"], base)
    made.append("connected it to Base Color")
    return mat.name, "; ".join(made) if made else "already set up"


class MG_OT_setup_color_material(bpy.types.Operator):
    """Wire the cloned object's material to read this effector's color"""
    bl_idname = "mographwerks.setup_color_material"
    bl_label = "Set Up Material"
    bl_options = {'REGISTER', 'UNDO'}
    mod_name: bpy.props.StringProperty()

    # ⚠ A DYNAMIC DESCRIPTION, because ONE operator serves BOTH buttons and they do not read
    # the same attribute — a static bl_description would name mg_color on the Ramp button,
    # which is the one thing someone wiring it by hand must not be told wrongly.
    # ⚠ This is also where the wordy explanation belongs. It used to sit in the panel as three
    # greyed lines under the buttons; a tooltip costs nothing until it is asked for.
    @classmethod
    def description(cls, context, properties):
        if getattr(properties, "style", 'COLOR') == 'RAMP':
            return ("Wire the cloned object's material to read the raw 0-1 factor (%s) through "
                    "a Color Ramp seeded from Color A and Color B, so you can add as many "
                    "stops as you like. The ramp lives in the material, not on the effector"
                    % ng.FAC_ATTR)
        return ("Wire the cloned object's material to read this effector's color (%s) into "
                "Base Color. The attribute is on the INSTANCES, not the mesh, so the Attribute "
                "node must be set to Instancer — on Geometry it renders flat with no error"
                % ng.COLOR_ATTR)
    # ⚠ TWO STYLES, ONE OPERATOR. The ramp is not a different feature, it is the same wiring
    # with Blender's ColorRamp in the middle — two operators would be two places to fix.
    style: bpy.props.EnumProperty(
        name="Style", default='COLOR',
        items=[('COLOR', "Color", "Read the effector's two colors directly"),
               ('RAMP', "Ramp", "Read the raw 0-1 factor through a Color Ramp, so you can "
                                "add as many stops as you like")])

    def execute(self, context):
        car = cloner.active(context)
        if car is None:
            return {'CANCELLED'}
        mod = car.modifiers.get(self.mod_name)
        stops = None
        if mod is not None:
            try:
                stops = (tuple(props.get(mod, "Color A")), tuple(props.get(mod, "Color B")))
            except Exception:
                stops = None
        targets = cloner.cloned_objects(car)
        if not targets:
            self.report({'WARNING'}, "Nothing to put a material on — this cloner has no source")
            return {'CANCELLED'}
        done = []
        for o in targets:
            name, what = wire_color_material(o, style=self.style, stops=stops)
            done.append("%s: %s" % (name, what))
        self.report({'INFO'}, " | ".join(done))
        return {'FINISHED'}


class MG_OT_add_effector(bpy.types.Operator):
    bl_idname = "mographwerks.add_effector"
    bl_label = "Add Effector"
    bl_description = "Add an effector. Effectors stack — each adds its offset, rotation "\
                     "and scale on top of the others"
    bl_options = {'REGISTER', 'UNDO'}

    # ⚠ the type is chosen UP FRONT so the effector can be NAMED for what it is. Spawning a
    # Plain one to re-type afterwards leaves auto-naming with nothing sensible to do.
    eff_type: bpy.props.EnumProperty(
        name="Type", default='PLAIN',
        # ⚠ (id, label, description, icon, number) — FIVE elements. A 4-tuple is read as
        # (id, label, desc, number), so an icon without the trailing number becomes the enum
        # VALUE and every item collapses onto the same one. Same trap as FIELD_ITEMS.
        items=[(n.upper().replace(" ", "_"), n, d, i, k)
               for k, (n, d, i) in enumerate(ng.EFFECTOR_ITEMS)])

    def execute(self, context):
        car = cloner.active(context)
        if car is None:
            return {'CANCELLED'}
        group = bpy.data.node_groups.get(EFFECTOR_NG) or ng.ensure()[EFFECTOR_NG]
        name = ng.EFFECTOR_IDENTS[self.eff_type]
        m = car.modifiers.new(name, 'NODES')
        m.node_group = group
        props.set(m, "Type", name)
        # ⚠ THE DEFAULT HAS TO SUIT THE TYPE. Random multiplies the Offset PER AXIS, so a
        # Z-only default could only ever scatter vertically — which reads as a messier Plain.
        # Rob: "Random just seems to be a Plain effector." Plain and Step want a lift; Random
        # wants a scatter in all three.
        # ⚠ PUSH APART IGNORES the typed Offset entirely — it computes its own from where
        # the neighbours are — so it gets none, and the panel does not draw one.
        if name != ng.PUSH_APART:
            props.set(m, "Offset", (1.0, 1.0, 1.0) if self.eff_type == 'RANDOM'
                      else (0.0, 0.0, 2.0))
        # ⚠ `modifiers.new()` made THIS the active modifier, which stops the cloner's gizmos
        # being drawn — see `cloner.focus_gizmos`. Hand it back.
        cloner.focus_gizmos(car)
        return {'FINISHED'}


class MG_OT_remove_effector(bpy.types.Operator):
    bl_idname = "mographwerks.remove_effector"
    bl_label = "Remove Effector"
    bl_options = {'REGISTER', 'UNDO'}
    mod_name: bpy.props.StringProperty()

    def execute(self, context):
        car = cloner.active(context)
        m = car.modifiers.get(self.mod_name) if car else None
        if m is None:
            return {'CANCELLED'}
        # ⚠ take the gizmos with it, but only the ones nothing else still points at
        owned = {props.get(m, s).name for s in SLOTS if props.get(m, s) is not None}
        car.modifiers.remove(m)
        for name in owned:
            f = bpy.data.objects.get(name)
            if f is not None and f.get("mg_field") and cloner.cloner_using(f) is None:
                bpy.data.objects.remove(f)
        # ⚠ removing a modifier hands ACTIVE to a neighbour, which is just as likely to be
        # another effector — so the gizmos would stay hidden after a remove too.
        cloner.focus_gizmos(car)
        return {'FINISHED'}


class MG_OT_move_effector(bpy.types.Operator):
    bl_idname = "mographwerks.move_effector"
    bl_label = "Move Effector"
    bl_options = {'REGISTER', 'UNDO'}
    mod_name: bpy.props.StringProperty()
    dir: bpy.props.IntProperty(default=1)

    def execute(self, context):
        car = cloner.active(context)
        if car is None or car.modifiers.get(self.mod_name) is None:
            return {'CANCELLED'}
        i = car.modifiers.find(self.mod_name)
        j = i + self.dir
        if 0 <= j < len(car.modifiers):
            car.modifiers.move(i, j)
        cloner.focus_gizmos(car)
        return {'FINISHED'}


class MG_OT_add_field(bpy.types.Operator):
    bl_idname = "mographwerks.add_field"
    bl_label = "Add Field"
    bl_description = "Add a field to this effector. The gizmo is a wireframe drawing of "\
                     "the falloff itself — it never renders, and scaling it scales the region"
    bl_options = {'REGISTER', 'UNDO'}

    mod_name: bpy.props.StringProperty()
    # ⚠ 0 means FIRST EMPTY, resolved in execute(). One menu serves every effector, so it
    # cannot know which slot is free — and having it guess from draw-time state is exactly
    # the stash bug that made every field land on the wrong stack.
    slot: bpy.props.IntProperty(default=0, min=0, max=4)
    field_type: bpy.props.EnumProperty(name="Type", default='LINEAR',
                                       items=list(fields.FIELD_ITEMS))

    def execute(self, context):
        car = cloner.active(context)
        if car is None:
            return {'CANCELLED'}
        mod = car.modifiers.get(self.mod_name)
        if mod is None:
            self.report({'ERROR'}, "No effector called '%s'" % self.mod_name)
            return {'CANCELLED'}
        # ⚠ RESOLVE THE DESTINATION BEFORE CREATING ANYTHING. Building the gizmo first and
        # validating after leaked an orphan field into the scene on every failed add.
        slot = self.slot or first_empty(mod)
        if not slot:
            self.report({'WARNING'}, "Four fields is the maximum")
            return {'CANCELLED'}
        f = fields.create(context, self.field_type,
                          name_base=car.name.replace(".Cloner", ""),
                          collection=cloner.group_of(car))
        # ⚠ AIM AND SIZE IT AT THE CLONES. A Linear field's ramp runs along its own +Z, so a
        # default-oriented gizmo over a flat grid gives EVERY clone the same value and the
        # field looks broken. Rob, on first use: "Linear field is pointing up on Z and
        # doesn't seem to be doing anything." Fitting it is the difference between a field
        # that does nothing and one that already reads.
        fields.fit_to(f, clone_positions(car))
        props.set(mod, SLOTS[slot - 1], f)
        # ⚠ tag AFTER the socket is set and the gizmo is fitted, so the first evaluation
        # already sees the finished field rather than an unfitted one
        car.update_tag()
        for o in context.selected_objects:
            o.select_set(False)
        f.select_set(True)
        context.view_layer.objects.active = f
        return {'FINISHED'}


class MG_OT_use_field(bpy.types.Operator):
    """Point this effector at a field that already exists, creating nothing.

    ⚠⚠ THE PICKER ALONE DID NOT CLOSE THE GAP. beta.19 made the field row an object picker, so
    an effector could be REPOINTED at an existing field — but a row is only drawn for a slot
    that already holds one (`ui.py`), and the only way to fill a slot was Add Field, which
    CREATES a gizmo. So sharing a field meant making one you did not want, swapping the picker
    off it, and leaving it orphaned in the scene. Measured: `Cube.001.Sphere.001`, used by
    nothing. Rob: *"So do you have to add a new field to pick an already existing one?"*
    ⚠ This is the SECOND time this exact shape has come up on this feature — the capability
    existed both times, and the panel had no route to it.
    """

    bl_idname = "mographwerks.use_field"
    bl_label = "Use Existing Field"
    bl_options = {'REGISTER', 'UNDO'}

    mod_name: bpy.props.StringProperty()
    field_name: bpy.props.StringProperty()

    @classmethod
    def description(cls, context, properties):
        return ("Point this effector at %s — the same gizmo then drives both, and moving it "
                "moves everything reading it. Nothing new is created"
                % (getattr(properties, "field_name", "") or "an existing field"))

    def execute(self, context):
        car = cloner.active(context)
        if car is None:
            return {'CANCELLED'}
        mod = car.modifiers.get(self.mod_name)
        if mod is None:
            self.report({'ERROR'}, "No effector called '%s'" % self.mod_name)
            return {'CANCELLED'}
        f = bpy.data.objects.get(self.field_name)
        # ⚠ RE-CHECK IT IS STILL A FIELD AT CLICK TIME. The menu was drawn from the scene as it
        # was; the object can be gone, or renamed, by the time the item is picked.
        if not fields.is_field(f):
            self.report({'WARNING'}, "'%s' is not a field any more" % self.field_name)
            return {'CANCELLED'}
        if any(props.get(mod, s) == f for s in SLOTS):
            self.report({'INFO'}, "This effector already reads %s" % f.name)
            return {'CANCELLED'}
        slot = first_empty(mod)
        if not slot:
            self.report({'WARNING'}, "Four fields is the maximum")
            return {'CANCELLED'}
        props.set(mod, SLOTS[slot - 1], f)
        # ⚠ tag the CARRIER, not the field: the field itself did not change, the effector that
        # reads it did, and an untagged carrier keeps handing out the previous evaluation.
        car.update_tag()
        return {'FINISHED'}


class MG_OT_remove_field(bpy.types.Operator):
    bl_idname = "mographwerks.remove_field"
    bl_label = "Remove Field"
    bl_description = "Take this field off the effector and delete its gizmo"
    bl_options = {'REGISTER', 'UNDO'}
    mod_name: bpy.props.StringProperty()
    index: bpy.props.IntProperty()

    def execute(self, context):
        car = cloner.active(context)
        mod = car.modifiers.get(self.mod_name) if car else None
        if mod is None:
            return {'CANCELLED'}
        gone = props.get(mod, SLOTS[self.index])
        # ⚠ shift the rest UP so the stack never shows a hole: occupancy is what switches a
        # blend on, so a gap would silently disable everything below it.
        for i in range(self.index, len(SLOTS) - 1):
            props.set(mod, SLOTS[i], props.get(mod, SLOTS[i + 1]))
            if BLENDS[i] and BLENDS[i + 1]:
                props.set(mod, BLENDS[i], props.get(mod, BLENDS[i + 1]))
        props.set(mod, SLOTS[-1], None)
        if gone is not None and gone.get("mg_field") and cloner.cloner_using(gone) is None:
            bpy.data.objects.remove(gone)
        return {'FINISHED'}


class MG_OT_fit_field(bpy.types.Operator):
    """Re-fit a field's gizmo to the clones it is masking.

    ⚠ DEFERRED UNTIL THE UI WAS DIALLED IN, on Rob's call, and now it is. A field is created
    fitted, but the cloner grows and moves afterwards — a Linear field aimed at a 4x4 grid
    reads nothing once that grid becomes 12x12 and twice the size, and re-aiming it by hand is
    the fiddliest thing in the addon.
    ⚠ IT MEASURES THE CLONES UNDISPLACED, which `clone_positions` already handles: fitting to
    where the clones currently ARE means fitting to a moving target, because the effectors
    have already shifted them.
    """

    bl_idname = "mographwerks.fit_field"
    bl_label = "Fit to Clones"
    bl_description = "Re-aim and re-size this field so it spans the clones again"
    bl_options = {'REGISTER', 'UNDO'}

    mod_name: bpy.props.StringProperty()
    index: bpy.props.IntProperty()

    def execute(self, context):
        car = cloner.active(context)
        mod = car.modifiers.get(self.mod_name) if car else None
        if mod is None:
            return {'CANCELLED'}
        f = props.get(mod, SLOTS[self.index])
        if f is None:
            return {'CANCELLED'}
        pts = clone_positions(car)
        if not pts:
            self.report({'WARNING'}, "No clones to fit to")
            return {'CANCELLED'}
        fields.fit_to(f, pts)
        # ⚠ tag AFTER the transform, or the cloner keeps handing out the previous evaluation
        # and the field looks inert until some unrelated edit forces a re-evaluate.
        f.update_tag()
        car.update_tag()
        return {'FINISHED'}


class MG_MT_add_field(bpy.types.Menu):
    """The field type list.

    ⚠ THE TARGET COMES FROM THE LAYOUT CONTEXT, never a stash. One menu serves every
    effector, so it has to learn which stack opened it. Parking that on the window manager
    during draw() meant the LAST panel drawn won, and every field landed on the wrong
    effector. `context_pointer_set` resolves at CLICK time and is scoped to the row.
    ⚠ No pointer = offer NOTHING. Falling back to "the first effector" is the old bug.
    """
    bl_idname = "MG_MT_add_field"
    bl_label = "Add Field"

    def draw(self, context):
        layout = self.layout
        mod = getattr(context, "mg_field_stack", None)
        if mod is None:
            r = layout.row()
            r.enabled = False
            r.label(text="No effector — reopen the panel", icon='ERROR')
            return
        for ident, label, _desc, icon, _n in fields.FIELD_ITEMS:
            op = layout.operator("mographwerks.add_field", text=label, icon=icon)
            op.field_type = ident
            op.slot = 0
            op.mod_name = mod.name
        # ⚠ EXISTING FIELDS BELOW THE TYPES, in the same menu. Sharing a field is the whole
        # point of fields being OBJECTS, and until now the only route to it was to create one
        # you did not want and swap the picker off it — leaving an orphan gizmo behind.
        # ⚠ EXCLUDE THE ONES THIS EFFECTOR ALREADY READS, or the menu offers a no-op that
        # reports "already reads" — a listed action that cannot do anything is the failure
        # this project keeps rebuilding.
        mine = {props.get(mod, s) for s in SLOTS}
        others = sorted((o for o in bpy.data.objects
                         if fields.is_field(o) and o not in mine),
                        key=lambda o: o.name)
        if not others:
            return
        layout.separator()
        # ⚠ NOT `enabled = False` on the header: a greyed label in a menu reads as a broken
        # item. A plain label is the section heading it is meant to be.
        layout.label(text="Use Existing")
        for o in others:
            op = layout.operator("mographwerks.use_field", text=o.name,
                                 icon=fields.icon_for(o))
            op.mod_name = mod.name
            op.field_name = o.name


CLASSES = (MG_OT_add_effector, MG_OT_remove_effector, MG_OT_move_effector,
           MG_OT_link_effector, MG_OT_unlink_effector, MG_OT_setup_color_material,
           MG_OT_add_field, MG_OT_use_field, MG_OT_remove_field, MG_OT_fit_field,
           MG_MT_add_field)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
