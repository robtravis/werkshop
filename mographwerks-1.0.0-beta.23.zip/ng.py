"""Append the node groups from nodegroups.blend, and verify they are what we expect.

⚠ WHY THE CONTRACT EXISTS. The graphs now live in a .blend, so a change to one is invisible
in git and cannot be code-reviewed. The trade for that convenience is this file: every group
must expose the socket NAMES and TYPES the addon addresses, checked on append, failing
LOUDLY. Registration refusing to complete is a good outcome; an addon whose panel draws
controls that quietly do nothing is the bad one, and we shipped that twice.
"""

import os
import bpy

_MISSING = object()

BLEND = os.path.join(os.path.dirname(__file__), "nodegroups.blend")
# ⚠ THE CONTRACT CHECKS SOCKETS, WHICH IS NOT ENOUGH ON ITS OWN. A fix that only rewires the
# INSIDE of a group — beta.15's field-space fix, beta.20's colour clamp — changes no socket, so
# `verify()` passes on the old group and a .blend saved with an earlier version keeps it
# forever. Rob hit exactly this: his file rendered a flat colour because it still held the
# pre-beta.20 MG_Effector while the shipped .blend had the fix. This sidecar closes it: the
# seeder writes a content hash per group, and anything that does not match gets refreshed.
BUILD = os.path.join(os.path.dirname(__file__), "nodegroups.json")

# ⚠ NAMES AND TYPES ONLY — never positions. Socket identifiers are creation-ordered, so any
# insert renumbers everything after it; that is precisely what this must not depend on.
# Adding a socket to the .blend without adding it here is fine. Renaming one is not.
_GEO = 'NodeSocketGeometry'
_OBJ = 'NodeSocketObject'
_INT = 'NodeSocketInt'
_FLT = 'NodeSocketFloat'
_VEC = 'NodeSocketVector'
_BOOL = 'NodeSocketBool'
_MENU = 'NodeSocketMenu'
_COLL = 'NodeSocketCollection'
_MAT = 'NodeSocketMaterial'
_COL = 'NodeSocketColor'

# ⚠ ONE GROUP PER CLONER MODE, no Menu Switch — the Add a Cloner buttons already choose the
# type, so an unused mode should not sit in the graph costing evaluation. CLONER_MODES is
# also what the Mode dropdown swaps between; see `swap_mode`.
# ⚠ A GENERATOR IS A CLONER **OR** A FRACTURE. Both put instances on the stack, so effectors
# and fields do not care which made them — that is what lets one effector stack serve both.
# ⚠ NO CELL FRACTURE PRESETS HERE, DELIBERATELY. Cell Fracture is Blender's own operator and
# the panel opens its window directly — settings and presets both live there. Rob had already
# decided this; I ported v0.65.0's preset table anyway because it was in the old source, and
# that is the cost of reading the old build for MECHANISM without checking the DECISIONS.
FRACTURE_MODES = {
    'LIVE':   "MG_Fracture",
    'PIECES': "MG_Pieces",
}

# ⚠ THE ADD GRID SHOWS THE VOCABULARY instead of hiding it behind a dropdown — pressing
# Radial GETS you a radial cloner rather than a grid you then have to re-mode. v0.65.0's
# icons, kept: they were chosen once and eyeballed, and a second set would only be different.
# ⚠ ORDER IS THE READING ORDER, not the dict's — Grid first because it is the common case.
# ⚠ THE DESCRIPTION LIVES HERE TOO, so the button, the dropdown and the tooltip all read the
# same words. The fracture buttons call the SAME operator as the cloner ones, so without a
# per-mode description they inherited its tooltip and Live and Pieces both claimed to "clone
# the selected object" — Rob: "Fracture's tooltips are still Cloner's."
CLONER_ITEMS = (
    ('GRID',      "Grid",      'MESH_GRID',
     "Rows, columns and layers"),
    ('LINEAR',    "Linear",    'MOD_ARRAY',
     "A line along the offset"),
    ('RADIAL',    "Radial",    'MESH_CIRCLE',
     "A ring of the given radius"),
    ('HONEYCOMB', "Honeycomb", 'SEQ_CHROMA_SCOPE',
     "A hex-packed array — odd rows offset half a cell, rows closed up to match"),
    ('OBJECT',    "Object",    'OUTLINER_OB_MESH',
     "Clone onto a target's geometry — its vertices, its face centres, or scattered "
     "over its surface"),
    ('CURVE',     "Curve",     'OUTLINER_OB_CURVE',
     "Distribute along a curve, following its tangent — railings, fences, path planting"),
)

# ⚠ LIVE AND PIECES ARE MODIFIERS; VORONOI IS A BAKE. They sit together because that is where
# people look for them, but the bake is drawn apart from the two — see the panel.
FRACTURE_ITEMS = (
    ('LIVE',   "Live",   'MOD_EXPLODE',
     "Break this mesh into shards that STAY ADJUSTABLE — change the piece count any time. "
     "The shards are convex hulls, so they are fast but not watertight; the Voronoi bake is "
     "the accurate one"),
    # ⚠ PIECES DOES NOT FRACTURE ANYTHING, and the label alone never says so — Rob asked
    # "What does pieces do again?" while looking straight at it. The tooltip has to answer it.
    ('PIECES', "Pieces", 'MOD_SIMPLIFY',
     "Drive a mesh that is ALREADY broken: every loose part becomes a piece an effector can "
     "move. Use it after a Voronoi bake, or on any pre-shattered mesh. It breaks nothing "
     "itself"),
)

CLONER_MODES = {
    'GRID':      "MG_Cloner_Grid",
    'LINEAR':    "MG_Cloner_Linear",
    'RADIAL':    "MG_Cloner_Radial",
    'HONEYCOMB': "MG_Cloner_Honeycomb",
    'OBJECT':    "MG_Cloner_Object",
    'CURVE':     "MG_Cloner_Curve",
}

# ⚠ ORDER IS THE STORED VALUE. Matches the Add Field menu, so the int in the socket and the
# list the user picked from agree. Appending is safe; reordering rewrites every saved field.
# ⚠ ORDER IS THE STORED VALUE and Max is first, so it is the default. Blend sockets are
# MENU sockets: the stored value is the item NAME, not an index, so reordering is safe and
# the raw modifier panel shows a word instead of a bare number.
# ⚠ Plain / Random / Step are ONE node group with a menu, unlike the cloner modes which are
# separate groups. The difference is real: the modes generate different GEOMETRY, while these
# only vary a per-clone MULTIPLIER on the same maths.
# ⚠ PUSH APART IS NOT HERE. It computes its own direction from neighbouring clones — a
# different algorithm needing proximity and iteration, not another multiplier. Adding it to
# this menu before it is built would be a control that does nothing.
# ⚠ PUSH APART IS NOT ANOTHER MULTIPLIER — it computes its own offset from where the
# neighbours are, in a repeat zone. It is a TYPE to the user, not a variation on the others.
# ⚠ ONE TABLE, carrying the icon and the description too — v0.65.0's note stands: a parallel
# {label: icon} dict is the obvious shortcut and the obvious way to let the two drift. The
# dropdown, the header row and the auto-name all read from here.
# ⚠ Random shares RNDCURVE with the Random FIELD on purpose: the word means the same thing in
# both lists, so it should look the same in both.
# ⚠ STEP IS `LINCURVE`, NOT `IPO_LINEAR`. IPO_LINEAR renders GREEN, and it was the only
# colored glyph in either dropdown — a color reads as a STATUS, not a type. LINCURVE is the
# same brush-curve family as RNDCURVE and draws a linear ramp. ✅ EYEBALLED AND CONFIRMED by
# Rob, 2026-08-06 — the dropdown reads as one monochrome family. CLOSED. No test can hold this
# down: asserting an icon is real and distinct is exactly what missed the colored one.
EFFECTOR_ITEMS = (
    ("Plain", "Every clone equally", 'EMPTY_ARROWS'),
    ("Random", "A different amount per clone, from Seed", 'RNDCURVE'),
    ("Step", "A ramp from the first clone to the last", 'LINCURVE'),
    ("Push Apart", "Shove overlapping clones off each other until they clear Radius. "
                   "Computes its own direction, so it replaces Offset", 'FORCE_CHARGE'),
    # ⚠ APPENDED. `EFFECTOR_TYPES.index(...)` resolves the menu to a code in the node group,
    # so anything but appending renumbers the existing types and repoints saved effectors.
    ("Color", "Tint the clones — writes a color the MATERIAL reads, and moves nothing. "
              "Read it with an Attribute node set to Instancer, name mg_color", 'COLOR'),
)

EFFECTOR_TYPES = tuple(n for n, _d, _i in EFFECTOR_ITEMS)
EFFECTOR_ICONS = {n: i for n, _d, i in EFFECTOR_ITEMS}

# ⚠ the controls only Push Apart uses; the panel draws them only for it, and it hides
# Rotation and Scale — which the node group also forces to identity, because a hidden
# control that still applies is worse than a visible one that does nothing.
PUSH_APART = "Push Apart"

# ⚠ COLOR TRANSFORMS NOTHING. Its per-clone amount is a ZERO vector in the node group, which
# silences Offset, Rotation and Scale together — so the panel hides all three rather than
# leaving controls that are drawn and inert.
COLOR = "Color"

# ⚠ THE NAME THE USER TYPES INTO THEIR MATERIAL. Stated in the panel rather than documented
# elsewhere: an Attribute node set to Instancer with the wrong name renders flat and reports
# nothing, so guessing it is the single most likely way to conclude the feature is broken.
COLOR_ATTR = "mg_color"

# ⚠ THE RAW 0-1 WEIGHT, written alongside the colour so the MATERIAL can hold the ramp.
# A Color Ramp is node STATE, not a socket, and MG_Effector is one shared group — a ramp inside
# it would be ONE ramp for the whole scene. Blender's own ColorRamp in the material gives
# unlimited stops and its own presets, and costs us nothing to maintain.
# ⚠ A cloner with NO Color effector never writes this, so it reads 0 and a ramp shows its FIRST
# stop — flat, but not black. That is why the colour path needed a white default and this
# does not.
FAC_ATTR = "mg_fac"

# ⚠ THE ENUM IDENTIFIER IS NOT THE SOCKET VALUE. An operator's enum identifiers cannot carry
# spaces sensibly, but the Menu socket stores the item NAME verbatim — "Push Apart", space and
# all. `.title()` happened to bridge the one-word types and would silently mis-map anything
# hyphenated or capitalised differently, so the pair is a table, not a transformation.
EFFECTOR_IDENTS = {t.upper().replace(" ", "_"): t for t in EFFECTOR_TYPES}

# ⚠ ORDER IS THE STORED VALUE and Each Object is first, so it is the default. Rob: "Clone
# mode default: Each Object. Whole Group and Pick Random as options."
# ⚠ EACH OBJECT CYCLES BY CLONE INDEX (i % n), so on a grid it runs X then Y then Z — 2
# objects across a 4-wide grid gives stripes, not a checkerboard. Same as C4D.
# ⚠ THE ORDER IS ALPHABETICAL BY OBJECT NAME: that is how Collection Info sorts children, so
# renaming is how you choose which object lands where.
CLONE_MODES = ("Each Object", "Whole Group", "Pick Random")

# ⚠ MUST MATCH the enum built into MG_Effector's Blend sockets — the node group is the
# authority and this list only has to agree with it. Overlay is 2ab / 1-2(1-a)(1-b), branching
# on the ACCUMULATED value, which is why it is the one mode that is not a single Math node.
BLEND_ITEMS = ("Max", "Min", "Multiply", "Add", "Subtract", "Overlay")

# ⚠ The parameters a field carries on its own gizmo mesh. A slot needs only the object and
# a blend mode because of these — four slots x eight params would be 32 sockets.
FIELD_ATTRS = ("mg_type", "mg_invert", "mg_bias", "mg_seed",
               "mg_width", "mg_scale", "mg_detail", "mg_spread", "mg_ease",
               "mg_inner", "mg_shape",
               "mg_freq", "mg_dir", "mg_exp",
               "mg_base", "mg_size", "mg_mirror", "mg_axis")

# ⚠ SEQUENCE IS LAST AND IS NOT A SHAPE. It REPLACES the shape: spatially it is the linear
# ramp along its own gizmo, and Progress plays that order. Every other type is animated by
# moving its gizmo; this one by keyframing a slider.
FALLOFF_TYPES = ("Linear", "Sphere", "Box", "Random", "Ring", "Radial",
                 "Voronoi", "Waves", "Noise", "Sequence")

# ⚠ ONE TABLE, TWO USES. The same five curves shape the falloff in SPACE (`Shape`) and the
# build in TIME (`Ease`). They are the same idea applied to different axes, so they share a
# table — if one gains a curve the other should too.
# ⚠ ONE TABLE AGAIN. I split these on the assumption that overshoot is meaningless in space
# — wrong. An overshooting FALLOFF is a RIPPLE: the factor rises above 1 in one band and
# falls below 0 in the next, so the effector over-applies in a ring and reverses beyond it.
# That is a real look, and it is what C4D gives you by dragging a remap point outside 0-1.
# ⚠ A field uses ONE of these: a Sequence bypasses Shape, everything else has no Ease. So
# Amount / Frequency / Decay serve whichever curve applies, with no extra sockets.
# ⚠ THIS IS THE PREVIOUS VERSION'S SET, verbatim. Rob showed the old menu after I invented
# my own (Ease In / Ease Out / Sharp / Spring) — which is why he kept looking for
# "Overshoot" and could not find it. Match what the user already knows.
# ⚠ THE ROBERT PENNER SET, implemented from the published equations. Every curve is exactly
# 0 at 0 and 1 at 1 in all three directions, BY CONSTRUCTION — which is why none of the
# landing corrections we built are needed any more.
# ⚠ "Custom" IS APPENDED, NEVER INSERTED. Blender persists an EnumProperty by its NUMBER,
# so giving Custom index 7 leaves every existing identifier on the number it was saved with.
# Inserting it anywhere else would silently rewrite saved fields to a different curve.
# ⚠ It takes none of the Penner parameters — see USES_EXP/BASE/SIZE/BOUNCES, which it is
# deliberately absent from, so the panel draws a curve widget and nothing else.
EASE_TYPES = ("Sine", "Power", "Expo", "Circular", "Back", "Elastic", "Bounce", "Custom")
CUSTOM_CURVE = "Custom"

# ⚠ WHAT EACH CURVE IS, IN THE TOOLTIP. The list used to be seven bare nouns, which hides the
# fact that the old hand-rolled "Ease In" and "Ease Out" are still right there: Power at
# Exponent 2 reproduces u^2 and 1-(1-u)^2 EXACTLY (measured to 0.0001, which is the measuring
# LUT's own error). Rob asked whether to add them back as presets — they were never gone, they
# were just unlabelled, and a second name for the same curve is a duplicate control.
CURVE_DESC = {
    "Sine":     "The gentlest ease in the set",
    "Power":    "The classic ease. At Exponent 2 this is exactly Ease In / Ease Out "
                "(u squared, and 1-(1-u) squared)",
    "Expo":     "A very sharp ease — almost nothing happens until the end",
    "Circular": "Eases along a quarter circle. Sharper than Sine, softer than Expo",
    "Back":     "Pulls back before it goes, and overshoots on arrival",
    "Elastic":  "Springs past the target and oscillates into it",
    "Bounce":   "Lands and bounces, losing height each time",
    "Custom":   "Draw the curve yourself",
}
# how many samples the baked curve LUT carries. 128 measured as the knee: a steep S is
# reproduced to 0.0002 and even a near-step to 0.02, while 256 is WORSE on a near-step
# because the knots straddle the discontinuity differently. More is not reliably better.
CURVE_SAMPLES = 128
EASE_DIRS = ("In", "Out", "InOut")
SHAPE_TYPES = EASE_TYPES
# ⚠ WHICH CURVE EACH PARAMETER ACTUALLY DRIVES — MEASURED, not assumed. Every socket of
# MoTools' Ease Falloff was swept against every type to find out; the panel draws from these
# sets so a control only ever appears where it does something. Getting this wrong in either
# direction is a bug: a dead slider, or a curve with a hidden parameter stuck on its default.
USES_EXP = ("POWER", "EXPO", "ELASTIC", "BOUNCE")     # Exponent
USES_BASE = ("EXPO", "ELASTIC", "BOUNCE")             # Base — the shared envelope
USES_SIZE = ("BACK",)                                 # Size — the overshoot distance
USES_BOUNCES = ("ELASTIC", "BOUNCE")                  # Bounces

# ⚠ ORDER IS THE STORED VALUE, and the sign is part of the axis — see fields.AXIS_ITEMS.
SEQ_AXES = ("+X", "+Y", "+Z", "-X", "-Y", "-Z")

# ⚠ Scattered Even is POISSON-DISK: it keeps a minimum gap so the covering reads even rather
# than clumping. Order is the stored value's meaning; Vertices is first and so is the default.
TARGET_MODES = ("Vertices", "Face Centers", "Scattered", "Scattered Even")

CONTRACT_GRID = {"Geometry": _GEO, "Source": _OBJ,
                 "Sources": _COLL, "Clone Mode": _MENU, "Seed": _INT,
                 "Count X": _INT, "Count Y": _INT, "Count Z": _INT,
                 "Spacing X": _FLT, "Spacing Y": _FLT, "Spacing Z": _FLT,
                 "Spacing Mode": _MENU, "Shift": _INT, "Material": _MAT, "Use Material": _BOOL}

CONTRACT = {
    # ⚠ instancing lives in ONE nested group, so a fix lands once rather than per mode.
    # ⚠ ONE object or a COLLECTION of them; the collection wins when both are set.
    # ⚠ Shift is listed even though the ADDON never drives it here — the cloner group does.
    # It is in the contract so a stale MG_Instance from an older file FAILS verification and
    # gets refreshed; without it the old group survives, the cloner's Shift links into
    # nothing, and the control reads as dead.
    "MG_Instance": {"Points": _GEO, "Self": _GEO, "Source": _OBJ, "Sources": _COLL, "Clone Mode": _MENU, "Seed": _INT, "Shift": _INT, "Material": _MAT, "Use Material": _BOOL},
    "MG_Cloner_Grid": dict(CONTRACT_GRID),
    # ⚠ HONEYCOMB IS THE GRID'S SOCKET SET, exactly — it is the same builder with the odd
    # rows nudged, so `swap_mode` carries every value across between the two.
    "MG_Cloner_Honeycomb": dict(CONTRACT_GRID),
    "MG_Cloner_Object": {"Geometry": _GEO, "Source": _OBJ,
                        "Sources": _COLL, "Clone Mode": _MENU, "Seed": _INT,
                        "Target": _OBJ, "Distribute": _MENU, "Density": _FLT,
                        "Min Distance": _FLT, "Align to Normal": _BOOL, "Shift": _INT, "Material": _MAT, "Use Material": _BOOL},
    "MG_Cloner_Curve": {"Geometry": _GEO, "Source": _OBJ,
                       "Sources": _COLL, "Clone Mode": _MENU, "Seed": _INT,
                       "Target": _OBJ, "Count": _INT, "Trim Start": _FLT,
                       "Trim End": _FLT, "Follow": _BOOL, "Shift": _INT, "Material": _MAT, "Use Material": _BOOL},
    "MG_Cloner_Linear": {"Geometry": _GEO, "Source": _OBJ,
                         "Sources": _COLL, "Clone Mode": _MENU, "Seed": _INT,
                         "Count": _INT, "Offset X": _FLT, "Offset Y": _FLT,
                         "Offset Z": _FLT, "Spacing Mode": _MENU, "Shift": _INT, "Material": _MAT, "Use Material": _BOOL},

    # ⚠ Arc Start / Arc End restored from v0.65.0 — factors of a turn, 0..1, defaults 0 and 1
    # ⚠ Rings restored from v0.65.0 too (2026-08-06) — Count is PER RING and Rings multiplies
    # it, so the default 1 is the old single ring exactly. Appended last, never inserted.
    "MG_Cloner_Radial": {"Geometry": _GEO, "Source": _OBJ, "Sources": _COLL, "Clone Mode": _MENU, "Seed": _INT,
                         "Count": _INT, "Radius": _FLT,
                         "Arc Start": _FLT, "Arc End": _FLT, "Rings": _INT, "Shift": _INT, "Material": _MAT, "Use Material": _BOOL},
    # ⚠ ONE unified falloff for every shape — Rob: "Keep the falloffs unified." Field TYPE
    # is switched constantly while experimenting; swapping the group each time is the wrong
    # trade, and every shape feeds the same weight anyway.
    "MG_Falloff": {"Field": _OBJ, "Type": _INT, "Invert": _BOOL, "Bias": _FLT, "Seed": _INT,
                   "Width": _FLT, "Scale": _FLT, "Detail": _FLT,
                   "Progress": _FLT, "Spread": _FLT, "Ease": _INT, "Shape": _INT,
                   "Inner": _FLT, "Ease Bounces": _INT,
                   "Ease Direction": _INT, "Ease Exponent": _FLT,
                   "Ease Base": _FLT, "Ease Size": _FLT, "Ease Mirror": _BOOL,
                   # ⚠ Sequence reduces over the clones to find its own extent, which needs
                   # the geometry — no other falloff type reads it.
                   "Geometry": _GEO, "Axis": _INT},
    # ⚠ FRACTURE OUTPUTS INSTANCES, one per shard, each with a real transform — which is why
    # the whole effector and field stack works on shards with no special case. Rob's item 6
    # on the old build was that effectors did not work with Live Fracture.
    "MG_Fracture": {"Geometry": _GEO, "Pieces": _INT, "Seed": _INT, "Detail": _FLT,
                    "Scale Cells": _VEC, "Gap": _FLT},
    "MG_Pieces": {"Geometry": _GEO, "Gap": _FLT},
    "MG_Effector": {"Geometry": _GEO, "Offset": _VEC, "Rotation": _VEC,
                    "Scale": _VEC, "Strength": _FLT, "Type": _MENU, "Seed": _INT,
                    "Field": _OBJ, "Field Type": _INT, "Field Invert": _BOOL,
                    "Field Bias": _FLT, "Field Seed": _INT, "Field Width": _FLT,
                    "Field Scale": _FLT, "Field Detail": _FLT, "Field Shape": _INT,
                    # ⚠ named exactly "Progress" — Motionwerks cue discovery scans for a
                    # float input with that name; renaming it silently unbinds every cue.
                    "Progress": _FLT, "Spread": _FLT, "Ease": _INT,
                    "Field 2": _OBJ, "Blend 2": _MENU,
                    "Field 3": _OBJ, "Blend 3": _MENU,
                    "Field 4": _OBJ, "Blend 4": _MENU,
                    "Iterations": _INT, "Radius": _FLT, "Use Clone Size": _BOOL,
                    "Color A": _COL, "Color B": _COL,
                    "Uniform Scale": _BOOL},
}


class ContractError(RuntimeError):
    pass


# ⚠ A SUBTYPE IS A DISPLAY HINT, NOT A TYPE. Giving Progress `subtype='FACTOR'` — which is
# what makes it draw as a slider — turns its idname into NodeSocketFloatFactor, and a naive
# string compare rejected it. The contract is about what a socket CARRIES, so compare
# families: any NodeSocketFloat* is a float.
_FAMILIES = ('NodeSocketFloat', 'NodeSocketInt', 'NodeSocketVector')


def _family(idname):
    for f in _FAMILIES:
        if idname.startswith(f):
            return f
    return idname


def _inputs(ng):
    return {s.name: s.bl_socket_idname
            for s in ng.interface.items_tree if getattr(s, "in_out", "") == 'INPUT'}


def verify(ng, name):
    """Raise unless `ng` exposes every socket the addon addresses, with the right type."""
    want = CONTRACT.get(name)
    if want is None:
        return ng
    have = _inputs(ng)
    problems = []
    for sock, kind in want.items():
        got = have.get(sock)
        if got is None:
            problems.append("missing input %r" % sock)
        elif _family(got) != _family(kind):
            problems.append("input %r is %s, expected %s" % (sock, got, kind))
    if problems:
        raise ContractError("%s does not match its contract: %s" % (name, "; ".join(problems)))
    return ng


def build_hashes():
    """The per-group content hashes the shipped .blend was seeded with, or {} if absent.

    ⚠ WRITTEN BY THE SEEDER, never by hand — `mg_seed_nodegroups.py` emits it from
    `fingerprint()` straight after building, so it cannot drift from the .blend beside it.
    Missing file means "cannot tell", and the caller must then trust the sockets alone rather
    than refreshing everything on every load.
    """
    global _BUILD_CACHE
    if _BUILD_CACHE is _MISSING:
        import json
        try:
            with open(BUILD) as fh:
                _BUILD_CACHE = json.load(fh)
        except (OSError, ValueError):
            _BUILD_CACHE = {}
    return _BUILD_CACHE


_BUILD_CACHE = _MISSING


def stale():
    """Names of contract groups present in this file whose CONTENTS are out of date.

    ⚠ Only groups already in the file — never report a missing one as stale, or a scene that
    has nothing to do with Mographwerks would get the groups appended into it on open.
    """
    want = build_hashes()
    if not want:
        return []
    have = fingerprint()
    return [n for n in CONTRACT
            if n in bpy.data.node_groups and n in want and have.get(n) != want[n]]


def load(reload=False):
    """Append the groups, reusing any already in the file.

    ⚠ REUSE BY NAME, do not append blindly. Appending on every register would give
    MG_Effector.001, .002 … and modifiers would keep pointing at the original while the
    panel drove a copy — the same silent-divergence failure as a stale node group.
    ⚠ `reload=True` REFRESHES, it does not re-append. Appending every group and then looking
    them up by canonical name finds the OLD ones — the fresh copies land as `.001` with zero
    users and the caller is told everything is fine. Measured in Rob's file: MG_Effector.001
    sat there with the fix in it while the modifiers went on driving the 122-node original.
    """
    groups = {}
    missing = [n for n in CONTRACT if n not in bpy.data.node_groups]
    if missing:
        if not os.path.exists(BLEND):
            raise ContractError("nodegroups.blend not found next to %s" % __file__)
        with bpy.data.libraries.load(BLEND, link=False) as (src, dst):
            dst.node_groups = [n for n in src.node_groups if n in missing]
    outdated = set(CONTRACT) if reload else set(stale())
    for name in CONTRACT:
        ng = bpy.data.node_groups.get(name)
        if ng is None:
            raise ContractError("nodegroups.blend has no group called %r" % name)
        if name in outdated and name not in missing:
            # ⚠ SAME SOCKETS, DIFFERENT INSIDES. `verify()` cannot see this: it checks the
            # interface, and an internal rewiring leaves the interface untouched.
            groups[name] = verify(_refresh(name), name)
            continue
        try:
            groups[name] = verify(ng, name)
        except ContractError:
            # ⚠ A STALE GROUP ALREADY IN THE FILE. Appending only fills in what is MISSING,
            # so a .blend saved with an older version keeps its old group forever — the
            # panel then drives sockets that are not there and the addon looks broken. Pull
            # a fresh copy, hand every user over to it, and drop the old one.
            groups[name] = verify(_refresh(name), name)
    return groups


def reconcile():
    """Bring an already-open file's groups up to the shipped build. Returns what it replaced.

    ⚠ THE FILE-OPEN ENTRY POINT. `ensure()` only runs when an operator needs a group, so a
    file that is opened and rendered — never touched — would keep stale graphs for good.
    ⚠ DOES NOTHING IN A FILE THAT HAS NO MOGRAPHWERKS GROUPS. Opening an unrelated scene must
    not drag eleven node groups into it.
    """
    if not any(n in bpy.data.node_groups for n in CONTRACT):
        return []
    out = stale()
    for name in out:
        verify(_refresh(name), name)
    return out


def _dedupe_nested():
    """Collapse `MG_Foo.001` onto `MG_Foo`.

    ⚠ APPENDING A GROUP BRINGS ITS NESTED GROUPS WITH IT, every time. MG_Cloner_Grid contains
    MG_Instance, so re-appending the cloner adds a SECOND MG_Instance as `.001` and the fresh
    cloner points at that copy. Refresh a few times while iterating and a file ends up with
    MG_Instance.001 .. .010 — measured, in a real session — with different cloners pointing at
    different copies, so a change to MG_Instance reaches some of them and not others.
    ⚠ REMAP THE DUPLICATE ONTO THE CANONICAL ONE, never the other way round: the canonical
    name is what `load()` looks up, so the survivor has to be the one holding the plain name.
    """
    for g in list(bpy.data.node_groups):
        base, _, suffix = g.name.rpartition(".")
        if not base or not suffix.isdigit() or base not in CONTRACT:
            continue
        canon = bpy.data.node_groups.get(base)
        if canon is None or canon is g:
            continue
        g.user_remap(canon)
        if g.users == 0:
            bpy.data.node_groups.remove(g)


def _refresh(name):
    """Replace one stale group with a fresh copy from the .blend, carrying its users over."""
    old = bpy.data.node_groups.get(name)
    before = {g.name for g in bpy.data.node_groups}
    with bpy.data.libraries.load(BLEND, link=False) as (src, dst):
        dst.node_groups = [n for n in src.node_groups if n == name]
    fresh = next((g for g in bpy.data.node_groups
                  if g.name not in before and g.name.startswith(name)), None)
    if fresh is None:
        raise ContractError("could not re-append %r from nodegroups.blend" % name)
    if old is not None:
        # ⚠ remap BEFORE renaming, or the two fight over the same name and the modifiers
        # end up pointing at whichever won.
        old.user_remap(fresh)
        old.name = name + ".stale"
        if old.users == 0:
            bpy.data.node_groups.remove(old)
    fresh.name = name
    # ⚠ the append dragged in a copy of every group nested inside this one — fold them back
    # onto the originals, or they pile up one per refresh.
    _dedupe_nested()
    return fresh


def ensure():
    """The groups, appended on first use.

    ⚠ Every entry point that needs a node group calls this rather than assuming register()
    did it — see the note in `__init__.register()`. Cheap when they are already present: it
    is a name lookup per group.
    """
    return load()


@bpy.app.handlers.persistent
def _on_file_load(*a):
    """Replace stale graphs the moment an older file is opened.

    ⚠ `persistent`, or Blender drops it on the first file load and every file opened after
    that keeps its old groups — the same trap `fields._drop_index` documents.
    ⚠ NEVER let this raise. It runs inside Blender's file-load, where an exception aborts the
    rest of the load handlers; a group we cannot refresh is worth a console line, not a
    broken open.
    """
    try:
        replaced = reconcile()
    except Exception as exc:                                  # noqa: BLE001
        print("Mographwerks: could not refresh node groups on load: %s" % exc)
        return
    if replaced:
        print("Mographwerks: updated %d node group(s) from an older file: %s"
              % (len(replaced), ", ".join(replaced)))


def register():
    if _on_file_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_file_load)


def unregister():
    if _on_file_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_file_load)


def fingerprint():
    """Hash interface + nodes + links per group.

    ⚠ The regression guard that replaces a readable diff. A .blend edit that changes more
    than intended shows up here even though the change itself is opaque.
    """
    import hashlib
    import json
    out = {}
    for name in CONTRACT:
        ng = bpy.data.node_groups.get(name)
        if ng is None:
            continue
        blob = json.dumps({
            "iface": [(s.name, s.bl_socket_idname, getattr(s, "in_out", ""))
                      for s in ng.interface.items_tree],
            "nodes": sorted((n.name, n.bl_idname) for n in ng.nodes),
            "links": sorted((l.from_node.name, list(l.from_node.outputs).index(l.from_socket),
                             l.to_node.name, list(l.to_node.inputs).index(l.to_socket))
                            for l in ng.links),
        }, sort_keys=True)
        out[name] = hashlib.sha256(blob.encode()).hexdigest()[:16]
    return out


def generators():
    """Every generator group by mode key — cloners AND fractures.

    ⚠ A GENERATOR IS WHATEVER PUTS INSTANCES ON THE STACK. Effectors and fields work on the
    instance domain and do not care what made it, so a fracture gets the entire effector
    stack for free. Rob's item 6 on the old build was that effectors did NOT work with Live
    Fracture; here they do, because a shard is an instance like any clone.
    """
    out = dict(CLONER_MODES)
    out.update(FRACTURE_MODES)
    return out


def describe(mode):
    """The tooltip for a generator mode."""
    for m, _l, _i, desc in CLONER_ITEMS + FRACTURE_ITEMS:
        if m == mode:
            return desc
    return ""


# ⚠ THE FOUR FRACTURE METHODS. Grid and Voronoi are the same BAKE with the lattice on or off;
# Live and Pieces are generator MODES. They sit in one list because to the user they are four
# ways to break something, and the difference in machinery is ours to hide.
FRACTURE_METHODS = {
    'GRID': "Break on a regular lattice — brick, tile, blockwork. Bakes real cells, watertight",
    'VORONOI': "Break into irregular Voronoi cells. Bakes real geometry — exact piece count, "
               "watertight",
}


def describe_method(method):
    """The tooltip for a fracture method, whichever kind it is."""
    return FRACTURE_METHODS.get(method) or describe(method)


def item_of(mode):
    """(label, icon) for a generator mode — from the ONE table that also draws the add grid."""
    for m, label, icon, _d in CLONER_ITEMS + FRACTURE_ITEMS:
        if m == mode:
            return label, icon
    return (mode or "?").title(), 'BLANK1'


def family_items(mode):
    """The (mode, label, icon, description) rows of whichever family this mode belongs to."""
    return FRACTURE_ITEMS if mode in FRACTURE_MODES else CLONER_ITEMS


def family_of(mode):
    """CLONER_MODES or FRACTURE_MODES — whichever this mode belongs to."""
    return FRACTURE_MODES if mode in FRACTURE_MODES else CLONER_MODES


def swap_mode(mod, mode):
    """Change a cloner's mode by swapping its node group, keeping what still applies.

    ⚠ MODE IS STILL CHANGEABLE AFTER CREATION. Splitting one mode-switching group into six
    must not cost that — picking Grid and later wanting Radial is an ordinary thing to do.
    Values are carried by SOCKET NAME, so Source and any shared setting survive; anything
    the new mode has no socket for is dropped, which is correct rather than lossy.
    """
    from . import props
    name = generators().get(mode)
    if name is None:
        raise ContractError("no generator mode %r" % mode)
    target = bpy.data.node_groups.get(name)
    if target is None:
        target = load()[name]
    if mod.node_group is target:
        return mod
    keep = {}
    if mod.node_group is not None:
        for s in mod.node_group.interface.items_tree:
            if getattr(s, "in_out", "") == 'INPUT':
                v = props.get(mod, s.name, _MISSING)
                if v is not _MISSING:
                    keep[s.name] = v
    mod.node_group = target
    for sock, val in keep.items():
        props.set(mod, sock, val)
    return mod


def mode_of(mod):
    """Which mode this generator modifier is in, or None if it is not one."""
    if mod is None or mod.node_group is None:
        return None
    for mode, name in generators().items():
        if mod.node_group.name == name:
            return mode
    return None
