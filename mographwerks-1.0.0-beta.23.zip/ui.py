"""Panels. Four of them: Source · Distribute · Effectors · Remove.

⚠ THERE IS NO BUILD OR SEQUENCE PANEL and there must never be one again. Sequence became a
FIELD TYPE, which reproduced the old build exactly and collapsed a whole panel — and a whole
concept a C4D artist had no name for — into one entry in the falloff dropdown.
"""

import bpy

from . import cloner, effectors, fields, ng, props

# ⚠ ONE LIST, read by the panel to DRAW the settings and again to hand them to the button —
# two lists would be two places for a new setting to be forgotten, and a forgotten one is a
# control that visibly does nothing.
VORONOI_SETTINGS = ("pieces", "seed", "grid", "jitter", "cell_scale",
                    "margin", "interior_material", "animate")

# ⚠ WHAT EACH METHOD ACTUALLY NEEDS SET BEFORE IT RUNS. `grid` is not in either bake list —
# it is implied by which METHOD you picked, and drawing it as well would be two controls for
# one decision. Live and Pieces are modifiers: everything they have is adjustable afterwards.
METHOD_SETTINGS = {
    'GRID': ("pieces", "seed", "jitter", "cell_scale", "margin", "interior_material",
             "animate"),
    'VORONOI': ("pieces", "seed", "cell_scale", "margin", "interior_material", "animate"),
    'LIVE': (),
    'PIECES': (),
}

HINTS = {
    'LIVE': "Stays adjustable — its settings live on the modifier",
    'PIECES': "Uses the mesh's existing loose parts",
}


class _Panel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # ⚠ THE PLAIN NAME. The "2" existed only so this could sit beside v0.65.0 while the two
    # were compared; v0.65.0 was retired 2026-08-05 and the name came back with it.
    bl_category = "Mographwerks"


class MG_PT_main(_Panel, bpy.types.Panel):
    bl_label = "Mographwerks"
    bl_idname = "MG_PT_main"

    def draw(self, context):
        layout = self.layout
        car = cloner.active(context)
        if car is None:
            # ⚠ TWO FRONT DOORS, ONE PIPELINE. The tab picks WHAT YOU ARE MAKING; everything
            # below — Source, Distribute, Effectors — is identical either way, which is the
            # point and is worth the panel showing rather than explaining.
            layout.prop(context.scene, "mg_tab", expand=True)
            box = layout.box()
            if context.scene.mg_tab == 'CLONE':
                # ⚠ THE HEADING AND THE ICONS ARE v0.65.0's, kept deliberately: the grid
                # SHOWS the vocabulary instead of hiding it in a dropdown, and pressing
                # Radial GETS you a radial cloner rather than a grid to re-mode.
                box.label(text="Add a Cloner", icon='OUTLINER_OB_POINTCLOUD')
                grid = box.grid_flow(row_major=True, columns=2, even_columns=True,
                                     align=True)
                grid.scale_y = 1.2
                # ⚠ THE PICKER RE-AIMS THE SAME BUTTONS rather than adding a second set.
                # "Add a Cloner" already answers WHAT to make; the collection answers FROM
                # WHAT, and pressing Radial should get you a radial cloner either way.
                src = context.scene.mg_from_collection
                for mode, label, icon, _d in ng.CLONER_ITEMS:
                    op = grid.operator("mographwerks.add_cloner", text=label, icon=icon)
                    op.mode = mode
                    op.collection = src.name if src is not None else ""
                col = box.column()
                col.use_property_split = True
                col.prop(context.scene, "mg_from_collection", text="From Collection")
                # ⚠ SAY WHICH WAY THE BUTTONS ARE POINTING. The same grid does two different
                # things depending on this field, and a control whose meaning changes silently
                # is the kind of thing a tester reports as "it ignored my selection".
                note = box.row()
                note.enabled = False
                note.label(text=("Clones %s where it stands" % src.name) if src is not None
                           else "Clones the selected objects",
                           icon='INFO')
            else:
                box.label(text="Fracture", icon='MOD_EXPLODE')
                # ⚠ FOUR TABS, THEN ONE ACTION. The methods differ in what they need set
                # BEFORE they run — a bake cannot be adjusted afterwards — so choosing and
                # then acting is the honest shape. ANIMAX's, and it earns its place here.
                # ⚠ THE SAME TWO-UP GRID AS THE CLONER MODES. `expand=True` stacks four
                # items VERTICALLY in a sidebar, which is a list, not a set of tabs — and the
                # add screen already established two-up as the house shape.
                # ⚠ READING ORDER, NOT ENUM ORDER: the two BAKES on top, the two MODIFIERS
                # below. `prop_enum` draws one item at a time, so the layout is free to group
                # them by what they are rather than by how the enum happens to be declared.
                # ⚠ VORONOI LEADS because it is the DEFAULT and the general case — Grid is the
                # same bake constrained to a lattice, so it reads as the variant of the two.
                mgrid = box.grid_flow(row_major=True, columns=2, even_columns=True,
                                      align=True)
                mgrid.scale_y = 1.2
                for meth in ('VORONOI', 'GRID', 'LIVE', 'PIECES'):
                    mgrid.prop_enum(context.scene, "mg_fracture_method", meth)
                method = context.scene.mg_fracture_method
                s = context.scene.mg_voronoi
                col = box.column()
                col.use_property_split = True
                col.use_property_decorate = False
                for n in METHOD_SETTINGS[method]:
                    col.prop(s, n)
                # ⚠ THE TWO MODIFIER METHODS HAVE NOTHING TO SET BEFOREHAND, and saying so is
                # better than an empty gap that reads as a missing panel.
                if method in HINTS:
                    hint = box.column()
                    hint.enabled = False
                    hint.label(text=HINTS[method])
                row = box.row()
                row.scale_y = 1.4
                op = row.operator("mographwerks.fracture", text="Fracture", icon='MOD_EXPLODE')
            return
        layout.label(text=car.name)


class MG_PT_source(_Panel, bpy.types.Panel):
    bl_label = "Source"
    bl_parent_id = "MG_PT_main"
    bl_order = 0

    @classmethod
    def poll(cls, context):
        return cloner.active(context) is not None

    def draw(self, context):
        m = cloner.cloner_mod(cloner.active(context))
        if m is None:
            return
        col = self.layout.column()
        col.use_property_split = True
        # ⚠ OBJECT ABOVE COLLECTION, and both named for WHAT THEY ARE. They used to read
        # "Source" and "Sources" — one letter apart, in two different panels, which is not a
        # distinction anyone can see. Rob: "each should be named Object & Collection".
        # ⚠ BOTH ARE DRAWN NOW, deliberately reversing the earlier "one or the other, never
        # both" rule. The operators still only ever SET one — a cloner built from a single
        # object has no collection — but repointing an existing cloner is a real thing to want,
        # and a field that is simply absent cannot be repointed.
        for sock, label in (("Source", "Object"), ("Sources", "Collection")):
            h = props.holder(m, sock)
            if h is not None:
                col.prop(h, "value", text=label)

        # ⚠ ALWAYS DRAWN, unlike Clone Mode and Shift below — the override applies whether you
        # are cloning one object or a collection, so gating it on Sources would hide it in the
        # single-object case where it is just as useful.
        # ⚠ THE CHECKBOX IS NOT DECORATION. An unset Material socket does NOT mean "leave it
        # alone" — Set Material would assign nothing and strip the source's own material — and
        # Geometry Nodes cannot test a Material socket for null, so there is nothing to derive
        # the on/off state from. One row, checkbox then slot, so it reads as a single idea.
        # ⚠⚠ THE GUARD BELOW EXISTS BECAUSE A BETA TESTER LOST TIME TO IT: "I seem to be unable
        # to add a material or change materials once the cloner has been created. Or it doesn't
        # show when I do." Reproduced exactly. Two things combine:
        #   1. Hide Source EXCLUDES the source collection from the view layer, so the source is
        #      unselectable AND absent from the outliner — there is no way to click it.
        #   2. So you select the CLONER, the only thing you can click, and assign a material
        #      there — and NOTHING HAPPENS, silently, because the carrier's own mesh is not what
        #      renders. Measured: the clones come back `<no slots>`.
        # The material system is fine; it is reachability that fails. Say so, at the moment the
        # user is looking at the material row.
        car = cloner.active(context)

        # ⚠ DEEP NESTING HAS A ROUTE, AND IT IS NOT THIS ONE. Cloning a cloner through the
        # Object socket nests TWO levels; the third does not expand (measured: 11 positions
        # where a full 3x3x3 is 27). Through a COLLECTION it nests three deep perfectly, 27 of
        # 27. So this is a signpost to a working technique, not an error — and it appears only
        # at depth 3+, because depth 2 works and a hint there would be a nag.
        if cloner.object_chain_depth(car) >= 3:
            box = col.box().column(align=True)
            box.label(text="Three cloners deep via Object", icon='INFO')
            box.label(text="The third level will not expand.")
            box.label(text="Put the inner cloner in a collection")
            box.label(text="and use Collection — that nests fully.")

        slots = [s for s in getattr(car, "material_slots", []) if s.material]
        clones_self = props.get(m, "Source") is None and props.get(m, "Sources") is None
        if slots and not clones_self:
            box = col.box().column(align=True)
            box.label(text="Material on this object won't show", icon='ERROR')
            box.label(text="The clones come from the source, not from here.")
            box.label(text="Use the Material override below, or edit the source.")

        hu = props.holder(m, "Use Material")
        hm = props.holder(m, "Material")
        if hu is not None and hm is not None:
            row = col.row(align=True)
            row.prop(hu, "value", text="Material")
            sub = row.row(align=True)
            sub.enabled = bool(props.get(m, "Use Material"))
            sub.prop(hm, "value", text="")

        srcs = props.get(m, "Sources")
        if srcs is not None:
            h = props.holder(m, "Clone Mode")
            if h is not None:
                col.prop(h, "value", text="Clone Mode")
            # ⚠ Seed only means something where something is random. On the other two modes
            # it would be a control that does nothing.
            if props.get(m, "Clone Mode") == "Pick Random":
                h = props.holder(m, "Seed")
                if h is not None:
                    col.prop(h, "value", text="Seed")
            # ⚠ AND SHIFT ONLY MEANS SOMETHING FOR "Each Object" — same argument as Seed,
            # opposite mode. Whole Group has a single source to deal, and Pick Random already
            # answers "make this cloner differ from that one" with its own Seed. Drawing it on
            # all three would be two dead controls out of three.
            elif props.get(m, "Clone Mode") == "Each Object":
                h = props.holder(m, "Shift")
                if h is not None:
                    col.prop(h, "value", text="Shift")
            # ⚠ THE TOGGLE DRIVES `exclude`, which is not a property we can draw directly —
            # it lives on the LayerCollection, one per view layer. So it is an operator.
            lcs = cloner._layer_collections(srcs.name)
            row = col.row()
            row.operator("mographwerks.toggle_hide_source",
                         text="Show Source" if (lcs and lcs[0].exclude) else "Hide Source",
                         icon='HIDE_ON' if (lcs and lcs[0].exclude) else 'HIDE_OFF')


class MG_PT_distribute(_Panel, bpy.types.Panel):
    bl_label = "Distribute"
    bl_parent_id = "MG_PT_main"
    bl_order = 1

    @classmethod
    def poll(cls, context):
        return cloner.active(context) is not None

    def draw(self, context):
        m = cloner.cloner_mod(cloner.active(context))
        if m is None:
            return
        layout = self.layout
        mode = ng.mode_of(m)
        # ⚠ A DROPDOWN, NOT A ROW OF BUTTONS. Six modes across a sidebar truncates — Rob's
        # screenshot shows "Hone..." — and a truncated label is not a label. The ADD screen
        # keeps its grid because there the point is to SHOW the vocabulary; here you already
        # know which one you picked and only occasionally change it.
        label, icon = ng.item_of(mode)
        layout.menu("MG_MT_mode", text=label, icon=icon)
        col = layout.column()
        col.use_property_split = True
        # ⚠ draw whatever THIS mode has, by name — the modes deliberately do not share a
        # socket set, and hardcoding a list here would silently drop a mode's own controls.
        # ⚠ THE SOURCE SOCKETS BELONG TO THE SOURCE PANEL, not here. This loop draws whatever
        # the mode exposes, and the source set is on every mode — so without this skip the
        # same Collection, Clone Mode and Seed appear in two panels at once, which is exactly
        # what put "Sources" up here and "Source" at the bottom of the tab.
        for s in m.node_group.interface.items_tree:
            # ⚠ "Shift" JOINS THE SKIP SET. It lives on every mode's interface because every
            # mode instances, but it is a SOURCE control — without this it draws here as well
            # as in Source, which is exactly the double-draw this skip set exists to stop.
            if (getattr(s, "in_out", "") != 'INPUT'
                    or s.name in {"Geometry", "Source", "Sources", "Clone Mode", "Seed",
                                  "Shift", "Material"}):
                continue
            h = props.holder(m, s.name)
            if h is not None and hasattr(h, "value"):
                col.prop(h, "value", text=s.name)


class MG_MT_add(bpy.types.Menu):
    """The Shift+A doorway.

    ⚠ A MoGraph ARTIST REACHES FOR ADD, not a sidebar tab. v0.65.0 called this "the C4D
    doorway" and it is the same argument: the vocabulary should be where the muscle memory is.
    ⚠ ONE SHARED TABLE with the panel, so the two can never drift — v0.65.0 hand-listed the
    fracture entries in both surfaces and they promptly disagreed, with Live Fracture in the
    panel and not in the menu.
    """

    bl_idname = "MG_MT_add"
    bl_label = "Mographwerks"

    def draw(self, context):
        layout = self.layout
        for mode, label, icon, _d in ng.CLONER_ITEMS:
            layout.operator("mographwerks.add_cloner", text=label, icon=icon).mode = mode
        layout.separator()
        # ⚠ THE BAKES NAME THEIR METHOD; the two modifier fractures are generator modes.
        for meth, label, icon in (('VORONOI', "Voronoi Fracture", 'MOD_REMESH'),
                                  ('GRID', "Grid Fracture", 'MESH_GRID')):
            layout.operator("mographwerks.fracture", text=label, icon=icon).method = meth
        for mode, label, icon, _d in ng.FRACTURE_ITEMS:
            layout.operator("mographwerks.add_cloner",
                            text="%s Fracture" % label, icon=icon).mode = mode


def _add_menu(self, context):
    self.layout.menu("MG_MT_add", icon='OUTLINER_OB_POINTCLOUD')


class MG_MT_mode(bpy.types.Menu):
    """The generator's own family of modes.

    ⚠ ONLY THE FAMILY IT BELONGS TO. Offering Grid beside Live Fracture would imply they are
    interchangeable; swapping one for the other drops every socket the new group does not
    share — which between those two is all of them.
    ⚠ A MENU RATHER THAN `operator_menu_enum`, because that draws EVERY item of the operator's
    enum and the operator has to accept all eight modes. Filtering is the whole job here.
    """

    bl_idname = "MG_MT_mode"
    bl_label = "Mode"

    def draw(self, context):
        m = cloner.cloner_mod(cloner.active(context))
        current = ng.mode_of(m)
        for mode, label, icon, _d in ng.family_items(current):
            op = self.layout.operator("mographwerks.set_mode", text=label, icon=icon)
            op.mode = mode


def _ease_params(col, fobj, curve):
    """The curve parameters that this curve actually uses.

    ⚠ THE SET IS MoTools' EASE FALLOFF, MEASURED FROM IT: Exponent, Base, Size, Bounces,
    Mirror. Rob: "We should mirror the settings from the Ease node with the Penner settings,
    disregard our previous settings." Amplitude and Decay belonged to the damped-sine model
    that these curves replaced and no longer exist.
    ⚠ DRAWN PER CURVE from ng's measured tables, so a slider never appears where it does
    nothing — Size on Sine moved nothing at all, which is exactly what a dead control is.
    """
    # ⚠ CUSTOM TAKES NO PENNER PARAMETERS — the curve IS the parameter. Drawing Exponent or
    # Bounces beside it would be four controls that do nothing.
    # ⚠ NOT IN THE PROPERTY-SPLIT COLUMN: the curve widget is a fixed-size box and the split
    # squeezes it into the value column, which makes it unusably narrow in a sidebar.
    if curve == 'CUSTOM':
        node = fields.curve_node(fobj, create=True)
        if node is not None:
            box = col.box()
            box.use_property_split = False
            # ⚠ `show_presets` gives Blender's own curve presets in the widget's header, so a
            # freehand curve has somewhere to start from instead of a bare diagonal.
            box.template_curve_mapping(node, "mapping", show_presets=True)
        return
    if curve in ng.USES_EXP:
        col.prop(fobj, "mg_field_exp")
    if curve in ng.USES_BASE:
        col.prop(fobj, "mg_field_base")
    if curve in ng.USES_SIZE:
        col.prop(fobj, "mg_field_size")
    if curve in ng.USES_BOUNCES:
        col.prop(fobj, "mg_field_freq")
    col.prop(fobj, "mg_field_mirror")


def _draw_field_row(box, mod, index, slot, blend, fobj, linked=False):
    """⚠ `linked` greys only what a follower cannot usefully change: WHICH field sits in the
    slot, and the blend mode — both are mirrored from the master and an edit would snap back.
    The field's OWN properties stay editable, because the field OBJECT is shared and editing
    it is meant to affect every effector using it. Progress stays editable too; it is
    deliberately not part of the link."""
    rb = box.box()
    row = rb.row(align=True)
    row.enabled = not linked
    # ⚠⚠ AN OBJECT PICKER, NOT A RENAME BOX. A field is an OBJECT, so pointing a second
    # effector at an existing one has always been possible — and the panel had no way to do it,
    # because this drew the field's NAME. Rob, with a Plain and a Color effector: "How do I
    # have the field drive both? Can this be done in the UI?" The answer was "only in the
    # modifier properties", which means the capability may as well not have existed.
    # ⚠ The picker shows the field's name AND lets you swap it, so nothing is lost but the
    # in-place rename — which the outliner still does, and which is far rarer than sharing.
    slot_h = props.holder(mod, slot)
    if slot_h is not None:
        row.prop(slot_h, "value", text="")
    else:
        row.prop(fobj, "name", text="")
    if blend is not None:
        h = props.holder(mod, blend)
        if h is not None:
            row.prop(h, "value", text="")
    # ⚠ ON THE ROW, beside the field it acts on — one field can be re-fitted without touching
    # the others, and a panel-level button could not say WHICH.
    op = row.operator("mographwerks.fit_field", text="", icon='SHADING_BBOX')
    op.mod_name = mod.name
    op.index = index
    op = row.operator("mographwerks.remove_field", text="", icon='X')
    op.mod_name = mod.name
    op.index = index
    col = rb.column()
    col.use_property_split = True
    col.prop(fobj, "mg_field_type", text="Falloff")
    ftype = fobj.mg_field_type
    if ftype == 'SEQUENCE':
        # ⚠ Progress lives on the EFFECTOR, not the field — one clock per effector, so two
        # Sequence fields on one stack cannot disagree about what time it is.
        h = props.holder(mod, "Progress")
        if h is not None:
            col.prop(h, "value", text="Progress", slider=True)
        # ⚠ AXIS REPLACES AIMING THE GIZMO. Sequence has no falloff and does not read its
        # own transform, so this dropdown is the only thing that sets the build direction.
        col.prop(fobj, "mg_field_axis")
        col.prop(fobj, "mg_field_spread")
        col.prop(fobj, "mg_field_ease")
        col.prop(fobj, "mg_field_dir")
        _ease_params(col, fobj, fobj.mg_field_ease)
    else:
        # ⚠ Invert is deliberately absent for Sequence: it would flip the ramp before the
        # timing maths and run the build backwards. Direction comes from rotating the gizmo.
        col.prop(fobj, "mg_field_invert")
        # ⚠ Inner only means something where u is a distance from a centre or along a
        # sweep. RING measures distance from its BAND and RADIAL measures an ANGLE, so a
        # nested inner shape says nothing there; Random and the textures have no centre at
        # all. Drawing it for those would be a control that does nothing.
        if ftype in {'SPHERE', 'BOX', 'LINEAR'}:
            col.prop(fobj, "mg_field_inner")
        # ⚠ Shape curves the RAMP, so it means nothing for types with no ramp — Random and
        # the textures read a value per clone rather than falling off across a distance.
        if ftype not in {'RANDOM', 'VORONOI', 'WAVES', 'NOISE'}:
            col.prop(fobj, "mg_field_shape")
            # ⚠ SHAPE AND EASE ARE THE SAME CURVE SET on two different inputs — Ease reads
            # time on a Sequence, Shape reads distance across the falloff — so they take the
            # same parameters and draw through the same helper. Direction is one of them:
            # leaving it off here left In/Out/InOut silently stuck on the stamped default.
            col.prop(fobj, "mg_field_dir")
            _ease_params(col, fobj, fobj.mg_field_shape)
        col.prop(fobj, "mg_field_bias")
        if ftype == 'RING':
            col.prop(fobj, "mg_field_width")
        if ftype in {'RANDOM', 'VORONOI', 'NOISE'}:
            col.prop(fobj, "mg_field_seed")
        if ftype in {'VORONOI', 'WAVES', 'NOISE'}:
            col.prop(fobj, "mg_field_scale")
        if ftype == 'NOISE':
            col.prop(fobj, "mg_field_detail")


class MG_PT_effectors(_Panel, bpy.types.Panel):
    bl_label = "Effectors"
    bl_parent_id = "MG_PT_main"
    bl_order = 2

    @classmethod
    def poll(cls, context):
        return cloner.active(context) is not None

    def draw(self, context):
        layout = self.layout
        car = cloner.active(context)
        layout.operator_menu_enum("mographwerks.add_effector", "eff_type",
                                  text="Add Effector", icon='ADD')
        effs = effectors.stack(car)
        if not effs:
            r = layout.row()
            r.enabled = False
            r.label(text="No effectors — nothing will move", icon='INFO')
            return
        for mod in effs:
            box = layout.box()
            hdr = box.row(align=True)
            hdr.prop(mod, "show_expanded", text="", emboss=False)
            # ⚠ EMBOSSED. Drawn flat this reads as a label and the name cannot be edited —
            # Rob: "I'm clicking on the Effector name in the N panel and I can't rename it".
            # ⚠ BLENDER'S OWN MODIFIER HEADER ORDER: expand, icon, name, viewport, render,
            # reorder, delete. Matching it is the whole point — a stack that reads like the
            # modifier stack needs no explaining, and every Blender user already knows which
            # icon does what.
            hdr.label(text="", icon=ng.EFFECTOR_ICONS.get(props.get(mod, "Type"), 'BLANK1'))
            hdr.prop(mod, "name", text="")
            sub = hdr.row(align=True)
            # ⚠ THE RENDER TOGGLE, which we never exposed: muting an effector in renders while
            # keeping it in the viewport is a real thing to want, and Blender draws the right
            # monitor/camera icons for these two on its own when the text is blank.
            sub.prop(mod, "show_viewport", text="")
            sub.prop(mod, "show_render", text="")
            op = sub.operator("mographwerks.move_effector", text="", icon='TRIA_UP')
            op.mod_name = mod.name
            op.dir = -1
            op = sub.operator("mographwerks.move_effector", text="", icon='TRIA_DOWN')
            op.mod_name = mod.name
            op.dir = 1
            sub.operator("mographwerks.remove_effector", text="",
                         icon='X').mod_name = mod.name
            if not mod.show_expanded:
                continue

            # ⚠ SAY WHAT IS DRIVING THIS, and grey what the user cannot usefully edit. A
            # driven field looks perfectly editable and silently snaps back, which is the
            # drawn-but-inert defect in a new costume.
            mobj, mmod = effectors.link_master(mod)
            linked = mmod is not None
            if not linked:
                # ⚠ OFFERED ONLY WHEN IT CAN WORK. Sharing needs other selected cloners, and a
                # button that reports "select some cloners" every time is the Add-Another
                # mistake again — drawn in a state where it cannot do its job.
                others = [o for o in context.selected_objects
                          if o is not car and cloner.cloner_mod(o) is not None]
                if others:
                    r = box.row(align=True)
                    r.operator("mographwerks.link_effector",
                               text="Share with %d selected" % len(others),
                               icon='LINKED').mod_name = mod.name
            if linked:
                r = box.row(align=True)
                r.label(text="Follows %s" % mobj.name, icon='LINKED')
                r.operator("mographwerks.unlink_effector", text="Unlink",
                           icon='UNLINKED').mod_name = mod.name
                note = box.row()
                note.enabled = False
                # ⚠ Progress is deliberately NOT linked, and that is worth saying HERE rather
                # than in a manual — it is the reason a cue can still drive this cloner alone.
                note.label(text="Progress stays local, so cues still work per cloner")

            col = box.column()
            col.use_property_split = True
            # ⚠ the whole detail block is read-only on a follower — the master owns the values
            col.enabled = not linked
            for nm in ("Type",):
                h = props.holder(mod, nm)
                if h is not None:
                    col.prop(h, "value", text=nm)
            # ⚠ Seed only means something for Random — the others do not roll anything, so
            # drawing it there would be a control that does nothing.
            if props.get(mod, "Type") == "Random":
                h = props.holder(mod, "Seed")
                if h is not None:
                    col.prop(h, "value", text="Seed")
            # ⚠ PUSH APART DRAWS A DIFFERENT SET. It computes its own offset from the
            # neighbours, so the typed Offset means nothing to it, and it deliberately does
            # not rotate or scale — the node group forces both to identity so that hiding
            # them here does not leave a control secretly still applying.
            # ⚠ COLOR DRAWS NEITHER OFFSET, ROTATION NOR SCALE. Its per-clone amount is a
            # zero vector in the node group, so all three are silenced at the source — drawing
            # them would be three controls that do nothing, which is this codebase's oldest
            # recurring defect.
            if props.get(mod, "Type") == ng.COLOR:
                # ⚠ NO STRENGTH. It multiplies the field factor, which is meaningful for
                # MOTION and actively misleading for a colour lookup — at 2.32 the ramp
                # saturated at 43% of the field and read as broken. The colour branch reads
                # the field directly now, so Strength would be a control that does nothing.
                rows = ("Color A", "Color B")
            elif props.get(mod, "Type") == ng.PUSH_APART:
                rows = ("Radius", "Use Clone Size", "Iterations", "Strength")
            else:
                rows = ("Offset", "Rotation", "Scale", "Strength")
            for nm in rows:
                h = props.holder(mod, nm)
                if h is not None:
                    col.prop(h, "value", text=nm)
                # ⚠ IMMEDIATELY UNDER SCALE, because that is the only thing it changes. It
                # first sat up by Seed, three controls away from what it modifies — the same
                # mistake as a keyframe diamond that is not beside its own button.
                # ⚠ RANDOM ONLY: Plain and Step already produce an amount whose components
                # are equal, so drawing it there would be a control that does nothing.
                if nm == "Scale" and props.get(mod, "Type") == "Random":
                    uh = props.holder(mod, "Uniform Scale")
                    if uh is not None:
                        col.prop(uh, "value", text="Uniform Scale")
            # ⚠ TELL THEM THE ATTRIBUTE NAME AND THE NODE TYPE. A Color effector does nothing
            # visible on its own — the material has to read what it writes — and an Attribute
            # node set to Geometry instead of Instancer renders flat with no error at all.
            # That is a support question waiting to happen, so the panel answers it in place.
            if props.get(mod, "Type") == ng.COLOR:
                # ⚠⚠ THE FEATURE IS INERT UNTIL THE MATERIAL READS IT, and the attribute is
                # invisible everywhere an artist would look for it — it lives on the EVALUATED
                # instance domain, so it never appears under Object Data Properties.
                # Rob, having added a Color effector: "Where is the color attribute?"
                # A name in a hint was not enough; this does the wiring.
                # ⚠ STACKED, NOT SIDE BY SIDE. Two labelled buttons sharing a row truncate at
                # the sidebar widths people actually work at — Rob's read "Set Up Material"
                # and "…with Ramp" clipped. A full-width column cannot clip whatever the
                # panel width, and it is still fewer rows than the hint it replaces.
                bcol = box.column(align=True)
                bcol.scale_y = 1.2
                op = bcol.operator("mographwerks.setup_color_material",
                                   text="Set Up Material", icon='NODE_MATERIAL')
                op.mod_name = mod.name
                op.style = 'COLOR'
                # ⚠ THE RAMP LIVES IN THE MATERIAL, not here. A ColorRamp is node STATE and
                # MG_Effector is one shared group, so a ramp on the effector would be one ramp
                # for the whole scene — the same wall the falloff curve hit. Blender's own ramp
                # gives unlimited stops and its presets for free.
                op = bcol.operator("mographwerks.setup_color_material",
                                   text="Set Up with Ramp", icon='COLOR')
                op.mod_name = mod.name
                op.style = 'RAMP'
                # ⚠ ONE LINE, and the wordy version lives in the buttons' TOOLTIPS where a
                # long explanation belongs. Three greyed lines of prose under two buttons that
                # already do the wiring is a wall of text charging rent on every redraw.
                hint = box.row()
                hint.enabled = False
                hint.label(text='Instancer attribute "%s"' % ng.COLOR_ATTR, icon='INFO')

            fbox = box.box()
            rws = effectors.rows(mod)
            filled = [r for r in rws if r[2] is not None]
            hdr = fbox.row(align=True)
            # ⚠ a follower cannot add a field — the master's set is mirrored over it
            hdr.enabled = len(filled) < len(rws) and not linked
            # ⚠ the target is set on the ROW, so it is scoped to this button and resolved
            # when the menu opens — not stashed during draw, where the last panel wins.
            hdr.context_pointer_set("mg_field_stack", mod)
            hdr.menu("MG_MT_add_field", text="Add Field", icon='ADD')
            if not filled:
                r = fbox.row()
                r.enabled = False
                r.label(text="No fields — applies everywhere", icon='INFO')
            for i, (slot, blend, fobj) in enumerate(rws):
                if fobj is not None:
                    _draw_field_row(fbox, mod, i, slot, blend, fobj, linked)


class MG_PT_remove(_Panel, bpy.types.Panel):
    """Just a button.

    ⚠ NO HEADER. Rob: "Remove Cloner doesn't need to be in a header. Can just be a button."
    `HIDE_HEADER` keeps it a panel — so it still sorts last under the parent — while drawing
    nothing but its contents. A plain button in the PARENT's draw would appear ABOVE every
    department, because Blender draws child panels after the parent's own content, and a
    destructive action at the top of the panel is the wrong place for it.
    """

    bl_label = ""
    bl_parent_id = "MG_PT_main"
    bl_options = {'HIDE_HEADER'}
    bl_order = 4

    @classmethod
    def poll(cls, context):
        return cloner.active(context) is not None

    def draw(self, context):
        row = self.layout.row()
        row.scale_y = 1.2
        row.operator("mographwerks.remove_cloner", text="Remove Cloner", icon='TRASH')


CLASSES = (MG_MT_add, MG_MT_mode, MG_PT_main, MG_PT_source, MG_PT_distribute, MG_PT_effectors,
           MG_PT_remove)


# ⚠⚠ SNAPSHOT THE PANEL INTENT AT IMPORT, while the classes are fresh from source. Blender
# writes `bl_*` back onto the Python class during (un)register, so repeated reload cycles leave
# STALE values that silently override this file — every `bl_order` comes back 0 and Blender
# then sorts tied sub-panels ALPHABETICALLY. That is how Source (order 0) ended up drawn last.
# ⚠ This is Werkbench's fix, ported. It was written there in v2.4.1 and noted as "worth porting
# to Motionwerks and Mographwerks"; the note was never acted on, which is why Werkbench healed
# itself after a restart and this did not.
_PANEL_INTENT = {c.__name__: (c.__dict__.get("bl_category", _Panel.bl_category),
                              c.__dict__.get("bl_order"))
                 for c in CLASSES if issubclass(c, bpy.types.Panel)}


def register():
    for c in CLASSES:
        intent = _PANEL_INTENT.get(c.__name__)
        if intent is not None:
            c.bl_category = intent[0]
            if intent[1] is not None:
                c.bl_order = intent[1]
        bpy.utils.register_class(c)
    bpy.types.VIEW3D_MT_add.append(_add_menu)


def unregister():
    # ⚠ REMOVE THE APPEND FIRST, and guard it: a reload that leaves the draw function on
    # VIEW3D_MT_add pointing at an unregistered menu makes Shift+A raise for the whole scene,
    # not just for us.
    try:
        bpy.types.VIEW3D_MT_add.remove(_add_menu)
    except Exception:
        pass
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
