# Sketchy Lines

**Realtime, hand-drawn line art for Blender — built for archviz, stable under camera motion.**

Sketchy Lines turns the feature edges of your models into wobbly, textured, hand-drawn
strokes (pencil, charcoal, ink, and more) using a single Geometry Nodes system. It was
built to replace Cinema 4D's Sketch & Toon workflow and to fix the problems that make
Blender's Grease Pencil Line Art and Freestyle painful for animation:

- **No jitter, no popping.** The wobble and texture are keyed to *world-space* geometry,
  never to the camera or screen, so lines can't swim or crawl as the camera moves.
- **No baking, no separate overlay.** Strokes are real mesh ribbons that render — and
  anti-alias — natively in **EEVEE and Cycles**, identical in the viewport and the final
  frame.
- **Realtime.** Everything updates live as you move objects, tweak sliders, or scrub the
  timeline.

Version **1.4.0** · Blender **4.2+** (developed and tested on 5.1) · EEVEE + Cycles.

---

## Installation

1. In Blender: **Edit → Preferences → Add-ons → Install…**
2. Select `sketchy_lines.zip`.
3. Enable **"Sketchy Lines"**.
4. Open the **N-panel** in the 3D viewport (press `N`) and go to the **Sketchy** tab.

Updating from an older version? Reinstall the zip, then click the **🔄 Update Node Group**
button in the Sketchy panel header — it rebuilds the node group from the new code while
keeping every line set's settings, materials and keyframes.

---

## Quick start

1. Put the objects you want outlined in a **collection**.
2. In the Sketchy tab, pick that collection, then press **+** to create a line set.
3. Choose a look from the **Style Preset** dropdown (e.g. *HB Pencil* or *Charcoal*).
4. Adjust **Width** and **Color**, then open any section below to refine.

A line set is a self-contained object (kept in a "Sketchy Lines" collection) with its own
modifier and material. Add several line sets to give different collections different styles
in the same scene — the list at the top switches between them and the panel follows.

---

## Marking edges

By default, drawn edges are auto-detected (see **Edges**). To force specific edges in or
out, enter **Edit Mode** on a source mesh, select edges, and use the buttons in the panel:

- **Mark Line / Clear** — force the selected edges to always draw.
- **Mark Hide / Clear** — remove the selected edges from the line art.

These are stored as mesh attributes, so they persist in the .blend and survive edits.

---

## The controls

The top of the panel holds the essentials; everything else is a collapsible section (also
mirrored as panels in the modifier's Properties tab). On/off sections are boxed — the
checkbox is the box header, and its controls appear when it's on.

### Line
- **Collection** — which collection's meshes get drawn.
- **Width (mm)** — stroke width in real millimetres (world-space, reads thinner with
  distance like a real pen).
- **Color** — the visible line colour.
- **Style Preset · +  · ↺** — pick a media preset from the menu, **+** saves the current
  look as your own, **↺** resets the look sliders to their defaults.

### Wobble — the hand-drawn wander
- **Amount (mm)** — how far lines stray from the true edge.
- **Size (cm)** — wavelength of the main wobble (smaller = tighter scribble).
- **Complexity** — octaves of finer wiggle (0 = smooth, 8 = scratchy).
- **Strokes** — how many times each line is over-drawn, offset slightly (hand overdraw).
- **Seed** — reshuffles all randomisation.
- **Boil Rate** — re-draws per second for a "boiling line" (0 = static, 8–12 = classic boil).

### Overshoot — pen running past the join
- **Enable** — master switch. Off, the whole overshoot branch is skipped (nothing to pay
  for on dense meshes) while your values stay dialed in.
- **Overshoot (mm)** — extend each line past its corners. **Negative** values *undershoot*.
- **Random (mm)** — vary each line end so some run long and some fall short.

### Breakup — media texture
- **Opacity / Size** — fades and full gaps along the stroke (dry-media skipping).
- **Thickness / Size** — width variation, like pencil pressure.
- **Grain / Size** — per-pixel paper tooth that chews in from the stroke edges (charcoal).
  Above 1 the bite reaches past the stroke core for dry, broken lines.

### Dashes
- **Dash (cm) / Gap (cm)** — dashed lines, cut in world arc-length so they don't crawl.

### Smudge — soft shading
Re-shades the source surfaces with grainy tone rubbed toward the forms — like a thumb
dragging graphite. Composes with the lines and stays realtime.
- **Enable / Strength** — turn it on and set its darkness (0–2).
- **Reach (cm)** — how far the tone bleeds in from form edges.
- **Grain (cm)** — tooth size (small = fine powder, large = rough charcoal).
- **Color** — the smudge tone.
- **Cavity (AO)** — *optional* true ambient-occlusion darkening. **In EEVEE this needs
  Raytracing enabled.** The base facing tone works without.

### Hidden Lines — occlusion
Occlusion always runs (camera raycast). This section styles the occluded lines:
- **Show Hidden Lines** — draw hidden lines in their own style instead of removing them,
  revealing Opacity / Color / Width Scale / Dash / Gap.
- **Bias (mm)** — how far short of a surface the visibility ray stops (raise it above
  Wobble Amount if lines flicker on the surfaces they lie on).
- **Occlude Against** — a collection this set *also* hides behind, on top of its own
  geometry (see below).

### Multiple objects that occlude each other
Split your model into several line sets (one per object/collection) for **independent
draw-on timing** — each has its own keyframeable `Draw Amount`. By default a set only
occludes against its own collection. To make separate sets hide each other, give them a
**shared occluder**:

1. Keep all source objects under **one parent collection** (nested children are included).
2. Set **Occlude Against** (the field under the line-set list) to that parent collection.
3. New line sets adopt it automatically; the **🔄 button** re-applies it to every set.

Keep the generated "Sketchy Lines" objects *out* of that occluder collection.

### Heavy scenes: the proxy occluder
The occlusion raycast scales with the occluder's polygon count, so on dense/high-poly
scenes it can dominate. The **decimate button** (next to *Occlude Against*) builds a
low-poly stand-in and points every line set at it:

1. Set **Occlude Against** to your real source geometry (a parent collection).
2. Press **Build Proxy Occluder** and choose a **Detail** ratio (0.1 = 10× lighter). A
   *Sketchy Occluder Proxy* collection is created and all line sets are re-pointed at it.

The proxy meshes **share your source data** (so they follow edits), carry a Decimate
modifier, **follow the originals** live via a constraint, and are **invisible to the
camera** (shown only as bounds in the viewport) — they never render, they just make the
raycast cheap. Re-run any time to refresh; it remembers its source, so it never proxies
the proxy. To go back to the full-resolution geometry, repick it in *Occlude Against* and
press the 🔄 button.

### Edges — what gets drawn
- **Angle** — draw edges whose face angle exceeds this threshold.
- **Sharp Edges / Boundaries / Freestyle Marks** — also include these edge types.

### Draw-On Animation — build-on reveal
Lines draw themselves on over time, like a hand sketching the scene.
- **Draw On** — enable the reveal, showing Amount / Stagger / Easing.
- **Amount** — 0 = blank, 1 = complete. **Keyframe this** to animate.
- **Stagger** — 0 = all lines draw at once; 1 = one after another (order shuffled by Seed).
- **Easing** — Linear / Ease In / Ease Out / Ease In-Out applied to Amount.

---

## Style presets

The **Style Preset** menu carries 20 media looks — Pencil (2H, HB, 6B, Colored), Charcoal
& Chalk, Pen (Technical, Fineliner, Ballpoint, Fountain), Ink & Brush, Wax & Pastel, and
Stylized (Architect Sepia, Blueprint, Boiling Sketch). Presets set the *look* only; they
never touch edge selection or occlusion.

**Save your own:** tune a line set, press **+** next to the preset menu, and name it. User
presets are JSON files in your Blender scripts folder (`presets/sketchy_lineart/`), so they
persist across sessions and .blends. A "User" section with a delete submenu appears in the
menu.

---

## Tips & notes

- **Line weight is world-space.** A 6 mm line looks bold up close and thin far away.
- **Smudge Cavity needs EEVEE Raytracing** (Render Properties → Raytracing).
- **Overshoot doubles stroke geometry while on** — switch its **Enable** off for heavy shots.
- **On big scenes, build a proxy occluder** — it's the biggest single win for keeping the
  occlusion raycast realtime.
- **Draw-On is keyframeable** — keyframe **Amount** for full easing control.
- **After updating the add-on**, click the **🔄 Update Node Group** button — it rebuilds
  the node group while keeping every setting, material and keyframe.

---

## How it works (the short version)

- **World-locked wobble.** Displacement noise is sampled from each point's stored world
  position, not from view or screen space — this eliminates the swimming/jitter.
- **Real geometry.** Strokes are `Curve → Mesh` ribbons; anti-aliasing is ordinary render
  sampling, identical in EEVEE and Cycles.
- **Occlusion by raycast.** Each point casts toward the active camera; occluded points are
  hidden, or (with *Show Hidden Lines*) slid along their view ray to render on top.
- **Grain in the shader.** Paper tooth is per-pixel world-position noise choking in from
  the stroke's silhouette, so it can be far finer than the mesh.

---

*Sketchy Lines · v1.4.0 · by Rob Travis*
