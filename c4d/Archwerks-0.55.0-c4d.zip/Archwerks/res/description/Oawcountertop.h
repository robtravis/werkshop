#ifndef OAWCOUNTERTOP_H__
#define OAWCOUNTERTOP_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawcountertop_DUMMY = 0,
};

#endif // OAWCOUNTERTOP_H__
