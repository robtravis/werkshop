#ifndef OAWSTAIR_H__
#define OAWSTAIR_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawstair_DUMMY = 0,
};

#endif // OAWSTAIR_H__
