#ifndef OAWDOOR_H__
#define OAWDOOR_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawdoor_DUMMY = 0,
};

#endif // OAWDOOR_H__
