#ifndef OAWBEAM_H__
#define OAWBEAM_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawbeam_DUMMY = 0,
};

#endif // OAWBEAM_H__
