#ifndef OAWCUTTER_H__
#define OAWCUTTER_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawcutter_DUMMY = 0,
};

#endif // OAWCUTTER_H__
