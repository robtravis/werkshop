#ifndef OAWPANELS_H__
#define OAWPANELS_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawpanels_DUMMY = 0,
};

#endif // OAWPANELS_H__
