#ifndef OAWCABINET_H__
#define OAWCABINET_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawcabinet_DUMMY = 0,
};

#endif // OAWCABINET_H__
