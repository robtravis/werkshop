#ifndef OAWCEILING_H__
#define OAWCEILING_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawceiling_DUMMY = 0,
};

#endif // OAWCEILING_H__
