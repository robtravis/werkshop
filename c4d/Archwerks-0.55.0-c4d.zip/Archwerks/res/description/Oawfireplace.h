#ifndef OAWFIREPLACE_H__
#define OAWFIREPLACE_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawfireplace_DUMMY = 0,
};

#endif // OAWFIREPLACE_H__
