#ifndef OAWRAILING_H__
#define OAWRAILING_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawrailing_DUMMY = 0,
};

#endif // OAWRAILING_H__
