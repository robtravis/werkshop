#ifndef OAWSINK_H__
#define OAWSINK_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawsink_DUMMY = 0,
};

#endif // OAWSINK_H__
