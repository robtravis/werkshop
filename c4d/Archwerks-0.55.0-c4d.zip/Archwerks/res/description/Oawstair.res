// Parameters are described in code: lib/aw_desc.py (SPECS), so they reload without a restart.
CONTAINER Oawstair
{
	NAME Oawstair;
	INCLUDE Obase;

	GROUP ID_OBJECTPROPERTIES
	{
	}
}
