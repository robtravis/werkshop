// Parameters are described in code: lib/aw_desc.py (SPECS), so they reload without a restart.
CONTAINER Oawdoor
{
	NAME Oawdoor;
	INCLUDE Obase;

	GROUP ID_OBJECTPROPERTIES
	{
	}
}
