#ifndef OAWMOLDING_H__
#define OAWMOLDING_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawmolding_DUMMY = 0,
};

#endif // OAWMOLDING_H__
