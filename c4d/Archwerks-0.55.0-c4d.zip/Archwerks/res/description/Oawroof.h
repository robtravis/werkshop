#ifndef OAWROOF_H__
#define OAWROOF_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawroof_DUMMY = 0,
};

#endif // OAWROOF_H__
