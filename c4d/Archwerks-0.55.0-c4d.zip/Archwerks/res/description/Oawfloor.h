#ifndef OAWFLOOR_H__
#define OAWFLOOR_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawfloor_DUMMY = 0,
};

#endif // OAWFLOOR_H__
