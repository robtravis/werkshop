#ifndef OAWPROFILE_H__
#define OAWPROFILE_H__

// Parameter ids live in lib/aw_ids.py; parameters are described in lib/aw_desc.py.
enum
{
	Oawprofile_DUMMY = 0,
};

#endif // OAWPROFILE_H__
