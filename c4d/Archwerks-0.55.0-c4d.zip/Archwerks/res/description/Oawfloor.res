// Parameters are described in code: lib/aw_desc.py (SPECS), so they reload without a restart.
CONTAINER Oawfloor
{
	NAME Oawfloor;
	INCLUDE Obase;

	GROUP ID_OBJECTPROPERTIES
	{
	}
}
