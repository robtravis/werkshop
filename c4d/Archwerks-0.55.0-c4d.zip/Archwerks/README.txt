Archwerks 0.55.0 for Cinema 4D 2027
=====================================

Parametric architecture for Cinema 4D: walls, windows, doors, cutouts,
fireplaces, floors, ceilings, roofs, stairs, railings, cabinets, countertops
and sinks, with live dimensions you can type into.

Install
-------
1. Quit Cinema 4D.
2. Put the Archwerks folder from this zip in your Cinema 4D plugins folder.
   In Cinema 4D: Edit > Preferences, Open Preferences Folder (bottom left),
   then the "plugins" folder inside it (make it if it isn't there).
   Or keep the folder anywhere and add its location under
   Edit > Preferences > Plugins.
3. Start Cinema 4D. You should see an Archwerks menu in the main menu bar.

Start
-----
- Archwerks > Archwerks Panel opens the panel: Build, Openings and Kitchen.
- Build > Wall: pick a type, then click the corners in the view (AW Draw).
  Type a length and press Return to place a point exactly; Shift holds 45
  degrees; click the first point to close a room; Escape ends a run.
- Openings: pick a window or door; hover a wall and click to place it. Type a
  size while placing (36x60). Everything placed in one go is linked.
- Kitchen: pick a cabinet, then click a wall.
- Select an Archwerks object: its settings are in the Attribute Manager;
  drag its handles with the Move tool or AW Edit Dimensions, where you can
  also click a dimension and type a value.

Requires Cinema 4D 2027 (macOS or Windows). Units follow your preferences.

Reporting a problem
-------------------
Please send: what you did, what you expected, a screenshot, and the Python
console's text (Extensions > Console) if it shows errors. A small scene that
shows it helps most.
