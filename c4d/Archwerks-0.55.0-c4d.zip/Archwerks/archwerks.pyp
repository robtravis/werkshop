"""Archwerks for Cinema 4D 2027+.

Registers every Archwerks plugin: the Wall, AW Opening and Slab objects, the AW
Edit Dimensions, AW Place Window and AW Scale Plan tools, the AW Walls from
Spline, AW Floor Plan and Archwerks Panel commands, the draw watcher and the
Archwerks menu, plus hidden placeholders for the ids registered for what comes
next (AW Duplicate). Installed by werks-src/archwerks/install_c4d.py, which copies this
folder into C4D's plugins folder and the modules from archwerks/src into lib/.
Edit the repo, not the installed copy.

This file is kept thin on purpose, because it is the one part that needs a
Cinema 4D restart to change. Each registered class is a shell: every call
Cinema 4D makes is handed to the class of the same name in lib/aw_plugins.py,
and parameters are described in code (lib/aw_desc.py), so behaviour and
parameters both reload with `install_c4d.py --lib`. Only a new plugin id, a
change to which methods a shell forwards, or a change to registration flags
needs a restart.

Scenes using these objects need the plugin. Files for other studios are baked
to plain geometry first (Make Editable), so they need nothing installed.
"""
import importlib
import os
import sys
import time

import c4d

HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.join(HERE, "lib")
sys.path.insert(0, LIB)

# Hot reload: `install_c4d.py --lib` replaces lib/ while C4D runs; within half a
# second of the next call into Archwerks every lib module reloads, in the order
# lib/aw_modules.py gives (so a module added there loads without a restart).
_lib_mtimes = {}
_lib_checked = 0.0
_lib_generation = 0
RELEASE = os.path.isfile(os.path.join(HERE, "RELEASE"))  # a shared build (tools/package_c4d.py): no watching lib/


def _stamps():
    return {f: os.path.getmtime(os.path.join(LIB, f)) for f in os.listdir(LIB) if f.endswith(".py")}


def _load_lib(reload):
    importlib.invalidate_caches()
    order = importlib.reload(sys.modules["aw_modules"]) if reload else importlib.import_module("aw_modules")
    for name in order.ORDER:
        module = sys.modules.get(name)
        if module is None:
            importlib.import_module(name)
        elif reload:
            importlib.reload(module)
    sys.modules["aw_plugins"].GENERATION = _lib_generation


def _refresh_lib():
    global _lib_checked, _lib_generation
    if RELEASE:
        return
    now = time.monotonic()
    if now - _lib_checked < 0.5:
        return
    _lib_checked = now
    try:
        stamps = _stamps()
    except OSError:
        return  # mid-install; try again next time
    if stamps != _lib_mtimes:
        _lib_generation += 1
        try:
            _load_lib(True)
            print("Archwerks: reloaded lib (generation %d)" % _lib_generation)
        except Exception as e:  # a broken module must not take the viewport down; fix it and install again
            print("Archwerks: lib reload FAILED, keeping what loaded:", e)
        _lib_mtimes.clear()
        _lib_mtimes.update(stamps)


_lib_mtimes.update(_stamps())
_load_lib(False)
import aw_ids  # noqa: E402
import aw_plugins  # noqa: E402  (looked up again on every call: it is replaced on reload)


def _impl(shell):
    return getattr(sys.modules["aw_plugins"], type(shell).IMPL)


def _forward(name, fallback):
    def method(self, *args):
        _refresh_lib()
        f = getattr(_impl(self), name, None)
        return fallback(self, *args) if f is None else f(self, *args)
    method.__name__ = name
    return method


def _shell(base, impl, methods):
    """A class C4D can register that hands each of `methods` ({name: fallback}) to
    aw_plugins.<impl>, and finds that class's _helpers and CONSTANTS for it."""
    def __init__(self):
        base.__init__(self)
        _refresh_lib()
        setup = getattr(_impl(self), "setup", None)
        if setup is not None:
            setup(self)

    def __getattr__(self, name):
        if name.startswith("__") or not (name.startswith("_") or name.isupper()):
            raise AttributeError(name)
        for cls in _impl(self).__mro__:
            if name in cls.__dict__:
                raw = cls.__dict__[name]
                if isinstance(raw, staticmethod):
                    return raw.__func__
                return raw.__get__(self) if callable(raw) and not isinstance(raw, type) else raw
        raise AttributeError(name)

    ns = {"IMPL": impl, "__init__": __init__, "__getattr__": __getattr__}
    ns.update({name: _forward(name, fallback) for name, fallback in methods.items()})
    return type(impl, (base,), ns)


def _describe(self, node, description, flags):
    return sys.modules["aw_desc"].describe(node, description, flags)


def _enabling(self, *args):
    try:
        return c4d.plugins.ObjectData.GetDEnabling(self, *args)
    except (AttributeError, TypeError):
        return True


OBJECT_METHODS = {
    "Init": lambda self, *a: True,
    "Message": lambda self, *a: True,
    "GetVirtualObjects": lambda self, op, hh: c4d.BaseObject(c4d.Onull),
    "Draw": lambda self, *a: c4d.plugins.ObjectData.Draw(self, *a),
    "GetHandleCount": lambda self, op: 0,
    "GetHandle": lambda self, *a: None,
    "SetHandle": lambda self, *a: None,
    "GetDDescription": _describe,
    "GetDEnabling": _enabling,
}
SPLINE_METHODS = dict(OBJECT_METHODS, GetContour=lambda self, *a: None)
del SPLINE_METHODS["GetVirtualObjects"]
TOOL_METHODS = {
    "GetState": lambda self, doc: c4d.CMD_ENABLED,
    "FreeTool": lambda self, *a: None,
    "MouseInput": lambda self, *a: False,
    "KeyboardInput": lambda self, *a: False,
    "Draw": lambda self, *a: c4d.TOOLDRAW_NONE,
    "GetCursorInfo": lambda self, *a: True,
}
COMMAND_METHODS = {
    "Execute": lambda self, doc: True,
    "GetState": lambda self, doc: c4d.CMD_ENABLED,
    "RestoreLayout": lambda self, sec_ref: False,
}
MESSAGE_METHODS = {"CoreMessage": lambda self, mid, bc: True}

GENERATOR, INPUT, SPLINE = c4d.OBJECT_GENERATOR, c4d.OBJECT_INPUT, c4d.OBJECT_ISSPLINE
I = aw_ids
# (id, name shown, aw_plugins class, description, flags); hidden ones are placeholders
OBJECTS = (
    (I.ID_AW_WALL, "Wall", "Wall", "Oawwall", GENERATOR | INPUT, False),
    (I.ID_AW_OPENING, "AW Opening", "Opening", "Oawopening", GENERATOR, False),
    (I.ID_AW_SLAB, "Slab", "Slab", "Oawslab", GENERATOR, False),
    (I.ID_AW_DOOR, "Door", "Door", "Oawdoor", GENERATOR, False),
    (I.ID_AW_MOLDING, "Molding", "Molding", "Oawmolding", GENERATOR, False),
    (I.ID_AW_FLOOR, "Floor", "Floor", "Oawfloor", GENERATOR | INPUT, False),
    (I.ID_AW_CEILING, "Ceiling", "Ceiling", "Oawceiling", GENERATOR | INPUT, False),
    (I.ID_AW_ROOF_CUTTER, "Roof Cutter", "RoofCutter", "Oawprofile", GENERATOR | SPLINE, False),
    (I.ID_AW_ROOF, "Roof", "Roof", "Oawroof", GENERATOR | INPUT, False),
    (I.ID_AW_STAIR, "Stair", "Stair", "Oawstair", GENERATOR | INPUT, False),
    (I.ID_AW_RAILING, "Railing", "Railing", "Oawrailing", GENERATOR | INPUT, False),
    (I.ID_AW_CUTTER, "Cutout", "Cutter", "Oawcutter", GENERATOR, False),  # shown as Cutout; aw_plugins.Cutter
    (I.ID_AW_BEAM, "Beam", "Beam", "Oawbeam", GENERATOR, False),
    (I.ID_AW_CABINET, "Cabinet", "Cabinet", "Oawcabinet", GENERATOR, False),
    (I.ID_AW_COUNTERTOP, "Countertop", "Countertop", "Oawcountertop", GENERATOR | INPUT, False),
    (I.ID_AW_SINK, "Sink", "Sink", "Oawsink", GENERATOR | SPLINE, False),
    (I.ID_AW_FIREPLACE, "Fireplace", "Fireplace", "Oawfireplace", GENERATOR, False),
    (I.ID_AW_WALL_PANELS, "Wall Panels", "WallPanels", "Oawpanels", GENERATOR, False),
)
TOOLS = (
    (I.ID_AW_EDIT_TOOL, "AW Edit Dimensions", "EditTool", "Click a dimension label and type its value", False),
    (I.ID_AW_SCALE_PLAN_TOOL, "AW Scale Plan", "ScalePlanTool", "Drag across a known dimension and type its real length",
     False),
    (I.ID_AW_PLACE_TOOL, "AW Place Window", "PlaceTool", "Hover a wall and click to place the chosen window", False),
    (I.ID_AW_DRAW_TOOL, "AW Draw", "DrawTool", "Draw a wall's path: guides, snapping, typed lengths", False),
    (I.ID_AW_DUPLICATE_TOOL, "AW Duplicate", "DuplicateTool", "Click a wall to place a copy of the selected window",
     True),
)
# Each plugin's icon, from archwerks/icons (the set Blender shows), copied to res/icons by install_c4d.py.
ICONS = {I.ID_AW_WALL: "wall", I.ID_AW_OPENING: "window", I.ID_AW_SLAB: "slab", I.ID_AW_DOOR: "door",
         I.ID_AW_MOLDING: "baseboard", I.ID_AW_FLOOR: "floor", I.ID_AW_CEILING: "ceiling",
         I.ID_AW_ROOF_CUTTER: "roof_cutter", I.ID_AW_ROOF: "roof", I.ID_AW_STAIR: "stair", I.ID_AW_RAILING: "railing",
         I.ID_AW_CUTTER: "hole", I.ID_AW_BEAM: "beam", I.ID_AW_CABINET: "cabinet", I.ID_AW_COUNTERTOP: "countertop",
         I.ID_AW_SINK: "sink", I.ID_AW_FIREPLACE: "fireplace", I.ID_AW_WALL_PANELS: "panels",
         I.ID_AW_EDIT_TOOL: "edit_dims", I.ID_AW_SCALE_PLAN_TOOL: "scale_plan", I.ID_AW_PLACE_TOOL: "window",
         I.ID_AW_DUPLICATE_TOOL: "duplicate", I.ID_AW_DRAW_TOOL: "wall", I.ID_AW_WALLS_FROM_SPLINE: "wall", I.ID_AW_FLOOR_PLAN: "floor_plan",
         I.ID_AW_PANEL: "archwerks"}


def _icon(pid):
    """The plugin's icon as a BaseBitmap, or None (C4D then shows its question mark)."""
    return _icon_file(ICONS.get(pid, ""))


def _icon_file(name):
    path = os.path.join(HERE, "res", "icons", name + ".png")
    if not os.path.isfile(path):
        return None
    bmp = c4d.bitmaps.BaseBitmap()
    return bmp if bmp.InitWith(path)[0] == c4d.IMAGERESULT_OK else None


COMMANDS = (
    (I.ID_AW_WALLS_FROM_SPLINE, "AW Walls from Spline", "WallsFromSpline",
     "Turn the selected splines into walls, or draw a new wall with the Spline Pen"),
    (I.ID_AW_FLOOR_PLAN, "AW Floor Plan", "FloorPlan", "Lay a floor plan image on the floor to trace walls over"),
    (I.ID_AW_PANEL, "Archwerks Panel", "Panel", "Open the Archwerks panel: wall presets, floor plans and tools"),
)


def PluginMessage(mid, data):
    if mid == c4d.C4DPL_BUILDMENU:
        try:
            _refresh_lib()
            sys.modules["aw_plugins"]._build_menu()
        except Exception as e:  # a menu problem must never stop the plugin loading
            print("Archwerks: couldn't add the menu:", e)
    return False


def _version():
    try:
        with open(os.path.join(HERE, "VERSION"), encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return "dev"


if __name__ == "__main__":
    version = _version()
    report = []
    for pid, name, impl, desc, info, hidden in OBJECTS:
        methods = SPLINE_METHODS if info & SPLINE else OBJECT_METHODS
        flags = info | (c4d.PLUGINFLAG_HIDE if hidden else 0)
        ok = c4d.plugins.RegisterObjectPlugin(id=pid, str=name, g=_shell(c4d.plugins.ObjectData, impl, methods),
                                              description=desc, icon=_icon(pid), info=flags)
        report.append((name, ok))
    for pid, name, impl, helptext, hidden in TOOLS:
        ok = c4d.plugins.RegisterToolPlugin(id=pid, str=name, info=c4d.PLUGINFLAG_HIDE if hidden else 0, icon=_icon(pid),
                                            help=helptext, dat=_shell(c4d.plugins.ToolData, impl, TOOL_METHODS)())
        report.append((name, ok))
    for pid, name, impl, helptext in COMMANDS:
        ok = c4d.plugins.RegisterCommandPlugin(id=pid, str=name, info=0, icon=_icon(pid), help=helptext,
                                               dat=_shell(c4d.plugins.CommandData, impl, COMMAND_METHODS)())
        report.append((name, ok))
    import aw_commands
    for key, pid in sorted(getattr(I, "COMMAND_IDS", {}).items()):  # the shared command list's own commands
        cmd = aw_commands.BY_KEY.get(key)
        if cmd is None or "c4d" not in cmd["hosts"]:
            continue
        dat = _shell(c4d.plugins.CommandData, "Command", COMMAND_METHODS)()
        dat.aw_key = key
        bmp = _icon_file(cmd["icon"])
        ok = c4d.plugins.RegisterCommandPlugin(id=pid, str=cmd["c4d_name"], info=0, icon=bmp, help=cmd["help"],
                                               dat=dat)
        report.append((cmd["label"], ok))
    ok = c4d.plugins.RegisterMessagePlugin(id=I.ID_AW_WATCHER, str="Archwerks draw watcher", info=0,
                                           dat=_shell(c4d.plugins.MessageData, "Watcher", MESSAGE_METHODS)())
    report.append(("draw watcher", ok))
    failed = [name for name, ok in report if not ok]
    print("Archwerks %s: %d plugins registered%s" % (version, len(report) - len(failed),
                                                      ", FAILED: " + ", ".join(failed) if failed else ""))
