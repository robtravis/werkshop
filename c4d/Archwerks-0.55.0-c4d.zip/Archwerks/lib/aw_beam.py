"""Archwerks beams: a straight beam of a chosen section, cloned in rows and layers.

A Beam runs along its +X from the origin, Length long, Width across (Z, centred)
and Height deep, standing on, hanging from or centred on its origin (Align).
Section: Rectangle, Rounded (its long edges filleted, Radius), Round (Width
across), I-Beam (flanges Flange thick, a web Web thick) or Custom (a linked
spline, drawn in its XY plane: X across the beam, Y up).

Clones: Count beams side by side along +Z, Spacing apart centre to centre, or
(Spacing Mode Span) spread evenly over Span from the first to the last; and
Layers of them stacked Layer Spacing apart up +Y (a grid). Joists, rafters,
purlins, a pergola's slats.

In AW Edit Dimensions, while the beam is selected: its Length, Width and Height,
the Spacing between the first two beams, the Span to the last one and the Count,
each typed into its label; grips at the end, the side and the top of the first
beam, and on the last beam (drag the spacing) and the top layer.

Sizes in cm.
"""
import math

import aw_host

RECTANGLE, ROUNDED, ROUND, I_BEAM, CUSTOM = range(5)
SECTION_NAMES = ("Rectangle", "Rounded", "Round", "I-Beam", "Custom")
BOTTOM, CENTRE, TOP = 0, 1, 2
PER_STEP, SPAN = 0, 1
GROUPS = ("Beam",)
ROUND_SIDES = 16
FILLET_STEPS = 4
DIM_OUT = 30.0  # cm the dimension lines stand off the beam


def section(kind, w, h, radius=0.0, flange=0.0, web=0.0, custom=None):
    """[(z, y)] counter-clockwise, centred on 0 across, 0..h up."""
    if kind == CUSTOM and custom and len(custom) >= 3:
        xs, ys = [p[0] for p in custom], [p[1] for p in custom]
        cx, y0 = (min(xs) + max(xs)) / 2, min(ys)
        pts = [(x - cx, y - y0) for x, y in custom]
    elif kind == ROUND:
        r = w / 2
        pts = [(r * math.cos(2 * math.pi * i / ROUND_SIDES), h / 2 + h / 2 * math.sin(2 * math.pi * i / ROUND_SIDES))
               for i in range(ROUND_SIDES)]
    elif kind == I_BEAM:
        f = min(max(flange, 0.1), h / 2 - 0.05)
        t = min(max(web, 0.1), w - 0.1)
        pts = [(-w / 2, 0), (w / 2, 0), (w / 2, f), (t / 2, f), (t / 2, h - f), (w / 2, h - f), (w / 2, h),
               (-w / 2, h), (-w / 2, h - f), (-t / 2, h - f), (-t / 2, f), (-w / 2, f)]
    elif kind == ROUNDED and radius > 1e-6:
        r = min(radius, w / 2, h / 2)
        pts = []
        for cz, cy, a0 in ((w / 2 - r, r, -90), (w / 2 - r, h - r, 0), (-w / 2 + r, h - r, 90), (-w / 2 + r, r, 180)):
            for k in range(FILLET_STEPS + 1):
                a = math.radians(a0 + 90.0 * k / FILLET_STEPS)
                pts.append((cz + r * math.cos(a), cy + r * math.sin(a)))
    else:
        pts = [(-w / 2, 0), (w / 2, 0), (w / 2, h), (-w / 2, h)]
    a = sum(p[0] * q[1] - q[0] * p[1] for p, q in zip(pts, pts[1:] + pts[:1]))
    return pts if a > 0 else pts[::-1]


def base_y(align, h):
    """Where the beam's underside sits for Align."""
    return {BOTTOM: 0.0, CENTRE: -h / 2, TOP: -h}.get(align, 0.0)


def spacing_of(s):
    """Centre to centre between neighbouring beams."""
    if s["count"] < 2:
        return 0.0
    if s["spacing_mode"] == SPAN:
        return s["span"] / (s["count"] - 1)
    return s["spacing"]


def offsets(s):
    """(z, y) of every clone, the first at (0, 0)."""
    sp = spacing_of(s)
    return [(i * sp, j * s["layer_spacing"]) for j in range(max(s["layers"], 1)) for i in range(max(s["count"], 1))]


def layout(s):
    """(dimension layout, grips) for a selected beam in its own space (aw_dims and
    aw_roofdims formats: grips [(position, direction, kind, action)])."""
    L, w, h = s["length"], s["width"], s["height"]
    y0 = base_y(s["align"], h)
    y1 = y0 + h
    n, sp = max(s["count"], 1), spacing_of(s)
    zl = -w / 2 - DIM_OUT
    xl = -DIM_OUT
    dims, ext, grips = [], [], []

    def dim(kind, value, a, b, out, edit, ends=("b",)):
        dims.append({"kind": kind, "role": "wall", "axis": "x", "value": value, "a": a, "b": b, "out": out,
                     "grips": ends, "edit": edit})

    def leader(p, q):
        dims_ext = {"role": "wall", "a": p, "b": q}
        ext.append(dims_ext)
    dim("length", L, (0.0, y0, zl), (L, y0, zl), (0.0, 0.0, -1.0), {"do": "beam_length"})
    leader((0.0, y0, -w / 2), (0.0, y0, zl))
    leader((L, y0, -w / 2), (L, y0, zl))
    dim("height", h, (L + DIM_OUT / 2, y0, 0.0), (L + DIM_OUT / 2, y1, 0.0), (1.0, 0.0, 0.0), {"do": "beam_height"})
    dim("thickness", w, (xl, y1, -w / 2), (xl, y1, w / 2), (-1.0, 0.0, 0.0), {"do": "beam_width"})
    leader((0.0, y1, -w / 2), (xl, y1, -w / 2))
    leader((0.0, y1, w / 2), (xl, y1, w / 2))
    grips.append(((L, (y0 + y1) / 2, 0.0), (1.0, 0.0, 0.0), "arrow", {"set": "length"}))
    if s["align"] == TOP:  # hanging from its origin: it deepens downwards
        grips.append(((L / 2, y0, 0.0), (0.0, -1.0, 0.0), "arrow", {"set": "height"}))
    else:
        grips.append(((L / 2, y1, 0.0), (0.0, 1.0, 0.0), "arrow", {"set": "height"}))
    grips.append(((L / 2, (y0 + y1) / 2, w / 2), (0.0, 0.0, 1.0), "arrow", {"set": "width"}))
    if n > 1:
        xs = xl - DIM_OUT
        dim("gap", sp, (xs, y0, 0.0), (xs, y0, sp), (-1.0, 0.0, 0.0), {"do": "beam_spacing"}, ())
        if n > 2:
            dim("chain", sp * (n - 1), (xs - DIM_OUT, y0, 0.0), (xs - DIM_OUT, y0, sp * (n - 1)), (-1.0, 0.0, 0.0),
                {"do": "beam_span"}, ())
        last = sp * (n - 1)
        count_at = (L / 2, y1 + DIM_OUT / 2, last / 2)
        dims.append({"kind": "count", "role": "wall", "axis": "x", "value": n, "a": count_at, "b": count_at,
                     "anchor": "centre", "edit": {"do": "beam_count"}})
        grips.append(((L / 2, (y0 + y1) / 2, last + w / 2), (0.0, 0.0, 1.0), "arrow", {"set": "spacing", "n": n}))
    if s["layers"] > 1:
        top = (s["layers"] - 1) * s["layer_spacing"]
        dim("gap", s["layer_spacing"], (L + DIM_OUT, y0, 0.0), (L + DIM_OUT, y0 + s["layer_spacing"], 0.0),
            (1.0, 0.0, 0.0), {"do": "beam_layer_spacing"}, ())
        grips.append(((L / 2, y1 + top, 0.0), (0.0, 1.0, 0.0), "arrow", {"set": "layer_spacing",
                                                                         "layers": s["layers"], "y1": y1}))
    return {"dims": dims, "ext": ext, "outline": None, "grips": True}, grips


def grip_value(act, p, s):
    """(setting, value) for grip `act` dragged to local point p (x, y, z)."""
    x, y, z = p
    what = act["set"]
    if what == "length":
        return "length", max(x, 1.0)
    if what == "height":  # the grip is on the face that moves: the top, or a hanging beam's underside
        return "height", max({BOTTOM: y, CENTRE: 2 * y, TOP: -y}.get(s["align"], y), 0.5)
    if what == "width":
        return "width", max(2 * z, 0.5)
    if what == "spacing":
        n = act["n"]
        return "spacing", max((z - s["width"] / 2) / (n - 1), 0.1)
    if what == "layer_spacing":
        return "layer_spacing", max((y - act["y1"]) / (act["layers"] - 1), 0.1)
    raise ValueError(what)


def build_from(name, s, custom=None):
    """The beams' mesh (pure but for MeshBuilder)."""
    import aw_slab
    from aw_mesh import MeshBuilder
    mesh = MeshBuilder(GROUPS)
    sec = section(s["section"], s["width"], s["height"], s["radius"], s["flange"], s["web"], custom)
    if len(sec) < 3 or s["length"] <= 0:
        return None
    y0 = base_y(s["align"], s["height"])
    tris = aw_slab.triangulate(sec)
    L = s["length"]
    m = len(sec)
    for oz, oy in offsets(s):
        mesh.new_part()
        first = len(mesh.polys)
        a = [mesh.pt(0.0, y0 + oy + v, oz + u) for u, v in sec]
        b = [mesh.pt(L, y0 + oy + v, oz + u) for u, v in sec]
        if m == 4:  # a plain box: one quad at each end
            mesh.quad(a[3], a[2], a[1], a[0], "Beam")
            mesh.quad(b[0], b[1], b[2], b[3], "Beam")
        else:
            for i, j, k in tris:
                mesh.quad(a[k], a[j], a[i], a[i], "Beam")
                mesh.quad(b[i], b[j], b[k], b[k], "Beam")
        for i in range(m):
            j = (i + 1) % m
            mesh.quad(a[i], a[j], b[j], b[i], "Beam")
        mesh._face_out(first)
    return mesh.build(name)


# Cinema 4D side ---------------------------------------------------------------------

FIELDS = (("length", "LENGTH", float), ("width", "WIDTH", float), ("height", "HEIGHT", float),
          ("align", "ALIGN", int), ("section", "SECTION", int), ("radius", "RADIUS", float),
          ("flange", "FLANGE", float), ("web", "WEB", float), ("count", "COUNT", int),
          ("spacing_mode", "SPACING_MODE", int), ("spacing", "SPACING", float), ("span", "SPAN", float),
          ("layers", "LAYERS", int), ("layer_spacing", "LAYER_SPACING", float))


def settings(op):
    import aw_ids as I
    s = {name: kind(aw_host.value(op, getattr(I, "AW_BEAM_" + key))) for name, key, kind in FIELDS}
    s["length"] = max(s["length"], 0.1)
    s["width"], s["height"] = max(s["width"], 0.1), max(s["height"], 0.1)
    s["count"], s["layers"] = max(s["count"], 1), max(s["layers"], 1)
    s["profile"] = aw_host.link(op, I.AW_BEAM_PROFILE)
    return s


def custom_section(spline):
    return aw_host.spline_points(spline)


def build(op):
    s = settings(op)
    return build_from(aw_host.name(op), s, custom_section(s["profile"]) if s["section"] == CUSTOM else None)


def set_grip(op, i, p):
    import aw_ids as I
    s = settings(op)
    _lay, grips = layout(s)
    if not 0 <= i < len(grips):
        return
    name, value = grip_value(grips[i][3], (p.x, p.y, p.z), s)
    if name == "spacing" and s["spacing_mode"] == SPAN:
        name, value = "span", value * (s["count"] - 1)
    aw_host.set_value(op, getattr(I, "AW_BEAM_" + name.upper()), value)


def apply(doc, op, edit, value):
    """A value typed into one of a beam's labels."""
    import aw_ids as I
    do = edit["do"]
    s = settings(op)
    if do == "beam_count":
        n = int(round(value))
        if n < 1:
            raise ValueError("needs at least one beam")
        aw_host.set_value(op, I.AW_BEAM_COUNT, n, undo=True)
        return "beam count"
    if value <= 0:
        raise ValueError("must be more than 0")
    if do in ("beam_spacing", "beam_span"):
        step = value if do == "beam_spacing" else value / max(s["count"] - 1, 1)
        if s["spacing_mode"] == SPAN:
            aw_host.set_value(op, I.AW_BEAM_SPAN, step * (s["count"] - 1), undo=True)
        else:
            aw_host.set_value(op, I.AW_BEAM_SPACING, step, undo=True)
        return "beam spacing"
    pid = {"beam_length": I.AW_BEAM_LENGTH, "beam_width": I.AW_BEAM_WIDTH, "beam_height": I.AW_BEAM_HEIGHT,
           "beam_layer_spacing": I.AW_BEAM_LAYER_SPACING}.get(do)
    if pid is None:
        raise ValueError("unknown edit %r" % do)
    aw_host.set_value(op, pid, value, undo=True)
    return do[5:].replace("_", " ")
