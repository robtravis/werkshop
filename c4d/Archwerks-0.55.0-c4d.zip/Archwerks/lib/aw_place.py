"""Archwerks window placing: pick a preset, hover a wall, click to place.

A preset is a dict: {"label", "key", "values"}, values being AW Opening settings
by aw_window.Style field name plus "width", "height" and "sill" (cm); anything a
preset leaves out takes the AW Opening default. Built-in presets are in PRESETS
(core/aw_placing, with the face under the mouse, the fit and the preview, shared
with Blender); saved ones live in one file shared by every scene (user_presets_path(), JSON),
so a preset saved in one project is there in the next. A preset made from a
placed window (copy_of) also carries that window as "source": placing it
places a copy, materials and all, which is how Duplicate works.

The panel's window presets set `preset` and start AW Place Window. While the tool
is active, hovering over any Wall finds the segment under the mouse (the wall's
face, not just its spline) and shows the window there: an orange outline on the
Exterior face at the preset's sill height, with live distances to whatever is
either side of it on that segment (its corners or a neighbouring opening). Shift
centres it on the segment. A click adds an AW Opening under the wall, one undo
step, named Window.<Type>.001; the tool stays active for more. Escape returns to
AW Edit Dimensions. A window that doesn't fit, or would overlap another, shows
its outline in grey and can't be placed.
"""
import c4d

import aw_groups_c4d
import aw_cutter as C
import aw_desc
import aw_door as D
import aw_draw
import aw_ids as I
import aw_wall_c4d
import aw_window as W

# The presets, the face under the mouse, the fit and the preview are in the core (shared
# with Blender): aw_placing.
from aw_placing import *  # noqa: E402,F401,F403
import aw_placing  # noqa: E402


def _kind_of(op):
    return {I.ID_AW_DOOR: DOOR, I.ID_AW_CUTTER: CUTTER, I.ID_AW_RAILING: RAILING,
            I.ID_AW_CABINET: CABINET, I.ID_AW_FIREPLACE: FIREPLACE}.get(op.GetType(), WINDOW)


def params_for(kind):
    if kind == RAILING:
        import aw_railing
        return aw_railing.param_ids()
    if kind == CABINET:
        import aw_cabinet_c4d
        return aw_cabinet_c4d.param_ids()
    return {DOOR: DOOR_PARAMS, CUTTER: CUTTER_PARAMS, FIREPLACE: FIREPLACE_PARAMS}.get(kind, PRESET_PARAMS)


def type_key(op):
    if _kind_of(op) == RAILING:
        return "Railing"
    if _kind_of(op) == CABINET:
        import aw_cabinet_c4d
        return aw_cabinet_c4d.TYPE_NAMES[int(aw_desc.value(op, I.AW_CAB_TYPE))]
    if _kind_of(op) == CUTTER:
        return C.SHAPE_NAMES[int(aw_desc.value(op, I.AW_CUTTER_SHAPE))].replace(" ", "")
    if _kind_of(op) == FIREPLACE:
        import aw_fireplace
        return aw_fireplace.SHAPE_NAMES[int(aw_desc.value(op, I.AW_FP_SHAPE))].replace(" ", "")
    if _kind_of(op) == DOOR:
        return D.TYPE_KEYS.get(int(aw_desc.value(op, I.AW_DOOR_TYPE)), "Door")
    return W.TYPE_KEYS.get(int(aw_desc.value(op, I.AW_OPENING_TYPE)), "Window")


preset = PRESETS[0]
_hover = None  # what the mouse is over: see hover()
def values_of(op):
    """{field: value} of every preset setting of window or door op."""
    out = {}
    for name, pid in params_for(_kind_of(op)):
        out[name] = aw_desc.value(op, pid)
    if aw_wall_parent(op) is not None:  # its sill as it stands, whatever its own height is
        out["sill"] = op.GetMl().off.y + out["sill"]
    return out


def aw_wall_parent(op):
    up = op.GetUp()
    return up if up is not None and up.GetType() == I.ID_AW_WALL else None


def copy_of(op):
    """A preset that places copies of window or door op."""
    return {"label": "copy of " + op.GetName(), "object": _kind_of(op), "key": type_key(op),
            "values": values_of(op), "source": op}


def choose(doc, p, link=None):
    """A preset button: remember it and start placing. Everything placed until the next
    choice is linked (aw_link_c4d): link, the source's own for linked copies, else a new one."""
    global preset, _hover, _base, typed, _link
    import aw_link_c4d
    preset, _hover, _base, typed = p, None, p, ""
    _link = link or aw_link_c4d.new_link()
    doc.SetAction(I.ID_AW_PLACE_TOOL)
    _status()
    c4d.EventAdd()


_link = ""  # what the windows placed now are linked by

# A size typed while placing (36x60, or 30 for a width alone), as Blender's place tool
# takes it: the preset chosen is the base, the one placed is it at the typed size.
_base = None
typed = ""
TYPED_KEYS = "0123456789.xX*"


def _status():
    note = ("   typed %s" % typed) if typed else "   type a size: 36x60"
    where = "a wall or the floor and click (R turns it)" if preset.get("object") == CABINET else "a wall and click"
    c4d.gui.StatusSetText("Place %s: hover %s (Shift: centre it); Escape to stop%s" % (preset["label"], where, note))


def size_key(char=None, back=False, commit=False):
    """A key while placing: a size character, Backspace (back) or Enter (commit: the
    size typed is kept for the ones after). True if it was the tool's."""
    global preset, typed, _base
    import aw_catalog
    base = _base or preset
    if commit:
        if not typed:
            return False
        typed, _base = "", preset  # the size typed is the one placed from now on
        _status()
        return True
    if back:
        if not typed:
            return False
        typed = typed[:-1]
    elif char and char in TYPED_KEYS:
        typed += "x" if char in "xX*" else char
    else:
        return False
    size = aw_catalog.parse_size(typed)
    preset = aw_catalog.resize(base.get("object", WINDOW), base, *size) if size else base
    _status()
    return True


def can_place():
    """Whether the hovered spot takes the chosen preset (hover() found one that fits)."""
    if preset.get("object") == CABINET:
        import aw_cabinet
        h = aw_cabinet._hover
    else:
        h = _hover
    return bool(h) and bool(h.get("ok"))


SELECTABLE = (I.ID_AW_CABINET, I.ID_AW_COUNTERTOP, I.ID_AW_SINK) + tuple(I.OPENING_TYPES)


def clicked_object(bd, doc, x, y):
    """The cabinet, countertop, window or door a click at (x, y) lands on, front-most, or
    None (a wall, the floor plan, nothing): the place tool selects it rather than placing."""
    import aw_openings_c4d
    top = aw_openings_c4d.topmost(bd, doc, x, y)
    if not top:
        return None
    first = top[0]
    if first.GetType() == I.ID_AW_WALL:  # a window shows in its wall: what pick() finds on the face
        found = aw_openings_c4d.pick(bd, doc, x, y)
        return found if found is not None and found.GetType() in SELECTABLE else None
    return first if first.GetType() in SELECTABLE else None


def duplicate(doc, linked=False):
    """Panel button: place copies of the selected window or door (linked: linked to it,
    so a change to any of them changes them all). False with nothing to copy."""
    import aw_link_c4d
    op = doc.GetActiveObject()
    if not I.is_opening(op):
        c4d.gui.MessageDialog("Select a window or door first: Place Copies places copies of it.")
        return False
    link = None
    if linked:
        link = aw_link_c4d.link_of(op) or aw_link_c4d.new_link()
        if not aw_link_c4d.link_of(op):
            doc.StartUndo()
            doc.AddUndo(c4d.UNDOTYPE_CHANGE_SMALL, op)
            aw_link_c4d.set_link(op, link)
            doc.EndUndo()
    choose(doc, copy_of(op), link)
    return True


# Saved presets: one file for every scene, windows, doors and railings together.

def user_presets_path():
    import os
    return os.path.expanduser("~/Library/Application Support/Archwerks/presets.json")


def user_presets(kind=None):
    """The saved presets (of one kind, WINDOW or DOOR, or all), oldest first; [] with no
    file (or an unreadable one)."""
    import json
    try:
        with open(user_presets_path(), encoding="utf-8") as f:
            data = json.load(f)
        found = [p for p in data.get("presets", []) if isinstance(p, dict) and p.get("label") and "values" in p]
    except (OSError, ValueError):
        return []
    for p in found:
        p.setdefault("object", WINDOW)
    return [p for p in found if kind is None or p["object"] == kind]


def _write_user_presets(presets):
    import json
    import os
    path = user_presets_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"version": 1, "units": "cm", "presets": presets}, f, indent=1)
    os.replace(tmp, path)  # never half a file


def save_user_preset(label, op):
    """Save window or door op's settings as preset `label` (replacing one of that
    name and kind). Returns it."""
    label, kind = label.strip(), _kind_of(op)
    if not label:
        raise ValueError("a preset needs a name")
    if any(p["label"].lower() == label.lower() for p in builtin(kind)):
        raise ValueError("%s is a built-in preset; pick another name" % label)
    saved = {"label": label, "object": kind, "key": type_key(op), "values": values_of(op)}
    presets = [p for p in user_presets() if not (p["object"] == kind and p["label"].lower() == label.lower())]
    _write_user_presets(presets + [saved])
    return saved


def delete_user_preset(label, kind=WINDOW):
    """Remove saved preset `label` of that kind. Returns whether there was one."""
    presets = user_presets()
    kept = [p for p in presets if not (p["object"] == kind and p["label"] == label)]
    if len(kept) == len(presets):
        return False
    _write_user_presets(kept)
    return True


def builtin(kind=WINDOW):
    if kind == RAILING:
        import aw_railing
        return aw_railing.PRESETS
    if kind == CABINET:
        import aw_cabinet_c4d
        return aw_cabinet_c4d.PRESETS
    return {DOOR: DOOR_PRESETS, CUTTER: CUTTER_PRESETS + HOLE_PRESETS,  # holes with the archways
            FIREPLACE: FIREPLACE_PRESETS}.get(kind, PRESETS)


def all_presets(kind=WINDOW):
    return list(builtin(kind)) + user_presets(kind)


def _walls(doc):
    out, stack = [], [doc.GetFirstObject()]
    while stack:
        o = stack.pop()
        while o:
            if o.GetType() == I.ID_AW_WALL:
                out.append(o)
            if o.GetDown():
                stack.append(o.GetDown())
            o = o.GetNext()
    return out


ORTHO_BACK = 1.0e6  # cm a parallel view's ray starts behind its camera: everything in the scene is in front


def _ray(bd, x, y):
    """(origin, direction) of the mouse ray at (x, y) in view bd. A parallel view (Top,
    Front and the rest) puts its camera anywhere, the Top view's at the floor, so its ray
    would start 10 cm below it; moved back along itself, the ray sees the whole scene."""
    a = bd.SW(c4d.Vector(x, y, 10.0))
    b = bd.SW(c4d.Vector(x, y, 10000.0))
    v = (b - a).GetNormalized()
    if bd[c4d.BASEDRAW_DATA_PROJECTION] != c4d.Pperspective:
        a = a - v * ORTHO_BACK
    return a, v


def _hit(bd, wall, x, y):
    """(distance along the mouse ray, segment, u along it, height) where the mouse ray first
    meets one of the wall's faces (aw_placing.hit), or None."""
    wp = aw_wall_c4d.wall_path(wall)
    if wp is None:
        return None
    plan, w0, w1, height, _s = wp
    inv = ~wall.GetMg()
    a, v = _ray(bd, x, y)
    la, lv = inv * a, inv.MulV(v)
    return aw_placing.hit(plan, w0, w1, height, (la.x, la.y, la.z), (lv.x, lv.y, lv.z))


def hover(doc, bd, x, y, centre=False):
    """Work out where the current preset would go under the mouse; None if not over
    a wall. Kept for drawing and for the click. (A cabinet: aw_cabinet_c4d's.)"""
    global _hover
    if preset.get("object") == CABINET:
        import aw_cabinet_c4d
        _hover = aw_cabinet_c4d.hover(doc, bd, x, y, preset, centre)
        return _hover
    best = None
    for wall in _walls(doc):
        h = _hit(bd, wall, x, y)
        if h is not None and (best is None or h[0] < best[0]):
            best = (h[0], wall, h[1], h[2], h[4])
    if best is None:
        _hover = None
        return None
    _t, wall, k, u, face = best
    plan, w0, w1, height, splines = aw_wall_c4d.wall_path(wall)
    rects = aw_wall_c4d.path_rects(wall, plan, w0, w1, height, splines).get(k, [])
    _hover = dict(aw_placing.fit(plan, w0, w1, height, k, u, rects, preset, centre, face=face), wall=wall)
    return _hover


def layout():
    """The preview as an aw_dims layout in the hovered wall's space (aw_placing.preview_layout)."""
    return aw_placing.preview_layout(_hover)


def draw(bd):
    """Draw the preview in whichever view it's being placed in."""
    if preset.get("object") == CABINET:
        import aw_cabinet_c4d
        return aw_cabinet_c4d.draw(bd)
    h = _hover
    if h is None or not aw_draw._alive(h["wall"]):
        return
    lay = layout()
    if lay:
        aw_draw.draw_layout(bd, h["wall"].GetMg(), lay)


def _next_name(doc, preset):
    prefix, highest = "%s.%s." % (placed_name(preset), preset["key"]), 0
    for wall in _walls(doc):
        for c in wall.GetChildren():
            n = c.GetName()
            if n.startswith(prefix) and n[len(prefix):].isdigit():
                highest = max(highest, int(n[len(prefix):]))
    return "%s%03d" % (prefix, highest + 1)


def place(doc):
    """Add the hovered window to its wall; one undo step. Returns it, or None."""
    global _hover
    if preset.get("object") == CABINET:
        import aw_cabinet_c4d
        op = aw_cabinet_c4d.place(doc)
        _hover = None
        return op
    h = _hover
    if h is None or not h["ok"] or not aw_draw._alive(h["wall"]):
        return None
    width, wheight, sill = size(preset)
    wall = h["wall"]
    x, _y, z = aw_placing.placed_at(h)
    source = preset.get("source")
    if source is not None and source.IsAlive():
        op = source.GetClone(c4d.COPYFLAGS_NONE)  # a copy: every setting, material and tag
    else:
        op = c4d.BaseObject(OBJECT_IDS[preset.get("object", WINDOW)])
        for name, pid in params_for(preset.get("object", WINDOW)):
            if name in preset["values"]:
                op[pid] = preset["values"][name]
    op.SetName(_next_name(doc, preset))
    import aw_link_c4d
    aw_link_c4d.set_link(op, _link)  # linked to what was placed with it (a copy: not its source's, unless asked)
    op[I.AW_OPENING_WIDTH], op[I.AW_OPENING_HEIGHT], op[I.AW_OPENING_SILL] = width, wheight, sill
    op[I.AW_OPENING_START] = -width / 2
    if op.GetType() == I.ID_AW_FIREPLACE:  # on the face it was placed from, facing whoever placed it
        op[I.AW_FP_SIDE] = aw_placing.side_for(h)
    op.SetMl(c4d.Matrix(c4d.Vector(x, 0, z)))  # on the floor line; the wall turns it to face out
    doc.StartUndo()
    op.InsertUnderLast(wall)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, op)
    import aw_materials
    aw_materials.apply_defaults(doc, op)  # default frame, glass and sill
    aw_groups_c4d.file(doc, op)  # into its group: null and layer (aw_groups_c4d)
    doc.EndUndo()
    _hover = None  # that spot is taken now: a second click there must not stack another
    c4d.gui.StatusSetText("Placed %s on %s" % (op.GetName(), wall.GetName()))
    c4d.EventAdd()
    return op
