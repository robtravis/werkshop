"""aw_roof for Cinema 4D: the parts of core/aw_roof.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_groups_c4d
import aw_roof  # noqa: F401
from aw_roof import *  # noqa: F401,F403
from aw_roof import _alive



def _ident(obj):
    import c4d
    u = obj.FindUniqueID(c4d.MAXON_CREATOR_ID)
    return bytes(u) if u is not None else id(obj)


def change_key(op):
    import c4d
    import aw_handles
    import aw_host
    import aw_ids as I
    import aw_wall_c4d
    wall, draft = op[I.AW_ROOF_WALL], op[I.AW_ROOF_DRAFT]

    def placed(obj):
        m = ~op.GetMg() * obj.GetMg()
        return tuple(round(x, 4) for vec in (m.off, m.v1, m.v2, m.v3) for x in (vec.x, vec.y, vec.z))
    wkey = (aw_wall_c4d.change_key(wall), placed(wall)) if _alive(wall) else None
    dkey = (aw_host.custom_key(draft), placed(draft)) if _alive(draft) else None
    kids = tuple((k.GetType(), k.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX | c4d.DIRTYFLAGS_CACHE),
                  k.GetDeformMode()) for k in op.GetChildren())
    return (op.GetName(), op.GetDirty(c4d.DIRTYFLAGS_DATA), wkey, dkey, kids)


def cutter_contour(op):
    """A Roof Cutter's outline (aw_roof.cutter_outline) as a closed linear spline
    flat in its own XZ plane, for its display; None without one."""
    outline = cutter_outline(op)
    if outline is None:
        return None
    sp = c4d.SplineObject(len(outline), c4d.SPLINETYPE_LINEAR)
    sp.SetAllPoints([c4d.Vector(x, 0, z) for x, z in outline])
    sp[c4d.SPLINEOBJECT_CLOSED] = True
    sp.Message(c4d.MSG_UPDATE)
    return sp


# Panel buttons -------------------------------------------------------------------

def add_for_selection(doc):
    """Panel button Roof: over each selected Wall (its on-the-walls ceilings set to fit
    inside, under it); else a draft roof over each selected polygon object (hidden:
    it is a guide now); else a standalone roof shaped by the selected splines (moved
    under it, laid flat); else an empty one to draw with the Spline Pen. One undo
    step. Returns the roofs."""
    import c4d
    import aw_floor
    import aw_floor_c4d
    import aw_ids as I
    import aw_materials
    import aw_panel
    import aw_slab
    import aw_slab_c4d
    sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
    walls = [o for o in sel if o.GetType() == I.ID_AW_WALL]
    ours = {I.ID_AW_ROOF, I.ID_AW_SLAB, I.ID_AW_FLOOR, I.ID_AW_CEILING, I.ID_AW_WALL, I.ID_AW_MOLDING,
            I.ID_AW_ROOF_CUTTER} | set(I.OPENING_TYPES)
    meshes = [o for o in sel if o.GetType() not in ours and not o.GetInfo() & c4d.OBJECT_ISSPLINE
              and (o.GetType() == c4d.Opolygon or o.GetInfo() & c4d.OBJECT_GENERATOR)]
    splines = aw_panel.selected_splines(doc)
    if not walls and not meshes and not splines:
        return [start_drawing(doc)]
    made = []
    doc.StartUndo()

    def new_roof(after):
        roof = c4d.BaseObject(I.ID_AW_ROOF)
        roof.SetName(aw_slab_c4d.next_name(doc, "Roof"))
        doc.InsertObject(roof, after.GetUp(), after)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, roof)
        made.append(roof)
        return roof
    if walls:
        for wall in walls:
            roof = new_roof(wall)
            roof[I.AW_ROOF_WALL] = wall
            roof.SetMg(c4d.Matrix(wall.GetMg()))
            o = doc.GetFirstObject()
            while o:  # ceilings on these walls: under the roof now
                if (o.GetType() == I.ID_AW_SLAB and o[I.AW_SLAB_TYPE] == aw_slab.CEILING and o[I.AW_SLAB_WALL] == wall
                        and o[I.AW_SLAB_FIT] == aw_slab.FIT_OUTSIDE):
                    doc.AddUndo(c4d.UNDOTYPE_CHANGE, o)
                    o[I.AW_SLAB_FIT] = aw_slab.FIT_INSIDE
                o = o.GetNext()
    elif meshes:
        for m in meshes:
            roof = new_roof(m)
            roof[I.AW_ROOF_DRAFT] = m
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, m)
            m.SetEditorMode(c4d.MODE_OFF)
            m.SetRenderMode(c4d.MODE_OFF)
    else:
        roof = new_roof(splines[0])
        for sp in splines:
            mg = sp.GetMg()
            aw_floor_c4d._lay_flat(doc, sp)
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, sp)
            sp.Remove()
            sp.InsertUnderLast(roof)
            sp.SetMg(mg)
    for roof in made:
        aw_materials.apply_defaults(doc, roof)
        aw_groups_c4d.file(doc, roof)  # into its group: null and layer (aw_groups_c4d)
    doc.EndUndo()
    doc.SetActiveObject(made[0], c4d.SELECTION_NEW)
    c4d.EventAdd()
    return made


def start_drawing(doc):
    """An empty standalone Roof with a spline to draw with the Spline Pen: closed, an
    outline to roof over; open, an axis to roof along."""
    import c4d
    import aw_ids as I
    import aw_materials
    import aw_panel
    import aw_slab
    import aw_slab_c4d
    roof = c4d.BaseObject(I.ID_AW_ROOF)
    roof.SetName(aw_slab_c4d.next_name(doc, "Roof"))
    spline = c4d.SplineObject(0, c4d.SPLINETYPE_LINEAR)
    spline.SetName(aw_panel.RUN_NAME % 1)
    doc.StartUndo()
    doc.InsertObject(roof)
    spline.InsertUnder(roof)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, roof)
    aw_materials.apply_defaults(doc, roof)
    aw_groups_c4d.file(doc, roof)  # into its group: null and layer (aw_groups_c4d)
    doc.SetActiveObject(spline, c4d.SELECTION_NEW)
    doc.EndUndo()
    aw_panel._arm_pen(doc, roof, spline)
    c4d.gui.StatusSetText("Draw the roof: close the outline to roof over it, or leave it open to roof along it")
    c4d.EventAdd()
    return roof


def add_cutter(doc):
    """Panel button Roof Cutter: a cutter under each selected Roof (or the roof the
    selection is in), in the middle of it. One undo step. A cutter cuts straight
    down through the roof wherever it sits, so its height is only for seeing it."""
    import c4d
    import aw_ids as I
    roofs = []
    for o in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE):
        while o is not None and o.GetType() != I.ID_AW_ROOF:
            o = o.GetUp()
        if o is not None and o not in roofs:
            roofs.append(o)
    if not roofs:
        c4d.gui.MessageDialog("Select a Roof first: the cutter goes under it.")
        return []
    made = []
    doc.StartUndo()
    for roof in roofs:
        cut = c4d.BaseObject(I.ID_AW_ROOF_CUTTER)
        cut.SetName("Roof Cutter")
        cache = roof.GetCache()
        if cache is not None and cache.GetType() == c4d.Opolygon and cache.GetPointCount():
            mp = cache.GetMp()
            cut.SetRelPos(mp)  # in the roof's middle, at its height (where you'll look for it)
        cut.InsertUnderLast(roof)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, cut)
        made.append(cut)
    doc.EndUndo()
    doc.SetActiveObject(made[0], c4d.SELECTION_NEW)
    c4d.EventAdd()
    return made


def swap_covering(roof):
    """After the tile model changes: if the Tiles slot holds one of the defaults (the
    asphalt or the metal), put in the new model's; a material of your own stays."""
    import aw_ids as I
    import aw_materials
    doc = roof.GetDocument()
    if doc is None:
        return
    slot = dict(I.AW_ROOF_MATERIAL_SLOTS)["Tiles"]
    cur = roof[slot]
    defaults = {DEFAULT_COVERING} | set(MODEL_MATERIALS.values())
    if cur is not None and cur.GetName() not in defaults:
        return
    want = MODEL_MATERIALS.get(roof[I.AW_ROOF_TILE_MODEL], DEFAULT_COVERING)
    mats = aw_materials.ensure(doc, [want])
    if want in mats:
        roof[slot] = mats[want]
        aw_materials.mark(roof)
