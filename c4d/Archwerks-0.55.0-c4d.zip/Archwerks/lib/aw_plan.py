"""Archwerks floor plans: an image to trace walls over, and scaling it to size.

AW Floor Plan lays an image flat on the floor, 1 pixel = 1 cm, under the walls
and hidden from renders. AW Scale Plan then measures a known dimension on it
and scales the plan (or any selected object, such as an imported DWG) so that
dimension comes out at its real length.
"""
import c4d
from c4d import bitmaps

PLAN_DROP = 0.5  # cm below the floor, so walls and splines drawn at 0 sit on top


def make_plan(doc, path):
    """A plane carrying the image at `path`, 1 px = 1 cm, centred on the origin and
    just below the floor; hidden from renders. Returns it and its material (not yet
    in the document), and shades the document's Top views so the image shows there."""
    bmp = bitmaps.BaseBitmap()
    if bmp.InitWith(path)[0] != c4d.IMAGERESULT_OK:
        raise ValueError("couldn't read the image")
    w, h = bmp.GetSize()
    name = "Floor Plan"
    mat = c4d.BaseMaterial(c4d.Mmaterial)
    mat.SetName(name)
    shader = c4d.BaseShader(c4d.Xbitmap)
    shader[c4d.BITMAPSHADER_FILENAME] = path
    mat.InsertShader(shader)
    # Luminance, not Color: the plan shows at its own brightness whatever the lighting
    mat[c4d.MATERIAL_USE_COLOR] = False
    mat[c4d.MATERIAL_USE_REFLECTION] = False
    mat[c4d.MATERIAL_USE_LUMINANCE] = True
    mat[c4d.MATERIAL_LUMINANCE_SHADER] = shader
    mat[c4d.MATERIAL_PREVIEWSIZE] = c4d.MATERIAL_PREVIEWSIZE_2048  # sharp enough to trace in the viewport

    plane = c4d.BaseObject(c4d.Oplane)
    plane.SetName(name)
    plane[c4d.PRIM_PLANE_WIDTH] = float(w)
    plane[c4d.PRIM_PLANE_HEIGHT] = float(h)
    plane[c4d.PRIM_PLANE_SUBW] = 1
    plane[c4d.PRIM_PLANE_SUBH] = 1
    plane[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_OFF
    plane.SetAbsPos(c4d.Vector(0, -PLAN_DROP, 0))
    tag = plane.MakeTag(c4d.Ttexture)
    tag[c4d.TEXTURETAG_MATERIAL] = mat
    tag[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_UVW
    shade_top_views(doc)
    return plane, mat


def shade_top_views(doc):
    """Top views default to No Shading (lines only), which hides the plan's image;
    switch any such Top view in this document to Gouraud Shading so the plan shows.
    A Top view already set to some other shading is left as it is."""
    for i in range(c4d.EDITOR_VIEWS_MAX if hasattr(c4d, "EDITOR_VIEWS_MAX") else 4):
        bd = doc.GetBaseDraw(i)
        if bd is None:
            break
        if bd.GetProjection() == c4d.Ptop and bd[c4d.BASEDRAW_DATA_SDISPLAYACTIVE] == c4d.BASEDRAW_SDISPLAY_NOSHADING:
            bd[c4d.BASEDRAW_DATA_SDISPLAYACTIVE] = c4d.BASEDRAW_SDISPLAY_GOURAUD
            bd[c4d.BASEDRAW_DATA_TEXTURES] = True


def floor_point(bd, x, y, height):
    """Where the mouse at (x, y) meets the horizontal plane at `height` (world)."""
    import aw_grab
    return aw_grab.point_on_plane(bd, c4d.Vector(0, height, 0), c4d.Vector(0, 1, 0), x, y)


def axis_lock(a, b):
    """b moved onto the X or Z line through a, whichever it is nearer."""
    d = b - a
    if abs(d.x) >= abs(d.z):
        return c4d.Vector(b.x, a.y, a.z)
    return c4d.Vector(a.x, a.y, b.z)


def scaled_about(mg, origin, k):
    """mg scaled by k about the world point origin."""
    s = c4d.Matrix(origin - origin * k, c4d.Vector(k, 0, 0), c4d.Vector(0, k, 0), c4d.Vector(0, 0, k))
    return s * mg


ID_MEASURED, ID_REAL = 1000, 1001


class ScaleDialog(c4d.gui.GeDialog):
    """AW Scale Plan's pop-up: the measured length, and a field for the real one
    (units can be typed: 36", 3', 0.9 m). Return scales, Escape cancels."""

    def __init__(self, measured, name):
        super().__init__()
        self.measured, self.name, self.result = measured, name, None

    def CreateLayout(self):
        self.SetTitle("Scale %s" % self.name)
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 2, 0)
        self.GroupBorderSpace(10, 10, 10, 4)
        self.GroupSpace(8, 6)
        self.AddStaticText(0, c4d.BFH_LEFT, name="Measured")
        self.AddStaticText(ID_MEASURED, c4d.BFH_SCALEFIT, 140, 0)
        self.AddStaticText(0, c4d.BFH_LEFT, name="Real length")
        self.AddEditNumberArrows(ID_REAL, c4d.BFH_SCALEFIT, 140, 0)
        self.GroupEnd()
        self.AddDlgGroup(c4d.DLG_OK | c4d.DLG_CANCEL)
        return True

    def InitValues(self):
        import aw_draw
        self.SetString(ID_MEASURED, aw_draw.fmt_length(self.measured))
        self.SetFloat(ID_REAL, self.measured, min=0.0, max=1.0e7, step=1.0, format=c4d.FORMAT_METER)
        self.SetString(c4d.DLG_OK, "Scale")
        self.Activate(ID_REAL)
        return True

    def Command(self, cid, msg):
        if cid == c4d.DLG_OK:
            value = self.GetFloat(ID_REAL)
            if value <= 0:
                c4d.gui.MessageDialog("The real length must be more than 0.")
                return True
            self.result = value
            self.Close()
        elif cid == c4d.DLG_CANCEL:
            self.Close()
        return True


def ask_real_length(measured, name, win, x, y):
    """The real length typed for a measured line, or None if cancelled. Opens
    beside the mouse, where the drag ended."""
    dlg = ScaleDialog(measured, name)
    gx, gy = -2, -2  # fallback: C4D places it at the mouse
    try:
        g = win.Local2Global()
        gx, gy = int(g["x"] + x + 20), int(g["y"] + y + 20)
    except Exception:
        pass
    dlg.Open(c4d.DLG_TYPE_MODAL, xpos=gx, ypos=gy, defaultw=260, defaulth=0)
    return dlg.result


def scale_plan(doc, target, a, b, real):
    """Scale target about a so the line a..b becomes `real` long; one undo step.
    Returns the line's new far end and the factor."""
    k = real / (b - a).GetLength()
    doc.StartUndo()
    doc.AddUndo(c4d.UNDOTYPE_CHANGE, target)
    target.SetMg(scaled_about(target.GetMg(), a, k))
    doc.EndUndo()
    c4d.EventAdd()
    return a + (b - a) * k, k
