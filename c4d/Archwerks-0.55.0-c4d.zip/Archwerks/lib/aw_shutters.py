"""Archwerks plantation shutters: interior shutters a window builds in front of its hole.

Two sides, each one leaf (or two, folding as a bifold for a wide window), hinged at the
opening's edges on the room side (in front of an interior casing, over an interior stool),
swinging into the room (Open: 0 closed .. 1, OPEN_MAX). A leaf is a frame (stiles, a top
rail, a deeper bottom rail, a Divider Rail across the middle if on) round louvers Louver
Width wide, turned Louver Tilt from flat (0) towards closed (1), with a tilt rod down their
middle. Built in the window's own space (x along the wall, y up, +z the room), sizes in cm,
into a MeshBuilder's "Shutters" group.
"""
import math

OPEN_MAX = math.radians(170.0)
THICK = 3.2       # a leaf's frame
STILE = 5.0
TOP_RAIL = 5.0
BOTTOM_RAIL = 7.5
DIVIDER = 5.0
LOUVER_T = 0.95   # a louver's own thickness
PITCH = 0.85      # louvers this much of their width apart (they overlap closed)
TILT_MAX = math.radians(80.0)
ROD_W, ROD_D = 1.3, 0.8
GAP = 0.3         # between the leaves, and off the wall


class _Leaf:
    """Points of a leaf given in its own (u along it from the hinge, y, t out from its back), turned
    about the hinge at its front face (t THICK)."""

    def __init__(self, mesh, hinge, d, n):
        self.m, self.h, self.d, self.n = mesh, hinge, d, n

    def at(self, u, y, t):
        t -= THICK  # from the hinge: the frame's front face
        return (self.h[0] + self.d[0] * u + self.n[0] * t, y, self.h[1] + self.d[1] * u + self.n[1] * t)

    def box(self, u0, u1, y0, y1, t0, t1, group="Shutters"):
        if u1 - u0 < 1e-4 or y1 - y0 < 1e-4 or t1 - t0 < 1e-4:
            return
        corners = {(i, j, k): self.at((u0, u1)[i], (y0, y1)[j], (t0, t1)[k])
                   for i in (0, 1) for j in (0, 1) for k in (0, 1)}
        first = len(self.m.polys)
        self.m.hexa(corners, group)
        self.m._face_out(first)

    def louver(self, u0, u1, yc, tc, width, tilt, group="Shutters"):
        """A louver across u0..u1 centred at (yc, tc), width across it, turned tilt."""
        wy, wt = math.sin(tilt) * width / 2, math.cos(tilt) * width / 2
        hy, ht = math.cos(tilt) * LOUVER_T / 2, -math.sin(tilt) * LOUVER_T / 2
        corners = {}
        for i, u in enumerate((u0, u1)):
            for j, sw in enumerate((-1, 1)):
                for k, sh in enumerate((-1, 1)):
                    corners[(i, j, k)] = self.at(u, yc + sw * wy + sh * hy, tc + sw * wt + sh * ht)
        first = len(self.m.polys)
        self.m.hexa(corners, group)
        self.m._face_out(first)


def _leaf(lf, width, y0, y1, s):
    """One leaf's frame, louvers and tilt rod, width wide, y0..y1."""
    lf.box(0.0, STILE, y0, y1, 0.0, THICK)
    lf.box(width - STILE, width, y0, y1, 0.0, THICK)
    lf.box(STILE, width - STILE, y1 - TOP_RAIL, y1, 0.0, THICK)
    lf.box(STILE, width - STILE, y0, y0 + BOTTOM_RAIL, 0.0, THICK)
    panels = [(y0 + BOTTOM_RAIL, y1 - TOP_RAIL)]
    if s.shutter_divider:
        mid = (y0 + BOTTOM_RAIL + y1 - TOP_RAIL) / 2
        lf.box(STILE, width - STILE, mid - DIVIDER / 2, mid + DIVIDER / 2, 0.0, THICK)
        panels = [(y0 + BOTTOM_RAIL, mid - DIVIDER / 2), (mid + DIVIDER / 2, y1 - TOP_RAIL)]
    lw = max(s.louver_w, 2.0)
    tilt = min(max(s.louver_tilt, 0.0), 1.0) * TILT_MAX
    tc = THICK / 2
    for p0, p1 in panels:
        span = p1 - p0
        n = max(1, int(span / (lw * PITCH)))
        step = span / n
        for k in range(n):
            lf.louver(STILE, width - STILE, p0 + step * (k + 0.5), tc, lw, tilt)
        front = tc + abs(math.cos(tilt)) * lw / 2 + 0.4  # the tilt rod, in front of their edges
        lf.box(width / 2 - ROD_W / 2, width / 2 + ROD_W / 2, p0 + 1.5, p1 - 1.5, front, front + ROD_D)


def build(mesh, x0, x1, y0, y1, z, s):
    """Both sides' shutters for an opening x0..x1 by y0..y1, hinged on the plane z (the room
    side of the wall, or of an interior casing), into mesh."""
    leaves = 2 if s.shutter_leaves >= 2 else 1
    width = ((x1 - x0) - GAP * (2 * leaves)) / (2 * leaves)
    if width < 2 * STILE + 2.0 or y1 - y0 < BOTTOM_RAIL + TOP_RAIL + 4.0:
        return
    a = min(max(s.shutter_open, 0.0), 1.0) * OPEN_MAX
    back = max(max(s.louver_w, 2.0) / 2 - THICK / 2, 0.0)  # flat louvers stand this far behind the frame
    for sgn, hx in ((1.0, x0 + GAP / 2), (-1.0, x1 - GAP / 2)):
        # the hinge is the stile's front corner (so a leaf folds flat against the wall); closed, the
        # leaf stands far enough out for its louvers to clear the window behind it
        hinge = (hx, z + GAP + back + THICK)
        angles = [a] if leaves == 1 else [a, -a]  # a bifold folds back on itself
        for ang in angles:
            d = (sgn * math.cos(ang), math.sin(ang))
            n = (-sgn * math.sin(ang), math.cos(ang))
            _leaf(_Leaf(mesh, hinge, d, n), width, y0, y1, s)
            hinge = (hinge[0] + d[0] * (width + GAP), hinge[1] + d[1] * (width + GAP))
