"""Archwerks viewport drawing: dimension layouts (aw_dims) and grips, in aw_style.

Everything is projected to screen pixels first and drawn in 2D, so sizes stay
constant at any zoom and nothing hides behind the geometry.

Every line is clipped first: to the camera's near plane (a point behind the
camera projects to millions of pixels away, and dashing that line hung C4D) and
then to the visible frame. Labels, arrowheads and grips only draw where their
point is actually on screen.
"""
import math
import re

import c4d
from c4d import bitmaps

import aw_style as S

_labels = {}  # (text, role) -> (clip map, bitmap, width, height); the clip map owns the bitmap

# Where editable labels were last drawn, for the AW Edit Dimensions tool:
# [(base draw, owner object, [{"rect": (x0, y0, x1, y1), "edit": ..., "value": ..., "text": ...}])]
_hits = []


def _alive(*nodes):
    """True if every C4D node still exists. A view or object from a closed document
    is dead, and even comparing one raises ReferenceError."""
    try:
        return all(n is not None and n.IsAlive() for n in nodes)
    except ReferenceError:
        return False


def _record_hits(bd, owner, entries):
    global _hits
    try:
        _hits = [h for h in _hits if _alive(h[0], h[1]) and not (h[0] == bd and h[1] == owner)]
        if entries:
            _hits.append((bd, owner, entries))
    except Exception as e:  # bookkeeping must never stop the drawing
        print("Archwerks: dimension hit bookkeeping reset:", e)
        _hits = []


def clear_hits(bd, owner):
    """Forget an owner's labels in this view (it stopped drawing them)."""
    _record_hits(bd, owner, [])


def hit_test(bd, x, y):
    """(owner, entry) for the editable label under screen point (x, y) in this view,
    or None. Later-drawn labels win, as they sit on top."""
    for view, owner, entries in reversed(_hits):
        if not _alive(view, owner) or view != bd:
            continue
        for e in reversed(entries):
            x0, y0, x1, y1 = e["rect"]
            if x0 <= x <= x1 and y0 <= y <= y1:
                return owner, e
    return None


def _vec(rgb):
    return c4d.Vector(*rgb)


NEAR = 1.0       # cm in front of the camera; anything closer is not drawn (perspective only)
MARGIN = 60.0    # points beyond the frame still drawn, so lines leave the edge cleanly
MAX_DASHES = 400  # a dashed line never costs more than this, whatever happens


_ratio = None


def ratio():
    """The display's pixel ratio: 2 on Retina, 1 on a standard screen. Read once from
    C4D's own interface icons, which carry it. Viewport coordinates are physical
    pixels, so every size in aw_style (points) is multiplied by this."""
    global _ratio
    if _ratio is None:
        _ratio = 1.0
        try:
            icon = c4d.gui.GetIcon(c4d.Ocube)
            r = icon["bmp"].GetData(c4d.BASEBITMAP_DATA_GUIPIXELRATIO, None) if icon else None
            if r and r >= 1.0:
                _ratio = float(r)
        except Exception:
            pass
    return _ratio


def px(points):
    return points * ratio()


def perspective(bd):
    """True in a perspective view. The ortho views (Top, Right, Front...) put the
    camera anywhere, often at the origin, so "behind the camera" means nothing there."""
    return bd.GetProjection() == c4d.Pperspective


def behind(bd, world):
    """True when a world point is behind (or too close to) a perspective camera."""
    return perspective(bd) and bd.WC(world).z < NEAR


def _screen(bd, mg, p):
    v = bd.WS(mg * c4d.Vector(*p))
    return c4d.Vector(v.x, v.y, 0)


class _View:
    """One redraw's camera and frame, for clipping."""

    def __init__(self, bd, mg):
        self.bd, self.mg = bd, mg
        self.persp = perspective(bd)
        f = bd.GetFrame()
        m = px(MARGIN)
        self.x0, self.y0 = f["cl"] - m, f["ct"] - m
        self.x1, self.y1 = f["cr"] + m, f["cb"] + m

    def cam(self, p):
        return self.bd.WC(self.mg * c4d.Vector(*p))

    def behind(self, p):
        return self.persp and self.cam(p).z < NEAR

    def on_screen(self, p):
        """Screen point for a local point, or None if it is behind the camera or off the frame."""
        if self.behind(p):
            return None
        v = _screen(self.bd, self.mg, p)
        if not (self.x0 <= v.x <= self.x1 and self.y0 <= v.y <= self.y1):
            return None
        return v

    def segment(self, a, b):
        """(a, b, a_kept, b_kept) on screen for a local segment, clipped to the near
        plane and the frame; None when nothing of it is visible. a_kept / b_kept say
        whether that end is the real end (so an arrowhead there means something)."""
        a_kept = b_kept = True
        if self.persp:
            ca, cb = self.cam(a), self.cam(b)
            if ca.z < NEAR and cb.z < NEAR:
                return None
            if ca.z < NEAR:
                ca, a_kept = ca + (cb - ca) * ((NEAR - ca.z) / (cb.z - ca.z)), False
            elif cb.z < NEAR:
                cb, b_kept = cb + (ca - cb) * ((NEAR - cb.z) / (ca.z - cb.z)), False
            sa, sb = self.bd.CS(ca, False), self.bd.CS(cb, False)
        else:
            sa, sb = _screen(self.bd, self.mg, a), _screen(self.bd, self.mg, b)
        # Liang-Barsky clip to the frame
        dx, dy = sb.x - sa.x, sb.y - sa.y
        t0, t1 = 0.0, 1.0
        for pk, qk in ((-dx, sa.x - self.x0), (dx, self.x1 - sa.x), (-dy, sa.y - self.y0), (dy, self.y1 - sa.y)):
            if abs(pk) < 1e-9:
                if qk < 0:
                    return None
                continue
            r = qk / pk
            if pk < 0:
                if r > t1:
                    return None
                t0 = max(t0, r)
            else:
                if r < t0:
                    return None
                t1 = min(t1, r)
        a2 = c4d.Vector(sa.x + dx * t0, sa.y + dy * t0, 0)
        b2 = c4d.Vector(sa.x + dx * t1, sa.y + dy * t1, 0)
        return a2, b2, a_kept and t0 == 0.0, b_kept and t1 == 1.0


def _unit(v):
    n = math.hypot(v.x, v.y)
    return c4d.Vector(v.x / n, v.y / n, 0) if n > 1e-6 else c4d.Vector(1, 0, 0)


def _triangle(bd, tip, direction, length, half, rgb):
    d = _unit(direction)
    n = c4d.Vector(-d.y, d.x, 0)
    base = tip - d * length
    pts = [tip, base + n * half, base - n * half]
    bd.DrawPolygon(pts, [_vec(rgb)] * 3)
    return pts


ARC_STEP = math.radians(5)  # one straight piece of an angle arc per 5 degrees

# While a corner is being dragged and has lined up with other points: [(from, to)]
# in world space, drawn as dashed guides (aw_grab sets them, every drag move).
SNAP_GUIDES = []


def _mouse_down():
    bc = c4d.BaseContainer()
    if not c4d.gui.GetInputState(c4d.BFM_INPUT_MOUSE, c4d.BFM_INPUT_MOUSELEFT, bc):
        return False
    return bool(bc.GetInt32(c4d.BFM_INPUT_VALUE))


def draw_snap_guides(bd):
    """The dashed guides from a dragged corner to the points it lined up with; gone
    once the mouse is released."""
    if not SNAP_GUIDES:
        return
    if not _mouse_down():
        SNAP_GUIDES[:] = []
        return
    view = _View(bd, c4d.Matrix())
    bd.SetMatrix_Screen()
    bd.SetPen(_vec(S.ROLES["edit"]["line"]))
    for a, b in SNAP_GUIDES:
        seg = view.segment((a.x, a.y, a.z), (b.x, b.y, b.z))
        if seg:
            _dashed(bd, seg[0], seg[1])


def _draw_arc(bd, view, arc, rgb):
    """An arc on the floor round a corner: arc = (centre, radius, start angle, sweep)
    in the wall's plan (x, z), drawn as short clipped pieces with an arrowhead at
    each end where it is long enough on screen."""
    (cx, cy, cz), radius, a0, sweep = arc
    n = max(4, int(abs(sweep) / ARC_STEP) + 1)
    pts = [(cx + radius * math.cos(a0 + sweep * t / n), cy, cz + radius * math.sin(a0 + sweep * t / n))
           for t in range(n + 1)]
    bd.SetPen(_vec(rgb))
    screen = []
    for p, q in zip(pts, pts[1:]):
        seg = view.segment(p, q)
        if seg:
            bd.DrawLine2D(seg[0], seg[1])
            screen.append(seg)
    if len(screen) < 2 or len(screen) < n:  # partly off screen: no arrowheads on cut ends
        return
    alen, ahalf = px(S.ARROW_LEN), px(S.ARROW_HALF)
    first, last = screen[0], screen[-1]
    total = sum(math.hypot(b.x - a.x, b.y - a.y) for a, b, _k1, _k2 in screen)
    if total > 2 * alen + px(4):
        _triangle(bd, first[0], first[0] - first[1], alen, ahalf, rgb)
        _triangle(bd, last[1], last[1] - last[0], alen, ahalf, rgb)


def _dashed(bd, a, b):
    d = b - a
    total = math.hypot(d.x, d.y)
    if total < 1e-6:
        return
    u = d * (1.0 / total)
    dash = px(S.DASH)
    step = max(dash + px(S.DASH_GAP), total / MAX_DASHES)  # bounded, whatever the length
    t = 0.0
    while t < total:
        bd.DrawLine2D(a + u * t, a + u * min(t + dash, total))
        t += step


def _label(text, role):
    key = (text, role, ratio())
    if key not in _labels and len(_labels) > 500:  # typing makes a new label per keystroke; keep it bounded
        _labels.clear()
    if key not in _labels:
        style = S.ROLES[role]
        font = bitmaps.GeClipMap.GetDefaultFont(c4d.GE_FONT_DEFAULT_SYSTEM)
        size = px(S.LABEL_PT)  # rendered at the display's real resolution
        probe = bitmaps.GeClipMap()
        probe.Init(8, 8, 32)
        probe.BeginDraw()
        probe.SetFont(font, size)
        tw, th = probe.TextWidth(text), probe.TextHeight()
        probe.EndDraw()
        pad_x, pad_y = int(round(px(S.LABEL_PAD_X))), int(round(px(S.LABEL_PAD_Y)))
        w, h = tw + 2 * pad_x, th + 2 * pad_y
        cm = bitmaps.GeClipMap()
        cm.Init(w, h, 32)
        cm.BeginDraw()
        cm.SetFont(font, size)
        cm.SetDrawMode(c4d.GE_CM_DRAWMODE_COPY, c4d.GE_CM_SRC_MAX_OPACITY)
        cm.SetColor(0, 0, 0, 0)
        cm.FillRect(0, 0, w - 1, h - 1)
        def pill(rgb, inset):
            cm.SetColor(*(int(255 * c) for c in rgb), 255)
            x0, y0, x1, y1 = inset, inset, w - 1 - inset, h - 1 - inset
            d = y1 - y0
            cm.FillEllipse(x0, y0, x0 + d, y1)
            cm.FillEllipse(x1 - d, y0, x1, y1)
            cm.FillRect(x0 + d // 2, y0, x1 - d // 2, y1)

        if "ring" in style:  # an outline drawn as part of the pill, so it follows the rounded ends
            pill(style["ring"], 0)
            pill(style["pill"], max(1, int(round(px(S.EDIT_RING)))))
        else:
            pill(style["pill"], 0)
        r, g, b = (int(255 * c) for c in style["text"])
        cm.SetColor(r, g, b, 255)
        cm.TextAt(pad_x, pad_y, text)
        cm.EndDraw()
        _labels[key] = (cm, cm.GetBitmap(), w, h)
    return _labels[key]


def _draw_label(bd, at, text, role, anchor, out=None):
    """out: screen direction (unit) the label moves along, clear of its line."""
    _cm, bmp, w, h = _label(text, role)
    off = px(S.LABEL_OFFSET)
    if out is not None:
        reach = abs(out.x) * w / 2 + abs(out.y) * h / 2 + off
        x0, y0 = at.x + out.x * reach - w / 2, at.y + out.y * reach - h / 2
    elif anchor == "above":
        x0, y0 = at.x - w / 2, at.y - off - h
    elif anchor == "above_right":
        x0, y0 = at.x + off, at.y - off - h
    elif anchor == "right":
        x0, y0 = at.x + off, at.y - h / 2
    else:
        x0, y0 = at.x - w / 2, at.y - h / 2
    x0, y0 = round(x0), round(y0)  # whole pixels keep the text crisp
    pts = [c4d.Vector(x0, y0, 0), c4d.Vector(x0 + w, y0, 0),
           c4d.Vector(x0 + w, y0 + h, 0), c4d.Vector(x0, y0 + h, 0)]
    uvs = [c4d.Vector(0, 0, 0), c4d.Vector(1, 0, 0), c4d.Vector(1, 1, 0), c4d.Vector(0, 1, 0)]
    bd.DrawTexture(bmp, pts, [c4d.Vector(1)] * 4, [c4d.Vector(0, 0, -1)] * 4, uvs, 4,
                   c4d.DRAW_ALPHA_NORMAL, c4d.DRAW_TEXTUREFLAGS_0)
    return (x0, y0, x0 + w, y0 + h)


# Decimals shown per display unit, so a dragged 117.9045 cm reads "117.9 cm" and
# 400 cm in inches reads "157.48 in", not "157.4803 in".
DECIMALS = {"mm": 0, "cm": 1, "m": 2, "km": 3, "in": 2, '"': 2, "ft": 2, "'": 2, "yd": 2, "mi": 3}


def fmt_length(value):
    """A length in the document's display unit, rounded for that unit."""
    try:
        text = c4d.utils.FormatNumber(value, c4d.FORMAT_METER, 0)
    except Exception:  # a formatting failure must not stop the rest of the drawing
        return "%g cm" % round(value, 1)
    m = re.match(r"^\s*(-?[0-9]+(?:[.,][0-9]+)?)\s*(.*?)\s*$", text)
    if not m:
        return text  # a composite format (feet and inches), shown as C4D gives it
    number, unit = float(m.group(1).replace(",", ".")), m.group(2)
    shown = ("%.*f" % (DECIMALS.get(unit, 2), number)).rstrip("0").rstrip(".") or "0"
    return "%s %s" % (shown, unit) if unit else shown


def label_text(dim):
    """The text a dimension shows: "400 cm", or "120 x 140 cm" for an opening."""
    if dim["kind"] in ("slope", "angle"):
        return ("%.1f" % dim["value"]).rstrip("0").rstrip(".") + "\u00b0"
    if dim["kind"] == "count":
        return "%d beams" % int(round(dim["value"]))
    if dim["kind"] == "segno":  # a Segment Overrides number
        return "Segment %d" % int(dim["value"])
    if dim["kind"] == "rise":
        text = fmt_length(abs(dim["value"]))
        return ("-" if dim["value"] < -1e-6 else "+") + text
    if dim["kind"] == "opening":
        w, h = dim["size"]
        unit_h = fmt_length(h)
        unit = unit_h.lstrip("0123456789.,- ")  # the unit suffix, shown once
        w_text = fmt_length(w)
        if unit and w_text.endswith(unit):
            w_text = w_text[: -len(unit)].rstrip()
        return "%s x %s" % (w_text, unit_h)
    return fmt_length(dim["value"])


def draw_layout(bd, mg, layout, _unused_label=None, owner=None):
    """Draw an aw_dims layout. Grips only show while the wall itself is selected,
    which is exactly when there is no focus outline; ends that carry a grip then
    get no arrowhead, so the two never overlap.

    Not while C4D is picking: everything drawn in the object pass counts as the object in
    its pick buffer, so a selected cabinet's labels over its neighbours made a click on a
    neighbour pick it again (the Move tool couldn't select the next cabinet)."""
    if bd.GetDrawParam(c4d.BASEDRAW_IS_PICK_OBJECT):
        return
    grips_shown = layout.get("grips", not layout.get("outline"))
    view = _View(bd, mg)
    bd.SetMatrix_Screen()

    for ext in layout["ext"]:
        seg = view.segment(ext["a"], ext["b"])
        if seg:
            bd.SetPen(_vec(S.ROLES[ext["role"]]["ext"]))
            _dashed(bd, seg[0], seg[1])

    if layout.get("outline"):
        bd.SetPen(_vec(S.ROLES[layout.get("outline_role", "focus")]["line"]))
        pts = layout["outline"]
        for k in range(4):
            seg = view.segment(pts[k], pts[(k + 1) % 4])
            if seg:
                bd.DrawLine2D(seg[0], seg[1])
    if layout.get("edges"):  # an outline as lines (a cabinet's whole box)
        bd.SetPen(_vec(S.ROLES[layout.get("outline_role", "focus")]["line"]))
        for a, b in layout["edges"]:
            seg = view.segment(a, b)
            if seg:
                bd.DrawLine2D(seg[0], seg[1])

    labels = []
    for dim in layout["dims"]:
        role = dim["role"]
        if dim.get("arc"):  # a corner's angle: an arc between its walls, arrowheads at both ends
            _draw_arc(bd, view, dim["arc"], S.ROLES[role]["line"])
        if dim["kind"] in ("opening", "slope", "angle", "count", "segno"):  # a label on its own, no line
            at = view.on_screen(dim["a"])
            if at is not None:
                labels.append((at, label_text(dim), role, dim.get("anchor", "centre"), None,
                               dim if dim.get("edit") else None))
            continue
        seg = view.segment(dim["a"], dim["b"])
        if not seg:
            continue
        a, b, a_kept, b_kept = seg
        rgb = S.ROLES[role]["line"]
        bd.SetPen(_vec(rgb))
        bd.DrawLine2D(a, b)
        span = math.hypot(b.x - a.x, b.y - a.y)
        skip = dim.get("grips", ()) if grips_shown else ()
        alen, ahalf = px(S.ARROW_LEN), px(S.ARROW_HALF)
        if span > 2 * alen + px(4):  # arrowheads only where they fit, at real ends
            if "a" not in skip and a_kept:
                _triangle(bd, a, a - b, alen, ahalf, rgb)
            if "b" not in skip and b_kept:
                _triangle(bd, b, b - a, alen, ahalf, rgb)
        m3 = [(p + q) / 2 for p, q in zip(dim["a"], dim["b"])]
        mid = view.on_screen(m3)
        if mid is None:  # the label belongs at the true middle; skip it when that is off screen
            continue
        out = None
        if dim.get("out"):  # the outer side, as it falls on screen from this view
            tip = _screen(bd, mg, [c + 10.0 * o for c, o in zip(m3, dim["out"])])
            out = _unit(tip - mid)
        labels.append((mid, label_text(dim), role, "above" if dim["axis"] == "x" else "right", out, dim))

    hits = []
    for at, text, role, anchor, out, dim in labels:  # labels last, on top of every line
        rect = _draw_label(bd, at, text, role, anchor, out)
        if dim is not None and dim.get("edit"):
            hits.append({"rect": rect, "edit": dim["edit"], "value": dim["value"], "text": text,
                         "kind": dim["kind"]})
    if owner is not None:
        _record_hits(bd, owner, hits)
    draw_snap_guides(bd)


def find_entry(bd, owner, edit, kind):
    """The current hit entry for a label (it moves as the view or model changes), or None."""
    for view, own, entries in _hits:
        if _alive(view, own) and view == bd and own == owner:
            for e in entries:
                if e["edit"] == edit and e["kind"] == kind:
                    return e
    return None


def draw_edit_label(bd, rect, text):
    """A label being typed into, drawn over its normal pill at rect (x0, y0, x1, y1):
    the same pill with the typed text, a cursor and its own orange outline."""
    bd.SetMatrix_Screen()
    centre = c4d.Vector((rect[0] + rect[2]) / 2, (rect[1] + rect[3]) / 2, 0)
    _draw_label(bd, centre, text, "edit", "centre")


def draw_grips(bd, mg, grips, hot=-1, role="wall", kinds=None):
    """grips: [(local position, local direction), ...]; hot: the index under the mouse;
    role "wall" (amber) or "focus" (orange, for an opening's own grips); kinds: per
    grip "arrow" (one way) or "move" (a double arrow that slides along its line)."""
    colour, colour_hot = (S.FOCUS_GRIP, S.FOCUS_GRIP_HOT) if role == "focus" else (S.GRIP, S.GRIP_HOT)
    view = _View(bd, mg)
    bd.SetMatrix_Screen()
    for i, (pos, direction) in enumerate(grips):
        if kinds and i < len(kinds) and kinds[i] == "hidden":  # upright, seen from above: not drawn
            continue
        p = view.on_screen((pos.x, pos.y, pos.z))
        tip3 = (pos.x + direction.x * 10, pos.y + direction.y * 10, pos.z + direction.z * 10)
        if p is None or view.behind(tip3):  # off screen or behind the camera: nothing to grab
            continue
        d = _unit(_screen(bd, mg, tip3) - p)
        rgb = colour_hot if i == hot else colour
        glen, ghalf = px(S.GRIP_LEN), px(S.GRIP_HALF)
        if kinds and i < len(kinds) and kinds[i] == "corner":  # moves anywhere on the floor: a diamond
            r = glen * 0.5
            pts = [p + c4d.Vector(0, -r, 0), p + c4d.Vector(r, 0, 0), p + c4d.Vector(0, r, 0), p + c4d.Vector(-r, 0, 0)]
            bd.DrawPolygon(pts, [_vec(rgb)] * 4)
            shapes = [pts]
        elif kinds and i < len(kinds) and kinds[i] == "move":
            gap = px(1.5)
            shapes = [_triangle(bd, p + d * (gap + glen * 0.8), d, glen * 0.8, ghalf, rgb),
                      _triangle(bd, p - d * (gap + glen * 0.8), d * -1, glen * 0.8, ghalf, rgb)]
        else:
            shapes = [_triangle(bd, p + d * (glen / 2), d, glen, ghalf, rgb)]
        bd.SetPen(_vec(S.GRIP_EDGE))
        for pts in shapes:
            for k in range(len(pts)):
                bd.DrawLine2D(pts[k], pts[(k + 1) % len(pts)])


def draw_measure(bd, a, b, text):
    """AW Scale Plan's measuring line between world points a and b: a solid edit-
    orange line with end ticks and its length in a pill above the middle. Returns
    the pill's rect, or None."""
    view = _View(bd, c4d.Matrix())
    bd.SetMatrix_Screen()
    seg = view.segment((a.x, a.y, a.z), (b.x, b.y, b.z))
    if not seg:
        return None
    sa, sb = seg[0], seg[1]
    rgb = S.ROLES["edit"]["line"]
    bd.SetPen(_vec(rgb))
    bd.DrawLine2D(sa, sb)
    d = _unit(sb - sa)
    tick = c4d.Vector(-d.y, d.x, 0) * px(S.GRIP_HALF)
    for p in (sa, sb):
        bd.DrawLine2D(p - tick, p + tick)
    mid = (sa + sb) * 0.5
    return _draw_label(bd, mid, text, "focus", "above")
