"""aw_roofdims for Cinema 4D: the parts of core/aw_roofdims.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_roofdims  # noqa: F401
from aw_roofdims import *  # noqa: F401,F403


def own_splines(op):
    """The roof's own editable splines (plain Spline objects, not its cutters), as
    layout() takes them."""
    import c4d
    out = []
    for idx, child in enumerate(op.GetChildren()):
        if child.GetType() != c4d.Ospline or not child.GetDeformMode():
            continue
        if child.GetSegmentCount() > 1:
            continue  # several segments in one spline: edit those with the point tools
        ml = child.GetMl()
        pts = [ml * p for p in child.GetAllPoints()]
        out.append({"child": idx, "pts": [(p.x, p.y, p.z) for p in pts], "closed": bool(child.IsClosed()),
                    "linear": child.GetInterpolationType() == c4d.SPLINETYPE_LINEAR})
    return out


def roof_layout(op, meta):
    """(layout, grips) for a built roof in its own space, or (None, [])."""
    if not meta or not meta.get("pieces"):
        return None, []
    to_local = meta["to"]

    def to(p):
        import c4d
        v = to_local * c4d.Vector(*p)
        return (v.x, v.y, v.z)
    splines = own_splines(op) if meta.get("source") == "own" else []
    return layout(meta, splines, to)


def set_grip(op, meta, i, p):
    """Grip i of the roof (as roof_layout lists them) dragged to p (roof space)."""
    import c4d
    import aw_ids as I
    _lay, grips = roof_layout(op, meta)
    if not 0 <= i < len(grips):
        return
    pos, d, _kind, act = grips[i]
    if "point" in act:
        child_i, k = act["point"]
        child = op.GetChildren()[child_i]
        inv = ~child.GetMl()
        old = child.GetPoint(k)
        local = inv * c4d.Vector(p.x, 0, p.z)
        child.SetPoint(k, c4d.Vector(local.x, old.y, local.z))
        child.Message(c4d.MSG_UPDATE)
        return
    a = act["from"]
    L = math.sqrt(sum(c * c for c in d)) or 1.0
    value = sum((pc - ac) * dc / L for pc, ac, dc in zip((p.x, p.y, p.z), a, d))
    pid = {"eave": I.AW_ROOF_EAVE, "rake": I.AW_ROOF_RAKE, "width_l": I.AW_ROOF_WIDTH_L,
           "width_r": I.AW_ROOF_WIDTH_R}[act["set"]]
    op[pid] = max(value, 1.0 if act["set"].startswith("width") else 0.0)


def set_cutter_grip(op, i, p):
    import aw_ids as I
    if i == 0:
        op[I.AW_RCUT_WIDTH] = max(2 * abs(p.x), 0.1)
    else:
        op[I.AW_RCUT_LENGTH] = max(2 * abs(p.z), 0.1)


def apply(doc, op, edit, value):
    """A value typed into one of a roof's (or cutter's) labels. Returns what changed,
    or raises ValueError (nothing changes)."""
    import c4d
    import aw_ids as I
    do = edit["do"]

    def change(obj):
        if doc is not None:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
    if do == "roof_pitch":
        pitch = pitch_for(value, edit.get("scale", 1.0))
        change(op)
        op[I.AW_ROOF_PITCH] = math.radians(pitch)
        if op[I.AW_ROOF_PITCH_FROM_WALLS]:
            op[I.AW_ROOF_PITCH_FROM_WALLS] = False  # a typed pitch wins over the walls'
        return "roof pitch"
    if do in ("roof_eave", "roof_rake"):
        if value < 0:
            raise ValueError("can't be less than 0")
        change(op)
        op[I.AW_ROOF_EAVE if do == "roof_eave" else I.AW_ROOF_RAKE] = value
        return do[5:] + " overhang"
    if do in ("roof_width_l", "roof_width_r"):
        if value < 1.0:
            raise ValueError("must be at least 1 cm")
        change(op)
        op[I.AW_ROOF_WIDTH_L if do == "roof_width_l" else I.AW_ROOF_WIDTH_R] = value
        return "axis width"
    if do == "roof_side":
        kids = op.GetChildren()
        if not 0 <= edit["child"] < len(kids) or kids[edit["child"]].GetType() != c4d.Ospline:
            raise ValueError("that spline changed; select the roof again")
        sp = kids[edit["child"]]
        ml = sp.GetMl()
        pts = [ml * p for p in sp.GetAllPoints()]
        moved = move_side([(p.x, p.y, p.z) for p in pts], bool(sp.IsClosed()), edit["k"], value)
        inv = ~ml
        change(sp)
        for i, q in enumerate(moved):
            sp.SetPoint(i, inv * c4d.Vector(*q))
        sp.Message(c4d.MSG_UPDATE)
        return "side %d" % (edit["k"] + 1)
    if do in ("cut_width", "cut_length"):
        if value <= 0:
            raise ValueError("must be more than 0")
        change(op)
        op[I.AW_RCUT_WIDTH if do == "cut_width" else I.AW_RCUT_LENGTH] = value
        return do.replace("_", " ")
    raise ValueError("unknown edit %r" % do)
