"""The mesh every Archwerks object is built into: welded points, quads, named
polygon groups, UVs and per-point tints. Host-neutral: a host (aw_host.mesh_object)
turns a finished builder into its own object (Cinema 4D: a PolygonObject with
selection tags; Blender: a mesh with material slots).
"""
import math

import aw_host
from aw_vec import Vec

UV_TILE = 100.0  # cm per UV tile, so materials tile once per metre
TINT_TAG = "Tint"  # the colour a tinting material reads (a vertex colour tag, a colour attribute)


class MeshBuilder:
    """Collects welded points and quads, sorted into named polygon selections."""

    def __init__(self, groups):
        self.points = []
        self.polys = []
        self.groups = {name: [] for name in groups}
        self.uvs = []  # per quad: four (u, v) in cm, or None to project the face
        self.tags = []  # per point: what made it (for build-on animation), or None
        self._index = {}
        self.tints = {}  # point index -> (r, g, b): written as a vertex colour tag, TINT_TAG (others white)
        self.optional = set()  # groups a host leaves out when empty (a wall's Segment Overrides)

    def new_part(self):
        """Start a separate part: later points never weld to earlier ones."""
        self._index = {}

    def pt(self, x, y, z, tag=None, seam=None):
        """Index of the point at (x, y, z), reusing an existing one so the mesh is welded.
        tag: kept with a new point (the first one to make it wins). seam: points with a
        different seam never weld, even at the same place."""
        key = (round(x, 4), round(y, 4), round(z, 4), seam)
        if key not in self._index:
            self._index[key] = len(self.points)
            self.points.append(Vec(x, y, z))
            self.tags.append(tag)
        return self._index[key]

    def quad(self, a, b, c, d, group, uv=None):
        """uv: four (u, v) in cm for the corners, e.g. distance along a wall and height,
        so a texture runs continuously round corners; None projects the face instead."""
        self.groups[group].append(len(self.polys))
        self.polys.append((a, b, c, d))
        self.uvs.append(uv)

    def box(self, x0, x1, y0, y1, z0, z1, group):
        """A closed box, welded within itself but not to anything else, so separate
        parts (frame members, sashes) stay separate solids. Faces wind like the
        wall's, so every normal points out."""
        if x1 - x0 < 1e-4 or y1 - y0 < 1e-4 or z1 - z0 < 1e-4:
            return
        self.hexa({(i, j, k): ((x0, x1)[i], (y0, y1)[j], (z0, z1)[k])
                   for i in (0, 1) for j in (0, 1) for k in (0, 1)}, group)

    def frustum(self, x0, x1, y0, y1, z0, z1, inset0, inset1, group):
        """A box whose z0 face is inset by inset0 and z1 face by inset1 on every side:
        a chamfered (raised) panel half. Closed, like box."""
        if x1 - x0 < 1e-4 or y1 - y0 < 1e-4 or z1 - z0 < 1e-4:
            return
        def corner(i, j, k):
            d = (inset0, inset1)[k]
            return ((x0 + d, x1 - d)[i], (y0 + d, y1 - d)[j], (z0, z1)[k])
        self.hexa({(i, j, k): corner(i, j, k) for i in (0, 1) for j in (0, 1) for k in (0, 1)}, group)

    def hexa(self, c, group):
        """A closed six-sided solid from its corners c[(i, j, k)] (i along x, j along y,
        k along z, 0 low 1 high), wound as box."""
        own = {}

        def p(key):
            xyz = c[key]
            if xyz not in own:
                own[xyz] = len(self.points)
                self.points.append(Vec(*xyz))
                self.tags.append(None)
            return own[xyz]

        q = self.quad
        q(p((0, 0, 0)), p((0, 1, 0)), p((1, 1, 0)), p((1, 0, 0)), group)  # -Z
        q(p((1, 0, 1)), p((1, 1, 1)), p((0, 1, 1)), p((0, 0, 1)), group)  # +Z
        q(p((0, 0, 1)), p((0, 1, 1)), p((0, 1, 0)), p((0, 0, 0)), group)  # -X
        q(p((1, 0, 0)), p((1, 1, 0)), p((1, 1, 1)), p((1, 0, 1)), group)  # +X
        q(p((0, 0, 0)), p((1, 0, 0)), p((1, 0, 1)), p((0, 0, 1)), group)  # -Y
        q(p((0, 1, 1)), p((1, 1, 1)), p((1, 1, 0)), p((0, 1, 0)), group)  # +Y

    def lathe(self, profile, to_world, group, segments=24):
        """A closed solid of revolution: profile is [(r, h)] from one end of the axis to
        the other (r 0 at both ends, so it closes), spun round the local h axis;
        to_world(x, y, h) places each local point. Wound so its normals point out,
        however to_world turns or mirrors it."""
        first, own = len(self.polys), {}

        def p(i, k):
            r, h = profile[i]
            key = (i, 0) if r <= 1e-6 else (i, k % segments)
            if key not in own:
                a = 2 * math.pi * k / segments
                own[key] = len(self.points)
                self.points.append(Vec(*to_world(r * math.cos(a), r * math.sin(a), h)))
                self.tags.append(None)
            return own[key]
        for i in range(len(profile) - 1):
            for k in range(segments):
                a, b, c, d = p(i, k), p(i, k + 1), p(i + 1, k + 1), p(i + 1, k)
                if a == b:
                    self.quad(a, c, d, d, group)
                elif c == d:
                    self.quad(a, b, c, c, group)
                else:
                    self.quad(a, b, c, d, group)
        self._face_out(first)

    def add_mesh(self, points, polys, to_world, group):
        """Someone else's polygons (points, [(a, b, c, d)], d == c for a triangle), placed
        by to_world(x, y, z) and wound so they face out as they did."""
        base, first = len(self.points), len(self.polys)
        for v in points:
            self.points.append(Vec(*to_world(v.x, v.y, v.z)))
            self.tags.append(None)
        for a, b, c, d in polys:
            self.quad(base + a, base + b, base + c, base + d, group)
        if points:  # a mirroring placement turns the faces inside out: turn them back
            o = Vec(*to_world(0, 0, 0))
            ex = Vec(*to_world(1, 0, 0)) - o
            ey = Vec(*to_world(0, 1, 0)) - o
            ez = Vec(*to_world(0, 0, 1)) - o
            if ex.Cross(ey).Dot(ez) < 0:
                self._reverse(first)

    def _volume(self, first):
        v = 0.0
        for a, b, c, d in self.polys[first:]:
            pa, pb, pc, pd = (self.points[k] for k in (a, b, c, d))
            v += pa.Dot(pb.Cross(pc))
            if c != d:
                v += pa.Dot(pc.Cross(pd))
        return v

    def _reverse(self, first):
        for n in range(first, len(self.polys)):
            a, b, c, d = self.polys[n]
            self.polys[n] = (a, c, b, b) if c == d else (a, d, c, b)

    def _face_out(self, first):
        """Make the faces from first on wind as box's do (normals out)."""
        if self._volume(first) * _box_sign() < 0:
            self._reverse(first)

    def face_uvs(self):
        """Per quad, four (u, v) in UV tiles: its own, or (none given) the face projected
        onto the plane it faces most, so a texture is one metre to a tile."""
        out = []
        for n, quad in enumerate(self.polys):
            if self.uvs[n] is not None:
                out.append([(u / UV_TILE, -v / UV_TILE) for u, v in self.uvs[n]])
                continue
            p = [self.points[k] for k in quad]
            normal = (p[1] - p[0]).Cross(p[3] - p[0])
            axis = max(range(3), key=lambda k: abs((normal.x, normal.y, normal.z)[k]))
            uv = []
            for v in p:
                u, w = {0: (v.z, v.y), 1: (v.x, v.z), 2: (v.x, v.y)}[axis]
                uv.append((u / UV_TILE, -w / UV_TILE))
            out.append(uv)
        return out

    def build(self, name):
        """The host's object for this mesh, named name (after any deforming() in force has
        moved its points: a window's build-on)."""
        for fn in list(_DEFORM):
            if fn is not None:
                fn(self)
        return aw_host.mesh_object(self, name)


_DEFORM = []  # fn(builder) each mesh built inside deforming() passes through, in order


class deforming:
    """with deforming(fn): every mesh built inside has fn(builder) move its points first
    (fn None: nothing). How a window's build-on reaches its mesh in either host."""

    def __init__(self, fn):
        self.fn = fn

    def __enter__(self):
        _DEFORM.append(self.fn)

    def __exit__(self, *_exc):
        _DEFORM.pop()


_BOX_SIGN = []


def _box_sign():
    """The sign of a box's signed volume as MeshBuilder winds it: the outward one."""
    if not _BOX_SIGN:
        m = MeshBuilder(("x",))
        m.box(0, 1, 0, 1, 0, 1, "x")
        _BOX_SIGN.append(1.0 if m._volume(0) > 0 else -1.0)
    return _BOX_SIGN[0]
