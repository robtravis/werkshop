"""aw_railing for Cinema 4D: the parts of core/aw_railing.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_groups_c4d
import aw_railing  # noqa: F401
import aw_stair_c4d
from aw_railing import *  # noqa: F401,F403
from aw_railing import _alive


def change_key(op):
    import c4d
    import aw_ids as I
    stair, prof = op[I.AW_RAIL_STAIR], op[I.AW_RAIL_HANDRAIL_PROFILE]
    skey = None
    if _alive(stair):
        m = ~op.GetMg() * stair.GetMg()
        skey = (aw_stair_c4d.change_key(stair), tuple(round(x, 4) for vec in (m.off, m.v1, m.v2, m.v3) for x in (vec.x, vec.y, vec.z)))
    pkey = prof.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_CACHE) if _alive(prof) else None
    kids = tuple((k.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX | c4d.DIRTYFLAGS_CACHE), k.GetDeformMode())
                 for k in op.GetChildren() if k.GetInfo() & c4d.OBJECT_ISSPLINE)
    return (op.GetName(), op.GetDirty(c4d.DIRTYFLAGS_DATA), skey, pkey, kids)


def add_for_selection(doc, preset=None):
    """Panel: a preset (or the Railing default) for what is selected: railings take
    the preset; each selected Stair gets a railing on both sides; each selected spline
    a fence along it (moved under it); with nothing selected, a fence to draw with
    the Spline Pen. One undo step. Returns the railings."""
    import c4d
    import aw_floor
    import aw_ids as I
    import aw_materials
    import aw_panel
    import aw_slab
    import aw_slab_c4d
    sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
    rails = [o for o in sel if o.GetType() == I.ID_AW_RAILING]
    stairs = [o for o in sel if o.GetType() == I.ID_AW_STAIR]
    splines = aw_panel.selected_splines(doc)
    doc.StartUndo()
    made = []
    if rails and preset is not None:
        for r in rails:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, r)
            apply_preset(r, preset)
        doc.EndUndo()
        c4d.EventAdd()
        return rails

    def new(name, after=None):
        r = c4d.BaseObject(I.ID_AW_RAILING)
        r.SetName(aw_slab_c4d.next_name(doc, name))
        if after is None:
            doc.InsertObject(r)
        else:
            doc.InsertObject(r, after.GetUp(), after)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, r)
        if preset is not None:
            apply_preset(r, preset)
        aw_materials.apply_defaults(doc, r)
        aw_groups_c4d.file(doc, r)  # into its group: null and layer (aw_groups_c4d)
        made.append(r)
        return r
    if stairs:
        for st in stairs:
            r = new("Railing", st)
            r[I.AW_RAIL_STAIR] = st
            r[I.AW_RAIL_SIDE] = SIDE_BOTH
            r.SetMg(c4d.Matrix(st.GetMg()))
    elif splines:
        for sp in splines:
            r = new("Fence", sp)
            mg = sp.GetMg()
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, sp)
            sp.Remove()
            sp.InsertUnderLast(r)
            sp.SetMg(mg)
    else:
        r = new("Fence")
        spline = c4d.SplineObject(0, c4d.SPLINETYPE_LINEAR)
        spline.SetName(aw_panel.RUN_NAME % 1)
        spline.InsertUnder(r)
        doc.EndUndo()
        doc.SetActiveObject(spline, c4d.SELECTION_NEW)
        aw_panel._arm_pen(doc, r, spline)
        c4d.gui.StatusSetText("Draw the fence: click each post's place; close it to go all the way round")
        c4d.EventAdd()
        return made
    doc.EndUndo()
    doc.SetActiveObject(made[0], c4d.SELECTION_NEW)
    c4d.EventAdd()
    return made
