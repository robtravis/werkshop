"""Archwerks groups in Cinema 4D (core/aw_groups): an Archwerks null with a null per group
under it (Walls, Trim, Floors...), the tree Blender's collections give, and a layer per
group under an Archwerks layer, for the switches a collection has (visible, render,
locked, solo). Nulls stay at the origin, so filing an object under one never moves it.

file() puts a new object in its group, within its creator's undo step. Openings, roof
cutters and sinks stay under their wall, roof or countertop and only take the layer; an
object you moved under a null of your own is left where it is. watch() catches what
Cinema 4D's own menus made (filed on the next scene change), and tidy() sorts a whole
scene, an older file say, into the same layout as one undo step.

The nulls and layers are found again by a mark in their container (renamed, still the
same group), else by their name, else made.
"""
import c4d

import aw_groups as G
import aw_ids as I

MARK = I.ID_AW_WATCHER  # a container id of ours: a group null's or layer's key, an object's filed flag
FILED = "filed"
_seen_docs = set()  # documents whose objects were there before the plugin looked: never moved unasked


def _marked(obj):
    bc = obj.GetDataInstance()
    return bc.GetString(MARK) if bc is not None else ""


def _mark(obj, key):
    obj.GetDataInstance().SetString(MARK, key)


def _walk(first):
    stack = [first] if first is not None else []
    while stack:
        o = stack.pop()
        while o:
            yield o
            if o.GetDown():
                stack.append(o.GetDown())
            o = o.GetNext()


def _null(doc, key, name, parent, undo):
    for o in _walk(doc.GetFirstObject()):
        if o.GetType() == c4d.Onull and _marked(o) == key:
            return o
    under = parent.GetDown() if parent is not None else doc.GetFirstObject()
    while under:
        if under.GetType() == c4d.Onull and under.GetName() == name and not _marked(under):
            _mark(under, key)
            return under
        under = under.GetNext()
    null = c4d.BaseObject(c4d.Onull)
    null.SetName(name)
    _mark(null, key)
    if parent is None:
        doc.InsertObject(null)
    else:
        null.InsertUnderLast(parent)
    if undo:
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, null)
    return null


def root(doc, undo=True):
    return _null(doc, "root", G.ROOT, None, undo)


def group_null(doc, key, undo=True):
    name = G.BY_KEY[key][0]
    return _null(doc, key, name, root(doc, undo), undo)


def _layers(first):
    return _walk(first)


def layer(doc, key, undo=True):
    """The group's layer, under an Archwerks layer, coloured as the group."""
    top = doc.GetLayerObjectRoot()
    parent = None
    for want, name in (("root", G.ROOT), (key, G.BY_KEY[key][0])):
        found = next((lay for lay in _layers(top.GetDown()) if _marked(lay) == want), None)
        if found is None:
            first = parent.GetDown() if parent is not None else top.GetDown()
            found = next((lay for lay in _layers(first) if lay.GetName() == name and not _marked(lay)
                          and lay.GetUp() == parent), None)
        if found is None:
            found = c4d.documents.LayerObject()
            found.SetName(name)
            found.InsertUnderLast(parent if parent is not None else top)
            if undo:
                doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, found)
            found[c4d.ID_LAYER_COLOR] = c4d.Vector(*G.BY_KEY[want][2]) if want != "root" else c4d.Vector(0.5)
        if not _marked(found):
            _mark(found, want)
        parent = found
    return parent


def _key_of(op):
    import aw_desc
    kind = op.GetType()
    ceiling = False
    if kind == I.ID_AW_SLAB:
        import aw_slab
        ceiling = int(aw_desc.value(op, I.AW_SLAB_TYPE) or 0) == aw_slab.CEILING
    return G.group_of(kind, ceiling)


def _ours(obj):
    return obj is not None and obj.GetType() == c4d.Onull and _marked(obj) in [k for k, *_r in G.GROUPS] + ["root"]


def file(doc, op, undo=True):
    """op (just made, in the document) into its group: its layer, and unless it lives
    under another Archwerks object or a null of yours, under its group's null."""
    if op is None or op.GetType() not in G.KIND_GROUP and op.GetType() != I.ID_AW_SLAB:
        return
    key = _key_of(op)
    lay = layer(doc, key, undo)
    if undo:
        doc.AddUndo(c4d.UNDOTYPE_CHANGE, op)
    op.SetLayerObject(lay)
    _mark(op, FILED)
    up = op.GetUp()
    if op.GetType() in G.NESTED or (up is not None and not _ours(up)):
        return  # a window in its wall, a sink in its countertop, or somewhere you put it
    target = group_null(doc, key, undo)
    if up == target:
        return
    mg = op.GetMg()
    op.Remove()
    op.InsertUnderLast(target)
    op.SetMg(mg)


def _doc_id(doc):
    """A lasting identity for doc (Cinema 4D hands Python a new wrapper on every call)."""
    u = doc.FindUniqueID(c4d.MAXON_CREATOR_ID)
    return bytes(u) if u is not None else (doc.GetDocumentPath(), doc.GetDocumentName())


def _archwerks(doc):
    return [o for o in _walk(doc.GetFirstObject()) if o.GetType() in G.KIND_GROUP or o.GetType() == I.ID_AW_SLAB]


def watch(doc):
    """On a scene change: file what appeared since the last look (Cinema 4D's own Create
    menu, a paste), as one undo step. A document seen for the first time only has its
    objects marked: what was already there stays where it is (tidy() sorts it)."""
    if doc is None:
        return
    ident = _doc_id(doc)
    objs = _archwerks(doc)
    if ident not in _seen_docs:
        _seen_docs.add(ident)
        for o in objs:
            if _marked(o) != FILED:
                _mark(o, FILED)
        return
    new = [o for o in objs if _marked(o) != FILED]
    if not new:
        return
    doc.StartUndo()
    for o in new:
        file(doc, o)
    doc.EndUndo()
    c4d.EventAdd()


def tidy(doc):
    """Every Archwerks object in doc into its group (the Archwerks panel's Tidy), as one
    undo step: openings and the like stay in their parents; your own nulls are left as
    they are. Returns how many it filed."""
    objs = _archwerks(doc)
    doc.StartUndo()
    for o in objs:
        file(doc, o)
    doc.EndUndo()
    c4d.EventAdd()
    return len(objs)
