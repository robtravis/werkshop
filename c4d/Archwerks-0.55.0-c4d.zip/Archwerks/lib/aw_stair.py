"""Archwerks stairs: straight, L and U with landings, or along a spline.

Every stair is laid out along its walking line, a path in plan from the foot of
the stair to the top: Straight (one line), L (a quarter turn at a landing), U (a
half turn: two quarter turns and one landing between the flights, Gap apart) or
Spline (the stair's own open child spline, curves and all). The stair is Width
wide, centred on the line, climbing from the object's floor (y 0) to Height.

Height is climbed in equal risers: Steps of them, or (Steps 0) as few as keep each
under Max Riser. The first riser stands at the start of the line, the last one at
its end (the upper floor is the last tread), so there are Steps - 1 treads between.
Each tread is a stretch of the line Going long (on a spline, the line shared out
evenly), level at its riser's height. Where the line turns sharply (30 degrees or
more) the stair turns on a landing: a level tread reaching far enough either side
of the turn to cover it. On L and U stairs Landing At sets how many steps come
before the landing (0: half way). On a spline the landing count is fixed by the
turns; on a gentle curve the steps fan round it (narrower on the inside).

Construction:
- Closed: every step a solid block, its face the riser, its underside Sloped (a
  Waist thick slab under the steps) or Solid (down to the floor).
- Open: treads only.
Both get tread boards Tread Thickness thick reaching Nosing past the step below.
Stringers: Sides or Centre, Thickness wide and Depth deep (square to them, the
same all along: across a landing they ramp up a riser, so the next flight carries
on without a jump). Side stringers at Spacing 0 stand at the edges and house the
treads between them, Above Nosing over the line of the nosings; at a Spacing
(centre to each stringer) they move in under full-width treads, which reach past
them, and are cut: a sawtooth, level under each tread. A Centre stringer is
always cut.

Built in the stair's own space, walking along +Z from the origin for the
parametric shapes. Plan points are (x, z); s is the distance along the walking
line; heights in cm.
"""
import math

import aw_host

STRAIGHT, L_SHAPE, U_SHAPE, SPLINE = 0, 1, 2, 3
SHAPE_NAMES = ("Straight", "L", "U", "Spline")
LEFT, RIGHT = 0, 1
CLOSED, OPEN = 0, 1
SLOPED, SOLID = 0, 1
NO_STRINGER, SIDE_STRINGERS, CENTRE_STRINGER = 0, 1, 2
GROUPS = ("Treads", "Risers", "Structure", "Stringers")
SHARP = math.radians(30.0)  # a turn at least this sharp gets a landing
MIN_STEPS = 2


def risers(height, steps, max_riser):
    """(count, riser height): Steps of them, or with Steps 0 the fewest that keep each
    riser no taller than Max Riser."""
    height = max(height, 1.0)
    if steps and steps >= MIN_STEPS:
        n = int(steps)
    else:
        n = max(MIN_STEPS, int(math.ceil(height / max(max_riser, 1.0) - 1e-9)))
    return n, height / n


class Line:
    """The walking line: a polyline in plan, its points (x, z)."""

    def __init__(self, pts):
        clean = [pts[0]]
        for p in pts[1:]:
            if math.dist(p, clean[-1]) > 1e-6:
                clean.append(p)
        self.pts = clean
        self.segs = []
        s = 0.0
        for a, b in zip(clean, clean[1:]):
            L = math.dist(a, b)
            d = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
            self.segs.append({"a": a, "d": d, "n": (-d[1], d[0]), "len": L, "s0": s})
            s += L
        self.total = s
        self.vs = [0.0] + [seg["s0"] + seg["len"] for seg in self.segs]  # s at each point

    def _seg(self, s, ahead):
        """The segment s lies on; at a point, the one after it (ahead) or before it."""
        for k, seg in enumerate(self.segs):
            lo, hi = seg["s0"], seg["s0"] + seg["len"]
            if (lo - 1e-9 <= s < hi - 1e-9) if ahead else (lo + 1e-9 < s <= hi + 1e-9):
                return k
        return 0 if s <= 0 else len(self.segs) - 1

    def side(self, s, off, ahead=True):
        """The point off to the left of the line (negative: right) square across from s;
        on the inside of a turn, never past the corner where the offset lines meet."""
        k = self._seg(s, ahead)
        seg = self.segs[k]
        t = s - seg["s0"]
        p = (seg["a"][0] + seg["d"][0] * t + seg["n"][0] * off, seg["a"][1] + seg["d"][1] * t + seg["n"][1] * off)
        d = seg["d"]
        if k + 1 < len(self.segs):  # the turn at its end
            c = self.corner(k + 1, off)
            if (p[0] - c[0]) * d[0] + (p[1] - c[1]) * d[1] > 0:
                return c
        if k > 0:  # the turn at its start
            c = self.corner(k, off)
            if (p[0] - c[0]) * d[0] + (p[1] - c[1]) * d[1] < 0:
                return c
        return p

    def turn(self, i):
        """The signed turn at inner point i (radians, positive to the left)."""
        d1, d2 = self.segs[i - 1]["d"], self.segs[i]["d"]
        return math.atan2(d1[0] * d2[1] - d1[1] * d2[0], d1[0] * d2[0] + d1[1] * d2[1])

    def corner(self, i, off):
        """Inner point i offset by off: where the two offset lines meet (mitred)."""
        s1, s2 = self.segs[i - 1], self.segs[i]
        p = self.pts[i]
        (n1, n2) = (s1["n"], s2["n"])
        det = n1[0] * n2[1] - n1[1] * n2[0]
        if abs(det) < 1e-9:
            return (p[0] + n1[0] * off, p[1] + n1[1] * off)
        c1 = n1[0] * p[0] + n1[1] * p[1] + off
        c2 = n2[0] * p[0] + n2[1] * p[1] + off
        return ((c1 * n2[1] - c2 * n1[1]) / det, (n1[0] * c2 - n2[0] * c1) / det)

    def inner(self, sa, sb):
        """Inner points strictly between sa and sb: [(index, s)]."""
        return [(i, self.vs[i]) for i in range(1, len(self.pts) - 1) if sa + 1e-6 < self.vs[i] < sb - 1e-6]

    def ring(self, sa, sb, lo, hi):
        """The plan outline of the stretch sa..sb between offsets lo (right) and hi
        (left), counter-clockwise: [(x, z, s)]; its last edge (back to the first point)
        is the front, across the line at sa."""
        right = [self.side(sa, lo, True) + (sa,)] + [self.corner(i, lo) + (s,) for i, s in self.inner(sa, sb)] + \
                [self.side(sb, lo, False) + (sb,)]
        left = [self.side(sb, hi, False) + (sb,)] + [self.corner(i, hi) + (s,) for i, s in reversed(self.inner(sa, sb))] + \
               [self.side(sa, hi, True) + (sa,)]
        out = []
        for p in right + left:
            if not out or math.dist(p[:2], out[-1][:2]) > 1e-6:
                out.append(p)
        if len(out) > 1 and math.dist(out[0][:2], out[-1][:2]) <= 1e-6:
            out.pop()
        return out


def landings(line, width):
    """[(sa, sb)] the landings the line's sharp turns need: each reaches far enough
    either side of its turn that the stair's whole width turns on it; two less than
    a stair's width apart (a U's two turns) are one landing."""
    out = []
    for i in range(1, len(line.pts) - 1):
        a = abs(line.turn(i))
        if a < SHARP:
            continue
        h = width / 2 * math.tan(min(a, math.radians(170)) / 2)
        sa, sb = max(0.0, line.vs[i] - h), min(line.total, line.vs[i] + h)
        if out and sa <= out[-1][1] + width:  # less than a stair's width between them: one landing
            out[-1] = (out[-1][0], max(out[-1][1], sb))
        else:
            out.append((sa, sb))
    return out


def treads(line, n, lands, going=None):
    """[(sa, sb, k, kind)] the n - 1 treads along the line (k: its riser count, so it
    sits at k risers up; kind "step" or "landing"). lands: the landings; the flights
    between them share the other treads by length (going: each flight's own going
    where it is set, else the line shared out evenly). A flight too short for a step
    joins the landing beside it."""
    lands = [list(l) for l in lands]
    while True:
        flights, at = [], 0.0
        for sa, sb in lands:
            flights.append((at, sa))
            at = sb
        flights.append((at, line.total))
        count = n - 1 - len(lands)
        lengths = [max(b - a, 0.0) for a, b in flights]
        total = sum(lengths)
        if count < 0:
            raise ValueError("too few steps for its landings")
        if going:
            alloc = [int(round(L / going)) for L in lengths]
            short = count - sum(alloc)
            order = sorted(range(len(alloc)), key=lambda j: -lengths[j])
            for j in order[:abs(short)]:
                alloc[j] += 1 if short > 0 else -1
        elif total <= 1e-9:
            alloc = [0] * len(lengths)
        else:
            raw = [count * L / total for L in lengths]
            alloc = [int(math.floor(r)) for r in raw]
            for j in sorted(range(len(raw)), key=lambda j: -(raw[j] - alloc[j]))[:count - sum(alloc)]:
                alloc[j] += 1
        empty = [j for j, (L, t) in enumerate(zip(lengths, alloc)) if t <= 0 and L > 1e-6]
        if not empty or not lands:
            break
        j = empty[0]  # a flight with no step: its landing(s) swallow it
        if j < len(lands):
            lands[j][0] = flights[j][0]
        else:
            lands[j - 1][1] = flights[j][1]
        merged = []
        for l in lands:
            if merged and l[0] <= merged[-1][1] + 1e-6:
                merged[-1][1] = max(merged[-1][1], l[1])
            else:
                merged.append(l)
        lands = merged
    out, k = [], 1
    for j, (a, b) in enumerate(flights):
        t = alloc[j]
        for m in range(t):
            g = (b - a) / t
            out.append((a + g * m, a + g * (m + 1), k, "step"))
            k += 1
        if j < len(lands):
            out.append((lands[j][0], lands[j][1], k, "landing"))
            k += 1
    return out


def walking_line(shape, n, going, width, turn, landing_at, gap):
    """(line, landings) for a parametric stair of n risers: Straight, L or U."""
    g, w = max(going, 1.0), max(width, 1.0)
    sx = 1.0 if turn == RIGHT else -1.0  # walking +Z, a right turn heads +X
    if shape == STRAIGHT:
        return Line([(0.0, 0.0), (0.0, (n - 1) * g)]), []
    treads_free = n - 2  # one tread is the landing
    n1 = landing_at if 0 < landing_at <= treads_free else treads_free // 2
    n2 = treads_free - n1
    y1 = n1 * g + w / 2
    if shape == L_SHAPE:
        line = Line([(0.0, 0.0), (0.0, y1), (sx * (w / 2 + n2 * g), y1)])
        return line, [(n1 * g, n1 * g + w)]
    x2 = sx * (w + max(gap, 0.0))
    line = Line([(0.0, 0.0), (0.0, y1), (x2, y1), (x2, y1 - w / 2 - n2 * g)])
    return line, [(n1 * g, n1 * g + 2 * w + max(gap, 0.0))]


def plan(s, spline_path=None):
    """(line, treads, riser height) for settings s (see settings()); spline_path: the
    stair's own path [(x, z)] for the Spline shape. None without a path."""
    n, rise = risers(s["height"], s["steps"], s["max_riser"])
    if s["shape"] == SPLINE:
        if not spline_path or len(spline_path) < 2:
            return None
        line = Line(spline_path)
        if line.total <= 1e-6:
            return None
        lands = landings(line, s["width"])
        try:
            return line, treads(line, n, lands), rise
        except ValueError:
            return line, treads(line, n, []), rise
    line, lands = walking_line(s["shape"], n, s["going"], s["width"], s["turn"], s["landing_at"], s["gap"])
    return line, treads(line, n, lands, s["going"]), rise


def flights(trs):
    """[(sa, sb, first k, steps)] the runs of steps, and [(sa, sb, k)] the landings."""
    runs, lands = [], []
    for sa, sb, k, kind in trs:
        if kind == "landing":
            lands.append((sa, sb, k))
        elif runs and abs(runs[-1][1] - sa) < 1e-6 and runs[-1][2] + runs[-1][3] == k:
            runs[-1] = (runs[-1][0], sb, runs[-1][2], runs[-1][3] + 1)
        else:
            runs.append((sa, sb, k, 1))
    return runs, lands


def nosing_line(trs, rise):
    """f(s): the height of the line through the nosings (the front of every tread's
    top), level across a landing."""
    runs, lands = flights(trs)

    def f(s):
        for sa, sb, k in lands:
            if sa - 1e-6 <= s <= sb + 1e-6:
                return k * rise
        for sa, sb, k, cnt in runs:
            if sa - 1e-6 <= s <= sb + 1e-6:
                return k * rise + (s - sa) / ((sb - sa) / cnt) * rise
        return 0.0
    return f


def pieces(trs):
    """[(sa, sb, kind, (first k, steps))]: flights and landings in order, for the
    stringers and the sloped underside."""
    runs, lands = flights(trs)
    out = [(a, b, "run", (k, c)) for a, b, k, c in runs] + [(a, b, "landing", (k, 1)) for a, b, k in lands]
    return sorted(out)


def stringer_line(trs, rise, cut, above=0.0, tread_t=0.0):
    """The line a stringer follows, [(s, y)] continuous from the foot to the top:
    housed (cut False), the line through the nosings plus above; cut (sawtooth, under
    the treads), the line through the inner corners where each riser meets the tread
    below. Across a landing it ramps up one riser, so the next flight carries on
    from it without a jump."""
    pts = []
    base = -tread_t if cut else above
    lift = -1 if cut else 0
    for sa, sb, kind, (k, c) in pieces(trs):
        y0 = (k + lift) * rise + base
        y1 = y0 + (c if kind == "run" else 1) * rise
        if not pts or abs(pts[-1][0] - sa) > 1e-6:
            pts.append((sa, y0))
        pts.append((sb, y1))
    return pts


def offset_below(pts, depth):
    """The line `depth` square below polyline pts [(s, y)] (mitred at its bends)."""
    lines = []
    for (s0, y0), (s1, y1) in zip(pts, pts[1:]):
        if s1 - s0 < 1e-9:
            continue
        m = (y1 - y0) / (s1 - s0)
        k = math.sqrt(1 + m * m)
        lines.append((s0 + m * depth / k, y0 - depth / k, m))  # a point on it, and its slope
    if not lines:
        return []
    out = [(lines[0][0], lines[0][1])]
    for (sa, ya, ma), (sb, yb, mb) in zip(lines, lines[1:]):
        if abs(ma - mb) < 1e-9:
            continue
        x = (yb - ya + ma * sa - mb * sb) / (ma - mb)
        out.append((x, ya + ma * (x - sa)))
    last = lines[-1]
    end = pts[-1][0]
    out.append((end, last[1] + last[2] * (end - last[0])))
    return out


def along(pts, s):
    """Polyline pts [(s, y)] at s, carried straight on past its ends."""
    if len(pts) == 1:
        return pts[0][1]
    for (s0, y0), (s1, y1) in zip(pts, pts[1:]):
        if s <= s1 or (s1, y1) == pts[-1]:
            if s1 - s0 < 1e-12:
                return y1
            return y0 + (y1 - y0) * (s - s0) / (s1 - s0)
    return pts[-1][1]


def bends(pts):
    """The s of every bend of polyline pts, and where it crosses the floor (y 0)."""
    out = [p[0] for p in pts]
    for (s0, y0), (s1, y1) in zip(pts, pts[1:]):
        if (y0 < 0) != (y1 < 0) and abs(y1 - y0) > 1e-12:
            out.append(s0 + (s1 - s0) * (-y0) / (y1 - y0))
    return out


# Building (through the host, aw_host) ---------------------------------------------------------

def settings(op):
    import aw_ids as I
    v = lambda pid: aw_host.value(op, pid)  # noqa: E731
    return {"shape": int(v(I.AW_STAIR_SHAPE)), "height": float(v(I.AW_STAIR_HEIGHT)),
            "steps": int(v(I.AW_STAIR_STEPS)), "max_riser": float(v(I.AW_STAIR_MAX_RISER)),
            "going": float(v(I.AW_STAIR_GOING)), "width": max(float(v(I.AW_STAIR_WIDTH)), 10.0),
            "turn": int(v(I.AW_STAIR_TURN)), "landing_at": int(v(I.AW_STAIR_LANDING_AT)),
            "gap": float(v(I.AW_STAIR_GAP)), "construction": int(v(I.AW_STAIR_CONSTRUCTION)),
            "underside": int(v(I.AW_STAIR_UNDERSIDE)), "waist": max(float(v(I.AW_STAIR_WAIST)), 1.0),
            "tread_t": max(float(v(I.AW_STAIR_TREAD_T)), 0.5), "nosing": max(float(v(I.AW_STAIR_NOSING)), 0.0),
            "stringers": int(v(I.AW_STAIR_STRINGERS)), "stringer_w": max(float(v(I.AW_STAIR_STRINGER_W)), 0.5),
            "stringer_d": max(float(v(I.AW_STAIR_STRINGER_D)), 1.0),
            "stringer_above": float(v(I.AW_STAIR_STRINGER_ABOVE)),
            "stringer_spacing": max(float(v(I.AW_STAIR_STRINGER_SPACING)), 0.0)}


def spline_path(op):
    """The stair's own path: its first open child spline (or the first closed one,
    opened), (x, z) in its own space; None without one."""
    closed, opened = aw_host.spline_paths(op)
    if opened:
        return opened[0]
    return closed[0] if closed else None


def _prism(mesh, ring, top, bottom, front, side, cap_top, cap_bottom):
    """A closed solid over a plan outline ring [(x, z, s)] (counter-clockwise, its last
    edge the front): top(s) and bottom(s) its heights at each point. The front face
    goes in group `front`, the other sides in `side`."""
    import aw_slab
    pts = [(p[0], p[1]) for p in ring]
    n = len(ring)
    if n < 3:
        return
    mesh.new_part()
    first = len(mesh.polys)
    t = [mesh.pt(x, top(s), z) for x, z, s in ring]
    b = [mesh.pt(x, min(bottom(s), top(s) - 0.1), z) for x, z, s in ring]
    for i, j, k in aw_slab.triangulate(pts):
        mesh.quad(t[i], t[j], t[k], t[k], cap_top)
        mesh.quad(b[k], b[j], b[i], b[i], cap_bottom)
    for i in range(n):
        j = (i + 1) % n
        mesh.quad(t[j], t[i], b[i], b[j], front if i == n - 1 else side)
    mesh._face_out(first)


def _strip(mesh, line, sa, sb, lo, hi, top, bottom, group, extra=()):
    """A board standing along the line from sa to sb between offsets lo and hi, its top
    and bottom heights top(s), bottom(s): one closed piece per straight stretch (a
    wedge where the inside of a turn shrinks to a point), cut again at every s in
    extra (where top or bottom bends, so each piece's faces stay flat)."""
    cuts = sorted({sa, sb} | {s for _i, s in line.inner(sa, sb)} | {x for x in extra if sa + 1e-6 < x < sb - 1e-6})
    corner = {s: i for i, s in line.inner(sa, sb)}
    for s0, s1 in zip(cuts, cuts[1:]):
        if s1 - s0 < 1e-6:
            continue

        def at(s, off, start):
            if s in corner:
                return line.corner(corner[s], off)
            return line.side(s, off, start)
        ring = []
        for x, z, sv in (at(s0, lo, True) + (s0,), at(s1, lo, False) + (s1,), at(s1, hi, False) + (s1,),
                         at(s0, hi, True) + (s0,)):
            if not ring or math.dist((x, z), ring[-1][:2]) > 1e-4:
                ring.append((x, z, sv))
        if len(ring) > 1 and math.dist(ring[0][:2], ring[-1][:2]) <= 1e-4:
            ring.pop()  # an edge shrunk to a point (the inside of a turn): a wedge, still closed
        if len(ring) >= 3:
            _prism(mesh, ring, top, lambda x: max(bottom(x), 0.0), group, group, group, group)


def build(op):
    s = settings(op)
    path = spline_path(op) if s["shape"] == SPLINE else None
    p = plan(s, path)
    if p is None:
        return None
    return build_from(aw_host.name(op), s, *p)


def build_from(name, s, line, trs, rise):
    """The stair's mesh for its plan (pure but for MeshBuilder)."""
    from aw_mesh import MeshBuilder
    mesh = MeshBuilder(GROUPS)
    w, tt, nose = s["width"], s["tread_t"], s["nosing"]
    sw = min(s["stringer_w"], w / 3)
    lo, hi = -w / 2, w / 2
    spacing = min(max(s.get("stringer_spacing", 0.0), 0.0), w / 2 - sw / 2)
    cut = s["stringers"] == CENTRE_STRINGER or (s["stringers"] == SIDE_STRINGERS and spacing > 1e-6)
    if s["stringers"] == SIDE_STRINGERS and not cut:
        lo, hi = lo + sw, hi - sw  # housed: the treads and steps between the stringers
    under = None
    if s["construction"] == CLOSED:
        if s["underside"] == SOLID:
            def under(_s):
                return 0.0
        else:
            parts = pieces(trs)

            def under(x):
                for sa, sb, kind, (k, c) in parts:
                    if sa - 1e-6 <= x <= sb + 1e-6:
                        if kind == "landing":
                            return (k - 1) * rise - s["waist"]
                        return (k - 1) * rise + (x - sa) / ((sb - sa) / c) * rise - s["waist"]
                return 0.0
    for sa, sb, k, kind in trs:
        y = k * rise
        if under is not None:  # the step's block, its face the riser
            _prism(mesh, line.ring(sa, sb, lo, hi), lambda _s, y=y: y - tt, lambda x: max(under(x), 0.0),
                   "Risers", "Structure", "Structure", "Structure")
        _prism(mesh, line.ring(sa - nose, sb, lo, hi), lambda _s, y=y: y, lambda _s, y=y: y - tt,
               "Treads", "Treads", "Treads", "Treads")
    if s["stringers"] != NO_STRINGER:
        depth = s["stringer_d"]
        if s["stringers"] == CENTRE_STRINGER:
            sides = [(-sw / 2, sw / 2)]
        elif cut:  # inset: under the treads, which reach past them
            sides = [(-spacing - sw / 2, -spacing + sw / 2), (spacing - sw / 2, spacing + sw / 2)]
        else:  # at the edges, housing the treads
            sides = [(-w / 2, -w / 2 + sw), (w / 2 - sw, w / 2)]
        ref = stringer_line(trs, rise, cut, s["stringer_above"], tt)
        low = offset_below(ref, depth)
        cuts = bends(ref) + bends(low)

        def bottom(x):
            return along(low, x)
        for a, b in sides:
            if cut:  # a sawtooth: level under each tread, a step up at each riser
                for sa, sb, k, _kind in trs:
                    _strip(mesh, line, sa, sb, a, b, lambda _x, y=k * rise - tt: y, bottom, "Stringers", cuts)
            else:
                _strip(mesh, line, -nose, line.total, a, b, lambda x: along(ref, x), bottom, "Stringers", cuts)
    return mesh.build(name)
