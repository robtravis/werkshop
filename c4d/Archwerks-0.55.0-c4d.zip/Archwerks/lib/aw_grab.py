"""Archwerks grips inside the AW Edit Dimensions tool.

C4D only draws and drags an object's handles in its own transform tools, so the
edit tool does it itself: it asks the selected Archwerks objects for their grips
(the same GetHandle/SetHandle the Move tool uses), picks the one under the mouse,
and moves the mouse along that grip's line.
"""
import c4d

import aw_dims
import aw_draw
import aw_ids as I

PICK_RADIUS = 9.0  # points: how close the mouse must be to grab a grip


def grip_objects(doc):
    """The selected objects that have Archwerks grips."""
    return [o for o in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
            if o.GetType() in (I.ID_AW_WALL, I.ID_AW_ROOF, I.ID_AW_ROOF_CUTTER, I.ID_AW_BEAM,
                                  I.ID_AW_CABINET) or I.is_opening(o)]


def moved_by(obj):
    """The splines a drag of obj's grips can move (for undo): a Wall's path, a Roof's
    own splines."""
    if obj.GetType() == I.ID_AW_WALL:
        import aw_wall_c4d
        return list(aw_wall_c4d.path_splines(obj))
    if obj.GetType() == I.ID_AW_ROOF:
        return [k for k in obj.GetChildren() if k.GetType() == c4d.Ospline]
    return []


_DRAG = {"obj": None, "t": 0.0, "start": None}  # what C4D's own tool is dragging, when it last moved, where it began
DRAG_GAP = 0.4  # s: a SetHandle this long after the last one is a new drag


_GRIPS = {}  # (type, name): an object's grips as last worked out, for its childless copies


def remembered_grips(obj, grips):
    """obj's grips, kept for later (grips worked out), or what was kept (grips None or
    empty). C4D's own tools read where a grip starts from a copy of the object made as
    the drag begins, WITHOUT its children; a Wall's or Roof's grips come from its child
    splines, so that copy has none and the grip read (0, 0, 0): the corner jumped to the
    world centre. The copy keeps the object's type and name (not its unique id), and
    Archwerks names are unique (Wall.Exterior.001), so it finds them by those."""
    key = (obj.GetType(), obj.GetName())
    if grips:
        if len(_GRIPS) > 2000:  # objects come and go: never let this grow without bound
            _GRIPS.clear()
        _GRIPS[key] = list(grips)
        return grips
    return _GRIPS.get(key, grips)


def record_drag(obj, index=None):
    """Called from SetHandle: on a drag's first move in Cinema 4D's own tools (Move, Scale,
    the selection tools), the splines it moves join the tool's undo step, which records
    only obj itself, so one Undo puts the path back with the wall. AW Edit Dimensions
    records them itself (_drag)."""
    import time
    doc = obj.GetDocument()
    if doc is None or doc.GetAction() == I.ID_AW_EDIT_TOOL:
        return
    now = time.monotonic()
    uid = obj.FindUniqueID(c4d.MAXON_CREATOR_ID)  # not obj itself: an undo replaces it, and a dead one can't compare
    uid = bytes(uid) if uid is not None else id(obj)
    new = _DRAG["obj"] != uid or now - _DRAG["t"] > DRAG_GAP
    _DRAG.update(obj=uid, t=now)
    if new:
        for spline in moved_by(obj):
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, spline)
        _DRAG["start"] = None
        if index is not None:  # where the grip began, in world space: Shift locks to its X or Z line
            info = c4d.HandleInfo()
            obj.GetNodeData().GetHandle(obj, index, info)
            _DRAG["start"] = obj.GetMg() * info.position


def ctrl_held():
    bc = c4d.BaseContainer()
    if not c4d.gui.GetInputState(c4d.BFM_INPUT_KEYBOARD, c4d.KEY_CONTROL, bc):
        return False
    return bool(bc.GetInt32(c4d.BFM_INPUT_QUALIFIER) & c4d.QCTRL)


def snap_rise(obj, index, p):
    """A wall's rise grip dragged to p (wall space), snapped as aw_wedit.snap_rise puts it:
    flat, level with a neighbour, or where the two top edges meeting there are square,
    within SNAP_RADIUS on screen, with dashed guides along the top edges it lined up; Ctrl:
    as it is. In any tool, AW Edit Dimensions too."""
    import aw_wall_c4d
    import aw_wedit
    aw_draw.SNAP_GUIDES[:] = []
    doc = obj.GetDocument()
    wp = aw_wall_c4d.wall_path(obj)
    if doc is None or wp is None or ctrl_held():
        return p
    path, w0, w1, height, splines = wp
    grips = aw_wall_c4d.wall_grips(path, w0, w1, height, splines)
    pt = index - sum(1 for g in grips if g[2] == "corner")
    bd = doc.GetActiveBaseDraw()
    if bd is None or pt < 0:
        return p
    mg = obj.GetMg()
    a, b = bd.WS(mg * p), bd.WS(mg * (p + c4d.Vector(0, 1, 0)))
    per_px = 1.0 / max(((a.x - b.x) ** 2 + (a.y - b.y) ** 2) ** 0.5, 1e-6)
    rise, why = aw_wedit.snap_rise(path, pt, p.y - height, aw_draw.px(SNAP_RADIUS) * per_px)
    if why is None:
        return p
    pts = getattr(path, "spline_points", None) or path.points
    heights = getattr(path, "heights", None) or [0.0] * len(pts)
    here = c4d.Vector(p.x, height + rise, p.z)
    for j, _L in aw_wedit.rise_neighbours(path, pt):  # the top edges it lined up
        if why[1] is None or why[1] == j:
            x, z = pts[j]
            aw_draw.SNAP_GUIDES.append((mg * c4d.Vector(x, height + heights[j], z), mg * here))
    return here


def native_corner(obj, index, p):
    """A wall corner dragged by C4D's own tool to p (wall space), as AW Draw and AW Edit
    Dimensions would put it: held to the X or Z line through where it began with Shift,
    lined up with other walls' points it passes (the dashed guides show what), Ctrl: as
    it is. In AW Edit Dimensions drag_to does this itself."""
    doc = obj.GetDocument()
    if doc is None or doc.GetAction() == I.ID_AW_EDIT_TOOL:
        return p
    aw_draw.SNAP_GUIDES[:] = []
    if ctrl_held():
        return p
    mg = obj.GetMg()
    world = mg * p
    free = ("x", "z")
    start = _DRAG.get("start")
    if start is not None and shift_held():
        world = axis_locked(start, world)
        moved = world - start
        free = ("x",) if abs(moved.x) >= abs(moved.z) else ("z",)
    bd = doc.GetActiveBaseDraw()
    if bd is not None:
        world, guides = snapped(bd, world, snap_points(doc, obj, index), free)
        aw_draw.SNAP_GUIDES[:] = guides
    return ~mg * world


def grips(obj):
    """[(local position, local direction), ...], role and kinds, as the Move tool shows
    them. A grip that moves on a plane (a spline wall's corner) is a "corner"."""
    nd = obj.GetNodeData()
    info = c4d.HandleInfo()
    out, kinds = [], []
    for i in range(nd.GetHandleCount(obj)):
        nd.GetHandle(obj, i, info)
        out.append((c4d.Vector(info.position), c4d.Vector(info.direction)))
        kinds.append("corner" if info.type == c4d.HANDLECONSTRAINTTYPE_PLANAR else
                     "hidden" if info.type == c4d.HANDLECONSTRAINTTYPE_INVALID else "arrow")
    if I.is_opening(obj):
        return out, "focus", aw_dims.OPENING_GRIP_KINDS
    return out, "wall", kinds


def pick(bd, doc, x, y):
    """(object, grip index) nearest the mouse within PICK_RADIUS, or None."""
    best, best_d = None, aw_draw.px(PICK_RADIUS)
    for obj in grip_objects(doc):
        mg = obj.GetMg()
        found, _role, kinds = grips(obj)
        for i, (pos, _d) in enumerate(found):
            if i < len(kinds) and kinds[i] == "hidden":  # upright, seen from above: not grabbable
                continue
            w = mg * pos
            if aw_draw.behind(bd, w):
                continue
            s = bd.WS(w)
            d = ((s.x - x) ** 2 + (s.y - y) ** 2) ** 0.5
            if d < best_d:
                best, best_d = (obj, i), d
    return best


def point_on_line(bd, origin, direction, x, y):
    """The point on the world line origin + t * direction nearest the mouse ray at
    screen (x, y): where the grip should be while the mouse is there."""
    a = bd.SW(c4d.Vector(x, y, 10.0))      # two points along the mouse ray
    b = bd.SW(c4d.Vector(x, y, 10000.0))
    u = direction.GetNormalized()
    v = (b - a).GetNormalized()
    w0 = origin - a
    uu, uv, vv = u.Dot(u), u.Dot(v), v.Dot(v)
    uw, vw = u.Dot(w0), v.Dot(w0)
    den = uu * vv - uv * uv
    if abs(den) < 1e-9:  # looking straight down the line: no movement along it
        return origin
    t = (uv * vw - vv * uw) / den
    return origin + u * t


def point_on_plane(bd, origin, normal, x, y):
    """Where the mouse ray at screen (x, y) meets the plane through origin with this
    normal (a corner grip moving on the floor); origin if the ray runs along it."""
    a = bd.SW(c4d.Vector(x, y, 10.0))
    b = bd.SW(c4d.Vector(x, y, 10000.0))
    n = normal.GetNormalized()
    v = (b - a).GetNormalized()
    den = v.Dot(n)
    if abs(den) < 0.02:  # looking along the plane (a Front or Right view): slide across the screen in it
        return point_on_line(bd, origin, n.Cross(v), x, y)
    return a + v * ((origin - a).Dot(n) / den)


def shift_held():
    """True while Shift is down (read live, so a drag can lock and unlock as it goes)."""
    bc = c4d.BaseContainer()
    if not c4d.gui.GetInputState(c4d.BFM_INPUT_KEYBOARD, c4d.KEY_SHIFT, bc):
        return False
    return bool(bc.GetInt32(c4d.BFM_INPUT_QUALIFIER) & c4d.QSHIFT)


def axis_locked(start, p):
    """p moved onto the world X or Z line through start, whichever it has moved along more."""
    d = p - start
    if abs(d.x) >= abs(d.z):
        return c4d.Vector(p.x, p.y, start.z)
    return c4d.Vector(start.x, p.y, p.z)


SNAP_RADIUS = 8.0  # points: how close on screen a dragged corner comes to another point's line before it snaps


def snap_points(doc, obj, index):
    """Every Wall's spline points in the document, on the floor in world space, but
    not the corner being dragged (point `index` of obj's splines)."""
    import aw_wall_c4d
    out = []
    o = doc.GetFirstObject() if doc else None
    stack = [o]
    while stack:
        o = stack.pop()
        while o:
            if o.GetType() == I.ID_AW_WALL:
                wp = aw_wall_c4d.wall_path(o)
                if wp is not None:
                    mg, splines = o.GetMg(), wp[4]
                    for i in range(splines.GetPointCount()):
                        if o == obj and i == index:
                            continue
                        p = splines.GetPoint(i)
                        out.append(mg * c4d.Vector(p.x, 0, p.z))
            if o.GetDown():
                stack.append(o.GetDown())
            o = o.GetNext()
    return out


def snapped(bd, p, candidates, free=("x", "z")):
    """p (world) moved onto another point's X and/or Z line where it is within
    SNAP_RADIUS of it on screen; free: the axes allowed to move. Returns the new
    point and the guides [(from, to)] to draw for what it lined up with."""
    radius = aw_draw.px(SNAP_RADIUS)
    if aw_draw.behind(bd, p):
        return p, []
    sp = bd.WS(p)
    out, guides = c4d.Vector(p), []
    for axis in free:
        best, best_d = None, radius
        for q in candidates:
            moved = c4d.Vector(q.x if axis == "x" else p.x, p.y, q.z if axis == "z" else p.z)
            if aw_draw.behind(bd, moved):
                continue
            sm = bd.WS(moved)
            d = ((sm.x - sp.x) ** 2 + (sm.y - sp.y) ** 2) ** 0.5
            if d < best_d:
                best, best_d = q, d
        if best is not None:
            if axis == "x":
                out.x = best.x
            else:
                out.z = best.z
            guides.append(best)
    return out, [(out, q) for q in guides]


def drag_to(bd, obj, index, start_world, direction_world, x, y, plane=False, lock=None, snap=True):
    """Move grip `index` of obj to where the mouse at (x, y) puts it: on its line, or
    on its plane for a corner grip (direction is then the plane's normal). A corner
    held with Shift (lock: True / False, None = read the keyboard) stays on the world
    X or Z line through where it started. snap: line it up with other Walls'
    points it passes (only along its free axis while locked), drawing a guide."""
    aw_draw.SNAP_GUIDES[:] = []
    if plane:
        p = point_on_plane(bd, start_world, direction_world, x, y)
        locked = lock if lock is not None else shift_held()
        free = ("x", "z")
        if locked:
            p = axis_locked(start_world, p)
            moved = p - start_world
            free = ("x",) if abs(moved.x) >= abs(moved.z) else ("z",)
        if snap and obj.GetType() == I.ID_AW_WALL:
            p, guides = snapped(bd, p, snap_points(obj.GetDocument(), obj, index), free)
            aw_draw.SNAP_GUIDES[:] = guides
    else:
        p = point_on_line(bd, start_world, direction_world, x, y)
    nd = obj.GetNodeData()
    info = c4d.HandleInfo()
    nd.GetHandle(obj, index, info)
    nd.SetHandle(obj, index, ~obj.GetMg() * p, info)
