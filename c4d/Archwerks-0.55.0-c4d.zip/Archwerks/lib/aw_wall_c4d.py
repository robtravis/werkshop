"""aw_wall for Cinema 4D: what core/aw_wall.py asks of the scene (its path splines
read as runs, its cutters, the keys its caches compare), the grips that move spline
points, and the build-on of a window's own mesh. Star-imports the core, so Cinema
4D's side uses this module for all of the wall."""
import c4d

import aw_c4d
import aw_dims
import aw_host
import aw_ids
import aw_wall  # noqa: F401
from aw_wall import *  # noqa: F401,F403


def hide_cutters(op):
    """Plain cutters (Cubes etc.) under a wall are consumed, like a Boolean's
    children; AW Openings and the path splines stay visible."""
    for child in op.GetChildren():
        if not aw_ids.is_opening(child) and not child.GetInfo() & c4d.OBJECT_ISSPLINE:
            child.Touch()


def deform_opening(child, plan, height, build, window):
    """An opening's window (PolygonObject in the opening's space, changed in place)
    moved by its wall's Build, as the wall's own points around it are."""
    if not build or build[0] >= 1.0:
        return
    ml = child.GetMl()
    k = plan.project(ml.off.x, ml.off.z)[0]
    pts = [ml * p for p in window.GetAllPoints()]
    deform(plan, height, build, pts, [point_tag(plan, k, p.x, p.z) for p in pts], sink=WINDOW_SINK)
    inv = ~ml
    window.SetAllPoints([inv * p for p in pts])
    window.Message(c4d.MSG_UPDATE)


def path_spline(op):
    """The wall's first path spline, or None."""
    for child in op.GetChildren():
        if child.GetInfo() & c4d.OBJECT_ISSPLINE:
            return child
    return None


def path_splines(op):
    """Every spline among the wall's children: together they are its path."""
    return [c for c in op.GetChildren() if c.GetInfo() & c4d.OBJECT_ISSPLINE]


class SplineSet:
    """A wall's path splines as one list of points, in the WALL's space: point i is
    point i of the first spline, then the second's, and so on. GetMl() is the
    identity, so code written for one spline (grips, typing) works on them all."""

    def __init__(self, splines):
        self.objects = []
        self._map = []  # point i -> (spline index, its own point index)
        for s, spline in enumerate(splines):
            real = spline.GetRealSpline()
            if real is None:
                continue
            self.objects.append((spline, real, spline.GetMl()))
            self._map += [(len(self.objects) - 1, k) for k in range(real.GetPointCount())]

    def GetPointCount(self):
        return len(self._map)

    def GetPoint(self, i):
        s, k = self._map[i]
        _spline, real, ml = self.objects[s]
        return ml * real.GetPoint(k)

    def SetPoint(self, i, v):
        s, k = self._map[i]
        spline, _real, ml = self.objects[s]
        spline.SetPoint(k, ~ml * v)

    def owner(self, i):
        """The spline object point i belongs to."""
        return self.objects[self._map[i][0]][0]

    def local(self, i):
        """(spline object, its own point index, its matrix in the wall) for point i."""
        sidx, k = self._map[i]
        spline, _real, ml = self.objects[sidx]
        return spline, k, ml

    def GetMl(self):
        return c4d.Matrix()

    def GetType(self):
        """Ospline when every path spline is editable (so corners can move)."""
        types = {spline.GetType() for spline, _r, _m in self.objects}
        return c4d.Ospline if types == {c4d.Ospline} else next(iter(types - {c4d.Ospline}), c4d.Ospline)

    def Message(self, mid):
        for spline, _r, _m in self.objects:
            spline.Message(mid)


def spline_runs(real, ml):
    """[(points (x, z) in the wall's space, closed, spline point indices)] for each
    segment (run) of a real spline, every point (x, z) in spline order, and every
    point's Y (how much taller than the wall's Height the wall is there)."""
    n = real.GetPointCount()
    pts = [ml * q for q in real.GetAllPoints()]
    xz = [(p.x, p.z) for p in pts]
    ys = [p.y for p in pts]
    count = real.GetSegmentCount()
    if count == 0:
        return [(xz, bool(real.IsClosed()), list(range(n)))], xz, ys
    runs, off = [], 0
    every_closed = bool(real.IsClosed())  # the object's Close Spline closes every run
    for s in range(count):
        seg = real.GetSegment(s)
        cnt = seg["cnt"]
        runs.append((xz[off:off + cnt], bool(seg["closed"]) or every_closed, list(range(off, off + cnt))))
        off += cnt
    return runs, xz, ys


_DIRTY = c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX | c4d.DIRTYFLAGS_CACHE
_PLACE = c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX


def _ident(obj):
    """An object's lasting identity. Not id(): C4D hands Python a new wrapper on
    every call."""
    u = obj.FindUniqueID(c4d.MAXON_CREATOR_ID)
    return bytes(u) if u is not None else obj.GetGUID()


def _path_key(op, splines=None):
    """Changes whenever the wall's settings, its splines (points, place, a
    primitive's own build) or which children are splines change."""
    splines = path_splines(op) if splines is None else splines
    return (op.GetDirty(c4d.DIRTYFLAGS_DATA),
            tuple((_ident(sp), sp.GetDirty(_DIRTY)) for sp in splines))


def change_key(op):
    """A cheap key that changes whenever anything a wall's mesh depends on does:
    its settings, its splines, and every child's settings and place. Generators
    compare it first and skip all the work when it hasn't moved."""
    kids = op.GetChildren()
    # Splines include their cache (a primitive's points live there); other children
    # only their settings and place: a window's own rebuild must not count as a change.
    return (op.GetDirty(c4d.DIRTYFLAGS_DATA),
            tuple((k.GetType(), k.GetDirty(_DIRTY if k.GetInfo() & c4d.OBJECT_ISSPLINE else _PLACE),
                   k.GetDeformMode()) for k in kids))


# Grips that change only their own object's settings: C4D's own tools (Move, Scale,
# the selection tools) drag them as they drag a Cube's, and their undo (the object) covers it.
OWN_GRIPS = (aw_ids.ID_AW_CABINET, aw_ids.ID_AW_BEAM, aw_ids.ID_AW_ROOF_CUTTER, aw_ids.ID_AW_WALL,
             aw_ids.ID_AW_ROOF) + tuple(aw_ids.OPENING_TYPES)


def grips_allowed(op):
    """Whether op's grips show and drag in the current tool: in any, C4D's Move and Scale
    included, as a Cube's do. A cabinet's, a window's, a beam's change only its own
    settings, which C4D's undo records; a Wall's and a Roof's move their spline points
    too, which C4D's tools don't record, so their SetHandle adds those splines to the
    tool's undo step (aw_grab.record_drag)."""
    doc = op.GetDocument()
    return doc is None or doc.GetAction() == aw_ids.ID_AW_EDIT_TOOL or op.GetType() in OWN_GRIPS


def wall_grips(path, w0, w1, height, splines):
    """A wall's grips: aw_dims.path_grips, then, editable, its side grips (aw_dims.side_grips,
    as Blender's walls have them), so every other grip keeps its index."""
    editable = splines.GetType() == c4d.Ospline
    grips = aw_dims.path_grips(path, w0, w1, height, editable)
    if editable:
        grips += aw_dims.side_grips(path, 0.0, clear_first=True, w_out=w0)
    return grips


def set_path_grip(op, i, p):
    """Grip i of a wall dragged to p (wall space), as aw_dims.path_grips lists them:
    a corner moves its spline point on the floor (keeping its height), a rise sets
    that point's height, then the wall's Height and Thickness."""
    wp = wall_path(op)
    if wp is None:
        return
    path, w0, w1, height, splines = wp
    grips = wall_grips(path, w0, w1, height, splines)
    kind = grips[i][2]
    if kind == "corner":
        old = splines.GetPoint(i)
        splines.SetPoint(i, c4d.Vector(p.x, old.y, p.z))
        splines.Message(c4d.MSG_UPDATE)
    elif kind == "rise":
        n = sum(1 for g in grips if g[2] == "corner")
        old = splines.GetPoint(i - n)
        splines.SetPoint(i - n, c4d.Vector(old.x, max(p.y, aw_ids.MIN_SIZE) - height, old.z))
        splines.Message(c4d.MSG_UPDATE)
    elif kind == "side":  # the whole side, parallel to itself, its corners sliding along the sides beside it
        import aw_wedit
        (gx, _gy, gz), (dx, _dy, dz), _kind, k = grips[i]
        t = (p.x - gx) * dx + (p.z - gz) * dz  # from where the side is now: SetHandle comes again and again
        before, ia, ib, after = aw_wedit.side_ends(path, k)
        xz = lambda idx: (splines.GetPoint(idx).x, splines.GetPoint(idx).z)  # noqa: E731
        a, b = aw_wedit.move_side(xz(ia), xz(ib), xz(before) if before is not None else None,
                                  xz(after) if after is not None else None, (dx * t, dz * t))
        for idx, (x, z) in ((ia, a), (ib, b)):
            old = splines.GetPoint(idx)
            splines.SetPoint(idx, c4d.Vector(x, old.y, z))
        splines.Message(c4d.MSG_UPDATE)
    elif kind == "height":
        op[aw_ids.AW_WALL_HEIGHT] = max(p.y, aw_ids.MIN_SIZE)
    else:
        op[aw_ids.AW_WALL_THICKNESS] = max(aw_dims.path_thickness_from(path, w0, w1, (p.x, p.z)), aw_ids.MIN_SIZE)


UPRIGHT = ("rise", "height")  # grips that point straight up: nothing to drag in a view looking straight down


def looking_down(bd):
    """Whether bd looks straight down at the floor (Top, or a camera aimed down), where an
    upright grip lands on the corner under it and can't be dragged."""
    if bd is None:
        return False
    if bd[c4d.BASEDRAW_DATA_PROJECTION] in (c4d.Ptop, c4d.Pbottom):
        return True
    cam = bd.GetSceneCamera(bd.GetDocument()) or bd.GetEditorCamera()
    return cam is not None and abs(cam.GetMg().v3.GetNormalized().y) > 0.98


def wall_curves(op):
    """(SplineSet, runs, every point (x, z), every point's rise) of a wall's path
    splines, for aw_wall.wall_path; None with fewer than two points."""
    splines = SplineSet(path_splines(op))
    if splines.GetPointCount() < 2:
        return None
    runs, every, rises = [], [], []
    for _spline, real, ml in splines.objects:
        r, xz, ys = spline_runs(real, ml)
        base = len(every)
        runs += [(pts, closed, [base + i for i in ids]) for pts, closed, ids in r]
        every += xz
        rises += ys
    return splines, runs, every, rises


def cutters(op, hide=False):
    """op's enabled children but its path splines: AW Openings and plain cutters.
    hide: plain cutters (enabled or not) are consumed, like a Boolean's children."""
    out = []
    for child in op.GetChildren():
        if child.GetInfo() & c4d.OBJECT_ISSPLINE:
            continue
        if hide and not aw_ids.is_opening(child):
            child.Touch()
        if child.GetDeformMode():
            out.append(child)
    return out


def box_size(child):
    """A plain cutter's size: a Cube's own, else its bounding box."""
    size = child[c4d.PRIM_CUBE_LEN] if child.GetType() == c4d.Ocube else child.GetRad() * 2
    return aw_c4d.to_vec(size)


def opening_frame(child, path, w0, w1):
    """aw_wall.opening_frame as a c4d.Matrix."""
    return aw_c4d.to_matrix(aw_wall.opening_frame(child, path, w0, w1))


aw_host.register(wall_curves=wall_curves, cutters=cutters, box_size=box_size, ident=_ident, path_key=_path_key)
