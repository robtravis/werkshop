"""Archwerks openings on spline walls: the selected window's guides and grips.

When a window (an AW Opening, or a plain cutter) under a Wall is selected, its
wall draws it in focus (orange, aw_style "focus"): its outline on the Exterior
face; along the floor in front of it, the gap to whatever is on its left, its
width, and the gap to its right (the segment's clear corner, or the nearest other
opening on that segment); and beside its right edge, its sill height and its
height stacked on one line. Every one of them can be typed into (aw_edit).

An AW Opening on a wall has five grips, on the ends of those guides: Left and
Right (each moves only its own edge), Sill (raises it, keeping its height), Top
(its height), and Move (slides it along the wall), in the edit tool only.

Everything is worked out in the segment's own frame: u along it, w across it
(the Exterior on the w0 side, see aw_path.Plan), y up.
"""
import aw_build
import aw_dims as D
import aw_host
import aw_ids as I
import aw_wall
from aw_vec import Vec

FIT = 0.5  # cm between an opening and what's either side of it, at the closest

# Build-on ----------------------------------------------------------------------------------
# A host that links windows (Blender) puts here fn(op) -> (progress, index, count, sequence):
# one Build for the linked ones, each starting after the one before.
GROUP_PROGRESS = []


def own_build(op):
    """True when window or door op builds on its own (Build With: Own), not with its wall.
    (A Cutter, an archway, has no Build of its own: it is a hole.)"""
    if op is None or aw_host.type_id(op) not in (I.ID_AW_OPENING, I.ID_AW_DOOR, I.ID_AW_FIREPLACE):
        return False
    return int(aw_host.value(op, I.AW_OPENING_BUILD_WITH) or 0) == I.AW_BUILD_OWN


def own_key(op):
    """What op's own build-on depends on now, for a host's change check."""
    if not own_build(op):
        return None
    return (round(build_progress(op), 6), int(aw_host.value(op, I.AW_OPENING_BUILD_STYLE)),
            round(float(aw_host.value(op, I.AW_OPENING_BUILD_STAGGER)), 6))


def build_progress(op):
    """How far op's own build has got, 0..1 (linked ones in turn, by their Sequence)."""
    if GROUP_PROGRESS:
        progress, i, n, sequence = GROUP_PROGRESS[0](op)
        return aw_build.share(progress, i, n, sequence)
    return min(max(float(aw_host.value(op, I.AW_OPENING_BUILD)), 0.0), 1.0)


HOLE_EPS = 0.01  # cm: a hole not yet opening is this small, so the wall looks solid but keeps its points


def hole_rect(op, u0, u1, y0, y1):
    """(u0, u1, y0, y1): the part of op's hole cut now. All of it, unless op builds on its
    own: then the hole opens with it, as its style brings it in (Rise: up from the sill;
    Parts in Order: during the first stage, so the frame builds into it; the others: out
    from its middle). Before it starts the hole is HOLE_EPS across: the wall looks solid
    there but has the same points on every frame (motion blur, point caches)."""
    if not own_build(op):
        return u0, u1, y0, y1
    progress = build_progress(op)
    if progress >= 1.0:
        return u0, u1, y0, y1
    style = int(aw_host.value(op, I.AW_OPENING_BUILD_STYLE))
    if style == aw_build.PARTS:
        t = aw_build.smooth(aw_build.share(progress, 0, len(aw_build.STAGES),
                                           float(aw_host.value(op, I.AW_OPENING_BUILD_STAGGER))))
    else:
        t = aw_build.smooth(progress)
    if style == aw_build.RISE_IN:
        return u0, u1, y0, y0 + max((y1 - y0) * t, HOLE_EPS)
    uc, yc = (u0 + u1) / 2, (y0 + y1) / 2
    hu, hy = max((u1 - u0) / 2 * t, HOLE_EPS / 2), max((y1 - y0) / 2 * t, HOLE_EPS / 2)
    return uc - hu, uc + hu, yc - hy, yc + hy


def own_deform(op):
    """fn(builder) for aw_mesh.deforming: op's own build-on, or None (built with its wall,
    or finished)."""
    if not own_build(op):
        return None
    progress = build_progress(op)
    if progress >= 1.0:
        return None
    style = int(aw_host.value(op, I.AW_OPENING_BUILD_STYLE))
    stagger = float(aw_host.value(op, I.AW_OPENING_BUILD_STAGGER))
    return lambda builder: aw_build.opening(builder, progress, style, stagger)


def follow_wall(op, frame, plan, height, build):
    """fn(builder) for aw_mesh.deforming: op's points (in its own frame, before frame
    carries them onto its segment) moved by its wall's Build as the wall's own points
    around it are, or None (it builds on its own, or the wall stands)."""
    if own_build(op) or not build or build[0] >= 1.0:
        return None
    ml = aw_host.local_matrix(op)
    k = plan.project(ml.off.x, ml.off.z)[0]

    def fn(builder):
        pts = [ml * (frame * p if frame is not None else p) for p in builder.points]
        aw_wall.deform(plan, height, build, pts, [aw_wall.point_tag(plan, k, p.x, p.z) for p in pts],
                       sink=aw_wall.WINDOW_SINK)
        inv, finv = ~ml, (~frame if frame is not None else None)
        builder.points[:] = [finv * (inv * p) if finv is not None else inv * p for p in pts]
    return fn


def _wall(op):
    up = aw_host.parent(op)
    return up if up is not None and aw_host.type_id(up) == I.ID_AW_WALL else None


def _at(plan, k, u, w, y=0.0):
    seg = plan.segments[k]
    return (seg["a"][0] + seg["d"][0] * u + seg["n"][0] * w, y, seg["a"][1] + seg["d"][1] * u + seg["n"][1] * w)


def place_of(op):
    """Where opening op sits on its wall, or None: {wall, plan, w0, w1, height, k,
    uc, u0, u1, y0, y1, left, right}, u along its segment (unclipped), left and right
    the nearest things either side on that segment."""
    wall = _wall(op)
    wp = aw_wall.wall_path(wall) if wall is not None else None
    if wp is None:
        return None
    plan, w0, w1, height, _splines = wp
    k, u0, u1, y0, y1, uc = aw_wall.path_opening(op, plan, height)
    c0, c1 = plan.clear_span(k, w0, w1)
    left, right = c0, c1
    me = aw_host.ident(op)
    for other in aw_host.cutters(wall):
        if aw_host.ident(other) == me:
            continue
        ok, o0, o1, _a, _b, _c = aw_wall.path_opening(other, plan, height)
        if ok != k:
            continue
        if o1 <= u0 + 1e-6:
            left = max(left, o1)
        elif o0 >= u1 - 1e-6:
            right = min(right, o0)
    return {"wall": wall, "plan": plan, "w0": w0, "w1": w1, "height": height, "k": k, "uc": uc,
            "u0": u0, "u1": u1, "y0": y0, "y1": y1, "left": left, "right": right}


def focus_layout(op):
    """The aw_dims layout (in the wall's space) for selected opening op."""
    f = place_of(op)
    if f is None:
        return None
    plan, k = f["plan"], f["k"]
    u0, u1, y0, y1 = f["u0"], f["u1"], f["y0"], f["y1"]
    seg = plan.segments[k]
    n, d = seg["n"], seg["d"]
    face = f["w0"] - D.FRONT
    chain = f["w0"] - D.CHAIN_OUT
    forward = (-n[0], 0.0, -n[1])     # out from the Exterior face
    toward = (n[0], 0.0, n[1])        # back towards the wall
    past = (d[0], 0.0, d[1])          # along the wall, past its right edge
    hu = u1 + D.OPENING_H_OUT
    dims, ext = [], []
    if u0 - f["left"] > 0.05:
        dims.append(D._dim("gap", "focus", "x", u0 - f["left"], _at(plan, k, f["left"], chain), _at(plan, k, u0, chain),
                           out=toward, grips=("b",), edit={"do": "opening_gap_left", "child": op}))
    dims.append(D._dim("width", "focus", "x", u1 - u0, _at(plan, k, u0, chain), _at(plan, k, u1, chain),
                       out=forward, grips=("a", "b"), edit={"do": "opening_width", "child": op}))
    if f["right"] - u1 > 0.05:
        dims.append(D._dim("gap", "focus", "x", f["right"] - u1, _at(plan, k, u1, chain), _at(plan, k, f["right"], chain),
                           out=toward, grips=("a",), edit={"do": "opening_gap_right", "child": op}))
    if y0 > 0.05:
        dims.append(D._dim("sill", "focus", "y", y0, _at(plan, k, hu, face), _at(plan, k, hu, face, y0), out=past,
                           grips=("b",), edit={"do": "opening_sill", "child": op}))
    dims.append(D._dim("opening_height", "focus", "y", y1 - y0, _at(plan, k, hu, face, y0), _at(plan, k, hu, face, y1),
                       out=past, grips=("a", "b"), edit={"do": "opening_height", "child": op}))
    ext += [D._ext(_at(plan, k, u1, face, y0), _at(plan, k, hu, face, y0), "focus"),
            D._ext(_at(plan, k, u1, face, y1), _at(plan, k, hu, face, y1), "focus"),
            D._ext(_at(plan, k, u0, f["w0"]), _at(plan, k, u0, chain), "focus"),
            D._ext(_at(plan, k, u1, f["w0"]), _at(plan, k, u1, chain), "focus")]
    outline = [_at(plan, k, u0, face, y0), _at(plan, k, u1, face, y0), _at(plan, k, u1, face, y1), _at(plan, k, u0, face, y1)]
    return {"dims": dims, "ext": ext, "outline": outline, "grips": I.is_opening(op)}


GRIP_KINDS = D.OPENING_GRIP_KINDS  # Left, Right, Sill, Top, Move


def grip_points(op):
    """[(position, direction)] (Vecs) in op's own space for its five grips, or [] when
    it isn't on a spline wall. (The host decides when grips show: grips().)"""
    f = place_of(op)
    if f is None:
        return []
    plan, k = f["plan"], f["k"]
    seg = plan.segments[k]
    d = Vec(seg["d"][0], 0, seg["d"][1])
    up = Vec(0, 1, 0)
    chain, face = f["w0"] - D.CHAIN_OUT, f["w0"] - D.FRONT
    hu = f["u1"] + D.OPENING_H_OUT
    wall_space = [(_at(plan, k, f["u0"], chain), -d), (_at(plan, k, f["u1"], chain), d),
                  (_at(plan, k, hu, face, f["y0"]), up), (_at(plan, k, hu, face, f["y1"]), up),
                  (_at(plan, k, (f["u0"] + f["u1"]) / 2, chain), d)]
    inv = ~aw_host.local_matrix(op)
    return [(inv * Vec(*p), inv.turn(v)) for p, v in wall_space]


def set_grip(op, i, p_local):
    """Grip i of opening op dragged to p (op's own space)."""
    f = place_of(op)
    if f is None or not I.is_opening(op):
        return
    ml = aw_host.local_matrix(op)
    p = ml * p_local  # the wall's space
    seg = f["plan"].segments[f["k"]]
    u = (p.x - seg["a"][0]) * seg["d"][0] + (p.z - seg["a"][1]) * seg["d"][1]
    uc, u0, u1 = f["uc"], f["u0"], f["u1"]
    width = u1 - u0
    base = ml.off.y
    put = aw_host.set_value
    if i == 0:  # Left: only the left edge moves
        nu0 = min(u, u1 - I.MIN_SIZE)
        put(op, I.AW_OPENING_START, nu0 - uc)
        put(op, I.AW_OPENING_WIDTH, u1 - nu0)
    elif i == 1:  # Right
        put(op, I.AW_OPENING_WIDTH, max(u - u0, I.MIN_SIZE))
    elif i == 2:  # Sill: raise or lower the whole opening, never below the floor
        put(op, I.AW_OPENING_SILL, max(p.y, 0.0) - base)
    elif i == 3:  # Top
        put(op, I.AW_OPENING_HEIGHT, max(p.y - f["y0"], I.MIN_SIZE))
    else:  # Move: slide along the wall
        put(op, I.AW_OPENING_START, u - uc - width / 2)


def apply(doc, wall, edit, value):
    """A typed value into one of the focus guides (aw_edit.apply hands these over)."""
    op = edit["child"]
    up = aw_host.parent(op) if aw_host.alive(op) else None
    if up is None or aw_host.ident(up) != aw_host.ident(wall):
        raise ValueError("that window moved; select it again")
    if not I.is_opening(op):
        raise ValueError("only Archwerks windows can be typed; move a cutter by hand")
    f = place_of(op)
    if f is None:
        raise ValueError("that window isn't on a wall")
    do = edit["do"]
    width, uc = f["u1"] - f["u0"], f["uc"]
    if do in ("opening_width", "opening_height") and value < I.MIN_SIZE:
        raise ValueError("must be more than 0")
    if value < 0:
        raise ValueError("can't be negative")
    put = aw_host.set_value
    if do == "opening_gap_left":
        put(op, I.AW_OPENING_START, f["left"] + value - uc, undo=True)
    elif do == "opening_gap_right":
        put(op, I.AW_OPENING_START, f["right"] - value - width - uc, undo=True)
    elif do == "opening_width":  # keeps its left edge
        put(op, I.AW_OPENING_WIDTH, value, undo=True)
    elif do == "opening_height":  # keeps its sill
        put(op, I.AW_OPENING_HEIGHT, value, undo=True)
    elif do == "opening_sill":  # keeps its height
        put(op, I.AW_OPENING_SILL, value - aw_host.local_matrix(op).off.y, undo=True)
    else:
        raise ValueError("unknown edit %r" % do)
    return "%s %s" % (aw_host.name(op), do[len("opening_"):].replace("_", " "))


def reach(child, plan, k, u0, u1, y0, y1):
    """(u0, u1, y0, y1) of everything a window shows on its segment: its hole, and
    for an AW Opening whatever stands past it (Frame Out casing, sills, a
    surface-mounted frame), from its built geometry's bounds."""
    pts = aw_host.shown_points(child) if I.is_opening(child) else None  # only on a click: a few hundred
    if not pts:
        return u0, u1, y0, y1
    seg = plan.segments[k]
    (ax, az), (dx, dz) = seg["a"], seg["d"]
    us = [(x - ax) * dx + (z - az) * dz for x, _y, z in pts]
    ys = [y for _x, y, _z in pts]
    return min(u0, min(us)), max(u1, max(us)), min(y0, min(ys)), max(y1, max(ys))


def drape_fit(x0, x1, y1, face_in, s, size):
    """Where a window's drape goes, in the window's own space (x along it, y up from the floor,
    +z the room): (centre x, bottom y, back z, width, height) for the window's hole x0..x1
    with its head at y1 and its room-side face at face_in; s: {rod, extend, drop, offset};
    size: the drape object's own (width, height), only to refuse a degenerate one. None if
    it can't fit (no height between its Drop and its rod)."""
    width = (x1 - x0) + 2 * max(s["extend"], 0.0)
    top = y1 + s["rod"]
    height = top - s["drop"]
    if width <= 1.0 or height <= 1.0 or size[0] <= 1e-6 or size[1] <= 1e-6:
        return None
    return ((x0 + x1) / 2, s["drop"], face_in + max(s["offset"], 0.0), width, height)
