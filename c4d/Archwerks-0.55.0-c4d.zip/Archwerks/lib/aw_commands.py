"""Every Archwerks command, the one list both hosts build their menus from: the Archwerks
menu in each menu bar (a submenu per group, in this order), the Add menu, and the
toolbars and palettes later. Each host maps a command's key to what it does there
(blender/menus.py, src/aw_commands_c4d.py) and leaves out what it hasn't got, so a name,
an icon or an order can't differ between them.

A command: key (stable, never renamed), label, group, icon (archwerks/icons), help (a
tooltip and Cinema 4D's status bar), presets (True: it picks from its kind's presets,
a submenu in Blender, a popup in Cinema 4D) and hosts (where it exists today).
"""

GROUPS = (("build", "Build"), ("openings", "Openings"), ("interior", "Interior"), ("kitchen", "Kitchen"),
          ("roof", "Roof"), ("annotate", "Annotate"), ("deliver", "Deliver"))

BOTH, C4D, BLENDER = ("c4d", "blender"), ("c4d",), ("blender",)


def _cmd(key, label, group, icon, help, presets=False, hosts=BOTH, c4d_name=None):
    """c4d_name: the command's own name in Cinema 4D where its words differ (a Layout, not a Workspace);
    else "AW " + label, as Cinema 4D shows plugin commands."""
    return {"key": key, "label": label, "group": group, "icon": icon, "help": help, "presets": presets,
            "hosts": tuple(hosts), "c4d_name": c4d_name or "AW " + label}


COMMANDS = (
    _cmd("workspace", "Archwerks Workspace", None, "archwerks",
         "Switch to the Archwerks layout: a Top plan view beside Perspective, the Archwerks panel open",
         c4d_name="Archwerks Layout"),
    _cmd("wall", "Wall", "build", "wall", "Draw a wall, or pick a wall preset to draw with", presets=True),
    _cmd("walls_from_spline", "Walls from Spline", "build", "wall", "Turn the selected splines into walls", hosts=C4D),
    _cmd("floor", "Floor", "build", "floor", "A floor in the selected walls' rooms, or one you draw"),
    _cmd("ceiling", "Ceiling", "build", "ceiling", "A ceiling over the selected walls' rooms, or one you draw"),
    _cmd("slab", "Slab", "build", "slab", "A slab under or over the selected walls"),
    _cmd("stair", "Stair", "build", "stair", "A stair along the selected spline, or a straight one"),
    _cmd("railing", "Railing", "build", "railing", "A railing on the selected stair, or along a path", presets=True),
    _cmd("beam", "Beam", "build", "beam", "A row of beams", hosts=C4D),
    _cmd("window", "Window", "openings", "window", "Pick a window, then click a wall to place it", presets=True),
    _cmd("door", "Door", "openings", "door", "Pick a door, then click a wall to place it", presets=True),
    _cmd("archway", "Cutout", "openings", "hole", "A shaped hole through a wall: an arch to walk through, or a "
         "pass-through over a counter", presets=True),  # key: its registered C4D menu id (aw_ids.COMMAND_IDS)
    _cmd("fireplace", "Fireplace", "openings", "fireplace", "Pick a fireplace, then click a wall", presets=True),
    _cmd("baseboard", "Baseboard", "interior", "baseboard", "Baseboards along the selected walls' rooms"),
    _cmd("crown", "Crown", "interior", "crown", "Crown molding along the selected walls' rooms"),
    _cmd("wall_panels", "Wall Panels", "interior", "panels", "Picture-frame panels on the selected walls"),
    _cmd("cabinet", "Cabinet", "kitchen", "cabinet", "Pick a cabinet, then click a wall to place it", presets=True),
    _cmd("countertop", "Countertop", "kitchen", "countertop", "A countertop over the selected cabinets"),
    _cmd("sink", "Sink", "kitchen", "sink", "Pick a sink for the selected countertop", presets=True),
    _cmd("add_pull", "Add to Pulls Library", "kitchen", "cabinet", "Keep the selected object as a pull or knob",
         hosts=C4D),
    _cmd("roof", "Roof", "roof", "roof", "A roof over the selected walls, or one you draw"),
    _cmd("roof_cutter", "Roof Cutter", "roof", "roof_cutter", "A cutter in the selected roof"),
    _cmd("edit_dimensions", "Edit Dimensions", "annotate", "edit_dims", "Click a dimension label and type its value",
         hosts=C4D),
    _cmd("floor_plan", "Floor Plan", "annotate", "floor_plan", "Lay a floor plan image on the floor to trace over",
         hosts=C4D),
    _cmd("scale_plan", "Scale Plan", "annotate", "scale_plan", "Drag across a known dimension and type its length",
         hosts=C4D),
    _cmd("bake", "Bake to Mesh", "deliver", "slab", "Turn the selected Archwerks objects into plain meshes",
         hosts=BLENDER),
    _cmd("tidy", "Tidy into Groups", "deliver", "archwerks", "Sort every Archwerks object into the Archwerks groups"),
)
BY_KEY = {c["key"]: c for c in COMMANDS}
TOP = ("workspace",)  # above the groups, at the top of each host's Archwerks menu


# The panels' Create (Blender's Sidebar, Cinema 4D's Archwerks panel): tabs of groups, as
# Motionwerks' Cues and Camera. (id, label, the groups it shows.)
TABS = (("BUILD", "Build", ("build", "interior", "roof")),
        ("OPENINGS", "Openings", ("openings",)),
        ("KITCHEN", "Kitchen", ("kitchen",)))
CARDS = {"window": "window", "door": "door", "archway": "cutter", "fireplace": "fireplace", "cabinet": "cabinet",
         "wall": "wall", "stair": "stair", "railing": "railing", "baseboard": "baseboard", "crown": "crown",
         "roof": "roof", "beam": "beam"}  # command key: the card (core/aw_catalog kind) its button shows
CARD_DEFAULT = {"OPENINGS": "window", "KITCHEN": "cabinet"}  # a tab's card before one is chosen
TAIL = ("tidy",)  # under every tab


def tab_of_card(kind):
    """The tab whose groups hold the command that shows card kind."""
    for tid, _label, groups in TABS:
        if any(c["group"] in groups and CARDS.get(c["key"]) == kind for c in COMMANDS):
            return tid
    return None


def for_host(host):
    """[(group key, group label, [command])] for what host has, groups in order, empty ones left out."""
    out = []
    for key, label in GROUPS:
        cmds = [c for c in COMMANDS if c["group"] == key and host in c["hosts"]]
        if cmds:
            out.append((key, label, cmds))
    return out
