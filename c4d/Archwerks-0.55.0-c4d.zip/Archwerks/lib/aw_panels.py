"""Archwerks wall panels: picture-frame moldings on a Wall's faces, as in a panelled room.

Wall Panels links to a Wall, as a Baseboard does, and lines its rooms (and any open run)
on the face Faces picks: along every stretch of wall between its corners and openings
(doors, windows, fireplaces, archways, each with its casing), frames of molding from
Bottom up to Top below the wall's top, Margin in from each end of the stretch and Gap
apart, as many as fit at about Panel Width each, all the same width. A stretch too short
for one of Min Width is left plain. Over and Under Openings frames what is left: one frame
over each opening (a door, a window, a fireplace's mantel), Gap above it, and one under
each window, Gap below it, each as wide as the opening, where there is room. The frame is a molding profile (aw_molding's, or a
Custom one) Frame Width across and Frame Depth deep, mitred at its corners.

Flourishes: an ornament in each top corner of every frame (or all four corners), Inset in
from the frame: the built-in one is a carved scroll (a curl along the top and one down the
side, a leaf between them, a bead in the corner), Flourish Size across; Custom places any
object instead, modelled flat for the top-left corner as seen from above (its origin at the
corner, running +X along the top and -Z down the side, its relief rising +Y), mirrored for
the other corners.

Stretches: a run is split only at its sharp turns (a room's corners, past SHARP); where its
segments meet at gentler ones (a curve drawn with many points) the stretch runs on and its
frames bend with it, mitred at every joint.

With no Wall linked, Wall Panels follow their own child curves instead (drawn with the
Blender add-on's Draw tool, or any spline in Cinema 4D), as a molding does: Faces Inside on
the path's left (the inside of a closed loop), from the path's height, Height standing in
for the wall's top. Built in the wall's space (aw_host.relative), or its own, in cm.
"""
import math

import aw_host
from aw_vec import Vec

GROUPS = ("Frames", "Flourishes")
INSIDE, OUTSIDE = 0, 1
NO_FLOURISH, TOP_CORNERS, ALL_CORNERS = 0, 1, 2
BUILT_IN, CUSTOM = 0, 1


def panel_spans(a, b, margin, gap, target, min_w):
    """[(u0, u1)] of the frames along a free stretch a..b: Margin in from each end, Gap
    apart, as many as fit at about target width, all alike; [] when none of min_w fits."""
    room = (b - a) - 2 * max(margin, 0.0)
    gap = max(gap, 0.0)
    if room < max(min_w, 1.0):
        return []
    n = max(1, int(round((room + gap) / (max(target, 1.0) + gap))))
    while n > 1 and (room - (n - 1) * gap) / n < min_w:
        n -= 1
    w = (room - (n - 1) * gap) / n
    if w < min_w:
        return []
    start = a + max(margin, 0.0)
    return [(start + i * (w + gap), start + i * (w + gap) + w) for i in range(n)]


def free_stretches(u0, u1, cuts):
    """u0..u1 with the cuts [(a, b)] taken out: [(a, b)]."""
    free = [(u0, u1)]
    for a, b in sorted(cuts):
        nxt = []
        for fa, fb in free:
            if b <= fa or a >= fb:
                nxt.append((fa, fb))
                continue
            if a > fa:
                nxt.append((fa, a))
            if b < fb:
                nxt.append((b, fb))
        free = nxt
    return [(a, b) for a, b in free if b - a > 0.05]


# The built-in flourish, drawn for a top-left corner in its own (p, q): p along the top
# edge into the panel, q down its side, the corner at (0, 0); 10 units across (scaled).

def _spiral(x0, y0, length, r0, turns, along_p=True):
    """A curl's centre line: straight from (x0, y0) for length, then a spiral tightening
    from radius r0 over turns, curling into the panel. along_p False: the same down the side."""
    pts = [(x0 + length * i / 6, y0) for i in range(7)]
    cx, cy = x0 + length, y0 + r0
    steps = int(28 * turns)
    for i in range(1, steps + 1):
        phi = 2 * math.pi * turns * i / steps
        r = r0 * (1.0 - 0.55 * phi / (2 * math.pi))
        pts.append((cx + r * math.sin(phi), cy - r * math.cos(phi)))
    return pts if along_p else [(q, p) for p, q in pts]


def flourish_pieces():
    """[(centre line [(p, q)], widths, depth)] of the built-in scroll, 10 units across."""
    out = []
    curl = _spiral(2.2, 0.9, 5.8, 1.6, 1.1)
    n = len(curl)
    widths = [0.6 if i < 7 else 0.6 - 0.38 * (i - 7) / max(n - 8, 1) for i in range(n)]
    out.append((curl, widths, 0.7))
    out.append(([(q, p) for p, q in curl], widths, 0.7))
    leaf = [(2.0 + 5.5 * i / 12, 2.0 + 5.5 * i / 12) for i in range(13)]
    out.append((leaf, [0.15 + 2.0 * math.sin(math.pi * i / 12) ** 0.7 for i in range(13)], 1.0))
    bead = [(0.45 + 1.8 * i / 8, 0.45 + 1.8 * i / 8) for i in range(9)]
    out.append((bead, [0.15 + 1.4 * math.sin(math.pi * i / 8) ** 0.5 for i in range(9)], 1.1))
    return out


def _strip(mesh, line, widths, depth, put, group):
    """A closed solid ribbon along line [(p, q)], widths across it, rising depth (thinner
    where it's narrow); put(p, q, out) gives a point's index."""
    first = len(mesh.polys)
    n = len(line)
    wmax = max(widths)
    sides = []
    for i in range(n):
        a = line[max(i - 1, 0)]
        b = line[min(i + 1, n - 1)]
        tp, tq = b[0] - a[0], b[1] - a[1]
        L = math.hypot(tp, tq) or 1.0
        np_, nq = -tq / L, tp / L
        w = max(widths[i], 0.15) / 2
        d = depth * (0.55 + 0.45 * widths[i] / wmax)
        p, q = line[i]
        sides.append(((p + np_ * w, q + nq * w), (p - np_ * w, q - nq * w), d))
    lb = [put(l[0], l[1], 0.0) for l, _r, _d in sides]
    rb = [put(r[0], r[1], 0.0) for _l, r, _d in sides]
    lt = [put(l[0], l[1], d) for l, _r, d in sides]
    rt = [put(r[0], r[1], d) for _l, r, d in sides]
    for i in range(n - 1):
        j = i + 1
        mesh.quad(lt[i], lt[j], rt[j], rt[i], group)
        mesh.quad(rb[i], rb[j], lb[j], lb[i], group)
        mesh.quad(lb[i], lb[j], lt[j], lt[i], group)
        mesh.quad(rt[i], rt[j], rb[j], rb[i], group)
    mesh.quad(lb[0], lt[0], rt[0], rb[0], group)
    mesh.quad(rb[-1], rt[-1], lt[-1], lb[-1], group)
    mesh._face_out(first)


# Settings and building (through the host) -------------------------------------------------

def settings(op):
    import aw_ids as I
    v = lambda pid: aw_host.value(op, pid)  # noqa: E731
    return {"wall": aw_host.link(op, I.AW_PNL_WALL), "side": int(v(I.AW_PNL_SIDE)),
            "bottom": float(v(I.AW_PNL_BOTTOM)), "top": float(v(I.AW_PNL_TOP)),
            "margin": float(v(I.AW_PNL_MARGIN)), "gap": float(v(I.AW_PNL_GAP)),
            "width": float(v(I.AW_PNL_WIDTH)), "min_w": float(v(I.AW_PNL_MIN_W)),
            "breaks": bool(v(I.AW_PNL_BREAKS)), "around": bool(v(I.AW_PNL_AROUND)), "profile": int(v(I.AW_PNL_PROFILE)),
            "frame_w": max(float(v(I.AW_PNL_FRAME_W)), 0.2), "frame_d": max(float(v(I.AW_PNL_FRAME_D)), 0.1),
            "custom": aw_host.link(op, I.AW_PNL_CUSTOM),
            "flourish": int(v(I.AW_PNL_FLOURISH)), "flourish_kind": int(v(I.AW_PNL_FLOURISH_KIND)),
            "flourish_size": max(float(v(I.AW_PNL_FLOURISH_SIZE)), 0.5),
            "flourish_d": max(float(v(I.AW_PNL_FLOURISH_D)), 0.05),
            "flourish_inset": float(v(I.AW_PNL_FLOURISH_INSET)),
            "flourish_obj": aw_host.link(op, I.AW_PNL_FLOURISH_OBJ), "height": float(v(I.AW_PNL_HEIGHT))}


def _frame_profile(s):
    import aw_molding as M
    shape = M.custom_profile(s["custom"]) if s["profile"] == M.CUSTOM and s["custom"] is not None else None
    kind = s["profile"] if s["profile"] != M.CUSTOM else M.SQUARE
    return M.ccw(shape or M.profile(kind, s["frame_w"], s["frame_d"]))


def _frame(mesh, put, s0, s1, y0, y1, shape, bends=()):
    """A mitred rectangle of the profile shape [(out, across)] from s0..s1 along a stretch
    by y0..y1, its across measured in from the outer edge; its top and bottom bend through
    the stretch's joints in bends (distances along it)."""
    mesh.new_part()
    first = len(mesh.polys)
    width = max(h for _o, h in shape)
    inner = [b for b in sorted(bends) if s0 + width + 1e-6 < b < s1 - width - 1e-6]
    rings = []
    for o, h in shape:
        a, b, lo, hi = s0 + h, s1 - h, y0 + h, y1 - h
        loop = [(a, lo)] + [(t, lo) for t in inner] + [(b, lo), (b, hi)] + [(t, hi) for t in reversed(inner)] + [(a, hi)]
        rings.append([put(t, y, o) for t, y in loop])
    m, n = len(shape), len(rings[0])
    for j in range(m):
        jj = (j + 1) % m
        for c in range(n):
            cc = (c + 1) % n
            mesh.quad(rings[j][c], rings[jj][c], rings[jj][cc], rings[j][cc], "Frames")
    mesh._face_out(first)


def _flourishes(mesh, s, put, s0, s1, y0, y1, custom):
    """The ornaments in a frame's corners (inside the frame, Inset in)."""
    e = s["frame_w"] + max(s["flourish_inset"], 0.0)
    corners = [(s0 + e, y1 - e, 1.0, -1.0), (s1 - e, y1 - e, -1.0, -1.0)]
    if s["flourish"] == ALL_CORNERS:
        corners += [(s0 + e, y0 + e, 1.0, 1.0), (s1 - e, y0 + e, -1.0, 1.0)]
    k = s["flourish_size"] / 10.0
    if (s1 - s0) - 2 * e < 2.2 * s["flourish_size"] or (y1 - y0) - 2 * e < 2.2 * s["flourish_size"]:
        return  # no room for them
    for cu, cy, su, sy in corners:
        if s["flourish_kind"] == CUSTOM:
            if custom:
                pts, polys = custom
                mesh.new_part()
                mesh.add_mesh(pts, polys, lambda x, y, z, cu=cu, cy=cy, su=su, sy=sy: put.at(cu + su * x, cy - sy * z, y),
                              "Flourishes")
            continue
        o = Vec(*put.at(cu, cy, 0.0))  # the scroll's own (p, q, out) carried onto the wall here
        ep = Vec(*put.at(cu + su * k, cy, 0.0)) - o
        eq = Vec(*put.at(cu, cy + sy * k, 0.0)) - o
        eo = Vec(*put.at(cu, cy, s["flourish_d"])) - o
        pts, polys = _scroll()
        mesh.new_part()
        mesh.add_mesh(pts, polys, lambda p, q, out, o=o, ep=ep, eq=eq, eo=eo: (
            o.x + ep.x * p + eq.x * q + eo.x * out, o.y + ep.y * p + eq.y * q + eo.y * out,
            o.z + ep.z * p + eq.z * q + eo.z * out), "Flourishes")


_SCROLL = []  # the built-in scroll's (points, polys) in its own (p, q, out), made once


def _scroll():
    """The built-in scroll as one mesh in its own (p, q, out): its pieces as _strip makes them."""
    if not _SCROLL:
        from aw_mesh import MeshBuilder
        m = MeshBuilder(GROUPS)
        for line, widths, depth in flourish_pieces():
            m.new_part()
            _strip(m, line, widths, depth, lambda p, q, out: m.pt(p, q, out), "Flourishes")
        _SCROLL.append((list(m.points), list(m.polys)))
    return _SCROLL[0]


SHARP = 35.0  # degrees: a turn sharper than this ends a stretch (a room's corner); gentler ones bend it


class Stretch:
    """Consecutive segments of a run meeting at gentle turns, one length to lay frames
    along: distance s from its start along the face line at w (mitred at its joints)."""

    def __init__(self, plan, ks, w):
        self.plan, self.items, self.w = plan, [], w
        at = 0.0
        for k in ks:
            a, b = plan.along(k, plan.corner(k, False, w)), plan.along(k, plan.corner(k, True, w))
            a, b = min(a, b), max(a, b)
            self.items.append((k, a, b, at))
            at += b - a
        self.length = at

    def joints(self):
        return [it[3] for it in self.items[1:]]

    def locate(self, s):
        """(index into items, segment, u along it) at distance s."""
        for i, (k, a, b, at) in enumerate(self.items):
            if s <= at + (b - a) + 1e-9 or i == len(self.items) - 1:
                return i, k, a + min(max(s - at, 0.0), b - a)
        return 0, self.items[0][0], self.items[0][1]

    def to_s(self, k, u):
        for kk, a, _b, at in self.items:
            if kk == k:
                return at + (u - a)
        return None

    def point(self, s, out, sign):
        """(x, z) at distance s, out from the face (mitred exactly at a joint)."""
        i, k, u = self.locate(s)
        w = self.w + sign * out
        _k, a, b, at = self.items[i]
        if i > 0 and abs(s - at) < 1e-6:
            return self.plan.corner(k, False, w)
        if i < len(self.items) - 1 and abs(s - (at + b - a)) < 1e-6:
            return self.plan.corner(k, True, w)
        seg = self.plan.segments[k]
        return (seg["a"][0] + seg["d"][0] * u + seg["n"][0] * w, seg["a"][1] + seg["d"][1] * u + seg["n"][1] * w)

    def lowest(self, s0, s1, fn):
        """The least of fn(segment, u) at s0, s1 and every joint between."""
        out = []
        for s in [s0, s1] + [j for j in self.joints() if s0 < j < s1]:
            _i, k, u = self.locate(s)
            out.append(fn(k, u))
        return min(out)


def stretches(plan, r, w):
    """Run r split into Stretches at its sharp turns (a closed run with none: one,
    from its first point)."""
    ks = plan.run_segments(r)
    if not ks:
        return []
    def sharp(k1, k2):
        d1, d2 = plan.segments[k1]["d"], plan.segments[k2]["d"]
        return d1[0] * d2[0] + d1[1] * d2[1] < math.cos(math.radians(SHARP))
    closed = plan.runs[r].closed
    n = len(ks)
    if closed:
        cut = next((i for i in range(n) if sharp(ks[i - 1], ks[i])), None)
        if cut is not None:
            ks = ks[cut:] + ks[:cut]
    groups = [[ks[0]]]
    for k in ks[1:]:
        if sharp(groups[-1][-1], k):
            groups.append([k])
        else:
            groups[-1].append(k)
    return [Stretch(plan, g, w) for g in groups]


class _Put:
    """Points on a stretch, carried into the panels' own space: (s along it, y up, out
    from the face) -> a mesh point."""

    def __init__(self, mesh, to_local, sign):
        self.mesh, self.sign = mesh, sign
        o, a, b, c = to_local.off, to_local.v1, to_local.v2, to_local.v3
        self.m = (o.x, o.y, o.z, a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z)
        self.stretch = None

    def at(self, s, y, out):
        x, z = self.stretch.point(s, out, self.sign)
        ox, oy, oz, ax, ay, az, bx, by, bz, cx, cy, cz = self.m  # to_local * (x, y, z), without a Vec per point
        return (ox + ax * x + bx * y + cx * z, oy + ay * x + by * y + cy * z, oz + az * x + bz * y + cz * z)

    def __call__(self, s, y, out):
        return self.mesh.pt(*self.at(s, y, out))


def opening_rects(wall, plan, height, band):
    """{segment: [(u0, u1, y0, y1)]} of what the wall's openings show (casings and all)
    in the band (lo, hi) of heights, as a molding finds them (aw_molding._cuts)."""
    import aw_ids as I
    import aw_openings
    import aw_wall
    out = {}
    for child in aw_host.cutters(wall):
        if aw_host.type_id(child) == I.ID_AW_CUTTER and not aw_host.value(child, I.AW_CUTTER_CUT_MOLDINGS):
            continue
        k, u0, u1, y0, y1, _uc = aw_wall.path_opening(child, plan, height)
        u0, u1, y0, y1 = aw_openings.reach(child, plan, k, u0, u1, y0, y1)
        if y0 < band[1] - 0.01 and y1 > band[0] + 0.01:
            out.setdefault(k, []).append((u0, u1, y0, y1))
    return out


def around(rects, bottom, top_at, gap, min_h):
    """[(u0, u1, y0, y1)] of the frames over and under openings rects [(u0, u1, y0, y1)]:
    one over each, from Gap above it to the top (top_at(u0, u1)), and one under each that
    stands clear of the floor (a window), from the bottom to Gap below it; only where
    there's min_h of height."""
    out = []
    for u0, u1, y0, y1 in rects:
        top = top_at(u0, u1)
        if top - (y1 + gap) >= min_h:
            out.append((u0, u1, y1 + gap, top))
        if (y0 - gap) - bottom >= min_h:
            out.append((u0, u1, bottom, y0 - gap))
    return out


def build(op):
    """The panels' mesh in their own space, or None: along the rooms of their Wall, or
    with none linked, along their own child curves (Height standing in for the wall's top)."""
    import aw_molding
    import aw_wall
    from aw_mat import Mat
    from aw_mesh import MeshBuilder
    s = settings(op)
    wall = s["wall"]
    own = not aw_host.alive(wall)
    if own:
        plan = aw_molding.own_path(op)
        if plan is None:
            return None
        w0 = w1 = 0.0
        height = s["height"]
    else:
        wp = aw_wall.wall_path(wall)
        if wp is None:
            return None
        plan, w0, w1, height, _splines = wp
    sign = 1.0 if s["side"] == INSIDE else -1.0  # rooms are on +n of every closed run
    face = w1 if s["side"] == INSIDE else w0
    rects = opening_rects(wall, plan, height, (s["bottom"], height)) if s["breaks"] and not own else {}
    custom = None
    if s["flourish"] != NO_FLOURISH and s["flourish_kind"] == CUSTOM and aw_host.alive(s["flourish_obj"]):
        custom = aw_host.custom_mesh(s["flourish_obj"])
    mesh = MeshBuilder(GROUPS)
    put = _Put(mesh, Mat() if own else aw_host.relative(op, wall), sign)
    shape = _frame_profile(s)
    min_h = max(4 * s["frame_w"] + 5.0, 15.0)
    for r, _run in enumerate(plan.runs):
        for st in stretches(plan, r, face):
            put.stretch = st
            cuts = []
            for k, items in rects.items():
                for u0, u1, y0, y1 in items:
                    a, b = st.to_s(k, u0), st.to_s(k, u1)
                    if a is not None:
                        cuts.append((max(min(a, b), 0.0), min(max(a, b), st.length), y0, y1))
            if own:  # on its own path: the frames from its points' heights
                base = st.lowest(0.0, st.length, lambda k, u: plan.top(k, u, 0.0))
                bottom, top_at = base + s["bottom"], (lambda s0, s1, base=base: base + height - s["top"])
            else:
                bottom = s["bottom"]
                top_at = lambda s0, s1, st=st: st.lowest(s0, s1, lambda k, u: plan.top(k, u, height)) - s["top"]  # noqa: E731
            frames = []
            for fa, fb in free_stretches(0.0, st.length, [(c[0], c[1]) for c in cuts]):
                top = top_at(fa, fb)
                if top - bottom >= 4 * s["frame_w"]:
                    frames += [(u0, u1, bottom, top)
                               for u0, u1 in panel_spans(fa, fb, s["margin"], s["gap"], s["width"], s["min_w"])]
            if s["around"]:
                frames += around([c for c in cuts if c[1] - c[0] >= s["min_w"]], bottom, top_at, s["gap"], min_h)
            for u0, u1, y0, y1 in frames:
                _frame(mesh, put, u0, u1, y0, y1, shape, st.joints())
                if s["flourish"] != NO_FLOURISH:
                    _flourishes(mesh, s, put, u0, u1, y0, y1, custom)
    if not mesh.polys:
        return None
    return mesh.build(aw_host.name(op))
