"""Cinema 4D's side of the mesh builder: a finished aw_mesh.MeshBuilder turned into
a PolygonObject. The builder itself is in the core (shared with Blender); this
module hands it out as before, so `from aw_lib import MeshBuilder` still works.
"""
import c4d

from aw_mesh import MeshBuilder, TINT_TAG, UV_TILE  # noqa: F401  (handed out from here)


def to_object(self, name):
    """A PolygonObject for MeshBuilder self: its UVs, one selection tag per group, its
    tints as a vertex colour tag, and Phong."""
    obj = c4d.PolygonObject(len(self.points), len(self.polys))
    obj.SetName(name)
    obj.SetAllPoints([c4d.Vector(p.x, p.y, p.z) for p in self.points])
    for n, (a, b, c, d) in enumerate(self.polys):
        obj.SetPolygon(n, c4d.CPolygon(a, b, c, d))
    uvw = c4d.UVWTag(len(self.polys))
    for n, uv in enumerate(self.face_uvs()):  # the core's UVs: the same in every host
        a, b, c, d = (c4d.Vector(u, v, 0) for u, v in uv)
        uvw.SetSlow(n, a, b, c, d)
    obj.InsertTag(uvw)

    for group, ids in self.groups.items():
        if not ids and group in getattr(self, "optional", ()):
            continue  # an unused Segment Override: no empty selection on every wall
        tag = c4d.SelectionTag(c4d.Tpolygonselection)
        tag.SetName(group)
        sel = tag.GetBaseSelect()
        for k in ids:
            sel.Select(k)
        obj.InsertTag(tag)

    if self.tints:  # a colour per point, for materials that read it (a tile's own shade)
        vc = c4d.VertexColorTag(len(self.points))
        vc.SetName(TINT_TAG)
        vc.SetPerPointMode(True)
        data = vc.GetDataAddressW()
        for i in range(len(self.points)):
            r, g, b = self.tints.get(i, (1.0, 1.0, 1.0))
            c4d.VertexColorTag.SetPoint(data, None, None, i, c4d.Vector4d(r, g, b, 1.0))
        obj.InsertTag(vc)

    phong = c4d.BaseTag(c4d.Tphong)
    phong[c4d.PHONGTAG_PHONG_ANGLELIMIT] = True
    obj.InsertTag(phong)
    obj.Message(c4d.MSG_UPDATE)
    return obj


