"""Archwerks dimension layout: where a selected object's dimensions go.

Pure geometry with no drawing, so tests can check the numbers. Points are
(x, y, z) tuples in the object's local space; aw_draw draws them.

A dimension is a dict:
    kind   "length", "chain", "height", "thickness", "sill", "gap", "width",
           "opening_height" or "opening"
    role   "wall" (normal), "dim" (pushed back while an opening is in focus) or
           "focus" (the selected opening's own measurements)
    a, b   end points of the dimension line (equal for a label-only "opening")
    axis   "x", "y" or "z", the direction it measures
    value  the measured distance in cm ("opening" carries its width; see size)
    size   for "opening" only: (width, height)
    grips  ends ("a", "b") where the wall's grips sit while it is selected, so the
           arrowhead gives way to the grip there
    out    the local direction pointing away from the wall, so the label sits on
           the outer side of its line
    edit   what typing a new value into this dimension does (aw_edit applies it):
           {"do": ...} plus the opening it acts on ("rect") or the chain span
    anchor for "opening" only: where its label sits ("above_right" = above and to
           the right of the point; else centred on it)

wall_layout() adds extension lines (dashed leaders from the measured edge out to
the dimension line) and, in focus, an outline round the selected opening.

Walls are drawn by path_layout() and gripped by path_grips(). wall_layout(),
grip_positions() and opening_grip_positions() were the retired straight wall's;
they work along one straight stretch of wall (x along it, y up, z across), which
is what a spline segment is, so they are kept to become the openings' focus
guides and grips on spline walls.
"""

# Archipack-style placement: plan dimensions lie on the floor out in front of the
# Outside face, height stands in front of the wall's end, thickness lies on the
# floor across the wall's start. Distances in cm.
LENGTH_OUT = 95.0   # overall length, in front of the Outside face
CHAIN_OUT = 35.0    # opening chain, between the wall and the overall length
HEIGHT_OUT = 50.0   # height guide, in front of the Outside face at the wall's end
THICK_OUT = 30.0    # thickness guide, beyond the wall's start
OPENING_H_OUT = 20.0  # a focused opening's height guide, beyond its right edge
FRONT = 0.5         # cm in front of the Outside face, so face dimensions are not hidden in it
ANGLE_R = 75.0      # cm from a corner: the radius of its angle arc (less on short walls)
ANGLE_Y = 1.0       # cm above the floor, so the arc isn't lost in it
EXT_GAP = 3.0       # cm between the measured edge and the start of its extension line
EXT_PAST = 4.0      # cm an extension line runs past its dimension line

FORWARD = (0.0, 0.0, -1.0)      # away from the wall, out past the Outside face
TOWARD_WALL = (0.0, 0.0, 1.0)   # the chain's labels sit between it and the wall,
                                # leaving the outer side to the overall length
PAST_END = (1.0, 0.0, 0.0)      # beyond the wall's end side
BEFORE_START = (-1.0, 0.0, 0.0)  # beyond the wall's start side


def merged_spans(rects):
    """Sorted x spans of the openings, with overlapping ones merged."""
    spans = []
    for x0, x1, _y0, _y1 in sorted(rects):
        if spans and x0 <= spans[-1][1]:
            spans[-1][1] = max(spans[-1][1], x1)
        else:
            spans.append([x0, x1])
    return [tuple(s) for s in spans]


def _dim(kind, role, axis, value, a, b, **extra):
    d = {"kind": kind, "role": role, "axis": axis, "value": value, "a": a, "b": b}
    d.update(extra)
    return d


def _ext(edge, line, role):
    """An extension line from a measured edge out to its dimension line, starting a
    little off the edge and running a little past the line."""
    d = [l - e for l, e in zip(line, edge)]
    n = sum(c * c for c in d) ** 0.5 or 1.0
    d = [c / n for c in d]
    return {"role": role, "a": tuple(e + c * EXT_GAP for e, c in zip(edge, d)),
            "b": tuple(l + c * EXT_PAST for l, c in zip(line, d))}


def _guides(start, length, height, thick):
    """Where the wall's guides sit: (len_z, chain_z, height_z, thick_x, face_z)."""
    face = -thick / 2
    return face - LENGTH_OUT, face - CHAIN_OUT, face - HEIGHT_OUT, start - THICK_OUT, face


def grip_positions(start, length, height, thick, on_guides):
    """[(position, direction), ...] for the End, Start, Height and Thickness grips:
    on the ends of their guides when dimensions show, otherwise on the wall."""
    end, mid = start + length, start + length / 2
    len_z, _chain_z, height_z, thick_x, face = _guides(start, length, height, thick)
    if on_guides:
        return [((end, 0.0, len_z), (1, 0, 0)), ((start, 0.0, len_z), (-1, 0, 0)),
                ((end, height, height_z), (0, 1, 0)), ((thick_x, 0.0, face), (0, 0, -1))]
    return [((end, height / 2, 0.0), (1, 0, 0)), ((start, height / 2, 0.0), (-1, 0, 0)),
            ((mid, height, 0.0), (0, 1, 0)), ((mid, height / 2, face), (0, 0, -1))]


OPENING_GRIP_KINDS = ("arrow", "arrow", "arrow", "arrow", "move")


def opening_grip_positions(start, length, height, thick, rect, on_guides):
    """[(position, direction), ...] in the WALL's space for an opening's Left, Right,
    Sill, Height and Move grips: on the ends of its focus guides while dimensions
    show, otherwise on its own edges. Move sits mid-way along the width guide
    (clear of the object's own gizmo at its base) and slides it along the wall."""
    x0, x1, y0, y1 = rect
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    _len_z, chain_z, _height_z, _thick_x, face = _guides(start, length, height, thick)
    z = face - FRONT
    if on_guides:
        move = ((cx, 0.0, chain_z), (1, 0, 0))
        hx = x1 + OPENING_H_OUT
        return [((x0, 0.0, chain_z), (-1, 0, 0)), ((x1, 0.0, chain_z), (1, 0, 0)),
                ((hx, y0, z), (0, 1, 0)), ((hx, y1, z), (0, 1, 0)), move]
    move = ((cx, cy, face), (1, 0, 0))  # no guides: the middle of its face
    return [((x0, cy, face), (-1, 0, 0)), ((x1, cy, face), (1, 0, 0)),
            ((cx, y0, face), (0, -1, 0)), ((cx, y1, face), (0, 1, 0)), move]


def wall_layout(start, length, height, thick, rects, focus=None, focus_grips=False):
    """Dimensions, extension lines and outline for a selected wall, or for one of its
    openings when focus is that opening's (x0, x1, y0, y1). focus_grips: the focused
    opening has grips of its own (an AW Opening), so its guide ends give way to them."""
    end = start + length
    len_z, chain_z, height_z, thick_x, face = _guides(start, length, height, thick)
    z = face - FRONT  # dimensions drawn on the Outside face itself
    back = "dim" if focus else "wall"

    dims = [
        _dim("length", back, "x", length, (start, 0.0, len_z), (end, 0.0, len_z), grips=("a", "b"), out=FORWARD,
             edit={"do": "wall_length"}),
        _dim("height", back, "y", height, (end, 0.0, height_z), (end, height, height_z), grips=("b",), out=PAST_END,
             edit={"do": "wall_height"}),
        _dim("thickness", back, "z", thick, (thick_x, 0.0, face), (thick_x, 0.0, -face), grips=("a",),
             out=BEFORE_START, edit={"do": "wall_thickness"}),
    ]
    ext = [_ext((start, 0.0, face), (start, 0.0, len_z), back),
           _ext((end, 0.0, face), (end, 0.0, len_z), back),
           _ext((end, height, face), (end, height, height_z), back),
           _ext((start, 0.0, face), (thick_x, 0.0, face), back),
           _ext((start, 0.0, -face), (thick_x, 0.0, -face), back)]

    if focus:
        x0, x1, y0, y1 = focus
        cx = (x0 + x1) / 2
        hx = x1 + OPENING_H_OUT
        # floor: gap to the wall start | the opening's width | gap to the wall end
        if x0 - start > 1e-4:
            dims.append(_dim("gap", "focus", "x", x0 - start, (start, 0.0, chain_z), (x0, 0.0, chain_z),
                             out=TOWARD_WALL, grips=("b",), edit={"do": "gap_start", "rect": focus}))
        dims.append(_dim("width", "focus", "x", x1 - x0, (x0, 0.0, chain_z), (x1, 0.0, chain_z),
                         out=FORWARD, grips=("a", "b"), edit={"do": "width", "rect": focus}))
        if end - x1 > 1e-4:
            dims.append(_dim("gap", "focus", "x", end - x1, (x1, 0.0, chain_z), (end, 0.0, chain_z),
                             out=TOWARD_WALL, grips=("a",), edit={"do": "gap_end", "rect": focus}))
        # beside it: sill height and opening height stacked on one vertical line
        if y0 > 1e-4:
            dims.append(_dim("sill", "focus", "y", y0, (hx, 0.0, z), (hx, y0, z), out=PAST_END, grips=("b",),
                             edit={"do": "sill", "rect": focus}))
        dims.append(_dim("opening_height", "focus", "y", y1 - y0, (hx, y0, z), (hx, y1, z),
                         out=PAST_END, grips=("a", "b"), edit={"do": "opening_height", "rect": focus}))
        ext += [_ext((x1, y0, z), (hx, y0, z), "focus"), _ext((x1, y1, z), (hx, y1, z), "focus"),
                _ext((x0, 0.0, face), (x0, 0.0, chain_z), "focus"),
                _ext((x1, 0.0, face), (x1, 0.0, chain_z), "focus")]
        outline = [(x0, y0, z), (x1, y0, z), (x1, y1, z), (x0, y1, z)]
        return {"dims": dims, "ext": ext, "outline": outline, "grips": focus_grips}

    if rects:
        spans = merged_spans(rects)
        marks = [start]
        for x0, x1 in spans:
            marks += [x0, x1]
        marks.append(end)
        for i, (p, q) in enumerate(zip(marks, marks[1:])):
            if q - p <= 1e-4:  # an opening flush with the wall end leaves no gap to label
                continue
            if i % 2 == 0 and i // 2 < len(spans):  # a gap ending at a span: typing slides that span
                edit = {"do": "chain_gap_before", "span": spans[i // 2]}
            elif i % 2 == 0:                         # the last gap, to the wall end
                edit = {"do": "chain_gap_end", "span": spans[-1]}
            else:                                    # a span: its width, if it is a single opening
                span = spans[i // 2]
                inside = [r for r in rects if span[0] <= r[0] and r[1] <= span[1]]
                edit = {"do": "width", "rect": inside[0]} if len(inside) == 1 else None
            dims.append(_dim("chain", "wall", "x", q - p, (p, 0.0, chain_z), (q, 0.0, chain_z), out=TOWARD_WALL,
                             edit=edit))
        for m in marks[1:-1]:
            ext.append(_ext((m, 0.0, face), (m, 0.0, chain_z), "wall"))
    for x0, x1, y0, y1 in rects:
        cx = (x0 + x1) / 2
        if y0 > 1e-4:
            dims.append(_dim("sill", "wall", "y", y0, (cx, 0.0, z), (cx, y0, z), out=PAST_END,
                             edit={"do": "sill", "rect": (x0, x1, y0, y1)}))
        dims.append(_dim("opening", "wall", "x", x1 - x0, (cx, (y0 + y1) / 2, z), (cx, (y0 + y1) / 2, z),
                         size=(x1 - x0, y1 - y0)))
    return {"dims": dims, "ext": ext, "outline": None, "grips": True}


def wall_dimensions(start, length, height, thick, rects):
    """The dimensions of a selected wall (no focus)."""
    return wall_layout(start, length, height, thick, rects)["dims"]


def segment_labels(path, height):
    """A label on the top of every segment of a wall's plan, its number for Segment Overrides
    ("Segment 1", along every run in turn), as label-only dims."""
    out = []
    for k, seg in enumerate(path.segments):
        u = seg["length"] / 2
        p = (seg["a"][0] + seg["d"][0] * u, path.top(k, u, height) if hasattr(path, "top") else height,
             seg["a"][1] + seg["d"][1] * u)
        out.append({"kind": "segno", "role": "wall", "axis": "x", "value": k + 1, "a": p, "b": p})
    return out


def path_layout(path, w0, w1, height, seg_rects):
    """Dimensions for a selected wall that follows a spline: each segment's length on
    the floor outside it (typing one moves that corner), the height at the start, and
    each opening's size on the Outside face. path: an aw_path.Plan (every run) or a
    single aw_path.Path."""
    outside_w0 = path.outside_is_w0()
    sign = -1.0 if outside_w0 else 1.0       # along n, pointing outside
    w_out = w0 if outside_w0 else w1
    z_face = w_out + sign * FRONT
    dims, ext = [], []

    def at(k, u, w, y=0.0):
        seg = path.segments[k]
        return (seg["a"][0] + seg["d"][0] * u + seg["n"][0] * w, y,
                seg["a"][1] + seg["d"][1] * u + seg["n"][1] * w)

    for k, seg in enumerate(path.segments):
        off = w_out + sign * CHAIN_OUT
        out = (seg["n"][0] * sign, 0.0, seg["n"][1] * sign)
        dims.append(_dim("segment", "wall", "x", seg["length"], at(k, 0, off), at(k, seg["length"], off),
                         out=out, edit={"do": "path_segment", "k": k}))
        ext.append(_ext(at(k, 0, w_out), at(k, 0, off), "wall"))
        if _run_ends_at(path, k):
            ext.append(_ext(at(k, seg["length"], w_out), at(k, seg["length"], off), "wall"))
        for u0, u1, y0, y1 in seg_rects.get(k, []):
            mid = at(k, (u0 + u1) / 2, z_face, (y0 + y1) / 2)
            dims.append(_dim("opening", "wall", "x", u1 - u0, mid, mid, size=(u1 - u0, y1 - y0)))
    first = path.segments[0]
    hz = w_out + sign * HEIGHT_OUT
    out = (first["n"][0] * sign, 0.0, first["n"][1] * sign)
    dims.append(_dim("height", "wall", "y", height, at(0, 0, hz), at(0, 0, hz, height), out=out,
                     edit={"do": "wall_height"}, grips=("b",)))
    ext.append(_ext(at(0, 0, w_out, height), at(0, 0, hz, height), "wall"))
    # each point's rise above the wall's Height (Archipack's height offset), floor to top:
    # on raised or lowered points, and on points partway along a straight wall (a ridge
    # just added), so a new point can be typed without dragging it first
    for i, (x, z) in enumerate(getattr(path, "spline_points", ())):
        rise = path.heights[i] if i < len(path.heights) else 0.0
        if abs(rise) > 1e-4 or _straight_through(path, i):
            top = height + rise
            dims.append(_dim("rise", "wall", "y", rise, (x, 0.0, z), (x, top, z),
                             edit={"do": "point_rise", "i": i}))
    # each corner's turn, signed (left +, right -), drawn as Archipack draws it: an arc
    # inside the corner between the two walls' normals on the side it turns to (the
    # angle between them is the turn, so a square corner's arc runs from one wall to
    # the other); off square, dashed leaders show those normals. Typing one swings the
    # wall after it
    import math
    for k_in, k_out, turn in corners(path):
        seg_in, seg = path.segments[k_in], path.segments[k_out]
        cx, cz = seg["a"]
        radius = min(ANGLE_R, 0.4 * seg_in["length"], 0.4 * seg["length"])
        side = math.copysign(math.pi / 2, turn)          # the normal on the side it turns to
        a0 = math.atan2(seg_in["d"][1], seg_in["d"][0]) + side
        sweep = math.radians(turn)                       # from the incoming wall's normal to the next's
        mid = a0 + sweep / 2
        pos = (cx + radius * math.cos(mid), ANGLE_Y, cz + radius * math.sin(mid))
        if abs(abs(turn) - 90.0) > 0.5:  # square: the normals lie along the walls themselves
            for a in (a0, a0 + sweep):
                ext.append({"role": "angle", "a": (cx, ANGLE_Y, cz),
                            "b": (cx + radius * math.cos(a), ANGLE_Y, cz + radius * math.sin(a))})
        dims.append(_dim("angle", "angle", "x", turn, pos, pos, anchor="centre",
                         arc=((cx, ANGLE_Y, cz), radius, a0, sweep), edit={"do": "corner_angle", "k": k_in}))
    # each sloped segment's slope, on its top, typed in degrees or as a pitch (5:12)
    for k, seg in enumerate(path.segments):
        drop = seg["hb"] - seg["ha"] if "ha" in seg else 0.0
        if abs(drop) > 1e-4:
            u = seg["length"] / 2
            mid = at(k, u, 0.0, height + (seg["ha"] + seg["hb"]) / 2)
            run = seg.get("u1", seg["length"]) - seg.get("u0", 0.0)  # the rake runs between the outside corners
            dims.append(_dim("slope", "angle", "x", slope_degrees(drop, run if run > 1e-6 else seg["length"]), mid, mid,
                             anchor="above", edit={"do": "segment_slope", "k": k}))
    return {"dims": dims, "ext": ext, "outline": None, "grips": True}


def corner_turn(d1, d2):
    """How far a corner turns, in degrees, from a segment running along d1 to the next
    along d2, as Archipack shows it: 0 straight on, positive turning left (towards +n,
    the room side of a closed run, so a square room reads 90 at every corner),
    negative turning right; in (-180, 180]."""
    import math
    turn = math.degrees(math.atan2(d1[0] * d2[1] - d1[1] * d2[0], d1[0] * d2[0] + d1[1] * d2[1]))
    return 180.0 if turn <= -180.0 + 1e-9 else turn


def corners(path):
    """[(incoming global segment, outgoing global segment, turn (corner_turn))] for
    every real corner: joints between segments of a run that aren't straight through."""
    runs = getattr(path, "runs", None)
    groups = [path.run_segments(r) for r in range(len(runs))] if runs is not None else [list(range(len(path.segments)))]
    closed = [run.closed for run in runs] if runs is not None else [path.closed]
    out = []
    for ks, is_closed in zip(groups, closed):
        pairs = list(zip(ks, ks[1:])) + ([(ks[-1], ks[0])] if is_closed and len(ks) > 2 else [])
        for k_in, k_out in pairs:
            turn = corner_turn(path.segments[k_in]["d"], path.segments[k_out]["d"])
            if abs(turn) > 0.01:
                out.append((k_in, k_out, turn))
    return out


def slope_degrees(rise, run):
    """A slope's angle in degrees, from its rise over its run (both positive)."""
    import math
    return math.degrees(math.atan2(abs(rise), run)) if run > 1e-9 else 90.0


def _straight_through(path, i):
    """True when spline point i joins two segments in a straight line (a point
    partway along a wall, not a corner)."""
    dirs = [(s["d"], s["ia"] == i) for s in path.segments if s.get("ia") == i or s.get("ib") == i]
    if len(dirs) != 2:
        return False
    (d1, _), (d2, _) = dirs
    return d1[0] * d2[0] + d1[1] * d2[1] > 0.9998


def _run_ends_at(path, k):
    """True when segment k is the last of an open run (its end is a free wall end)."""
    runs = getattr(path, "runs", None)
    if runs is None:
        return not path.closed and k == len(path.segments) - 1
    seg = path.segments[k]
    run = runs[seg["run"]]
    return not run.closed and seg["local"] == len(run.segments) - 1


def path_grips(path, w0, w1, height, editable):
    """[(position, direction, kind), ...] in the wall's space for a spline wall: a
    "corner" grip on every path point (it moves on the floor; direction is the
    floor's normal) and a "rise" grip above it when the spline is editable, then
    Height (top of the height guide) and Thickness (on the face that moves when
    thickness changes: the Outside face for Center align, else the face away from the
    path line). A wall's side grips (side_grips) come after these."""
    outside_w0 = path.outside_is_w0()
    sign = -1.0 if outside_w0 else 1.0
    w_out = w0 if outside_w0 else w1
    out = []
    points = getattr(path, "spline_points", None) or path.points
    if editable:  # one per spline point, in the spline's own order, so grip i is point i
        for x, z in points:
            out.append(((x, 0.0, z), (0, 1, 0), "corner"))
        # then each point's own height, on the wall's top above it
        rises = getattr(path, "heights", None) or [0.0] * len(points)
        for (x, z), rise in zip(points, rises):
            out.append(((x, height + rise, z), (0, 1, 0), "rise"))
    first = path.segments[0]
    ax, az = first["a"]
    (nx, nz), (dx, dz) = first["n"], first["d"]
    hz = w_out + sign * HEIGHT_OUT
    out.append(((ax + nx * hz, height, az + nz * hz), (0, 1, 0), "height"))
    w_face = w_out if abs(w0 + w1) < 1e-6 else (w1 if abs(w0) < 1e-6 else w0)
    face_sign = 1.0 if w_face > 0 else -1.0
    u = first["length"] / 2
    out.append(((ax + dx * u + nx * w_face, height / 2, az + dz * u + nz * w_face),
                (nx * face_sign, 0, nz * face_sign), "thickness"))
    return out


SIDE_CLEAR = 40.0  # cm a wall's first side grip stands off the middle, clear of its Thickness grip there
SIDE_OUT = 15.0    # cm a side grip stands out past the side it moves, clear of Blender's insert grip on it


def side_grips(plan, y, clear_first=False, w_out=0.0):
    """[(position, direction, "side", k)]: a grip by the middle of every segment of plan,
    at height y, pointing out (to the Exterior of a wall, out of a room), SIDE_OUT past
    the face at w_out (a wall's w0; a floor's outline, 0): drag it to move the whole side,
    its corners sliding along the sides beside it (aw_wedit.move_side). clear_first: the
    first segment's stands SIDE_CLEAR along, off the Thickness grip. Both hosts list them
    after a wall's path_grips, so every other grip keeps its index."""
    out = []
    off = max(-w_out, 0.0) + SIDE_OUT
    for k, seg in enumerate(plan.segments):
        (ax, az), (dx, dz), (nx, nz), L = seg["a"], seg["d"], seg["n"], seg["length"]
        u = min(L / 2 + SIDE_CLEAR, L * 0.8) if clear_first and k == 0 else L / 2
        out.append(((ax + dx * u - nx * off, y, az + dz * u - nz * off), (-nx, 0, -nz), "side", k))
    return out


def path_thickness_from(path, w0, w1, p):
    """The thickness that puts the Thickness grip at local point p (x, z): twice its
    distance from the path for Center align, once for Inside or Outside."""
    first = path.segments[0]
    (ax, az), (nx, nz) = first["a"], first["n"]
    dist = abs((p[0] - ax) * nx + (p[1] - az) * nz)
    return 2 * dist if abs(w0 + w1) < 1e-6 else dist
