"""Archwerks parameters in Cinema 4D: the Attribute Manager description and Init,
built from the shared table (core/aw_params.py), which this star-imports.

C4D reads .res files once, at startup; a description built here in
GetDDescription is rebuilt every time the Attribute Manager asks, so adding or
changing a parameter only needs `install_c4d.py --lib`, not a restart. The .res
files are kept to a bare Obase include (the Basic and Coordinates tabs).
"""
import c4d

import aw_params
from aw_params import *  # noqa: F401,F403
from aw_params import BIG, DEGREE, METER, OBJECT, PERCENT, SEPARATOR_BASE, SPECS, params  # noqa: F401

ACCEPT = {aw_params.MATERIAL: c4d.Mbase, aw_params.ANY_OBJECT: c4d.Obase}  # the table's link targets


def _group(gid):
    return c4d.ID_OBJECTPROPERTIES if gid == OBJECT else gid


_SETTERS = {"real": ("SetFloat", float), "int": ("SetInt32", int), "bool": ("SetBool", bool)}


def init(plugin, node):
    """Give a new object every parameter's default (from its plugin's Init), straight into
    its container. Not InitAttr and node[id] = value: each of those asks for the whole
    description (describe(), every row of the table) to find the parameter's type, so a
    new window built its Attribute Manager 135 times, most of what placing one cost."""
    bc = node.GetDataInstance()
    for p in params(node.GetType()):
        setter = _SETTERS.get(p["type"])
        if setter is not None:
            getattr(bc, setter[0])(p["id"], setter[1](p["default"]))


def _container(p):
    if p["type"] == "real":
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
        bc[c4d.DESC_UNIT] = {PERCENT: c4d.DESC_UNIT_PERCENT, DEGREE: c4d.DESC_UNIT_DEGREE}.get(p["unit"],
                                                                                         c4d.DESC_UNIT_METER)
        bc[c4d.DESC_MIN], bc[c4d.DESC_MAX], bc[c4d.DESC_STEP] = p["min"], p["max"], p["step"]
        if p["slider"]:
            bc[c4d.DESC_CUSTOMGUI] = c4d.CUSTOMGUI_REALSLIDER
        return c4d.DTYPE_REAL, bc
    if p["type"] == "int":
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_LONG)
        if p.get("cycle"):
            items = c4d.BaseContainer()
            for i, label in enumerate(p["cycle"]() if callable(p["cycle"]) else p["cycle"]):
                if isinstance(label, tuple):  # (value, label): values that aren't 0, 1, 2...
                    i, label = label
                items.SetString(i, label)
            bc.SetContainer(c4d.DESC_CYCLE, items)
        if p.get("min") is not None:
            bc[c4d.DESC_MIN] = p["min"]
        if p.get("max") is not None:
            bc[c4d.DESC_MAX] = p["max"]
        return c4d.DTYPE_LONG, bc
    if p["type"] == "bool":
        return c4d.DTYPE_BOOL, c4d.GetCustomDataTypeDefault(c4d.DTYPE_BOOL)
    if p["type"] == "list":
        return c4d.CUSTOMDATATYPE_INEXCLUDE_LIST, c4d.GetCustomDataTypeDefault(c4d.CUSTOMDATATYPE_INEXCLUDE_LIST)
    bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_BASELISTLINK)
    accept = c4d.BaseContainer()
    for kind in p["accept"]:
        accept.SetInt32(ACCEPT.get(kind, kind), 1)
    bc.SetContainer(c4d.DESC_ACCEPT, accept)
    return c4d.DTYPE_BASELISTLINK, bc


def _shown(test, node):
    try:
        return test is None or bool(test(node))
    except Exception:
        return True


READOUT = SEPARATOR_BASE + 99  # the readout line's id: the top of the separators' range, which they count up to


def _readout(node, description):
    """The readout line (core/aw_readout) at the top of the Object tab, as the Blender
    Sidebar has it above its tabs."""
    import aw_draw
    import aw_readout
    line = aw_readout.readout(node, aw_draw.fmt_length)
    if not line:
        return
    bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_STATICTEXT)
    bc[c4d.DESC_NAME] = bc[c4d.DESC_SHORT_NAME] = line
    bc[c4d.DESC_ANIMATE] = c4d.DESC_ANIMATE_OFF
    bc[c4d.DESC_SCALEH] = True
    description.SetParameter(c4d.DescID(c4d.DescLevel(READOUT, c4d.DTYPE_STATICTEXT, 0)), bc,
                             c4d.DescID(c4d.DescLevel(c4d.ID_OBJECTPROPERTIES, c4d.DTYPE_GROUP, 0)))


def describe(node, description, flags):
    """GetDDescription: the bare .res (Basic, Coordinates), then SPECS. A ("group", id,
    name[, show]) row starts a tab, a ("sub", id, name[, show]) row a section inside it
    (name may be a function of the object; show leaves the tab or section out)."""
    if not description.LoadDescription(node.GetType()):
        return False
    _readout(node, description)
    tab = group = c4d.DescID(c4d.DescLevel(_group(OBJECT), c4d.DTYPE_GROUP, 0))
    seps, hidden, tab_hidden = 0, False, False
    for row in SPECS.get(node.GetType(), ()):
        if isinstance(row, tuple):
            kind, gid, name = row[:3]
            test = row[3] if len(row) > 3 else None
            group = c4d.DescID(c4d.DescLevel(_group(gid), c4d.DTYPE_GROUP, 0))
            if kind == "group":  # a tab; with a show test, only when it passes (a countertop's Sinks)
                tab = group
                hidden = tab_hidden = not _shown(test, node)
                if gid == OBJECT or hidden:
                    continue
            else:
                hidden = tab_hidden or not _shown(test, node)
                if hidden:
                    continue
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
            bc[c4d.DESC_NAME] = bc[c4d.DESC_SHORT_NAME] = name(node) if callable(name) else name
            bc[c4d.DESC_DEFAULT] = 1  # open
            bc[c4d.DESC_ANIMATE] = c4d.DESC_ANIMATE_OFF
            description.SetParameter(group, bc, c4d.DescID(0) if kind == "group" else tab)
        elif hidden:
            continue
        elif row == "sep":
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_SEPARATOR)
            bc[c4d.DESC_SEPARATORLINE] = True
            description.SetParameter(c4d.DescID(c4d.DescLevel(SEPARATOR_BASE + seps, c4d.DTYPE_SEPARATOR, 0)),
                                     bc, group)
            seps += 1
        elif _shown(row.get("show"), node):
            dtype, bc = _container(row)
            bc[c4d.DESC_NAME] = bc[c4d.DESC_SHORT_NAME] = row["name"]
            bc[c4d.DESC_ANIMATE] = c4d.DESC_ANIMATE_ON
            description.SetParameter(c4d.DescID(c4d.DescLevel(row["id"], dtype, 0)), bc, group)
    return True, flags | c4d.DESCFLAGS_DESC_LOADED
