"""A 3D vector for the core: the few things the geometry code asks of one.

It answers to the same names as Cinema 4D's c4d.Vector (x, y, z, +, -, * by a
number, Dot, Cross, GetLength, GetNormalized), so code written against either
reads the same; a host turns these into its own vectors when it makes the mesh.
"""
import math


class Vec:
    __slots__ = ("x", "y", "z")

    def __init__(self, x=0.0, y=0.0, z=0.0):
        self.x, self.y, self.z = float(x), float(y), float(z)

    def __iter__(self):
        return iter((self.x, self.y, self.z))

    def __repr__(self):
        return "Vec(%g, %g, %g)" % (self.x, self.y, self.z)

    def __add__(self, o):
        return Vec(self.x + o.x, self.y + o.y, self.z + o.z)

    def __sub__(self, o):
        return Vec(self.x - o.x, self.y - o.y, self.z - o.z)

    def __neg__(self):
        return Vec(-self.x, -self.y, -self.z)

    def __mul__(self, k):
        return Vec(self.x * k, self.y * k, self.z * k)

    __rmul__ = __mul__

    def __truediv__(self, k):
        return Vec(self.x / k, self.y / k, self.z / k)

    def __eq__(self, o):
        return isinstance(o, Vec) and (self.x, self.y, self.z) == (o.x, o.y, o.z)

    def __hash__(self):
        return hash((self.x, self.y, self.z))

    def Dot(self, o):  # noqa: N802 - c4d.Vector's names, on purpose
        return self.x * o.x + self.y * o.y + self.z * o.z

    def Cross(self, o):  # noqa: N802
        return Vec(self.y * o.z - self.z * o.y, self.z * o.x - self.x * o.z, self.x * o.y - self.y * o.x)

    def GetLength(self):  # noqa: N802
        return math.sqrt(self.x * self.x + self.y * self.y + self.z * self.z)

    def GetNormalized(self):  # noqa: N802
        L = self.GetLength()
        return self * (1.0 / L) if L > 1e-12 else Vec(self.x, self.y, self.z)
