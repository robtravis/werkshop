"""aw_panels for Cinema 4D: the parts of core/aw_panels.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_groups_c4d
import aw_panels  # noqa: F401
from aw_panels import *  # noqa: F401,F403


def change_key(op):
    """What the panels are built from besides their settings: their wall (and where it is
    from them), or their own child splines, a Custom profile spline and a Custom flourish."""
    import c4d
    import aw_wall_c4d
    s = settings(op)
    wall = s["wall"]
    wkey = None
    if wall is not None and wall.IsAlive():
        m = ~op.GetMg() * wall.GetMg()
        wkey = (aw_wall_c4d.change_key(wall), tuple(round(x, 4) for vec in (m.off, m.v1, m.v2, m.v3)
                                                 for x in (vec.x, vec.y, vec.z)))
    linked = []
    for obj in (s["custom"], s["flourish_obj"]):
        linked.append((obj.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_CACHE), obj.GetHDirty(c4d.HDIRTYFLAGS_OBJECT))
                      if obj is not None and obj.IsAlive() else None)
    kids = tuple(k.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX | c4d.DIRTYFLAGS_CACHE)
                 for k in op.GetChildren() if k.GetInfo() & c4d.OBJECT_ISSPLINE)  # its own path, with no wall
    return (op.GetName(), op.GetDirty(c4d.DIRTYFLAGS_DATA), wkey, tuple(linked), kids)


def add_for_selection(doc):
    """Panel button Wall panels: on each selected Wall, after it, with the default
    material. One undo step. Returns them."""
    import c4d
    import aw_ids as I
    import aw_materials
    import aw_slab_c4d
    walls = [o for o in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE) if o.GetType() == I.ID_AW_WALL]
    if not walls:
        c4d.gui.MessageDialog("Select a Wall first: the panels line its rooms.")
        return []
    made = []
    doc.StartUndo()
    for wall in walls:
        p = c4d.BaseObject(I.ID_AW_WALL_PANELS)
        p.SetName(aw_slab_c4d.next_name(doc, "Wall Panels"))
        p[I.AW_PNL_WALL] = wall
        doc.InsertObject(p, wall.GetUp(), wall)
        p.SetMg(c4d.Matrix(wall.GetMg()))
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, p)
        aw_materials.apply_defaults(doc, p)
        aw_groups_c4d.file(doc, p)  # into its group: null and layer (aw_groups_c4d)
        made.append(p)
    doc.EndUndo()
    doc.SetActiveObject(made[0], c4d.SELECTION_NEW)
    for p in made[1:]:
        doc.SetActiveObject(p, c4d.SELECTION_ADD)
    c4d.EventAdd()
    return made
