"""Archwerks dimension editing: what typing a value into a dimension does.

Each editable dimension carries an "edit" spec (see aw_dims). apply() turns a
typed value into changes on the wall and its splines (a wall's own edits worked
out by the core, aw_wedit, shared with Blender), registering undo for every
object it touches, so the caller wraps it in one StartUndo/EndUndo and the whole
edit is one undo step. (The straight wall's opening edits, gaps, widths, sills,
went with it; openings on spline walls get theirs in the openings work.)
"""
import c4d

import aw_ids as I
import aw_wall_c4d
import aw_wedit

TOL = 1e-3


def _change(doc, obj):
    if doc is not None:
        doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)


def _apply_wall(doc, wall, edit, value):
    """A wall's own edit (aw_wedit.wall_edit), applied to its splines and settings."""
    wp = aw_wall_c4d.wall_path(wall)
    if wp is None and edit["do"] not in ("wall_height", "wall_thickness"):
        raise ValueError("that wall has no path")
    plan, height, splines = (wp[0], wp[3], wp[4]) if wp is not None else (None, 0.0, None)
    points = [] if splines is None else [
        (v.x, v.y, v.z) for v in (splines.GetPoint(i) for i in range(splines.GetPointCount()))]
    change = aw_wedit.wall_edit(edit, value, plan, height, points)
    moved = change["points"]
    if any(splines.owner(m).GetType() != c4d.Ospline for m in moved):
        raise ValueError("can't be typed while the path is a spline primitive: make it editable (C)")
    for m in moved:
        _change(doc, splines.owner(m))
    for m, p in moved.items():
        splines.SetPoint(m, c4d.Vector(*p))
    if moved:
        splines.Message(c4d.MSG_UPDATE)
    if change["params"]:
        _change(doc, wall)
        for pid, v in change["params"].items():
            wall[pid] = v
    return change["label"]


def apply(doc, wall, edit, value):
    """Apply a typed value. Returns a short description of what changed, or raises
    ValueError for a value that makes no sense (the caller shows it, changes nothing)."""
    do = edit["do"]
    if do.startswith(("roof_", "cut_")):  # a Roof's or a Roof Cutter's labels
        import aw_roofdims_c4d
        return aw_roofdims_c4d.apply(doc, wall, edit, value)
    if do.startswith("cab_"):
        import aw_cabinet_c4d
        return aw_cabinet_c4d.apply(doc, wall, edit, value)
    if do.startswith("beam_"):
        import aw_beam
        return aw_beam.apply(doc, wall, edit, value)
    if do.startswith("opening_") and "child" in edit:  # a selected window's focus guides
        import aw_openings_c4d
        return aw_openings_c4d.apply(doc, wall, edit, value)
    if do in aw_wedit.WALL_EDITS:
        return _apply_wall(doc, wall, edit, value)
    raise ValueError("unknown edit %r" % do)


ADD_RADIUS = 10.0  # points: how close to a wall's top edge a Cmd-click adds a point


def _top_edge_hit(bd, wall, x, y):
    """(global segment, distance along it) under the mouse on the wall's top edge,
    or None. The top edge is the centre of the wall's top, sloped or level."""
    import aw_draw
    import aw_grab
    wp = aw_wall_c4d.wall_path(wall)
    if wp is None:
        return None
    plan, w0, w1, height, _s = wp
    mg, wc = wall.GetMg(), (w0 + w1) / 2
    best, best_d = None, aw_draw.px(ADD_RADIUS)
    for k, seg in enumerate(plan.segments):
        (ax, az), (dx, dz), (nx, nz), L = seg["a"], seg["d"], seg["n"], seg["length"]
        A = c4d.Vector(ax + nx * wc, plan.top(k, 0, height), az + nz * wc)
        B = c4d.Vector(ax + dx * L + nx * wc, plan.top(k, L, height), az + dz * L + nz * wc)
        if aw_draw.behind(bd, mg * A) or aw_draw.behind(bd, mg * B):
            continue
        sa, sb = bd.WS(mg * A), bd.WS(mg * B)
        ex, ey = sb.x - sa.x, sb.y - sa.y
        ll = ex * ex + ey * ey
        if ll < 1e-6:
            continue
        t = max(0.0, min(1.0, ((x - sa.x) * ex + (y - sa.y) * ey) / ll))
        dist = ((sa.x + ex * t - x) ** 2 + (sa.y + ey * t - y) ** 2) ** 0.5
        if dist < best_d:
            p = ~mg * aw_grab.point_on_line(bd, mg * A, mg.MulV(B - A), x, y)  # exact, not the screen's t
            u = (p.x - A.x) * dx + (p.z - A.z) * dz
            best, best_d = (k, u), dist
    return best


def insert_point(doc, bd, x, y):
    """Cmd-click on a selected wall's top edge: a new spline point there, on the
    path and at the wall's current height there, so nothing moves until it is
    dragged or typed. Returns a description, or None if no top edge was hit."""
    for wall in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE):
        if wall.GetType() != I.ID_AW_WALL:
            continue
        hit = _top_edge_hit(bd, wall, x, y)
        if hit is None:
            continue
        k, u = hit
        plan, _w0, _w1, height, splines = aw_wall_c4d.wall_path(wall)
        seg = plan.segments[k]
        L = seg["length"]
        u = min(max(u, 1.0), L - 1.0)  # never on top of an existing point
        if L < 2.0:
            continue
        spline, at, ml = splines.local(seg["ia"])
        if spline.GetType() != c4d.Ospline:
            raise ValueError("points can't be added to a spline primitive: make it editable (C)")
        rise = seg["ha"] + (seg["hb"] - seg["ha"]) * u / L
        new = ~ml * c4d.Vector(seg["a"][0] + seg["d"][0] * u, rise, seg["a"][1] + seg["d"][1] * u)
        _change(doc, spline)
        _insert(spline, at + 1, new)
        return "added a point to segment %d" % (k + 1)
    return None


def _insert(spline, index, point):
    """Insert point into a SplineObject at index, keeping its runs (segments) intact:
    the run the point lands in grows by one."""
    pts = spline.GetAllPoints()
    segs = [spline.GetSegment(s) for s in range(spline.GetSegmentCount())]
    tangents = [spline.GetTangent(i) for i in range(spline.GetTangentCount())]
    pts.insert(index, point)
    spline.ResizeObject(len(pts), len(segs))
    spline.SetAllPoints(pts)
    if tangents:
        tangents.insert(index, {"vl": c4d.Vector(), "vr": c4d.Vector()})
        for i, t in enumerate(tangents):
            spline.SetTangent(i, t["vl"], t["vr"])
    if segs:
        start = 0
        for sidx, sg in enumerate(segs):
            cnt = sg["cnt"]
            if start <= index - 1 < start + cnt:  # the run holding the point before it
                cnt += 1
            spline.SetSegment(sidx, cnt, sg["closed"])
            start += sg["cnt"]
    spline.Message(c4d.MSG_UPDATE)


# Inline typing (InlineEdit and its parsers) is in the core, shared with Blender.
from aw_wedit import COUNT, DEG, TYPABLE, UNITS_CM, InlineEdit, parse_angle, parse_length, unit_of  # noqa: E402,F401
