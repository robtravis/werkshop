"""Archwerks wall paths: the plan-view maths for walls that follow a spline.

Pure (no c4d), so it is tested outside Cinema 4D. Points are (x, z) on the floor,
in the wall's local space. A path is a polyline, open or closed.

For each segment, d is its unit direction and n its left normal, n = (-d.z, d.x):
for a segment running along +X, n is +Z, matching the straight wall, whose
Outside faces -Z. A wall occupies the band between offsets w0 < w1 along n.
"""
import math

EPS = 1e-6
ALIGNS = ("center", "inside", "outside")


def clean(points, closed):
    """Drop consecutive duplicates (and a closing point equal to the first)."""
    out = []
    for p in points:
        if not out or math.dist(p, out[-1]) > 1e-4:
            out.append((float(p[0]), float(p[1])))
    if closed and len(out) > 2 and math.dist(out[0], out[-1]) <= 1e-4:
        out.pop()
    return out


def signed_area(points):
    """Positive when the loop runs counter-clockwise (x right, z up): its interior
    is then on the left, the +n side."""
    a = 0.0
    for (x0, z0), (x1, z1) in zip(points, points[1:] + points[:1]):
        a += x0 * z1 - x1 * z0
    return a / 2


class Path:
    def __init__(self, points, closed):
        self.points = clean(points, closed)
        self.closed = closed and len(self.points) > 2
        n = len(self.points)
        pairs = list(zip(range(n), range(1, n))) + ([(n - 1, 0)] if self.closed else [])
        self.segments = []
        for i, j in pairs:
            a, b = self.points[i], self.points[j]
            length = math.dist(a, b)
            if length < EPS:
                continue
            d = ((b[0] - a[0]) / length, (b[1] - a[1]) / length)
            self.segments.append({"a": a, "b": b, "d": d, "n": (-d[1], d[0]), "length": length, "i": i, "j": j})
        # which side of the path is "inside": the interior of a closed loop; +n for an open path
        self.inside_sign = 1 if (not self.closed or signed_area(self.points) > 0) else -1

    def band(self, thick, align):
        """(w0, w1): where the wall sits across the path, along n."""
        s = self.inside_sign
        if align == "inside":
            return (0.0, thick) if s > 0 else (-thick, 0.0)
        if align == "outside":
            return (-thick, 0.0) if s > 0 else (0.0, thick)
        return (-thick / 2, thick / 2)

    def outside_is_w0(self):
        """True when the -n side (w0) faces out: the wall's Outside selection goes there."""
        return self.inside_sign > 0

    def corner(self, k, end, w):
        """The point at segment k's start (end=False) or end (end=True), on the line
        offset w along n: mitred with the neighbouring segment at a joint, square at
        an open path's ends."""
        seg = self.segments[k]
        nseg = len(self.segments)
        p = seg["b"] if end else seg["a"]
        if end:
            other = self.segments[(k + 1) % nseg] if (k + 1 < nseg or self.closed) else None
        else:
            other = self.segments[k - 1] if (k > 0 or self.closed) else None
        n1 = seg["n"]
        if other is None or nseg < 2:
            return (p[0] + n1[0] * w, p[1] + n1[1] * w)
        n2 = other["n"]
        dot = n1[0] * n2[0] + n1[1] * n2[1]
        if dot < -0.95:  # a near hairpin: a mitre would shoot off; square it instead
            return (p[0] + n1[0] * w, p[1] + n1[1] * w)
        k_ = w / (1 + dot)
        return (p[0] + (n1[0] + n2[0]) * k_, p[1] + (n1[1] + n2[1]) * k_)

    def along(self, k, point):
        """A point's distance along segment k from its start (can be negative)."""
        seg = self.segments[k]
        return (point[0] - seg["a"][0]) * seg["d"][0] + (point[1] - seg["a"][1]) * seg["d"][1]

    def clear_span(self, k, w0, w1):
        """(u0, u1) along segment k that is full-height wall on both faces, clear of
        the mitres: openings are clipped to it."""
        u0 = max(self.along(k, self.corner(k, False, w0)), self.along(k, self.corner(k, False, w1)), 0.0)
        u1 = min(self.along(k, self.corner(k, True, w0)), self.along(k, self.corner(k, True, w1)),
                 self.segments[k]["length"])
        return u0, u1

    def project(self, x, z):
        """(segment index, distance along it, distance from it) for the nearest segment."""
        best = None
        for k, seg in enumerate(self.segments):
            u = max(0.0, min(seg["length"], self.along(k, (x, z))))
            px, pz = seg["a"][0] + seg["d"][0] * u, seg["a"][1] + seg["d"][1] * u
            dist = math.hypot(x - px, z - pz)
            if best is None or dist < best[2] - 1e-9:
                best = (k, u, dist)
        return best

    def start_distance(self, k):
        """Distance along the path to segment k's start: for UVs that run continuously."""
        return sum(s["length"] for s in self.segments[:k])

    @property
    def length(self):
        return sum(s["length"] for s in self.segments)

    def at(self, d, w):
        """The point (x, z) a distance d along the path, offset w along that segment's n."""
        acc = 0.0
        for seg in self.segments:
            if d <= acc + seg["length"] + EPS or seg is self.segments[-1]:
                u = min(max(d - acc, 0.0), seg["length"])
                return (seg["a"][0] + seg["d"][0] * u + seg["n"][0] * w,
                        seg["a"][1] + seg["d"][1] * u + seg["n"][1] * w)
            acc += seg["length"]


class Plan:
    """Every run of a wall's spline, used like one Path. A C4D spline can hold
    several separate runs (segments); each is its own Path, mitred within itself
    and never joined to the others. Segment indices are global: run 0's segments,
    then run 1's, and so on; each segment also says its run ("run"), its index in
    that run ("local") and the spline points it joins ("ia", "ib").

    Closed runs are turned to run counter-clockwise, so every run's inside is on
    its +n side: one band (w0, w1) then fits them all, and the Outside face is
    always on w0.

    runs: [(points [(x, z)], closed, spline point index per point)].
    spline_points: every spline point (x, z) in spline order, for corner grips.
    heights: per spline point (same order), how much taller than the wall's Height
    the wall is there (the point's Y); each segment's top runs straight between
    its two points' heights ("ha", "hb"). None: all 0, a level wall."""

    def __init__(self, runs, spline_points=(), heights=None):
        self.runs, self.ids = [], []
        for points, closed, ids in runs:
            kept, kept_ids = [], []
            for p, i in zip(points, ids):  # clean() again, keeping each point's spline index
                if not kept or math.dist(p, kept[-1]) > 1e-4:
                    kept.append((float(p[0]), float(p[1])))
                    kept_ids.append(i)
            if closed and len(kept) > 2 and math.dist(kept[0], kept[-1]) <= 1e-4:
                kept.pop()
                kept_ids.pop()
            if closed and len(kept) > 2 and signed_area(kept) < 0:
                kept, kept_ids = kept[::-1], kept_ids[::-1]
            path = Path(kept, closed)
            if path.segments:
                self.runs.append(path)
                self.ids.append(kept_ids)
        self.heights = list(heights) if heights is not None else [0.0] * len(spline_points)
        rise = lambda i: self.heights[i] if 0 <= i < len(self.heights) else 0.0  # noqa: E731
        self.segments = []
        for r, (path, ids) in enumerate(zip(self.runs, self.ids)):
            for k, seg in enumerate(path.segments):
                ia, ib = ids[seg["i"]], ids[seg["j"]]
                self.segments.append(dict(seg, run=r, local=k, ia=ia, ib=ib, ha=rise(ia), hb=rise(ib)))
        self.points = [p for path in self.runs for p in path.points]
        self.closed = tuple(path.closed for path in self.runs)
        self.spline_points = list(spline_points)

    def anchor(self, w):
        """Measure every sloped segment's top between its corners on the face at w
        (the Outside face, w0) rather than between its spline points, so a gable's
        rake runs straight from the eave at the outside corner to the peak, and the
        two walls at a corner meet at the same height there (no level corner strip).
        Until this is called the slope runs between the spline points."""
        for k, seg in enumerate(self.segments):
            u0, u1 = self.along(k, self.corner(k, False, w)), self.along(k, self.corner(k, True, w))
            seg["u0"], seg["u1"] = (u0, u1) if u1 - u0 > EPS else (0.0, seg["length"])

    def rise(self, k, x):
        """How much taller than its Height segment k's top is a distance x along it,
        carried on past its ends (the slope's own line)."""
        seg = self.segments[k]
        u0, u1 = seg.get("u0", 0.0), seg.get("u1", seg["length"])
        t = (x - u0) / (u1 - u0) if u1 - u0 > EPS else 0.0
        return seg["ha"] + (seg["hb"] - seg["ha"]) * t

    def top(self, k, u, base):
        """The wall's height a distance u along global segment k, for a wall whose
        Height is base (level past the anchored corners)."""
        seg = self.segments[k]
        u0, u1 = seg.get("u0", 0.0), seg.get("u1", seg["length"])
        return base + self.rise(k, min(max(u, u0), u1))

    def locate(self, r, d):
        """(global segment, distance along it) at a distance d along run r."""
        ks = self.run_segments(r)
        acc = 0.0
        for k in ks:
            L = self.segments[k]["length"]
            if d <= acc + L + EPS or k == ks[-1]:
                return k, min(max(d - acc, 0.0), L)
            acc += L
        return ks[0], 0.0

    def level(self):
        """True when no point is raised or lowered (every segment's top is flat)."""
        return all(abs(seg["ha"]) < EPS and abs(seg["hb"]) < EPS for seg in self.segments)

    def _run(self, k):
        seg = self.segments[k]
        return self.runs[seg["run"]], seg["local"]

    def run_segments(self, r):
        """Global indices of run r's segments."""
        return [k for k, seg in enumerate(self.segments) if seg["run"] == r]

    def band(self, thick, align):
        return self.runs[0].band(thick, align)

    def outside_is_w0(self):
        return True

    def corner(self, k, end, w):
        path, local = self._run(k)
        return path.corner(local, end, w)

    def along(self, k, point):
        path, local = self._run(k)
        return path.along(local, point)

    def clear_span(self, k, w0, w1):
        path, local = self._run(k)
        return path.clear_span(local, w0, w1)

    def start_distance(self, k):
        path, local = self._run(k)
        return path.start_distance(local)

    def project(self, x, z):
        """(global segment, distance along it, distance from it) for the nearest segment."""
        best = None
        for k, seg in enumerate(self.segments):
            u = max(0.0, min(seg["length"], (x - seg["a"][0]) * seg["d"][0] + (z - seg["a"][1]) * seg["d"][1]))
            px, pz = seg["a"][0] + seg["d"][0] * u, seg["a"][1] + seg["d"][1] * u
            dist = math.hypot(x - px, z - pz)
            if best is None or dist < best[2] - 1e-9:
                best = (k, u, dist)
        return best
