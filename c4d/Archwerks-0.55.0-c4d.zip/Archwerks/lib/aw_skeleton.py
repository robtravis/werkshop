"""A weighted straight skeleton, for roofs. Pure Python, no Cinema 4D.

Shrink a simple counter-clockwise polygon by moving every edge inward along its
normal, edge i at speed weights[i]: a roof whose eaves all start at height 0 and
rise one unit per unit of time t, edge i's roof plane climbing 1 / weights[i]
per unit inward (weight = 1 / tan(pitch)). A weight of 0 is a gable end: that
edge never moves, so the roof ends in a vertical gable over it, the edges either
side sliding along it. As the edges move, vertices meet: an edge shrinks to
nothing (an edge event: a hip, or the end of a ridge), or a reflex corner runs
into an edge across the polygon and splits it in two (a split event: a valley
meeting a ridge on an L or a T). The traces the moving vertices leave are the
hips, valleys and ridges.

The output is the roof surface itself: between events every moving edge sweeps
a planar quad (or a triangle when it closes up), tagged with the edge it came
from, so each roof face is the set of pieces with its edge's index, all in that
edge's plane. Points are (x, z, height).

The event loop is plain: at each step every candidate event's time is worked
out and the earliest taken, O(n^3) over a run, which is nothing for a house.
"""
import math

EPS = 1e-7


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def _cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def area(pts):
    return sum(_cross(a, b) for a, b in zip(pts, pts[1:] + pts[:1])) / 2


def _normal(a, b):
    """The inward unit normal of edge a->b of a counter-clockwise polygon (left of it)."""
    d = _sub(b, a)
    L = math.hypot(*d)
    return (-d[1] / L, d[0] / L), (d[0] / L, d[1] / L)


class _Edge:
    __slots__ = ("id", "n", "d", "w", "c")

    def __init__(self, eid, a, b, w):
        self.id, self.w = eid, w
        self.n, self.d = _normal(a, b)
        self.c = _dot(self.n, a)  # the line: n . x = c + w t


def _velocity(ea, eb):
    """How a vertex between incoming edge ea and outgoing edge eb moves per unit t:
    v . na = wa and v . nb = wb."""
    na, nb = ea.n, eb.n
    det = _cross(na, nb)
    if abs(det) < 1e-9:  # parallel: straight through (or folded back)
        if _dot(na, nb) > 0 and abs(ea.w - eb.w) < 1e-9:
            return (na[0] * ea.w, na[1] * ea.w)
        return None
    vx = (ea.w * nb[1] - eb.w * na[1]) / det
    vz = (eb.w * na[0] - ea.w * nb[0]) / det
    return (vx, vz)


class _Vertex:
    __slots__ = ("p", "t", "v")

    def __init__(self, p, t, v):
        self.p, self.t, self.v = p, t, v

    def at(self, t):
        return (self.p[0] + self.v[0] * (t - self.t), self.p[1] + self.v[1] * (t - self.t))


def skeleton(pts, weights, max_steps=2000):
    """The roof over polygon pts (counter-clockwise, (x, z)), edge i from pts[i] to
    pts[i + 1] moving at weights[i]: [(edge index, [(x, z, h), ...])] planar
    pieces, counter-clockwise seen from above, h the time (height) of each point."""
    n = len(pts)
    edges = [_Edge(i, pts[i], pts[(i + 1) % n], max(weights[i], 0.0)) for i in range(n)]
    # a wavefront: a cycle of (vertex, outgoing edge); vertex k sits between edge k-1 and edge k
    fronts = [[(_Vertex(pts[i], 0.0, None), edges[i]) for i in range(n)]]
    for f in fronts:
        _refresh(f)
    pieces = []
    t = 0.0
    steps = 0
    while fronts and steps < max_steps:
        steps += 1
        best = None  # (time, kind, front index, data)
        for fi, f in enumerate(fronts):
            m = len(f)
            if m < 3 or any(v.v is None for v, _e in f):
                continue
            for k in range(m):
                ev = _edge_event(f, k, t)
                if ev is not None and (best is None or ev < best[0] - EPS):
                    best = (ev, "edge", fi, k)
            for k in range(m):
                if not _reflex(f, k):
                    continue
                for j in range(m):
                    if j in (k, (k - 1) % m):
                        continue
                    ev = _split_event(f, k, j, t)
                    if ev is not None and (best is None or ev < best[0] - EPS):
                        best = (ev, "split", fi, (k, j))
        if best is None:
            break
        t1, kind, fi, data = best
        t1 = max(t1, t)
        for f in fronts:  # every front sweeps up to t1
            _sweep(f, t, t1, pieces)
            for vtx, _e in f:
                vtx.p, vtx.t = vtx.at(t1), t1
        t = t1
        f = fronts[fi]
        if kind == "edge":
            k = data
            m = len(f)
            a, b = f[k][0], f[(k + 1) % m][0]
            merged = _Vertex(_mid(a.p, b.p), t, None)
            f[(k + 1) % m] = (merged, f[(k + 1) % m][1])
            del f[k]
            _refresh(f)
            new = [f]
        else:
            k, j = data
            m = len(f)
            v = f[k][0]
            ej = f[j][1]
            # the reflex vertex splits edge j: two fronts, each keeping a copy of it
            left = [(_Vertex(v.p, t, None), f[k][1])] + [f[(k + 1 + i) % m] for i in range((j - k) % m)]
            right_start = (j + 1) % m
            right = [(_Vertex(v.p, t, None), ej)] + [f[(right_start + i) % m] for i in range((k - right_start) % m)]
            # left: v (outgoing = v's old outgoing edge) ... up to the vertex before edge j's end, ending on edge j
            # right: v (outgoing = edge j's continuation) ... back to the vertex before v, ending on v's incoming edge
            new = [_tidy(left), _tidy(right)]
        fronts = [g for i, g in enumerate(fronts) if i != fi] + [g for g in new if g is not None]
        fronts = [g for g in (_tidy(g) for g in fronts) if g is not None]
    return pieces


def _mid(a, b):
    return ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)


def _refresh(f):
    m = len(f)
    for k in range(m):
        vtx, e_out = f[k]
        e_in = f[k - 1][1]
        vtx.v = _velocity(e_in, e_out)


def _tidy(f):
    """Drop collapsed vertices and fronts with nothing left to roof (None)."""
    if f is None:
        return None
    changed = True
    while changed and len(f) >= 3:
        changed = False
        m = len(f)
        for k in range(m):
            a, b = f[k][0], f[(k + 1) % m][0]
            if math.dist(a.p, b.p) < 1e-6:  # edge k has no length: merge its ends
                f[(k + 1) % m] = (f[(k + 1) % m][0], f[(k + 1) % m][1])
                del f[k]
                changed = True
                break
    _despike(f)
    if len(f) < 3:
        return None
    _refresh(f)
    pts = [v.p for v, _e in f]
    if abs(area(pts)) < 1e-6 * max(1.0, sum(math.dist(a, b) for a, b in zip(pts, pts[1:] + pts[:1]))):
        return None  # folded flat: a ridge, nothing more to sweep
    if any(v.v is None for v, _e in f):
        return None
    return f


def _despike(f):
    """Trim zero-width spikes: where a part of the front has closed up (a narrower
    wing's two sides meeting in its ridge), a vertex sits between two edges running
    back along the same line. Drop it, joining its neighbours by whichever of the
    two edges runs their way, until none is left."""
    changed = True
    while changed and len(f) >= 3:
        changed = False
        m = len(f)
        for k in range(m):
            e_in, e_out = f[k - 1][1], f[k][1]
            if _dot(e_in.n, e_out.n) > -0.999999 or abs(_cross(e_in.n, e_out.n)) > 1e-6:
                continue
            prev, nxt = f[k - 1][0], f[(k + 1) % m][0]
            run = _sub(nxt.p, prev.p)
            keep = e_in if _dot(run, e_in.d) >= 0 else e_out
            f[k - 1] = (prev, keep)
            del f[k]
            m = len(f)
            if m >= 2:  # the spike's two sides were the same length: its ends meet too
                i = (k - 1) % m
                j = k % m
                if math.dist(f[i][0].p, f[j][0].p) < 1e-6:
                    f[i] = (f[i][0], f[j][1])
                    del f[j]
            changed = True
            break


def _edge_event(f, k, t):
    """When edge k (from vertex k to vertex k+1) shrinks to nothing, or None."""
    m = len(f)
    a, b = f[k][0], f[(k + 1) % m][0]
    d = f[k][1].d
    rel = _dot(_sub(b.p, a.p), d)  # its length now (along its own direction)
    rate = _dot(_sub(b.v, a.v), d)
    if rate >= -1e-12:
        return None
    dt = -rel / rate
    return t + dt if dt > -1e-9 else None


def _reflex(f, k):
    m = len(f)
    e_in, e_out = f[k - 1][1], f[k][1]
    return _cross(e_in.d, e_out.d) < -1e-9


def _split_event(f, k, j, t):
    """When reflex vertex k reaches edge j's moving line within its span, or None."""
    m = len(f)
    v = f[k][0]
    ej = f[j][1]
    # n . (p + v dt) = c + w (t + dt)
    num = ej.c + ej.w * t - _dot(ej.n, v.p)
    den = _dot(ej.n, v.v) - ej.w
    if den >= -1e-12:
        return None
    dt = num / den
    if dt <= 1e-9:
        return None
    hit = (v.p[0] + v.v[0] * dt, v.p[1] + v.v[1] * dt)
    a, b = f[j][0], f[(j + 1) % m][0]
    pa, pb = a.at(t + dt), b.at(t + dt)
    s = _dot(_sub(hit, pa), ej.d)
    L = _dot(_sub(pb, pa), ej.d)
    if L < -1e-9 or s < -1e-6 or s > L + 1e-6:
        return None
    return t + dt


def _sweep(f, t0, t1, pieces):
    """Every edge of front f sweeps the strip between t0 and t1."""
    if t1 - t0 <= 1e-12:
        return
    m = len(f)
    for k in range(m):
        a, b = f[k][0], f[(k + 1) % m][0]
        e = f[k][1]
        a0, b0, a1, b1 = a.at(t0), b.at(t0), a.at(t1), b.at(t1)
        quad = [(a0[0], a0[1], t0), (b0[0], b0[1], t0), (b1[0], b1[1], t1), (a1[0], a1[1], t1)]
        out = [quad[0]]
        for p in quad[1:]:
            if math.dist(p[:2], out[-1][:2]) > 1e-7 or abs(p[2] - out[-1][2]) > 1e-7:
                out.append(p)
        if math.dist(out[0][:2], out[-1][:2]) < 1e-7 and abs(out[0][2] - out[-1][2]) < 1e-7:
            out.pop()
        if len(out) >= 3:
            pieces.append((e.id, out))


def footprint_area(pieces):
    """The plan area the pieces cover (for checks)."""
    return sum(abs(area([(p[0], p[1]) for p in poly])) for _e, poly in pieces)


def roof_area(pieces):
    total = 0.0
    for _e, poly in pieces:
        o = poly[0]
        for a, b in zip(poly[1:], poly[2:]):
            u = (a[0] - o[0], a[2] - o[2], a[1] - o[1])
            v = (b[0] - o[0], b[2] - o[2], b[1] - o[1])
            cx = (u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0])
            total += math.sqrt(sum(c * c for c in cx)) / 2
    return total
