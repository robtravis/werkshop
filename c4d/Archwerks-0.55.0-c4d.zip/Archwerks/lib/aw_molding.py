"""Archwerks moldings: baseboards and crowns that follow a Wall.

A Molding links to a Wall, like a Slab, and sweeps a profile along the faces of
its rooms (closed runs): the Inside faces (the rooms' own), or the Outside faces
(a plinth or a frieze round the building). Corners are mitred by the wall's own
offset maths (aw_path corner), at every point of the profile, so they meet
cleanly however deep the profile is.

Type Base sits on the floor (Offset lifts it) and breaks wherever the wall has a
hole that comes down into it: every window or door (at its casing, if it has
one) and every plain cutter under the wall (a Cube, a Cylinder, any object: the
wall cuts its bounding box, and so does the molding). Type Crown runs
along the wall tops (Offset lowers it), sloping with them on a gable; it
breaks only where an opening reaches up into it.

A profile is a closed outline [(o, h)]: o out from the wall face, h up from the
floor (a base) or down from the ceiling (a crown), in cm. The built-in ones are
drawn to the molding's Height and Depth; Custom takes the outline of a linked
spline (its X out from the wall, its Y up), at the spline's own size.

With no Wall linked, a Molding follows its own child splines instead (drawn with
the Blender add-on's Draw tool, or any spline in Cinema 4D): every run, open or
closed, its points' heights included. Base sits on the path, Crown hangs from it;
Faces Inside puts the profile on the path's left (the inside of a closed loop),
Outside on its right; an open run ends square.

The outline and span maths (profile, spans) is pure, so it is tested outside C4D.
"""
import math

import aw_host
from aw_vec import Vec

BASE, CROWN = 0, 1
INSIDE, OUTSIDE = 0, 1
SQUARE, ROUNDED, OGEE, QUARTER, COVE, CROWN_OGEE, CUSTOM = range(7)
PROFILE_NAMES = ("Square", "Rounded", "Ogee", "Quarter Round", "Cove", "Crown", "Custom")
GROUPS = ("Molding",)
ARC = 8  # points per curved stretch of a profile


def _arc(cx, cy, rx, ry, a0, a1, n=ARC):
    """Points on an elliptical arc from angle a0 to a1 (degrees), both ends included."""
    return [(cx + rx * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
             cy + ry * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]


def profile(kind, height, depth):
    """The outline of built-in profile `kind`, Height x Depth, counter-clockwise from
    the wall's foot (0, 0) out along the bottom."""
    h, d = max(height, 0.1), max(depth, 0.1)
    if kind == ROUNDED:  # a bullnose along the top edge
        r = min(d, h / 3)
        return [(0, 0), (d, 0)] + _arc(d - r, h - r, r, r, 0, 90)[:-1] + [(d - r, h), (0, h)]
    if kind == OGEE:  # a square base with an ogee (S) top: convex, then concave into the wall
        top = h * 0.55
        s = [(d, top)] + _arc(d * 0.55, top, d * 0.45, (h - top) * 0.5, 0, 90)[1:]
        s += _arc(d * 0.55, h, d * 0.25, (h - top) * 0.5, 270, 180)[1:]
        return [(0, 0), (d, 0)] + s + [(0, h)]
    if kind == QUARTER:  # a shoe: a quarter ellipse
        return [(0, 0)] + _arc(0, 0, d, h, 0, 90)[:-1] + [(0, h)]
    if kind == COVE:  # concave: a quarter ellipse cut out of the corner square
        return [(0, 0), (d, 0)] + _arc(d, h, d, h, 270, 180)[1:-1] + [(0, h)]
    if kind == CROWN_OGEE:  # an S from out along the ceiling down to the wall
        mid = (d * 0.5, h * 0.5)
        s = _arc(d, mid[1], d - mid[0], mid[1], 270, 180)[1:] + _arc(0, mid[1], mid[0], h - mid[1], 0, 90)[1:-1]
        return [(0, 0), (d, 0)] + s + [(0, h)]
    return [(0, 0), (d, 0), (d, h), (0, h)]


def area(pts):
    return sum(x0 * y1 - x1 * y0 for (x0, y0), (x1, y1) in zip(pts, pts[1:] + pts[:1])) / 2


def ccw(pts):
    """pts counter-clockwise (o right, h up), without repeated points."""
    out = []
    for p in pts:
        if not out or math.dist(p, out[-1]) > 1e-4:
            out.append(p)
    while len(out) > 1 and math.dist(out[0], out[-1]) <= 1e-4:
        out.pop()
    return out if area(out) > 0 else out[::-1]


def spans(lengths, closed, cuts):
    """Where a molding runs round one run of segments: lengths[i] the length of
    segment i (its face line, from mitre to mitre, as (start, end) along it), closed
    whether the run loops, cuts {i: [(u0, u1)]} the stretches openings take out.
    Returns [(loop, [(i, u0, u1), ...])]: each a run of pieces along consecutive
    segments; loop True when it goes all the way round with no cut (no ends)."""
    pieces = []
    for i, (s, e) in enumerate(lengths):
        free = [(s, e)]
        for a, b in sorted(cuts.get(i, [])):
            nxt = []
            for fs, fe in free:
                if b <= fs or a >= fe:
                    nxt.append((fs, fe))
                    continue
                if a > fs:
                    nxt.append((fs, a))
                if b < fe:
                    nxt.append((b, fe))
            free = nxt
        pieces.append([(i, fs, fe) for fs, fe in free if fe - fs > 0.05])
    n = len(lengths)
    whole = [len(p) == 1 and abs(p[0][1] - lengths[i][0]) < 1e-6 and abs(p[0][2] - lengths[i][1]) < 1e-6
             for i, p in enumerate(pieces)]
    if closed and all(whole):
        return [(True, [p[0] for p in pieces])]
    flat = [pc for p in pieces for pc in p]
    out, cur = [], []
    for pc in flat:  # join pieces that meet at a corner
        if cur:
            i, _a, e = cur[-1]
            if pc[0] == i + 1 and abs(e - lengths[i][1]) < 1e-6 and abs(pc[1] - lengths[pc[0]][0]) < 1e-6:
                cur.append(pc)
                continue
            out.append(cur)
        cur = [pc]
    if cur:
        out.append(cur)
    if closed and len(out) > 1:  # the last span may run on round the corner into the first
        i, _a, e = out[-1][-1]
        j, s, _b = out[0][0]
        if i == n - 1 and j == 0 and abs(e - lengths[i][1]) < 1e-6 and abs(s - lengths[0][0]) < 1e-6:
            out[0] = out.pop() + out[0]
    return [(False, sp) for sp in out]


# Building (needs Cinema 4D) ----------------------------------------------------

def settings(op):
    import aw_ids as I
    v = lambda pid: aw_host.value(op, pid)  # noqa: E731
    return {"kind": int(v(I.AW_MOLDING_TYPE)), "wall": aw_host.link(op, I.AW_MOLDING_WALL), "side": int(v(I.AW_MOLDING_SIDE)),
            "profile": int(v(I.AW_MOLDING_PROFILE)), "height": float(v(I.AW_MOLDING_HEIGHT)),
            "depth": float(v(I.AW_MOLDING_DEPTH)), "offset": float(v(I.AW_MOLDING_OFFSET)),
            "gap": float(v(I.AW_MOLDING_GAP)), "breaks": bool(v(I.AW_MOLDING_BREAK)),
            "custom": aw_host.link(op, I.AW_MOLDING_CUSTOM)}


def custom_profile(spline):
    """The outline of a linked spline (its own X out, Y up), or None."""
    samples = aw_host.sample_curve(spline)
    if not samples:
        return None
    pts = []
    for x, y, _z in samples:
        if not pts or math.dist((x, y), pts[-1]) > 1e-3:
            pts.append((x, y))
    return ccw(pts) if len(pts) >= 3 and abs(area(pts)) > 1e-3 else None


def _cuts(wall, plan, height, s, band):
    """{segment: [(u0, u1)]} that openings take out of the band (lo, hi) of heights."""
    import aw_ids as I
    import aw_openings
    import aw_wall
    out = {}
    for child in aw_host.cutters(wall):  # what the wall cuts for: everything but its splines (aw_wall.path_rects)
        if aw_host.type_id(child) == I.ID_AW_CUTTER and not aw_host.value(child, I.AW_CUTTER_CUT_MOLDINGS):
            continue  # a cutter set to leave moldings whole
        k, u0, u1, y0, y1, _uc = aw_wall.path_opening(child, plan, height)
        u0, u1, y0, y1 = aw_openings.reach(child, plan, k, u0, u1, y0, y1)  # casings and all
        if y0 < band[1] - 0.01 and y1 > band[0] + 0.01:
            out.setdefault(k, []).append((u0, u1))
    return out


def own_path(op):
    """The molding's own path, from its child splines: an aw_path.Plan, or None."""
    import aw_path
    wc = aw_host.wall_curves(op)
    if wc is None:
        return None
    _splines, runs, every, rises = wc
    plan = aw_path.Plan(runs, every, rises)
    return plan if plan.segments else None


def wall_runs(op):
    """What a molding on a wall follows, as paths of its own: [(closed, [(x, y, z)])] in op's
    space (its core cm), along the wall's face it lines (Side), at the floor for a base and
    at the wall's top for a crown, round every room; split where openings break it (Break
    at Openings), so each piece is an open run. Given to op as its own splines and its
    Wall cleared, it builds as it did, and its runs can be edited (Make Independent)."""
    import aw_wall
    s = settings(op)
    wall = s["wall"]
    if not aw_host.alive(wall):
        return []
    wp = aw_wall.wall_path(wall)
    if wp is None:
        return []
    plan, w0, w1, height, _splines = wp
    face = w1 if s["side"] == INSIDE else w0
    crown = s["kind"] == CROWN
    shape = custom_profile(s["custom"]) if s["profile"] == CUSTOM else None
    shape = shape or profile(s["profile"] if s["profile"] != CUSTOM else SQUARE, s["height"], s["depth"])
    hmin, hmax = min(h for _o, h in shape), max(h for _o, h in shape)
    band = (height - s["offset"] - hmax, height - s["offset"] - hmin) if crown else (s["offset"] + hmin, s["offset"] + hmax)
    cuts = _cuts(wall, plan, height, s, band) if s["breaks"] else {}
    to_local = aw_host.relative(op, wall)

    def at(k, u):  # a point of the face line, u along segment k (None: its start corner)
        seg = plan.segments[k]
        if u is None:
            x, z = plan.corner(k, False, face)
            u = 0.0
        else:
            x, z = seg["a"][0] + seg["d"][0] * u + seg["n"][0] * face, seg["a"][1] + seg["d"][1] * u + seg["n"][1] * face
        p = to_local * Vec(x, plan.top(k, u, height) if crown else 0.0, z)
        return (p.x, p.y, p.z)
    out = []
    for r, run in enumerate(plan.runs):
        if not run.closed:  # a wall's rooms only, as build
            continue
        ks = plan.run_segments(r)
        lengths = [(plan.along(k, plan.corner(k, False, face)), plan.along(k, plan.corner(k, True, face))) for k in ks]
        local_cuts = {i: cuts[k] for i, k in enumerate(ks) if k in cuts}
        for loop, pieces in spans(lengths, run.closed, local_cuts):
            if loop:
                out.append((True, [at(ks[i], None) for i, _a, _b in pieces]))
            else:
                pts = [at(ks[pieces[0][0]], pieces[0][1])]
                pts += [at(ks[i], None) for i, _a, _b in pieces[1:]]
                pts.append(at(ks[pieces[-1][0]], pieces[-1][2]))
                out.append((False, pts))
    return out


def build(op):
    """The molding's mesh in its own space, or None."""
    import aw_slab
    import aw_wall
    from aw_mat import Mat
    from aw_mesh import MeshBuilder
    s = settings(op)
    wall = s["wall"]
    own = not aw_host.alive(wall)
    if own:  # no wall: along its own splines, the path its face line
        plan = own_path(op)
        if plan is None:
            return None
        w0 = w1 = height = 0.0
    else:
        wp = aw_wall.wall_path(wall)
        if wp is None:
            return None
        plan, w0, w1, height, _splines = wp
    shape = custom_profile(s["custom"]) if s["profile"] == CUSTOM else None
    shape = ccw(shape or profile(s["profile"] if s["profile"] != CUSTOM else SQUARE, s["height"], s["depth"]))
    hmin, hmax = min(h for _o, h in shape), max(h for _o, h in shape)
    crown = s["kind"] == CROWN
    sign = 1.0 if s["side"] == INSIDE else -1.0       # rooms are on +n of every closed run
    face = (w1 if s["side"] == INSIDE else w0) + sign * s["gap"]
    if crown:
        band = (height - s["offset"] - hmax, height - s["offset"] - hmin)
    else:
        band = (s["offset"] + hmin, s["offset"] + hmax)
    cuts = _cuts(wall, plan, height, s, band) if s["breaks"] and not own else {}
    to_local = Mat() if own else aw_host.relative(op, wall)
    mesh = MeshBuilder(GROUPS)
    # one ring of the profile at a station: (segment, u along it, or None at its start corner)
    def ring(k, u):
        seg = plan.segments[k]
        top = plan.top(k, 0.0 if u is None else u, height)
        lift = top if own else 0.0  # its own path: a base on it, a crown hanging from it, rising with it
        pts = []
        for o, h in shape:
            w = face + sign * o
            if u is None:
                x, z = plan.corner(k, False, w)
            else:
                x, z = (seg["a"][0] + seg["d"][0] * u + seg["n"][0] * w, seg["a"][1] + seg["d"][1] * u + seg["n"][1] * w)
            y = (top - s["offset"] - h) if crown else (lift + s["offset"] + h)
            p = to_local * Vec(x, y, z)
            pts.append(mesh.pt(p.x, p.y, p.z))
        return pts
    for r, run in enumerate(plan.runs):
        if not run.closed and not own:  # a wall's rooms; its open runs have no room to line
            continue
        ks = plan.run_segments(r)
        lengths = [(plan.along(k, plan.corner(k, False, face)), plan.along(k, plan.corner(k, True, face))) for k in ks]
        local_cuts = {i: cuts[k] for i, k in enumerate(ks) if k in cuts}
        for loop, pieces in spans(lengths, run.closed, local_cuts):
            mesh.new_part()
            first = len(mesh.polys)
            if loop:  # all the way round: a mitred ring at every corner, closed
                stations = [ring(ks[i], None) for i, _a, _b in pieces]
                stations.append(stations[0])
            else:  # square ends where openings cut it, mitred rings at the corners between
                stations = [ring(ks[pieces[0][0]], pieces[0][1])]
                stations += [ring(ks[i], None) for i, _a, _b in pieces[1:]]
                stations.append(ring(ks[pieces[-1][0]], pieces[-1][2]))
            m = len(shape)
            for a_, b_ in zip(stations, stations[1:]):
                for j in range(m):
                    jj = (j + 1) % m
                    mesh.quad(a_[j], a_[jj], b_[jj], b_[j], "Molding")
            if not loop:  # end caps, the profile's own triangles
                tris = aw_slab.triangulate(shape)
                for i0, i1, i2 in tris:
                    st, en = stations[0], stations[-1]
                    mesh.quad(st[i2], st[i1], st[i0], st[i0], "Molding")
                    mesh.quad(en[i0], en[i1], en[i2], en[i2], "Molding")
            mesh._face_out(first)
    if not mesh.polys:
        return None
    return mesh.build(aw_host.name(op))

