"""Linked windows and doors in Cinema 4D, as Blender's (blender/objects.linked): the ones
placed in one go share a link, and a setting changed on one in the Attribute Manager goes
to the others too, selected or not, each keeping its own place along its wall (Start).
Make Unique takes one out; Select Linked selects them all. The link is a string in the
object's own container, so it saves with the scene and a copy (Ctrl-drag) keeps it.
"""
import uuid

import c4d

import aw_ids as I

KEY = I.ID_AW_PLACE_TOOL  # the object container entry holding its link (no parameter uses a plugin id)
UNLINKED = {I.AW_OPENING_START}  # each its own: where it sits along its wall
_syncing = []


def new_link():
    return uuid.uuid4().hex[:12]


def link_of(op):
    return op.GetDataInstance().GetString(KEY) if op is not None else ""


def set_link(op, link):
    op.GetDataInstance().SetString(KEY, link or "")


def _walk(doc):
    stack = [doc.GetFirstObject()]
    while stack:
        o = stack.pop()
        while o:
            yield o
            if o.GetDown():
                stack.append(o.GetDown())
            o = o.GetNext()


def linked(op):
    """The other objects linked to op (same type, same link), or []."""
    link, doc = link_of(op), op.GetDocument() if op is not None else None
    if not link or doc is None:
        return []
    return [o for o in _walk(doc) if o != op and o.GetType() == op.GetType() and link_of(o) == link]


def sync(op, descid):
    """op's parameter descid changed in the Attribute Manager: the same value into every
    object linked to it, one undo step."""
    if _syncing or descid is None or descid[0].id in UNLINKED:
        return
    others = linked(op)
    if not others:
        return
    value = op.GetParameter(descid, c4d.DESCFLAGS_GET_NONE)
    doc = op.GetDocument()
    _syncing.append(op)
    try:
        doc.StartUndo()
        for o in others:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE_SMALL, o)
            o.SetParameter(descid, value, c4d.DESCFLAGS_SET_NONE)
            o.Message(c4d.MSG_UPDATE)
        doc.EndUndo()
    finally:
        _syncing.pop()
    c4d.EventAdd()


def make_unique(doc):
    """Unlink the selected windows and doors. How many."""
    n = 0
    doc.StartUndo()
    for o in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN):
        if I.is_opening(o) and link_of(o):
            doc.AddUndo(c4d.UNDOTYPE_CHANGE_SMALL, o)
            set_link(o, "")
            n += 1
    doc.EndUndo()
    c4d.EventAdd()
    return n


def select_linked(doc):
    """Add every object linked to a selected one to the selection. How many."""
    found = []
    for o in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN):
        found += [x for x in linked(o) if x not in found]
    for o in found:
        doc.SetSelection(o, c4d.SELECTION_ADD)
    c4d.EventAdd()
    return len(found)
