"""Archwerks cutters: shaped holes in a wall, archways first.

A Cutter sits under a Wall like a window or door and shares their size
parameters (Width, Height, Sill Height, Start Offset), so the wall cuts it,
draws its guides and grips it the same way. The wall always cuts a rectangle;
the Cutter fills back what lies outside its Shape, through the wall's
thickness, in the wall's own materials (its faces Exterior and Interior, the
curved soffit Reveals), so the hole reads as the shape.

Shapes (Archipack's, and Pointed):
- Rectangle: nothing filled.
- Top Round: an arc across the top of radius Radius (at least half the Width: a
  semicircle; more: a flatter segmental arch).
- Top Elliptic: half an ellipse Rise tall.
- Top Oblique: the top slopes up Rise from left to right.
- Pointed: two arcs of radius Radius meeting at a point (a Gothic arch).
- Full Circle: an ellipse filling the Width and Height (a round or oval hole).
- Rounded Corners: square sides and top, its top corners rounded to Radius (15 cm
  at 0), as a fireplace opening often is.
Resolution is the points along a curve. Cut Moldings: whether baseboards and
crowns stop at it.

Built in the cutter's own space, like a window: x0..x1 by y0..y1, the wall z
-thick/2 (Outside) .. +thick/2. Sizes in cm.
"""
import math

import aw_host

RECTANGLE, ROUND, ELLIPTIC, OBLIQUE, POINTED, CIRCLE, ROUNDED = range(7)
SHAPE_NAMES = ("Rectangle", "Top Round", "Top Elliptic", "Top Oblique", "Pointed", "Full Circle", "Rounded Corners")
ROUNDED_RADIUS = 15.0  # cm: Rounded Corners' radius when Radius is 0
GROUPS = ("Exterior", "Interior", "Reveals")


class Style:
    FIELDS = (("shape", ROUND), ("resolution", 32), ("radius", 0.0), ("rise", 30.0), ("cut_moldings", True))

    def __init__(self, **values):
        for name, default in self.FIELDS:
            setattr(self, name, values.pop(name, default))
        if values:
            raise TypeError("unknown cutter settings: %s" % ", ".join(values))

    def key(self):
        return tuple(getattr(self, name) for name, _d in self.FIELDS)


def top_curve(x0, x1, y1, s):
    """[(x, y)] left to right along the top of the hole's shape (its intrados), for
    the top shapes; [] for Rectangle and Full Circle."""
    w = x1 - x0
    n = max(4, min(256, int(s.resolution)))
    if w <= 0 or s.shape in (RECTANGLE, CIRCLE):
        return []
    if s.shape == ROUNDED:
        r = min(s.radius if s.radius > 0 else ROUNDED_RADIUS, w / 2)
        q = max(2, n // 4)  # points round each corner
        left = [(x0 + r - r * math.cos(math.pi / 2 * i / q), y1 - r + r * math.sin(math.pi / 2 * i / q))
                for i in range(q + 1)]
        right = [(x1 - r + r * math.sin(math.pi / 2 * i / q), y1 - r + r * math.cos(math.pi / 2 * i / q))
                 for i in range(q + 1)]
        return left + right
    if s.shape == OBLIQUE:
        rise = min(max(s.rise, 0.0), y1)
        return [(x0, y1 - rise), (x1, y1)]
    if s.shape == ELLIPTIC:
        rise = min(max(s.rise, 0.1), y1)
        return [(x0 + w / 2 - w / 2 * math.cos(math.pi * i / n), y1 - rise + rise * math.sin(math.pi * i / n))
                for i in range(n + 1)]
    r = max(s.radius, w / 2) if s.radius > 0 else w / 2
    if s.shape == POINTED:  # two arcs of radius r, centred on the spring line, meeting at the top
        r = max(r, w / 2)
        rise = math.sqrt(max(r * r - (r - w / 2) ** 2, 0.0))
        left, right = [], []
        half = n // 2 or 1
        a_end = math.acos(min(1.0, (r - w / 2) / r))
        for i in range(half + 1):
            a = a_end * i / half
            left.append((x0 + r - r * math.cos(a), y1 - rise + r * math.sin(a)))
        for i in range(half, -1, -1):
            a = a_end * i / half
            right.append((x1 - r + r * math.cos(a), y1 - rise + r * math.sin(a)))
        return left + right[1:]
    # Top Round: an arc of radius r over the chord w; a semicircle when r == w / 2
    sag = r - math.sqrt(max(r * r - (w / 2) ** 2, 0.0))
    a0 = math.asin(min(1.0, (w / 2) / r))
    cx, cy = x0 + w / 2, y1 - r
    return [(cx + r * math.sin(-a0 + 2 * a0 * i / n), cy + r * math.cos(-a0 + 2 * a0 * i / n)) for i in range(n + 1)]


def regions(x0, x1, y0, y1, s):
    """The outlines (counter-clockwise, in x and y) of what the Cutter fills back:
    the corners between the shape and the rectangle the wall cuts."""
    def ccw(pts):
        out = []
        for p in pts:
            if not out or math.dist(p, out[-1]) > 1e-4:
                out.append(p)
        while len(out) > 1 and math.dist(out[0], out[-1]) <= 1e-4:
            out.pop()
        if len(out) < 3:
            return None
        a = sum(xa * yb - xb * ya for (xa, ya), (xb, yb) in zip(out, out[1:] + out[:1]))
        if abs(a) < 1e-4:
            return None
        return out if a > 0 else out[::-1]
    out = []
    if s.shape == CIRCLE:
        n = 4 * max(2, min(64, (int(s.resolution) + 3) // 4))  # whole quarters
        cx, cy, rx, ry = (x0 + x1) / 2, (y0 + y1) / 2, (x1 - x0) / 2, (y1 - y0) / 2
        ring = [(cx + rx * math.cos(2 * math.pi * i / n), cy + ry * math.sin(2 * math.pi * i / n)) for i in range(n + 1)]
        q = n // 4
        corners = ((x1, y1), (x0, y1), (x0, y0), (x1, y0))
        for k in range(4):
            arc = ring[k * q:(k + 1) * q + 1]
            out.append(ccw(arc + [corners[k]]))
        return [r for r in out if r]
    curve = top_curve(x0, x1, y1, s)
    if len(curve) < 2:
        return []
    if s.shape == ROUNDED:  # a fill in each corner, the flat top between them left open
        left, right = curve[:len(curve) // 2], curve[len(curve) // 2:]
    else:
        i = max(range(len(curve)), key=lambda k: curve[k][1])  # the crown: split there, so no region pinches
        left, right = curve[:i + 1], curve[i:]
    out.append(ccw(left + [(left[-1][0], y1), (x0, y1)]))
    out.append(ccw(right + [(x1, y1), (right[0][0], y1)]))
    return [r for r in out if r]


def build(name, x0, x1, y0, y1, thick, style=None, custom=None):
    """The fill for a hole x0..x1 by y0..y1 in a wall thick deep."""
    import aw_slab
    from aw_mesh import MeshBuilder
    s = style or Style()
    mesh = MeshBuilder(GROUPS)
    za, zb = -thick / 2, thick / 2
    for reg in regions(x0, x1, y0, y1, s):
        mesh.new_part()
        first = len(mesh.polys)
        front = [mesh.pt(x, y, za) for x, y in reg]
        back = [mesh.pt(x, y, zb) for x, y in reg]
        for a, b, c in aw_slab.triangulate(reg):
            mesh.quad(front[a], front[b], front[c], front[c], "Exterior")
            mesh.quad(back[c], back[b], back[a], back[a], "Interior")
        n = len(reg)
        for e in range(n):
            f = (e + 1) % n
            mesh.quad(front[e], back[e], back[f], front[f], "Reveals")
        mesh._face_out(first)
    return mesh.build(name)


def settings(op):
    import aw_host
    import aw_ids as I
    defaults = dict(Style.FIELDS)
    values = {}
    for name, pid in I.AW_CUTTER_STYLE_PARAMS:
        v = aw_host.value(op, pid)
        values[name] = defaults[name] if v is None else type(defaults[name])(v)
    return Style(**values)


def custom_handle(op):
    return None, None  # cutters have no handles
