"""Archwerks slabs: floors and ceilings that fill a Wall's rooms.

A Slab links to a Wall and fills every closed run of its splines (each a room;
open runs, partitions, are left out) out to the walls' outer perimeter (Fit
Outside, the default), their Interior faces, or the spline line itself. A floor's
top sits at the wall's base; a ceiling sits on the walls (or, fitted inside them,
flush with their tops), and with Follow Wall Tops it climbs where they do: each
corner at its wall's top, the surface between triangulated as high as it can be,
so gables facing each other meet in a ridge (roof_triangulate: the highest
surface its edges allow). Offset moves either up or down, Thickness is how deep it
is. It follows the wall live.

The outline maths (outlines, triangulate) is pure, so it is tested outside C4D.
"""
import math

import aw_host
from aw_vec import Vec

FIT_INSIDE, FIT_OUTSIDE, FIT_CENTER = 0, 1, 2
FLOOR, CEILING = 0, 1
GROUPS = ("Top", "Bottom", "Edge")


def fit_offset(fit, w0, w1):
    """Where across the walls a slab's edge runs, as an offset along n (see
    aw_path.Plan: every closed run's room is on its +n side, the Exterior on w0)."""
    if fit == FIT_OUTSIDE:
        return w0
    if fit == FIT_CENTER:
        return 0.0
    return w1


def outlines(plan, w):
    """[[(x, z), ...]] counter-clockwise, one per closed run: the run's corners
    offset w along n, mitred as the walls are."""
    out = []
    for r, run in enumerate(plan.runs):
        if not run.closed:
            continue
        pts = [run.corner(k, False, w) for k in range(len(run.segments))]
        if len(pts) >= 3 and abs(_area(pts)) > 1e-6:
            out.append(pts if _area(pts) > 0 else pts[::-1])
    return out


def outlines_with_rise(plan, w, w0=None, w1=None, edge=0.5):
    """[(outline, rises)] like outlines(), each point with how much higher than the
    wall's Height its top is there: the top line of the wall's face at w exactly as
    the wall builds it (aw_wall._add_run), so a ceiling sits on it with no gap. At
    a corner that is the higher of the two walls' slopes carried to that point; a
    sloped wall raised at its corner for its neighbour stays level for the corner
    strip and starts its slope `edge` inside its clear span (a point there too).
    w0, w1: the wall's faces (None: no clear-span points, corners only)."""
    eps = 1e-4

    def seg_T(k, x):  # segment k's rise a distance x along it, carried on past its ends
        return plan.rise(k, x) if hasattr(plan, "rise") else 0.0

    out = []
    for r, run in enumerate(plan.runs):
        if not run.closed:
            continue
        ks = plan.run_segments(r)
        n = len(ks)

        def corner_top(i, end, ww):
            k = ks[i]
            pt = plan.corner(k, end, ww)
            t = seg_T(k, plan.along(k, pt))
            nb = ks[(i + 1) % n] if end else ks[i - 1]
            return max(t, seg_T(nb, plan.along(nb, pt)))
        pts, rises = [], []
        for i, k in enumerate(ks):
            seg = plan.segments[k]
            pts.append(plan.corner(k, False, w))
            rises.append(corner_top(i, False, w))
            if w0 is None:
                continue
            c0, c1 = plan.clear_span(k, w0, w1)
            inner = []
            for end, c in ((False, c0 + edge), (True, c1 - edge)):
                raised = any(corner_top(i, end, ww) > seg_T(k, plan.along(k, plan.corner(k, end, ww))) + eps
                             for ww in (w0, w1))
                if raised and eps < c < seg["length"] - eps:
                    inner.append(c)
            for u in sorted(inner):
                pts.append((seg["a"][0] + seg["d"][0] * u + seg["n"][0] * w,
                            seg["a"][1] + seg["d"][1] * u + seg["n"][1] * w))
                rises.append(seg_T(k, u))
        if len(pts) >= 3 and abs(_area(pts)) > 1e-6:
            if _area(pts) < 0:
                pts, rises = pts[::-1], rises[::-1]
            out.append((pts, rises))
    return out


def _cross(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def _diagonal_ok(pts, i, j):
    """True when the chord i-j lies inside the simple counter-clockwise polygon pts."""
    n = len(pts)
    a, b = pts[i], pts[j]
    for e in range(n):
        f = (e + 1) % n
        if e in (i, j) or f in (i, j):
            continue
        c, d = pts[e], pts[f]
        if _cross(c, d, a) * _cross(c, d, b) < -1e-9 and _cross(a, b, c) * _cross(a, b, d) < -1e-9:
            return False
    # inside: the chord leaves i into the polygon (between i's two edges)
    prev, nxt = pts[(i - 1) % n], pts[(i + 1) % n]
    if _cross(prev, a, nxt) >= 0:  # a convex corner: b must be left of both edges
        return _cross(a, nxt, b) > 1e-9 and _cross(prev, a, b) > 1e-9
    return not (_cross(a, nxt, b) <= 1e-9 and _cross(prev, a, b) <= 1e-9)


def roof_triangulate(pts, rises, limit=80):
    """Triangles [(i, j, k)] (counter-clockwise) of the simple counter-clockwise
    polygon pts whose corners stand at heights rises, chosen so the surface stands
    as high as its edges allow (the most volume under it): gables facing each
    other meet in a ridge, never a dip or a saddle across the room. (The least
    area is not the same: extra points along an eave let a saddle undercut it.)
    Level outlines, or ones with more than `limit` corners, ear-clip instead."""
    n = len(pts)
    if n < 4 or n > limit or max(rises) - min(rises) < 1e-6:
        return triangulate(pts)

    def under(i, j, k):  # minus the volume under the triangle: the pass below minimises it
        return -abs(_cross(pts[i], pts[j], pts[k])) / 2 * (rises[i] + rises[j] + rises[k]) / 3
    ok = [[False] * n for _ in range(n)]
    for i in range(n):
        ok[i][(i + 1) % n] = ok[(i + 1) % n][i] = True
        for j in range(i + 2, n):
            if not (i == 0 and j == n - 1):
                ok[i][j] = ok[j][i] = _diagonal_ok(pts, i, j)
    ok[0][n - 1] = ok[n - 1][0] = True
    INF = float("inf")
    cost = [[0.0 if j <= i + 1 else INF for j in range(n)] for i in range(n)]
    pick = [[None] * n for _ in range(n)]
    for span in range(2, n):
        for i in range(0, n - span):
            j = i + span
            if not ok[i][j]:
                continue
            for k in range(i + 1, j):
                if not (ok[i][k] and ok[k][j]) or _cross(pts[i], pts[k], pts[j]) <= 1e-9:
                    continue
                c = cost[i][k] + cost[k][j] + under(i, k, j)
                if c < cost[i][j]:
                    cost[i][j], pick[i][j] = c, k
    if cost[0][n - 1] == INF:
        return triangulate(pts)
    tris, stack = [], [(0, n - 1)]
    while stack:
        i, j = stack.pop()
        k = pick[i][j]
        if k is None:
            continue
        tris.append((i, k, j))
        stack += [(i, k), (k, j)]
    return tris


def _area(pts):
    return sum(x0 * z1 - x1 * z0 for (x0, z0), (x1, z1) in zip(pts, pts[1:] + pts[:1])) / 2


def _inside(p, a, b, c):
    """True when p is inside (or on the edge of) triangle abc, counter-clockwise."""
    def cross(o, s, t):
        return (s[0] - o[0]) * (t[1] - o[1]) - (s[1] - o[1]) * (t[0] - o[0])
    return cross(a, b, p) >= -1e-9 and cross(b, c, p) >= -1e-9 and cross(c, a, p) >= -1e-9


def triangulate(pts):
    """Ear clipping for a simple counter-clockwise polygon: [(i, j, k)] indices
    into pts, every triangle counter-clockwise. Works for concave rooms (an L, a U)."""
    idx = list(range(len(pts)))
    tris = []
    guard = 0
    while len(idx) > 3 and guard < 10000:
        guard += 1
        n = len(idx)
        for e in range(n):
            i, j, k = idx[(e - 1) % n], idx[e], idx[(e + 1) % n]
            a, b, c = pts[i], pts[j], pts[k]
            if (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]) <= 1e-9:
                continue  # a reflex (or flat) corner: not an ear
            if any(_inside(pts[m], a, b, c) for m in idx if m not in (i, j, k)):
                continue
            tris.append((i, j, k))
            idx.pop(e)
            break
        else:
            break  # no ear found (a self-crossing outline): stop rather than loop
    if len(idx) == 3:
        tris.append(tuple(idx))
    return tris


def levels(kind, height, thick, offset, fit=FIT_OUTSIDE):
    """(bottom, top) heights of a floor or ceiling slab. A floor's top is at the
    wall's base. A ceiling over the walls (Fit Outside, the default) sits on them,
    its underside at the wall Height; one inside the walls sits flush with their
    tops, its underside Thickness below (Fit Inside or Spline)."""
    if kind == CEILING:
        if fit == FIT_OUTSIDE:
            return height + offset, height + offset + thick
        return height + offset - thick, height + offset
    return offset - thick, offset


def angle_sum_ok(pts):
    """Sanity: a simple polygon's turns add up to one full turn."""
    total = 0.0
    n = len(pts)
    for e in range(n):
        a, b, c = pts[e - 1], pts[e], pts[(e + 1) % n]
        t1 = math.atan2(b[1] - a[1], b[0] - a[0])
        t2 = math.atan2(c[1] - b[1], c[0] - b[0])
        d = (t2 - t1 + math.pi) % (2 * math.pi) - math.pi
        total += d
    return abs(abs(total) - 2 * math.pi) < 1e-6


# Building (through the host, aw_host) ----------------------------------------------

def settings(op):
    """(kind, wall, fit, thickness, offset) from a Slab."""
    import aw_ids as I

    def get(pid, default):
        v = aw_host.value(op, pid)
        return default if v is None else v
    return (int(get(I.AW_SLAB_TYPE, FLOOR)), aw_host.link(op, I.AW_SLAB_WALL), int(get(I.AW_SLAB_FIT, FIT_OUTSIDE)),
            max(float(get(I.AW_SLAB_THICKNESS, 15.0)), 0.1), float(get(I.AW_SLAB_OFFSET, 0.0)))


def build(op):
    """The slab's mesh in its own space, or None when its wall has no closed room."""
    import aw_wall
    from aw_mesh import MeshBuilder
    kind, wall, fit, thick, offset = settings(op)
    wp = aw_wall.wall_path(wall) if aw_host.alive(wall) else None
    if wp is None:
        return None
    plan, w0, w1, height, _s = wp
    import aw_ids as I
    follow = kind == CEILING and bool(aw_host.value(op, I.AW_SLAB_FOLLOW))  # gables, not a flat plane
    import aw_build
    rooms = outlines_with_rise(plan, fit_offset(fit, w0, w1), w0, w1, aw_build.EDGE)
    if not rooms:
        return None
    bottom, top = levels(kind, height, thick, offset, fit)
    to_local = aw_host.relative(op, wall)
    mesh = MeshBuilder(GROUPS)
    for pts, rises in rooms:
        if not follow:
            rises = [0.0] * len(pts)
        mesh.new_part()
        first = len(mesh.polys)
        tp = [mesh.pt(*_v(to_local, x, top + h, z)) for (x, z), h in zip(pts, rises)]
        bt = [mesh.pt(*_v(to_local, x, bottom + h, z)) for (x, z), h in zip(pts, rises)]
        for i, j, k in roof_triangulate(pts, rises):  # counter-clockwise from above: as C4D winds an upward face
            mesh.quad(tp[i], tp[k], tp[j], tp[j], "Top")
            mesh.quad(bt[i], bt[j], bt[k], bt[k], "Bottom")
        n = len(pts)
        for e in range(n):
            f = (e + 1) % n
            mesh.quad(tp[e], tp[f], bt[f], bt[e], "Edge")
        mesh._face_out(first)
    return mesh.build(aw_host.name(op))


def _v(m, x, y, z):
    p = m * Vec(x, y, z)
    return p.x, p.y, p.z
