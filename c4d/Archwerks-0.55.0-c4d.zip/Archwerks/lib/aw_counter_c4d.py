"""aw_counter for Cinema 4D: the parts of core/aw_counter.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_groups_c4d
import aw_counter  # noqa: F401
from aw_counter import *  # noqa: F401,F403


def change_key(op):
    import c4d
    s = settings(op)
    cabs = tuple((c.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX),
                  tuple(round(x, 3) for v in (c.GetMg().off, c.GetMg().v1) for x in (v.x, v.y, v.z)))
                 for c in cabinets(op, s))
    kids = tuple((k.GetType(), k.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX | c4d.DIRTYFLAGS_CACHE),
                  k.GetDeformMode()) for k in op.GetChildren())
    return (op.GetName(), op.GetDirty(c4d.DIRTYFLAGS_DATA), op.GetMg().off.y, cabs, kids)


def sink_contour(op):
    """A sink's outline as a closed linear spline in its own XZ (what you see and move)."""
    import c4d
    s = sink_settings(op)
    pts = outline(s["shape"], s["width"], s["length"], s["radius"])
    sp = c4d.SplineObject(len(pts), c4d.SPLINETYPE_LINEAR)
    sp.SetAllPoints([c4d.Vector(x, 0, z) for x, z in pts])
    sp[c4d.SPLINEOBJECT_CLOSED] = True
    sp.Message(c4d.MSG_UPDATE)
    return sp


def add_countertop(doc):
    """Panel button Countertop: one over the selected cabinets (bases and vanities); with
    none selected, an empty one with a spline to draw its outline. One undo step."""
    import c4d
    import aw_cabinet as C
    import aw_ids as I
    import aw_materials
    import aw_panel
    import aw_slab
    import aw_slab_c4d
    cabs = [o for o in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE) if o.GetType() == I.ID_AW_CABINET
            and int(C.settings(o)["type"]) in (C.BASE, C.VANITY)]
    ct = c4d.BaseObject(I.ID_AW_COUNTERTOP)
    ct.SetName(aw_slab_c4d.next_name(doc, "Countertop"))
    doc.StartUndo()
    if cabs:
        lst = c4d.InExcludeData()
        for c in cabs:
            lst.InsertObject(c, 1)
        ct[I.AW_CT_CABINETS] = lst
        doc.InsertObject(ct, cabs[0].GetUp(), cabs[0])
        ct.SetMg(c4d.Matrix(cabs[0].GetMg()))
    else:
        doc.InsertObject(ct)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, ct)
    aw_materials.apply_defaults(doc, ct)
    aw_groups_c4d.file(doc, ct)  # into its group: null and layer (aw_groups_c4d)
    if not cabs:
        spline = c4d.SplineObject(0, c4d.SPLINETYPE_LINEAR)
        spline.SetName(aw_panel.RUN_NAME % 1)
        spline.InsertUnder(ct)
        doc.EndUndo()
        doc.SetActiveObject(spline, c4d.SELECTION_NEW)
        aw_panel._arm_pen(doc, ct, spline)
        c4d.gui.StatusSetText("Draw the countertop's outline (an island, say): close it")
        c4d.EventAdd()
        return ct
    doc.EndUndo()
    sync_sinks(doc)  # its Sink zones' sinks
    doc.SetActiveObject(ct, c4d.SELECTION_NEW)
    c4d.EventAdd()
    return ct


def add_sink(doc, preset):
    """Panel sink button: the preset under the selected countertop (or the countertop of
    a selected cabinet): centred over its sink base (a cabinet with a Sink, False Front or
    Empty top zone) if it has one, near the front, else in its middle."""
    import c4d
    import aw_ids as I
    sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
    ct = next((o for o in sel if o.GetType() == I.ID_AW_COUNTERTOP), None)
    if ct is None:
        cab = next((o for o in sel if o.GetType() == I.ID_AW_CABINET), None)
        o = doc.GetFirstObject()
        while o and cab is not None and ct is None:
            if o.GetType() == I.ID_AW_COUNTERTOP and cab in cabinets(o):
                ct = o
            o = o.GetNext()
    if ct is None:
        c4d.gui.MessageDialog("Select a countertop (or a cabinet under one) first: the sink goes in it.")
        return None
    doc.StartUndo()
    sk = place_sink(doc, ct, preset)
    doc.EndUndo()
    doc.SetActiveObject(sk, c4d.SELECTION_NEW)
    c4d.EventAdd()
    return sk


AUTO = 1072222  # a sink's container entry (its own type id, never a parameter): added for a Sink zone


def place_sink(doc, ct, preset, cab=None):
    """The preset's sink under countertop ct, in the open undo step: centred over cab, else
    over its sink base (a cabinet whose top zone is Sink, False Front or Empty), near the
    front; with neither, in the countertop's middle."""
    import c4d
    import aw_cabinet as C
    import aw_ids as I
    v = preset["values"]
    sk = c4d.BaseObject(I.ID_AW_SINK)
    sk.SetName(preset["label"])
    for name, key in SINK_FIELDS:
        sk[getattr(I, "AW_SINK_" + key)] = v[name]
    s = settings(ct)
    target = None
    for c in ([cab] if cab is not None else cabinets(ct, s)):
        cs = C.settings(c)
        zs = C.zones(cs)
        if cab is not None or (zs and zs[-1][0]["kind"] in (C.SINK, C.FALSE_FRONT, C.EMPTY)
                               and cs.get("corner", 0) == 0):
            target = (c, cs)
            break
    inv = ~ct.GetMg()
    if target is not None:
        c, cs = target
        if v["mount"] == APRON:  # its apron flush with the fronts
            z = -cs["depth"] + v["length"] / 2
        else:
            z = -(cs["depth"] + s["front"]) + 3 * IN + v["length"] / 2
        m = inv * c.GetMg() * c4d.Matrix(c4d.Vector(cs["width"] / 2, 0, z))
    else:
        polys, _y, _b, _e, _c = layout(ct, s)
        pts = [p for poly in polys for p in poly]
        cx = sum(p[0] for p in pts) / max(len(pts), 1)
        cz = sum(p[1] for p in pts) / max(len(pts), 1)
        m = c4d.Matrix(c4d.Vector(cx, 0, cz))
    _polys, y0, _b, _e, _c = layout(ct, s)
    m.off = c4d.Vector(m.off.x, y0 + s["thick"], m.off.z)  # on the top, where you'll look for it
    sk.InsertUnderLast(ct)
    sk.SetMl(m)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, sk)
    match_base(sk)  # its base: an empty top for an apron, a false front for the rest
    doc.AddUndo(c4d.UNDOTYPE_CHANGE_SMALL, ct)
    sink_to_tab(sk)  # the countertop's Sinks tab shows it
    return sk


_SYNCING = []  # while the Sinks tab and its sinks write to each other: neither passes it on again


def sink_to_tab(sink):
    """aw_counter.sink_to_tab, without the countertop passing it back to every sink (setting a
    parameter sends Cinema 4D's change message, which would)."""
    if _SYNCING:
        return None
    _SYNCING.append(sink)
    try:
        return aw_counter.sink_to_tab(sink)
    finally:
        _SYNCING.pop()


def sinks_from_tab(ct, ct_pid):
    """The countertop's Sinks tab changed ct_pid: every sink under it takes it (and its
    sink base follows a new mount), one undo step."""
    import c4d
    import aw_ids as I
    doc = ct.GetDocument()
    if doc is None or _SYNCING:
        return
    _SYNCING.append(ct)
    try:
        _sinks_from_tab(doc, ct, ct_pid)
    finally:
        _SYNCING.pop()
    ct.Message(c4d.MSG_UPDATE)
    c4d.EventAdd()


def _sinks_from_tab(doc, ct, ct_pid):
    import c4d
    import aw_ids as I
    doc.StartUndo()
    for k in sinks_of(ct):
        doc.AddUndo(c4d.UNDOTYPE_CHANGE_SMALL, k)
    for k in tab_to_sinks(ct, ct_pid):
        k.Message(c4d.MSG_UPDATE)
        if ct_sink_pids()[ct_pid] in (I.AW_SINK_MOUNT, I.AW_SINK_DEPTH):
            match_base(k)
    doc.EndUndo()


def is_auto(sk):
    return bool(sk.GetDataInstance().GetBool(AUTO))


def sync_sinks(doc, cab=None):
    """Every countertop over cab (None: every countertop) gets a sink over each of its Sink
    zones that has none, and loses the ones it was given over cabinets that aren't any
    more (aw_counter.auto_sinks); one undo step. How many changed."""
    import c4d
    import aw_ids as I
    import aw_c4d
    tops = [o for o in aw_c4d.scan(doc, I.ID_AW_COUNTERTOP) if cab is None or cab in cabinets(o)]
    changed = 0
    for ct in tops:
        need, drop = auto_sinks(ct, is_auto)
        if not need and not drop:
            continue
        doc.StartUndo()
        for k in drop:
            doc.AddUndo(c4d.UNDOTYPE_DELETEOBJ, k)
            k.Remove()
        for c in need:
            sk = place_sink(doc, ct, sink_for(c), c)
            sk.GetDataInstance().SetBool(AUTO, True)
        doc.EndUndo()
        changed += len(need) + len(drop)
    if changed:
        c4d.EventAdd()
    return changed
