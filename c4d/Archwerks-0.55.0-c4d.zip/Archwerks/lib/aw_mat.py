"""A 3D transform for the core: an offset and three axes, as Cinema 4D's c4d.Matrix
(off, v1, v2, v3) has them, so code written against either reads the same.

m * Vec places a point (m.off + x v1 + y v2 + z v3); m * Mat chains two; ~m undoes
one. A host hands these to the core (aw_host.relative) from its own matrices.
"""
from aw_vec import Vec


class Mat:
    __slots__ = ("off", "v1", "v2", "v3")

    def __init__(self, off=None, v1=None, v2=None, v3=None):
        self.off = off if off is not None else Vec(0, 0, 0)
        self.v1 = v1 if v1 is not None else Vec(1, 0, 0)
        self.v2 = v2 if v2 is not None else Vec(0, 1, 0)
        self.v3 = v3 if v3 is not None else Vec(0, 0, 1)

    def __repr__(self):
        return "Mat(off=%r, v1=%r, v2=%r, v3=%r)" % (self.off, self.v1, self.v2, self.v3)

    def turn(self, p):
        """p turned (and scaled) by the axes, without the offset."""
        return self.v1 * p.x + self.v2 * p.y + self.v3 * p.z

    def __mul__(self, o):
        if isinstance(o, Mat):
            return Mat(self * o.off, self.turn(o.v1), self.turn(o.v2), self.turn(o.v3))
        return self.off + self.turn(o)

    def __invert__(self):
        a, b, c = self.v1, self.v2, self.v3
        det = a.Dot(b.Cross(c))
        if abs(det) < 1e-12:
            return Mat()
        # the inverse's rows are the cofactors over the determinant; as columns:
        r1, r2, r3 = b.Cross(c) / det, c.Cross(a) / det, a.Cross(b) / det
        v1, v2, v3 = Vec(r1.x, r2.x, r3.x), Vec(r1.y, r2.y, r3.y), Vec(r1.z, r2.z, r3.z)
        inv = Mat(Vec(0, 0, 0), v1, v2, v3)
        inv.off = -inv.turn(self.off)
        return inv
