"""What the core asks of the application it runs in, filled in by that host.

The core never imports Cinema 4D or Blender. Where it needs something only the
host has (an object's parameter, the polygons of an object a setting links to, a
finished mesh turned into the host's own object) it calls these, and the host
registers its own at startup: Cinema 4D's in src/aw_c4d.py, Blender's in the
add-on. An object reaching the core is an opaque handle it only passes back here.
"""


def _missing(*_args, **_kw):
    raise RuntimeError("Archwerks: no host registered (aw_host.register was never called)")


stored = _missing         # stored(obj, pid): what obj holds for setting pid, None if it never had it
link = _missing           # link(obj, pid): the object a link setting points to, or None
custom_mesh = _missing    # custom_mesh(obj): (points with .x .y .z, [(a, b, c, d)]) in obj's own space, or None
custom_key = _missing     # custom_key(obj): changes whenever obj (or what's under it) does
mesh_object = _missing    # mesh_object(builder, name): the host's object for an aw_mesh.MeshBuilder
name = _missing           # name(obj): the object's name
spline_paths = _missing   # spline_paths(obj, skip=(), with_y=False): ([closed loops], [open runs]) of obj's
                          # child curves in obj's space, (x, z) or (x, y, z), curves sampled evenly by length;
                          # children whose aw_ids type is in skip passed over
alive = _missing          # alive(obj): obj is not None and still in the scene
type_id = _missing        # type_id(obj): obj's aw_ids type (ID_AW_STAIR...), or None for anything else
relative = _missing       # relative(obj, other): the aw_mat.Mat taking other's space into obj's
spline_points = _missing  # spline_points(obj): [(x, y)] of a profile curve's points in its own plane, or None
set_value = _missing      # set_value(obj, pid, v, undo=False): set obj's setting pid (as an undo step with undo)
pull_library = _missing   # pull_library(): [(name, (points, polys))] of the user's own pulls, [] without any
local_matrix = _missing   # local_matrix(obj): obj's aw_mat.Mat in its parent's space
box_size = _missing       # box_size(obj): a plain cutter object's size, a Vec
cutters = _missing        # cutters(obj, hide=False): obj's enabled children but its path curves (openings,
                          # plain cutters); hide: the host consumes the plain ones, as a Boolean does
wall_curves = _missing    # wall_curves(obj): (handle, runs [(points (x, z), closed, point ids)], every point
                          # (x, z), every point's rise) of a wall's path curves, or None under two points
ident = _missing          # ident(obj): a lasting, hashable identity for obj
path_key = _missing       # path_key(obj): changes whenever obj's settings or its path curves do
children = _missing       # children(obj): obj's child objects that are switched on, in order
curve_points = _missing   # curve_points(obj): [(x, y, z)] of obj's first child curve with 3 points or more, in
                          # obj's space, or None
parent = _missing         # parent(obj): the object obj sits under, or None
world_matrix = _missing   # world_matrix(obj): obj's aw_mat.Mat in the scene's space
objects = _missing        # objects(obj, type_id): every object of that aw_ids type in obj's scene (none outside one)
object_list = _missing    # object_list(obj, pid): the live objects an object-list setting holds, in order
move = _missing           # move(obj, vec, undo=False): obj moved by vec (a Vec, scene space), an undo step with undo
undo_change = _missing    # undo_change(obj): record obj for the undo step about to change it
animated = _missing       # animated(obj, pid): obj's setting pid has keys
sample_curve = _missing   # sample_curve(obj): [(x, y, z)] evenly along a linked curve's first run, in its own
                          # space (about 8 a point, 8 to 256 in all), or None for anything else
shown_points = _missing   # shown_points(obj): [(x, y, z)] of the mesh obj's generator built, in obj's parent's
                          # space, or None while it has none
NAMES = ("stored", "link", "custom_mesh", "custom_key", "mesh_object", "name", "spline_paths", "alive", "type_id",
         "relative", "spline_points", "set_value", "pull_library", "local_matrix", "box_size", "cutters", "wall_curves", "ident",
         "path_key", "children", "curve_points", "parent", "world_matrix",
         "objects", "object_list", "move", "undo_change", "animated", "sample_curve",
         "shown_points")


def register(**functions):
    """Fill in the host's functions (by the names above)."""
    g = globals()
    for key, fn in functions.items():
        if key not in NAMES:
            raise KeyError(key)
        g[key] = fn


def value(obj, pid):
    """obj's setting pid, or its default (aw_params) when obj predates that setting."""
    v = stored(obj, pid)
    if v is None:
        import aw_params
        return aw_params.default(type_id(obj), pid)
    return v

