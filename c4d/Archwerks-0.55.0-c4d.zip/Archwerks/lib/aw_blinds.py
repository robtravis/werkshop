"""Archwerks window shades: a Roman shade or a roller blind on a window's room side.

Roman (as in the FTF-812 game room): soft fabric hanging from a fabric-covered headrail. Open
lifts its hem, and the fabric it takes up folds into soft loops stacked at the bottom of the
shade, Fold Spacing of fabric to a loop, each loop bulging into the room; closed, it hangs
flat to the sill, a faint seam where each fold will form. Roller: fabric off a roll at the top,
the roll fatter as it takes the fabric up, a hem bar at the bottom.

Mount Inside hangs it in the opening, behind the wall's room face; Outside hangs it on the wall
over the opening and its casing (Frame In), wider and taller. Open: 0 closed (down), 1 open
(up). Built in the window's own space (x along the wall, y up, +z the room), cm, into a
MeshBuilder's "Blinds" group.
"""
import math

ROMAN, ROLLER = 1, 2
INSIDE, OUTSIDE = 0, 1
FABRIC_T = 0.35      # the fabric's thickness
HEAD_H, HEAD_D = 5.0, 4.5   # a Roman shade's headrail
FOLD_H = 6.0         # how tall a fold is, stacked
MAX_TAKE_UP = 0.88   # how much of the drop Open 1 takes up (the stack can't fold away to nothing)
CLEAR = 0.5          # off the opening's sides, inside
OUT_OVER = 2.5       # past the casing, outside
SEAM_BULGE = 0.35    # a closed Roman shade's faint folds
ROLL_R0 = 1.6        # the roll's tube
ROLL_GROW = 2.2      # how much fatter the roll is with all its fabric on it
HEM_H, HEM_D = 2.0, 1.2


def extent(x0, x1, y0, y1, face_in, s, bottom):
    """(x0, x1, top, closed bottom, z of the fabric's back) the shade hangs in."""
    tw = s.trim_w if s.trim else 0.0
    td = max(s.trim_d, 0.1) if s.trim else 0.0
    if int(s.blind_mount) == OUTSIDE:
        return (x0 - tw - OUT_OVER, x1 + tw + OUT_OVER, y1 + tw + 5.0, bottom - tw - OUT_OVER,
                face_in + td + 0.8)
    return x0 + CLEAR, x1 - CLEAR, y1 - CLEAR, bottom + 0.3, face_in - HEAD_D - 1.0  # its front 1 cm in


def _solid(mesh, profile, x0, x1, t, group="Blinds"):
    """Fabric: a profile [(y, z)] top to bottom (z its front, toward the room), t thick behind
    it, run from x0 to x1; a closed solid, UVs along the width and down the fabric."""
    if len(profile) < 2 or x1 - x0 < 1e-3:
        return
    mesh.new_part()
    first = len(mesh.polys)
    front = [(y, z) for y, z in profile]
    back = [(y, z - t) for y, z in profile]
    s = [0.0]
    for (ya, za), (yb, zb) in zip(profile, profile[1:]):
        s.append(s[-1] + math.hypot(yb - ya, zb - za))
    P = lambda x, y, z: mesh.pt(x, y, z, seam="blind")  # noqa: E731
    for i in range(len(profile) - 1):
        (fa, fb), (ba, bb) = (front[i], front[i + 1]), (back[i], back[i + 1])
        mesh.quad(P(x0, *fa), P(x1, *fa), P(x1, *fb), P(x0, *fb), group,
                  [(x0, s[i]), (x1, s[i]), (x1, s[i + 1]), (x0, s[i + 1])])
        mesh.quad(P(x0, *bb), P(x1, *bb), P(x1, *ba), P(x0, *ba), group,
                  [(x0, s[i + 1]), (x1, s[i + 1]), (x1, s[i]), (x0, s[i])])
        mesh.quad(P(x0, *fa), P(x0, *fb), P(x0, *bb), P(x0, *ba), group)
        mesh.quad(P(x1, *fb), P(x1, *fa), P(x1, *ba), P(x1, *bb), group)
    for (f_, b_) in ((front[0], back[0]), (front[-1], back[-1])):
        mesh.quad(P(x0, *f_), P(x0, *b_), P(x1, *b_), P(x1, *f_), group)
    mesh._face_out(first)


def roman_profile(top, bottom, z, spacing, opened):
    """The Roman shade's front, top to bottom: (profile, its hem's height)."""
    drop = max(top - bottom, 1.0)
    spacing = max(spacing, 4.0)
    o = min(max(opened, 0.0), 1.0)
    taken = o * drop * MAX_TAKE_UP
    folds = taken / spacing
    flat = drop - taken
    prof = [(top, z)]
    if folds < 1e-3:  # closed: flat, a faint seam every Spacing
        n = max(1, int(drop / spacing))
        for k in range(1, n + 1):
            y = top - min(k * spacing, drop)
            if k < n:
                prof += [(y + 1.5, z), (y, z + SEAM_BULGE), (y - 1.5, z)]
            else:
                prof.append((top - drop, z))
        return prof, top - drop
    y = top - flat
    prof.append((y, z))
    whole = int(folds)
    sizes = [1.0] * whole + ([folds - whole] if folds - whole > 1e-3 else [])
    for k, f in enumerate(sizes):  # each fold a soft loop into the room, the lowest the fullest
        h = FOLD_H * f
        reach = min(spacing * 0.34, 9.0)  # half its fabric, looped out into the room
        reach *= f * (0.8 + 0.2 * (k + 1) / len(sizes))  # the lowest the fullest
        steps = 6
        for j in range(1, steps + 1):
            t = j / steps
            prof.append((y - h * t, z + reach * math.sin(math.pi * t)))
        y -= h
    return prof, y


def build(mesh, x0, x1, y0, y1, face_in, s, bottom):
    """The window's shade, its opening x0..x1 by y0..y1 (bottom: where a closed one stops, a
    stool's top if it has one), the wall's room face at face_in, into mesh."""
    kind = int(s.blinds)
    if kind not in (ROMAN, ROLLER):
        return
    bx0, bx1, top, closed, zb = extent(x0, x1, y0, y1, face_in, s, bottom)
    if bx1 - bx0 < 5.0 or top - closed < 10.0:
        return
    if kind == ROMAN:
        mesh.new_part()
        mesh.box(bx0, bx1, top - HEAD_H, top, zb, zb + HEAD_D, "Blinds")  # the headrail, fabric over it
        z = zb + HEAD_D  # the fabric hangs off the headrail's front
        prof, hem = roman_profile(top - HEAD_H, closed, z, s.blind_fold, s.blind_open)
        _solid(mesh, prof, bx0, bx1, FABRIC_T)
        mesh.new_part()
        mesh.box(bx0 + 0.3, bx1 - 0.3, hem, hem + HEM_H, z - HEM_D - FABRIC_T, z - FABRIC_T, "Blinds")  # its weight bar
        return
    # roller: the roll, the fabric off its front, a hem bar
    o = min(max(s.blind_open, 0.0), 1.0)
    r = ROLL_R0 + ROLL_GROW * o
    cy, cz = top - ROLL_R0 - ROLL_GROW, zb + ROLL_R0 + ROLL_GROW
    mesh.new_part()
    first = len(mesh.polys)
    n = 16
    ring = [(cy + r * math.sin(2 * math.pi * k / n), cz + r * math.cos(2 * math.pi * k / n)) for k in range(n)]
    for k in range(n):
        (ya, za), (yb, zb_) = ring[k], ring[(k + 1) % n]
        a0, a1 = mesh.pt(bx0, ya, za, seam="roll"), mesh.pt(bx1, ya, za, seam="roll")
        b0, b1 = mesh.pt(bx0, yb, zb_, seam="roll"), mesh.pt(bx1, yb, zb_, seam="roll")
        mesh.quad(a0, a1, b1, b0, "Blinds")
        c0, c1 = mesh.pt(bx0, cy, cz, seam="roll"), mesh.pt(bx1, cy, cz, seam="roll")
        mesh.quad(a0, b0, c0, c0, "Blinds")
        mesh.quad(b1, a1, c1, c1, "Blinds")
    mesh._face_out(first)
    hem = closed + (cy - closed) * o * MAX_TAKE_UP
    z = cz + r  # off the roll's front
    _solid(mesh, [(cy, z), (hem, z)], bx0 + 0.6, bx1 - 0.6, FABRIC_T)
    mesh.new_part()
    mesh.box(bx0 + 0.3, bx1 - 0.3, hem - HEM_H, hem, z - HEM_D, z + 0.2, "Blinds")
