"""The lib modules archwerks.pyp loads and hot-reloads, in dependency order (a
module after everything it imports). A new module goes in this list; the running
plugin picks it up on the next `install_c4d.py --lib`, no restart needed."""

ORDER = ("aw_vec", "aw_mat", "aw_host", "aw_ids", "aw_mesh", "aw_params", "aw_desc", "aw_lib", "aw_c4d", "aw_groups", "aw_groups_c4d", "aw_commands", "aw_style", "aw_path", "aw_build", "aw_wall", "aw_wall_c4d", "aw_handles", "aw_shutters", "aw_blinds", "aw_window", "aw_door", "aw_cutter", "aw_cutter_c4d", "aw_fireplace", "aw_dims", "aw_pen", "aw_wedit",
         "aw_draw", "aw_edit", "aw_grab", "aw_openings", "aw_openings_c4d", "aw_plan", "aw_slab", "aw_slab_c4d", "aw_skeleton", "aw_roof", "aw_roof_c4d", "aw_roofdims", "aw_roofdims_c4d", "aw_stair", "aw_stair_c4d", "aw_railing", "aw_railing_c4d", "aw_beam", "aw_beam_c4d", "aw_pulls", "aw_pulls_c4d", "aw_cabinet", "aw_cabinet_c4d", "aw_counter", "aw_counter_c4d", "aw_floor", "aw_floor_c4d", "aw_molding", "aw_molding_c4d", "aw_panels", "aw_panels_c4d", "aw_placing", "aw_catalog", "aw_readout", "aw_link_c4d", "aw_drawtool_c4d", "aw_place", "aw_buttons_c4d", "aw_panel",
         "aw_matdefaults", "aw_materials", "aw_commands_c4d", "aw_plugins")
