"""Archwerks cabinet pulls: knobs and pulls for cabinet doors and drawers.

Every pull is built in aw_handles' frame: the origin where it meets the front
(the middle of a pull, between its screws), +Z standing out of the front, +X
along the pull's length, +Y across it. Size is a knob's diameter (or width), or
a pull's centre to centre; the rest is in proportion, kept low in polygons.

Types: None, Round Knob, Mushroom Knob, Square Knob, T Knob, Bar Pull (a round
bar on two posts), Square Bar, Wire Pull (thin, low), Cup Pull (a half shell,
open below), Edge Pull (a lip over the front's edge: on a drawer its top, on a
door its free side), Library (a pull from the pulls library file) and Custom (a
linked object).

The pulls library is a Cinema 4D file of pulls, one top-level object each,
modelled in the same frame (axis where it meets the front, sticking out along
+Z, its length along +X). The user's own is
~/Library/Application Support/Archwerks/pulls.c4d: "Add to pulls library" in the
panel copies the selected object into it; every cabinet's Library list shows
what is in it. Sizes in cm.
"""
import math
import os

NONE, ROUND_KNOB, MUSHROOM, SQUARE_KNOB, T_KNOB, BAR, SQUARE_BAR, WIRE, CUP, EDGE, LIBRARY, CUSTOM = range(12)
NAMES = ("None", "Round Knob", "Mushroom Knob", "Square Knob", "T Knob", "Bar Pull", "Square Bar", "Wire Pull",
         "Cup Pull", "Edge Pull", "Library", "Custom")
KNOBS = (ROUND_KNOB, MUSHROOM, SQUARE_KNOB, T_KNOB)
IN = 2.54
# standard sizes, cm: knob diameters, and pulls' centre to centre
STANDARD_SIZES = {ROUND_KNOB: 1.25 * IN, MUSHROOM: 1.25 * IN, SQUARE_KNOB: 1.0 * IN, T_KNOB: 1.5 * IN,
                  BAR: 12.8, SQUARE_BAR: 12.8, WIRE: 9.6, CUP: 3.0 * IN, EDGE: 6.0 * IN}
SEGMENTS = 12


def length(kind, size):
    """How long a pull is, end to end along its +X (a knob: its diameter)."""
    if kind in KNOBS:
        return size * (1.6 if kind == T_KNOB else 1.0)
    if kind in (BAR, SQUARE_BAR):
        return size + 2 * min(0.15 * size, 2.5)
    if kind == CUP:
        return size + 1.6
    return size


def reach(kind, size):
    """How far it stands out of the front, cm."""
    if kind in KNOBS:
        return 0.9 * size if kind != T_KNOB else 0.6 * size
    return {BAR: 3.5, SQUARE_BAR: 3.5, WIRE: 2.6, CUP: 2.2, EDGE: 1.6}.get(kind, 0.0)


def _extrude_x(mesh, to_world, poly, x0, x1, group):
    """A closed solid: polygon poly [(y, z)] (counter-clockwise) run along +X from x0 to x1."""
    import aw_slab
    mesh.new_part()
    first = len(mesh.polys)
    a = [mesh.pt(*to_world(x0, y, z)) for y, z in poly]
    b = [mesh.pt(*to_world(x1, y, z)) for y, z in poly]
    m = len(poly)
    for i, j, k in aw_slab.triangulate(poly):
        mesh.quad(a[k], a[j], a[i], a[i], group)
        mesh.quad(b[i], b[j], b[k], b[k], group)
    for i in range(m):
        j = (i + 1) % m
        mesh.quad(a[i], a[j], b[j], b[i], group)
    mesh._face_out(first)


def _box(mesh, to_world, x0, x1, y0, y1, z0, z1, group):
    import aw_handles
    import aw_host
    aw_handles._box(mesh, to_world, x0, x1, y0, y1, z0, z1, group)


def build(mesh, kind, size, to_world, group="Pulls", custom=None):
    """One pull into mesh in the frame to_world (aw_handles.place)."""
    import aw_handles
    import aw_host
    s = max(size, 0.5)
    if kind in (LIBRARY, CUSTOM):
        if custom:
            mesh.add_mesh(custom[0], custom[1], to_world, group)
        return
    if kind == ROUND_KNOB:
        r = s / 2
        prof = [(0, 0), (0.55 * r, 0), (0.55 * r, 0.08 * s), (0.32 * r, 0.2 * s), (0.3 * r, 0.42 * s),
                (0.75 * r, 0.55 * s), (r, 0.7 * s), (0.85 * r, 0.85 * s), (0.4 * r, 0.92 * s), (0, 0.93 * s)]
        mesh.lathe(prof, to_world, group, SEGMENTS)
    elif kind == MUSHROOM:
        r = s / 2
        prof = [(0, 0), (0.5 * r, 0), (0.5 * r, 0.06 * s), (0.28 * r, 0.18 * s), (0.28 * r, 0.5 * s),
                (r, 0.62 * s), (r, 0.72 * s), (0.7 * r, 0.86 * s), (0, 0.9 * s)]
        mesh.lathe(prof, to_world, group, SEGMENTS)
    elif kind == SQUARE_KNOB:
        h = 0.5 * s
        _box(mesh, to_world, -0.18 * s, 0.18 * s, -0.18 * s, 0.18 * s, 0.0, 0.55 * s, group)
        _box(mesh, to_world, -h, h, -h, h, 0.55 * s, 0.9 * s, group)
    elif kind == T_KNOB:
        mesh.lathe([(0, 0), (0.22 * s, 0), (0.15 * s, 0.1 * s), (0.15 * s, 0.45 * s), (0, 0.45 * s)], to_world,
                   group, SEGMENTS)
        _box(mesh, to_world, -0.8 * s, 0.8 * s, -0.2 * s, 0.2 * s, 0.4 * s, 0.6 * s, group)
    elif kind == BAR:
        post = [(0, 0), (0.75, 0), (0.75, 0.2), (0.45, 0.4), (0.45, 3.0), (0, 3.0)]
        for x in (-s / 2, s / 2):
            mesh.lathe(post, aw_handles._shift(to_world, x, 0.0), group, SEGMENTS)
        half = length(BAR, s) / 2
        bar = [(0, -half), (0.5, -half + 0.05), (0.6, -half + 0.4), (0.6, half - 0.4), (0.5, half - 0.05), (0, half)]
        mesh.lathe(bar, lambda a, b, h: to_world(h, a, b + 3.0), group, SEGMENTS)
    elif kind == SQUARE_BAR:
        for x in (-s / 2, s / 2):
            _box(mesh, to_world, x - 0.5, x + 0.5, -0.5, 0.5, 0.0, 2.9, group)
        half = length(SQUARE_BAR, s) / 2
        _box(mesh, to_world, -half, half, -0.6, 0.6, 2.9, 3.5, group)
    elif kind == WIRE:
        for x in (-s / 2, s / 2):
            _box(mesh, to_world, x - 0.3, x + 0.3, -0.3, 0.3, 0.0, 2.6, group)
        _box(mesh, to_world, -s / 2 - 0.3, s / 2 + 0.3, -0.3, 0.3, 2.0, 2.6, group)
    elif kind == CUP:  # a half shell open below, hung from a plate on the front
        r, t = 1.6, 0.25
        arc = [math.radians(135.0 * i / 6) for i in range(7)]  # from the plate, out and over, down to a lip
        outer = [(r * math.cos(a), 0.6 + r * math.sin(a)) for a in arc]
        inner = [(y * (r - t) / r, 0.6 + (z - 0.6) * (r - t) / r) for y, z in outer[::-1]]
        half = length(CUP, s) / 2
        _extrude_x(mesh, to_world, _ccw(outer + inner), -half, half, group)
        _box(mesh, to_world, -half, half, -0.2, r, 0.0, 0.6, group)  # the plate it hangs from
    elif kind == EDGE:
        # a lip over the edge: +Y points out over the edge; flat on the face, then up and over
        prof = [(-3.0, 0.0), (0.25, 0.0), (0.25, 1.6), (-0.15, 1.6), (-0.15, 0.3), (-3.0, 0.3)]
        _extrude_x(mesh, to_world, _ccw(prof), -s / 2, s / 2, group)


def _ccw(poly):
    a = sum(p[0] * q[1] - q[0] * p[1] for p, q in zip(poly, poly[1:] + poly[:1]))
    return poly if a > 0 else poly[::-1]


# The pulls library (the host keeps it: aw_host.pull_library) ----------------------

def library_names():
    """The Library list's entries, for the Attribute Manager."""
    import aw_host
    names = [n for n, _m in aw_host.pull_library()]
    return tuple(names) if names else ("(the pulls library is empty)",)
