"""Archwerks countertops and sinks.

A Countertop covers the cabinets in its Cabinets list (bases and vanities; uppers
and talls are passed over) as one piece, corners and all, following them as they
move or change; or, with none listed, the closed splines under it at Elevation (an
island, say). It reaches Front Overhang past the fronts, Back Overhang past the
backs (0 against a wall; more for an island's bar) and Side Overhang past an end
that's exposed (a cabinet with an end panel there). Thickness thick, on top of
the cabinets.

Backsplash: along every cabinet's back (against the wall), Backsplash Height tall
and Backsplash Thickness thick, round the corners. Waterfall: at every exposed end
the top turns down to the floor.

Wipe (0 to 100%, keyframe it) wipes the countertop on: only what a front has passed
is there, cut clean (the top, its edge, the backsplash and waterfall ends; a sink
once the front passes its middle). Wipe Direction Along the Run follows the run's
centre line from one end round every corner to the other (an L turns its corner);
Along X or Z sweeps straight across. Reverse starts from the other end.

Sinks are children of the countertop: move one where you want it. Mount:
- Undermount: a bowl under the top, the top's hole its outline.
- Drop-in: a bowl hanging from a rim Rim wide resting on the top.
- Vessel: a bowl standing on the top.
- Apron: a farmhouse sink, its front an apron face (the top is cut away in front
  of it; put it over a cabinet whose top zone is Empty, e.g. Farmhouse sink base).
- Cooktop: a glass panel set into the top.
Shape: Rectangle, Rounded (Radius), Oval, Round (Width across); Width along the
sink's X, Length along its Z (its front faces -Z, like a cabinet); Bowl Depth;
Wall. The countertop builds them, in its Sink and Cooktop materials. The sink base
under a sink follows its Mount: an apron fills an Empty top zone, any other sink
has a False Front there.

Plan points are (x, z); heights in cm.
"""
import math

import aw_host
from aw_mat import Mat
from aw_vec import Vec

import aw_roof as R

UNDERMOUNT, DROP_IN, VESSEL, APRON, COOKTOP = range(5)
MOUNT_NAMES = ("Undermount", "Drop-in", "Vessel", "Apron", "Cooktop")
RECTANGLE, ROUNDED, OVAL, ROUND = range(4)
SHAPE_NAMES = ("Rectangle", "Rounded", "Oval", "Round")
GROUPS = ("Top", "Bottom", "Edge", "Backsplash", "Sink", "Cooktop")
IN = 2.54
CURVE = 24          # points round a round or oval sink
FILLET = 4          # points round each rounded corner
FLANGE = 1.0        # cm an undermount bowl's lip reaches under the top past its hole
RIM_T = 0.4         # a drop-in's rim
GLASS_T = 0.6       # a cooktop's glass
COOKTOP_INSET = 2.0  # cm the hole under a cooktop stays inside its glass
APRON_CUT = 200.0   # cm the cut in front of an apron sink reaches (past any top)


# Outlines (pure) --------------------------------------------------------------------

def ccw(pts):
    return pts if R.area(pts) > 0 else pts[::-1]


def outline(shape, w, l, radius=0.0):
    """A sink's outline, centred on 0: [(x, z)] counter-clockwise."""
    if shape == ROUND:
        r = w / 2
        return [(r * math.cos(2 * math.pi * i / CURVE), r * math.sin(2 * math.pi * i / CURVE)) for i in range(CURVE)]
    if shape == OVAL:
        return [(w / 2 * math.cos(2 * math.pi * i / CURVE), l / 2 * math.sin(2 * math.pi * i / CURVE))
                for i in range(CURVE)]
    if shape == ROUNDED and radius > 1e-6:
        r = min(radius, w / 2 - 0.01, l / 2 - 0.01)
        pts = []
        for cx, cz, a0 in ((w / 2 - r, -l / 2 + r, -90), (w / 2 - r, l / 2 - r, 0), (-w / 2 + r, l / 2 - r, 90),
                           (-w / 2 + r, -l / 2 + r, 180)):
            for k in range(FILLET + 1):
                a = math.radians(a0 + 90.0 * k / FILLET)
                pts.append((cx + r * math.cos(a), cz + r * math.sin(a)))
        return pts
    return [(-w / 2, -l / 2), (w / 2, -l / 2), (w / 2, l / 2), (-w / 2, l / 2)]


def grow(pts, d):
    """pts (counter-clockwise) with every edge pushed out by d (in, for d < 0)."""
    return R.offset(pts, [d] * len(pts))


def cabinet_top(s, front, back, side_l, side_r):
    """[convex [(x, z)]] of what a cabinet (aw_cabinet settings s) holds up, in its own
    space, the overhangs added: a plain cabinet's box; a corner cabinet's L (two
    pieces) or its cut-off corner."""
    import aw_cabinet as C
    W, D = s["width"], s["depth"]
    zf, zb = -(D + front), back
    if s.get("corner", C.NO_CORNER) == C.NO_CORNER:
        return [[(-side_l, zb), (-side_l, zf), (W + side_r, zf), (W + side_r, zb)]]
    Rt = max(s.get("return", W), D + 2.0)
    right = s.get("corner_side") == C.CORNER_RIGHT

    def flip(poly):
        return [(W - x, z) for x, z in poly][::-1] if right else poly
    if s["corner"] == C.PIE_CUT:
        return [flip([(0.0, zb), (0.0, zf), (W, zf), (W, zb)]),
                flip([(0.0, zf), (0.0, -Rt), (D + front, -Rt), (D + front, zf)])]
    p0, p1 = (W, -D), (D, -Rt)  # the diagonal: pushed out by front
    L = math.dist(p0, p1)
    e = ((p0[0] - p1[0]) / L, (p0[1] - p1[1]) / L)
    n = (e[1], -e[0])
    q0, q1 = (p0[0] + n[0] * front, p0[1] + n[1] * front), (p1[0] + n[0] * front, p1[1] + n[1] * front)
    line = (q0, (q1[0] - q0[0], q1[1] - q0[1]))
    return [flip([(0.0, zb), (0.0, -Rt), _cross_z(line, -Rt), _cross_x(line, W), (W, zb)])]


def _cross_x(line, x):
    (px, pz), (dx, dz) = line
    return (x, pz + dz * (x - px) / dx) if abs(dx) > 1e-9 else (x, pz)


def _cross_z(line, z):
    (px, pz), (dx, dz) = line
    return (px + dx * (z - pz) / dz, z) if abs(dz) > 1e-9 else (px, z)


def union(polys, y):
    """Convex polygons (each counter-clockwise [(x, z)]) as non-overlapping convex
    pieces [(0, [(x, z, y)])]: each one less those before it."""
    pieces = []
    done = []
    for poly in polys:
        poly = ccw(poly)
        mine = [(0, [(x, z, y) for x, z in poly])]
        for prev in done:
            mine = R.subtract(mine, prev)
            if not mine:
                break
        pieces += mine
        done.append(poly)
    return pieces


def sink_hole(mount, shape, w, l, radius, rim):
    """The hole a sink takes out of the top, in the sink's own space (counter-clockwise),
    or None (a vessel)."""
    out = outline(shape, w, l, radius)
    if mount == VESSEL:
        return None
    if mount == DROP_IN:
        return grow(out, -max(rim, 0.5))
    if mount == COOKTOP:
        return grow(out, -COOKTOP_INSET)
    if mount == APRON:  # its outline, carried on out past the top's front
        xs = [p[0] for p in out]
        return [(min(xs), -l / 2 - APRON_CUT), (max(xs), -l / 2 - APRON_CUT), (max(xs), l / 2), (min(xs), l / 2)]
    return out


def merge_segments(segs, tol=0.5):
    """Back edges [(a, b, inward)] merged where they run on along one line."""
    out = []
    for a, b, inward in segs:
        d = (b[0] - a[0], b[1] - a[1])
        L = math.hypot(*d)
        if L < 1e-6:
            continue
        u = (d[0] / L, d[1] / L)
        for i, (c, e, inw, uu) in enumerate(out):
            same_dir = abs(uu[0] * u[1] - uu[1] * u[0]) < 1e-6
            on_line = abs((a[0] - c[0]) * uu[1] - (a[1] - c[1]) * uu[0]) < tol
            if same_dir and on_line:
                ts = [(p[0] - c[0]) * uu[0] + (p[1] - c[1]) * uu[1] for p in (a, b, c, e)]
                lo, hi = min(ts[2], ts[3]), max(ts[2], ts[3])
                a_t, b_t = min(ts[0], ts[1]), max(ts[0], ts[1])
                if a_t <= hi + tol and b_t >= lo - tol:
                    lo, hi = min(lo, a_t), max(hi, b_t)
                    out[i] = ((c[0] + uu[0] * lo, c[1] + uu[1] * lo), (c[0] + uu[0] * hi, c[1] + uu[1] * hi), inw, uu)
                    break
        else:
            out.append((a, b, inward, u))
    return [(a, b, inw) for a, b, inw, _u in out]


def splash_boxes(segs, thick):
    """A backsplash's plan rectangles [(x, z)] along merged back edges, thick in from
    them; where two meet in a corner the later one stops short of the first."""
    out = []
    for i, (a, b, inw) in enumerate(segs):
        for j, (c, e, inw2) in enumerate(segs[:i]):  # a corner with an earlier one: stop at its inner face
            for end in (0, 1):
                p = (a, b)[end]
                if min(math.dist(p, c), math.dist(p, e)) < thick + 0.5 or _on_seg(p, c, e):
                    d = (b[0] - a[0], b[1] - a[1])
                    L = math.hypot(*d)
                    u = (d[0] / L, d[1] / L)
                    if end == 0:
                        a = (a[0] + u[0] * thick, a[1] + u[1] * thick)
                    else:
                        b = (b[0] - u[0] * thick, b[1] - u[1] * thick)
        out.append(ccw([a, b, (b[0] + inw[0] * thick, b[1] + inw[1] * thick),
                        (a[0] + inw[0] * thick, a[1] + inw[1] * thick)]))
    return out


def _on_seg(p, a, b, tol=0.5):
    d = (b[0] - a[0], b[1] - a[1])
    L2 = d[0] ** 2 + d[1] ** 2
    if L2 < 1e-12:
        return False
    t = ((p[0] - a[0]) * d[0] + (p[1] - a[1]) * d[1]) / L2
    if t < -1e-6 or t > 1 + 1e-6:
        return False
    return abs((p[0] - a[0]) * d[1] - (p[1] - a[1]) * d[0]) / math.sqrt(L2) < tol


# Wiping on (pure) ----------------------------------------------------------------------

ALONG_RUN, ALONG_X, ALONG_Z = 0, 1, 2
JOIN = 60.0  # cm: run ends closer than this join up (a turn at a blind corner leaves a gap)


def _line_meet(p, d, q, e):
    """Where the lines p + t d and q + u e cross, or None if they run parallel."""
    det = d[0] * e[1] - d[1] * e[0]
    if abs(det) < 1e-9:
        return None
    t = ((q[0] - p[0]) * e[1] - (q[1] - p[1]) * e[0]) / det
    return (p[0] + d[0] * t, p[1] + d[1] * t)


def run_path(segs):
    """One polyline [(x, z)] through the centre lines segs [(a, b)] of a run's cabinets,
    end to end from a free end: where two meet at an angle, the corner is where their
    lines cross; where they run on, halfway between their ends."""
    segs = [(tuple(a), tuple(b)) for a, b in segs if math.dist(a, b) > 1e-6]
    if not segs:
        return []
    ends = [p for sg in segs for p in sg]

    def partner(p):
        return min((q for q in ends if q is not p), key=lambda q: math.dist(p, q), default=None)
    free = [p for p in ends if partner(p) is None or math.dist(p, partner(p)) > JOIN]
    start = free[0] if free else ends[0]
    first = next(sg for sg in segs if start in sg)
    a, b = (first if first[0] == start else (first[1], first[0]))
    path, left = [a, b], [sg for sg in segs if sg is not first]
    while left:
        tail = path[-1]
        best = min(left, key=lambda sg: min(math.dist(tail, sg[0]), math.dist(tail, sg[1])))
        if min(math.dist(tail, best[0]), math.dist(tail, best[1])) > JOIN:
            break
        c, e = best if math.dist(tail, best[0]) <= math.dist(tail, best[1]) else (best[1], best[0])
        left.remove(best)
        d1 = (path[-1][0] - path[-2][0], path[-1][1] - path[-2][1])
        d2 = (e[0] - c[0], e[1] - c[1])
        cross = abs(d1[0] * d2[1] - d1[1] * d2[0]) / max(math.hypot(*d1) * math.hypot(*d2), 1e-9)
        corner = _line_meet(path[-2], d1, c, d2) if cross > 0.05 else None
        path[-1] = corner if corner is not None else ((tail[0] + c[0]) / 2, (tail[1] + c[1]) / 2)
        path.append(e)
    clean = [path[0]]
    for p in path[1:]:
        if math.dist(p, clean[-1]) > 1e-6:
            clean.append(p)
    out = [clean[0]]  # points where it runs straight on (between two cabinets) aren't turns
    for i in range(1, len(clean) - 1):
        a, b, c = out[-1], clean[i], clean[i + 1]
        cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
        if abs(cross) > 1e-6 * max(1.0, math.dist(a, b) * math.dist(b, c)):
            out.append(b)
    return out + clean[-1:] if len(clean) > 1 else clean


def _clip_half(poly, origin, normal):
    """The part of convex poly [(x, z, y)] where (p - origin) . normal <= 0."""
    def f(p):
        return (p[0] - origin[0]) * normal[0] + (p[1] - origin[1]) * normal[1]
    out = []
    n = len(poly)
    for i in range(n):
        p, q = poly[i], poly[(i + 1) % n]
        fp, fq = f(p), f(q)
        if fp <= 1e-9:
            out.append(p)
        if (fp <= 1e-9) != (fq <= 1e-9):
            t = fp / (fp - fq)
            out.append(tuple(p[k] + (q[k] - p[k]) * t for k in range(len(p))))
    clean = []
    for p in out:
        if not clean or math.dist(p[:2], clean[-1][:2]) > 1e-7:
            clean.append(p)
    if len(clean) > 1 and math.dist(clean[0][:2], clean[-1][:2]) <= 1e-7:
        clean.pop()
    return clean if len(clean) >= 3 and abs(R.area(clean)) > 1e-6 else []


def _unit(v):
    L = math.hypot(*v)
    return (v[0] / L, v[1] / L) if L > 1e-12 else (1.0, 0.0)


class Wipe:
    """A front travelling along path [(x, z)] (amount 0: before its start; 1: past its
    end), the countertop split between the path's legs at the bisector of every turn.
    from_pts: every point to be wiped, so the front starts and ends clear of them."""

    def __init__(self, path, amount, from_pts=()):
        self.path = path
        n = len(path) - 1
        self.dirs = [_unit((path[i + 1][0] - path[i][0], path[i + 1][1] - path[i][1])) for i in range(n)]
        self.lens = [math.dist(path[i], path[i + 1]) for i in range(n)]
        # how far points reach before the first leg starts and past the last one ends
        before = max([0.0] + [-((p[0] - path[0][0]) * self.dirs[0][0] + (p[1] - path[0][1]) * self.dirs[0][1])
                              for p in from_pts if self.leg_of(p) == 0])
        after = max([0.0] + [(p[0] - path[-1][0]) * self.dirs[-1][0] + (p[1] - path[-1][1]) * self.dirs[-1][1]
                             for p in from_pts if self.leg_of(p) == n - 1])
        total = before + sum(self.lens) + after
        s = -before + min(max(amount, 0.0), 1.0) * total  # how far along the path the front is
        self.leg, self.at = n - 1, s - sum(self.lens[:-1])
        acc = 0.0
        for i, L in enumerate(self.lens):
            if s <= acc + L or i == n - 1:
                self.leg, self.at = i, s - acc
                break
            acc += L

    def _turn(self, i):
        """The bisector at turn i (between leg i - 1 and leg i): (point, the way leg i lies)."""
        u = _unit((self.dirs[i - 1][0] + self.dirs[i][0], self.dirs[i - 1][1] + self.dirs[i][1]))
        return self.path[i], u

    def leg_of(self, p):
        for i in range(len(self.path) - 2, 0, -1):
            v, u = self._turn(i)
            if (p[0] - v[0]) * u[0] + (p[1] - v[1]) * u[1] > 0:
                return i
        return 0

    def clip(self, poly):
        """[convex polys] of what of poly [(x, z, ...)] the front has passed."""
        out = []
        turns = len(self.path) - 2
        for j in range(self.leg + 1):
            part = poly
            for i in range(1, turns + 1):  # leg j's region: past every turn before it, short of every one after
                if not part:
                    break
                v, u = self._turn(i)
                part = _clip_half(part, v, (-u[0], -u[1]) if i <= j else u)
            if part and j == self.leg:  # the leg the front is on: behind the front
                d = self.dirs[j]
                front = (self.path[j][0] + d[0] * self.at, self.path[j][1] + d[1] * self.at)
                part = _clip_half(part, front, d)
            if part:
                out.append(part)
        return out

    def passed(self, p):
        """True once the front has passed point p."""
        return bool(self.clip([(p[0] - 0.01, p[1] - 0.01, 0), (p[0] + 0.01, p[1] - 0.01, 0), (p[0], p[1] + 0.01, 0)]))


def straight_path(points, axis):
    """A one-leg path across points along the countertop's X (axis ALONG_X) or Z."""
    if not points:
        return []
    k = 0 if axis == ALONG_X else 1
    lo, hi = min(p[k] for p in points), max(p[k] for p in points)
    other = sum(p[1 - k] for p in points) / len(points)
    return [(lo, other), (hi, other)] if k == 0 else [(other, lo), (other, hi)]


# Building ----------------------------------------------------------------------------

def _ring_solid(mesh, outer, inner, y_top, depth, wall, group, closed_bottom=True):
    """A bowl: outer and inner outlines (same number of points, counter-clockwise) at
    y_top, its outside down to y_top - depth, its inside to y_top - depth + wall, a rim
    across the top between them: one closed solid."""
    import aw_slab
    mesh.new_part()
    first = len(mesh.polys)
    yo, yi = y_top - depth, y_top - depth + wall
    ot = [mesh.pt(x, y_top, z) for x, z in outer]
    it = [mesh.pt(x, y_top, z) for x, z in inner]
    ob = [mesh.pt(x, yo, z) for x, z in outer]
    ib = [mesh.pt(x, yi, z) for x, z in inner]
    m = len(outer)
    for i in range(m):
        j = (i + 1) % m
        mesh.quad(ot[i], ot[j], it[j], it[i], group)    # the rim
        mesh.quad(ot[j], ot[i], ob[i], ob[j], group)    # outside
        mesh.quad(it[i], it[j], ib[j], ib[i], group)    # inside
    for i, j, k in aw_slab.triangulate(outer):  # wound against the walls they meet, so the bowl is closed
        mesh.quad(ob[k], ob[j], ob[i], ob[i], group)
    for i, j, k in aw_slab.triangulate(inner):
        mesh.quad(ib[i], ib[j], ib[k], ib[k], group)
    mesh._face_out(first)


def _annulus(mesh, outer, inner, y0, y1, group):
    """A flat ring between outer and inner outlines (same number of points), y0 to y1:
    a drop-in's rim, open in the middle."""
    mesh.new_part()
    first = len(mesh.polys)
    ob, ot = [mesh.pt(x, y0, z) for x, z in outer], [mesh.pt(x, y1, z) for x, z in outer]
    ib, it = [mesh.pt(x, y0, z) for x, z in inner], [mesh.pt(x, y1, z) for x, z in inner]
    m = len(outer)
    for i in range(m):
        j = (i + 1) % m
        mesh.quad(ot[i], ot[j], it[j], it[i], group)
        mesh.quad(ib[i], ib[j], ob[j], ob[i], group)
        mesh.quad(ot[j], ot[i], ob[i], ob[j], group)
        mesh.quad(it[i], it[j], ib[j], ib[i], group)
    mesh._face_out(first)


def _plate(mesh, poly, y0, y1, group):
    import aw_stair
    aw_stair._prism(mesh, [(x, z, 0.0) for x, z in ccw(poly)], lambda _s: y1, lambda _s: y0, group, group, group,
                    group)


def build_sink(mesh, sk, place, top_y, thick):
    """A sink's geometry, placed by place(x, z) -> (x, z) (the sink's space into the
    countertop's): its top at top_y, the countertop thick."""
    out = [place(x, z) for x, z in outline(sk["shape"], sk["width"], sk["length"], sk["radius"])]
    out = ccw(out)
    wall, depth = max(sk["wall"], 0.2), max(sk["depth"], 1.0)
    mount = sk["mount"]
    if mount == COOKTOP:
        _plate(mesh, out, top_y, top_y + GLASS_T, "Cooktop")
        return
    if mount == VESSEL:
        _ring_solid(mesh, out, ccw(grow(out, -wall)), top_y + depth, depth, wall, "Sink")
        return
    if mount == APRON:  # flush with the top, its front the apron
        _ring_solid(mesh, out, ccw(grow(out, -wall)), top_y, depth, wall, "Sink")
        return
    bottom = top_y - thick
    if mount == DROP_IN:
        hole = ccw(grow(out, -max(sk["rim"], 0.5)))
        _annulus(mesh, out, hole, top_y, top_y + RIM_T, "Sink")  # the rim, resting on the top
        _ring_solid(mesh, ccw(grow(hole, wall)), hole, top_y, depth + thick, wall, "Sink")
        return
    _ring_solid(mesh, ccw(grow(out, wall + FLANGE)), out, bottom - 0.05, depth, wall, "Sink")  # undermount


# Settings and sources (through the host, aw_host) ---------------------------------------------

def settings(op):
    import aw_ids as I
    v = lambda pid: aw_host.value(op, pid)  # noqa: E731
    return {"thick": max(float(v(I.AW_CT_THICKNESS)), 0.5),
            "front": float(v(I.AW_CT_FRONT)), "back": float(v(I.AW_CT_BACK)), "side": float(v(I.AW_CT_SIDE)),
            "elevation": float(v(I.AW_CT_ELEVATION)), "splash": bool(v(I.AW_CT_SPLASH)),
            "splash_h": max(float(v(I.AW_CT_SPLASH_H)), 0.5), "splash_t": max(float(v(I.AW_CT_SPLASH_T)), 0.3),
            "waterfall": bool(v(I.AW_CT_WATERFALL)), "wipe": min(max(float(v(I.AW_CT_WIPE)), 0.0), 1.0),
            "wipe_dir": int(v(I.AW_CT_WIPE_DIR)), "wipe_reverse": bool(v(I.AW_CT_WIPE_REVERSE))}


def sink_settings(op):
    import aw_ids as I
    v = lambda pid: aw_host.value(op, pid)  # noqa: E731
    return {"mount": int(v(I.AW_SINK_MOUNT)), "shape": int(v(I.AW_SINK_SHAPE)),
            "width": max(float(v(I.AW_SINK_WIDTH)), 2.0), "length": max(float(v(I.AW_SINK_LENGTH)), 2.0),
            "radius": max(float(v(I.AW_SINK_RADIUS)), 0.0), "depth": max(float(v(I.AW_SINK_DEPTH)), 1.0),
            "wall": max(float(v(I.AW_SINK_WALL)), 0.2), "rim": max(float(v(I.AW_SINK_RIM)), 0.5)}


def cabinets(op, s=None):
    """The countertop's cabinets that carry a top (bases and vanities)."""
    import aw_cabinet as C
    import aw_ids as I
    return [o for o in aw_host.object_list(op, I.AW_CT_CABINETS)
            if aw_host.type_id(o) == I.ID_AW_CABINET and int(C.settings(o)["type"]) in (C.BASE, C.VANITY)]


def layout(op, s=None):
    """(top polygons, under-top height, back edges, exposed ends) in op's space:
    from its cabinets, else from its own closed splines at Elevation."""
    import aw_cabinet as C
    import aw_ids as I
    s = s or settings(op)
    inv = ~aw_host.world_matrix(op)
    polys, backs, ends, tops, centres = [], [], [], [], []
    for cab in cabinets(op, s):
        cs = C.settings(cab)
        m = inv * aw_host.world_matrix(cab)
        corner = cs.get("corner", C.NO_CORNER) != C.NO_CORNER
        side_l = s["side"] if cs.get("end_l") and not corner else 0.0
        side_r = s["side"] if cs.get("end_r") and not corner else 0.0

        def to(x, z, m=m):
            p = m * Vec(x, 0, z)
            return (p.x, p.z)
        for poly in cabinet_top(cs, s["front"], s["back"], side_l, side_r):
            polys.append(ccw([to(x, z) for x, z in poly]))
        mid = -cs["depth"] / 2  # the run's centre line through this cabinet (two legs for a corner one)
        if corner and cs["corner"] == C.PIE_CUT:
            Rt = max(cs.get("return", cs["width"]), cs["depth"] + 2.0)
            right = cs.get("corner_side") == C.CORNER_RIGHT
            free_x, leg_x = (0.0, cs["width"] + mid) if right else (cs["width"], -mid)
            centres += [(to(free_x, mid), to(leg_x, mid)), (to(leg_x, mid), to(leg_x, -Rt))]
        else:
            centres.append((to(0.0, mid), to(cs["width"], mid)))
        tops.append(m.off.y + cs["height"])
        inward = m.turn(Vec(0, 0, -1))
        if s["back"] <= 1e-6:  # against the wall: a backsplash's line
            backs.append((to(-side_l, 0.0), to(cs["width"] + side_r, 0.0), (inward.x, inward.z)))
            if corner:  # its other back, on the other wall
                Rt = max(cs.get("return", cs["width"]), cs["depth"] + 2.0)
                xw = cs["width"] if cs.get("corner_side") == C.CORNER_RIGHT else 0.0
                into = m.turn(Vec(-1.0 if xw else 1.0, 0, 0))
                backs.append((to(xw, 0.0), to(xw, -Rt), (into.x, into.z)))
        for flag, x in (("end_l", -side_l), ("end_r", cs["width"] + side_r)):
            if cs.get(flag) and not corner:
                out_dir = m.turn(Vec(-1.0 if flag == "end_l" else 1.0, 0, 0))
                ends.append((to(x, s["back"]), to(x, -(cs["depth"] + s["front"])), (out_dir.x, out_dir.z),
                             m.off.y))
    if polys:
        return polys, max(tops), backs, ends, centres
    closed, _open = aw_host.spline_paths(op, skip=(I.ID_AW_SINK,))
    for pts in closed:
        if len(pts) >= 3 and abs(R.area(pts)) > 1e-3:
            import aw_slab
            pts = ccw(pts)
            polys += [[pts[i], pts[j], pts[k]] for i, j, k in aw_slab.triangulate(pts)]
    return polys, s["elevation"] - s["thick"], [], [], []


def sinks(op):
    """[(sink settings, place)] of the sinks under op: place maps the sink's (x, z) into
    op's space."""
    import aw_ids as I
    out = []
    for child in aw_host.children(op):
        if aw_host.type_id(child) != I.ID_AW_SINK:
            continue
        m = aw_host.local_matrix(child)

        def place(x, z, m=m):
            p = m * Vec(x, 0, z)
            return (p.x, p.z)
        out.append((sink_settings(child), place))
    return out


def build(op):
    from aw_mesh import MeshBuilder
    s = settings(op)
    polys, y0, backs, ends, centres = layout(op, s)
    if not polys or s["wipe"] <= 1e-6:
        return None
    pieces = union(polys, y0)
    sk = sinks(op)
    for ss, place in sk:  # the holes
        hole = sink_hole(ss["mount"], ss["shape"], ss["width"], ss["length"], ss["radius"], ss["rim"])
        if hole:
            pieces = R.subtract(pieces, ccw([place(x, z) for x, z in hole]))
    if not pieces:
        return None
    t = s["thick"]
    splashes = splash_boxes(merge_segments(backs), s["splash_t"]) if s["splash"] and backs else []
    falls = [[a, b, (b[0] - out[0] * t, b[1] - out[1] * t), (a[0] - out[0] * t, a[1] - out[1] * t)]
             for a, b, out, _floor in ends] if s["waterfall"] else []
    floors = [floor for _a, _b, _o, floor in ends]
    wipe = None
    if s["wipe"] < 1.0 - 1e-6:  # wiping on: only what the front has passed
        pts = [p[:2] for _e, poly in pieces for p in poly] + [p for b in splashes + falls for p in b]
        path = run_path(centres) if s["wipe_dir"] == ALONG_RUN and centres else \
            straight_path(pts, ALONG_Z if s["wipe_dir"] == ALONG_Z else ALONG_X)
        if s["wipe_reverse"]:
            path = path[::-1]
        if len(path) >= 2:
            wipe = Wipe(path, s["wipe"], pts)
            pieces = [(e, part) for e, poly in pieces for part in wipe.clip(poly)]
            splashes = [[q[:2] for q in part] for b in splashes for part in wipe.clip([(x, z, 0.0) for x, z in b])]
            falls = [([q[:2] for q in part], floor) for b, floor in zip(falls, floors)
                     for part in wipe.clip([(x, z, 0.0) for x, z in b])]
            if not pieces:
                return None
    if wipe is None:
        falls = list(zip(falls, floors))
    mesh = MeshBuilder(GROUPS)
    R._solid(mesh, pieces, t, Mat(), ("Top", "Bottom", "Edge"))
    top = y0 + t
    for box in splashes:
        _plate(mesh, box, top, top + s["splash_h"], "Backsplash")
    for box, floor in falls:  # the top turned down to the floor, flush with its end
        _plate(mesh, box, floor, y0, "Edge")
    for ss, place in sk:
        if wipe is None or wipe.passed(place(0.0, 0.0)):  # a sink comes in once the front passes its middle
            build_sink(mesh, ss, place, top, t)
    return mesh.build(aw_host.name(op))


# The cabinet under a sink -------------------------------------------------------------

FALSE_FRONT_H = 6 * IN  # a sink base's false front, when it goes back to one


def base_under(sink):
    """The cabinet (in the sink's countertop's list) whose top the sink's middle is over,
    or None."""
    import aw_cabinet as C
    import aw_ids as I
    ct = aw_host.parent(sink)
    if ct is None or aw_host.type_id(ct) != I.ID_AW_COUNTERTOP:
        return None
    at = aw_host.world_matrix(sink).off
    for cab in cabinets(ct):
        cs = C.settings(cab)
        p = ~aw_host.world_matrix(cab) * at
        if -1e-6 <= p.x <= cs["width"] + 1e-6 and -cs["depth"] - 1e-6 <= p.z <= 1e-6:
            return cab
    return None


def match_base(sink, undo=True):
    """The sink base under a sink follows its mount: an Apron sink's apron fills an Empty
    top zone (as tall as its bowl is deep); any other sink has a False Front there. Only
    a cabinet whose top zone is already one or the other (a sink base) is changed."""
    import aw_cabinet as C
    import aw_ids as I
    cab = base_under(sink)
    if cab is None:
        return None
    n = max(1, min(int(aw_host.value(cab, I.AW_CAB_ZONES)), C.MAX_ZONES))
    top = n - 1
    kind = int(aw_host.value(cab, I.cab_zone(top, 0)))
    if kind not in (C.FALSE_FRONT, C.EMPTY, C.SINK):
        return None
    ss = sink_settings(sink)
    want = C.EMPTY if ss["mount"] == APRON else (C.SINK if kind == C.SINK else C.FALSE_FRONT)
    height = ss["depth"] if want == C.EMPTY else (FALSE_FRONT_H if kind == C.EMPTY else
                                                    float(aw_host.value(cab, I.cab_zone(top, 1))))
    if kind == want and abs(float(aw_host.value(cab, I.cab_zone(top, 1))) - height) < 1e-6:
        return cab
    if undo:
        aw_host.undo_change(cab)
    aw_host.set_value(cab, I.cab_zone(top, 0), want)
    aw_host.set_value(cab, I.cab_zone(top, 1), height)
    return cab


# A Sink zone's sink: the countertop over a cabinet whose top zone is Sink gets one ---------

SINK_MARGIN = 6 * IN  # a sink's bowl stays this much narrower than its cabinet


def top_kind(cab):
    """The kind of cab's top zone (aw_cabinet ZONE_NAMES)."""
    import aw_cabinet as C
    import aw_ids as I
    n = max(1, min(int(aw_host.value(cab, I.AW_CAB_ZONES)), C.MAX_ZONES))
    return int(aw_host.value(cab, I.cab_zone(n - 1, 0)))


def wants_sink(cab):
    """Whether cab's top zone is Sink (and it isn't a corner cabinet, which has no middle)."""
    import aw_cabinet as C
    return top_kind(cab) == C.SINK and int(C.settings(cab).get("corner", 0)) == 0


def sink_for(cab):
    """The sink a Sink zone gets, sized to its cabinet: a vanity's the Vanity rectangle (18
    x 13 in), a base's the Undermount (30 x 18 in), each no wider than the cabinet less
    SINK_MARGIN; under 21 in wide, the Bar sink. A preset (SINK_PRESETS' shape)."""
    import aw_cabinet as C
    cs = C.settings(cab)
    name = "Vanity rectangle" if int(cs["type"]) == C.VANITY else (
        "Bar sink" if cs["width"] < 21 * IN else "Undermount")
    p = next(q for q in SINK_PRESETS if q["label"] == name)
    v = dict(p["values"])
    v["width"] = max(min(v["width"], cs["width"] - SINK_MARGIN), 6 * IN)
    return {"label": p["label"], "values": v}


def sinks_over(ct, cab):
    """The sinks under countertop ct whose middle is over cab's top."""
    import aw_ids as I
    return [k for k in aw_host.children(ct) if aw_host.type_id(k) == I.ID_AW_SINK and base_under(k) == cab]


def auto_sinks(ct, is_auto):
    """What ct's Sink zones call for: ([cabinet that needs a sink], [auto sink to remove]).
    A Sink cabinet with no sink over it needs one; a sink Archwerks added (is_auto(sink))
    over a cabinet that is no longer a Sink zone goes. A sink you added is never touched."""
    need, drop = [], []
    for cab in cabinets(ct):
        over = sinks_over(ct, cab)
        if wants_sink(cab):
            if not over:
                need.append(cab)
        else:
            drop += [k for k in over if is_auto(k)]
    return need, drop


# A countertop's Sinks tab: its settings are its sinks' (each sink setting's id + I.CT_SINK) --

def ct_sink_pids():
    """{countertop setting id: sink setting id} of the Sinks tab."""
    import aw_ids as I
    return {pid + I.CT_SINK: pid for pid in (I.AW_SINK_MOUNT, I.AW_SINK_SHAPE, I.AW_SINK_WIDTH, I.AW_SINK_LENGTH,
                                             I.AW_SINK_RADIUS, I.AW_SINK_DEPTH, I.AW_SINK_WALL, I.AW_SINK_RIM)}


def sinks_of(ct):
    import aw_ids as I
    return [k for k in aw_host.children(ct) if aw_host.type_id(k) == I.ID_AW_SINK]


def tab_to_sinks(ct, ct_pid):
    """The Sinks tab's setting ct_pid changed: every sink under ct takes it. The sinks
    changed (each keeps its own place over its cabinet)."""
    pid = ct_sink_pids()[ct_pid]
    v = aw_host.value(ct, ct_pid)
    out = []
    for k in sinks_of(ct):
        if aw_host.value(k, pid) != v:
            aw_host.set_value(k, pid, v)
            out.append(k)
    return out


def sink_to_tab(sink):
    """A sink's settings into its countertop's Sinks tab, so the tab shows what its sinks
    are. The countertop, or None (a sink not under one)."""
    import aw_ids as I
    ct = aw_host.parent(sink)
    if ct is None or aw_host.type_id(ct) != I.ID_AW_COUNTERTOP:
        return None
    for ct_pid, pid in ct_sink_pids().items():
        v = aw_host.value(sink, pid)
        if aw_host.value(ct, ct_pid) != v:
            aw_host.set_value(ct, ct_pid, v)
    return ct


# Presets and the panel -----------------------------------------------------------------

def _sink(label, mount, shape, w, l, depth, radius=1.5 * IN, rim=1.0 * IN):
    return {"label": label, "values": {"mount": mount, "shape": shape, "width": w, "length": l, "depth": depth,
                                       "radius": radius, "rim": rim}}


SINK_PRESETS = (
    _sink("Undermount", UNDERMOUNT, ROUNDED, 30 * IN, 18 * IN, 9 * IN, radius=1.0 * IN),
    _sink("Farmhouse", APRON, ROUNDED, 33 * IN, 20 * IN, 10 * IN, radius=0.5 * IN),
    _sink("Drop-in", DROP_IN, ROUNDED, 25 * IN, 22 * IN, 8 * IN, radius=2.0 * IN),
    _sink("Bar sink", UNDERMOUNT, ROUNDED, 15 * IN, 15 * IN, 7 * IN, radius=1.0 * IN),
    _sink("Vanity oval", UNDERMOUNT, OVAL, 17 * IN, 14 * IN, 6 * IN),
    _sink("Vanity rectangle", UNDERMOUNT, ROUNDED, 18 * IN, 13 * IN, 5.5 * IN, radius=0.75 * IN),  # a 20 x 15 in
    # rectangular undermount's bowl (Kohler Caxton: 17 5/8 x 13 1/8, 5 5/16 deep)
    _sink("Vessel round", VESSEL, ROUND, 16 * IN, 16 * IN, 5.5 * IN),
    _sink("Vessel oval", VESSEL, OVAL, 20 * IN, 14 * IN, 5.5 * IN),
    _sink("Cooktop", COOKTOP, RECTANGLE, 30 * IN, 21 * IN, 3 * IN),
)
SINK_FIELDS = (("mount", "MOUNT"), ("shape", "SHAPE"), ("width", "WIDTH"), ("length", "LENGTH"), ("depth", "DEPTH"),
               ("radius", "RADIUS"), ("rim", "RIM"))
