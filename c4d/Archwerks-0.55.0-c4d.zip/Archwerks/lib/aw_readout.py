"""The readout line under an Archwerks object's name: what its settings add up to, in
words, the -werks house idiom ("a derived readout line stating what the settings mean").
The same line in every host: the Blender Sidebar shows it above the tabs, Cinema 4D's
Attribute Manager at the top of the object's tab.

readout(obj, length) -> str, length(cm) -> the host's own length text (its units). An
object it can't describe, or a setting it can't read, gives "".
"""
import math

import aw_host
import aw_ids as I

DOT = " · "


def _v(obj, pid):
    return aw_host.value(obj, pid)


def _wall(obj, length):
    import aw_wall
    wp = aw_wall.wall_path(obj)
    if wp is None:
        return "no path yet: draw one, or put a spline under it"
    plan, w0, w1, height, _s = wp
    runs = len(plan.runs)
    total = sum(seg["length"] for seg in plan.segments)
    openings = sum(1 for c in aw_host.cutters(obj) if I.is_opening(c))
    parts = ["%d run%s" % (runs, "" if runs == 1 else "s"), length(total), "%s tall" % length(height),
             "%s thick" % length(w1 - w0)]
    if openings:
        parts.append("%d opening%s" % (openings, "" if openings == 1 else "s"))
    return DOT.join(parts)


def _opening(obj, length):
    w, h, sill = _v(obj, I.AW_OPENING_WIDTH), _v(obj, I.AW_OPENING_HEIGHT), _v(obj, I.AW_OPENING_SILL)
    parts = ["%s × %s" % (length(w), length(h))]
    if sill > 1e-6:
        parts.append("sill %s" % length(sill))
    if aw_host.type_id(aw_host.parent(obj)) != I.ID_AW_WALL:
        parts.append("not in a wall")
    return DOT.join(parts)


def _cabinet(obj, length):
    import aw_cabinet
    kind = int(_v(obj, I.AW_CAB_TYPE) or 0)
    name = aw_cabinet.TYPE_NAMES[kind] if 0 <= kind < len(aw_cabinet.TYPE_NAMES) else "Cabinet"
    zones = int(_v(obj, I.AW_CAB_ZONES) or 1)
    return DOT.join(["%s wide %s" % (length(_v(obj, I.AW_CAB_WIDTH)), name.lower()),
                     "%d zone%s" % (zones, "" if zones == 1 else "s")])


def _stair(obj, length):
    import aw_stair
    s = aw_stair.settings(obj)
    p = aw_stair.plan(s, aw_stair.spline_path(obj) if s["shape"] == aw_stair.SPLINE else None)
    if p is None:
        return "no path yet"
    n, rise = aw_stair.risers(s["height"], s["steps"], s["max_riser"])
    return DOT.join(["%d risers" % n, "%s each" % length(rise), "%s total" % length(s["height"])])


def _roof(obj, _length):
    return "%s° pitch" % ("%.1f" % math.degrees(_v(obj, I.AW_ROOF_PITCH))).rstrip("0").rstrip(".")


def _thick(pid):
    def describe(obj, length):
        return "%s thick" % length(_v(obj, pid))
    return describe


def _railing(obj, length):
    return "%s tall" % length(_v(obj, I.AW_RAIL_HEIGHT))


def _beam(obj, length):
    n = int(_v(obj, I.AW_BEAM_COUNT) or 1)
    return DOT.join(["%d beam%s" % (n, "" if n == 1 else "s"), "%s long" % length(_v(obj, I.AW_BEAM_LENGTH))])


def _molding(obj, length):
    return "%s tall" % length(_v(obj, I.AW_MOLDING_HEIGHT))


DESCRIBE = {I.ID_AW_WALL: _wall, I.ID_AW_OPENING: _opening, I.ID_AW_DOOR: _opening, I.ID_AW_CUTTER: _opening,
            I.ID_AW_FIREPLACE: _opening, I.ID_AW_CABINET: _cabinet, I.ID_AW_STAIR: _stair, I.ID_AW_ROOF: _roof,
            I.ID_AW_FLOOR: _thick(I.AW_FLOOR_THICKNESS), I.ID_AW_CEILING: _thick(I.AW_FLOOR_THICKNESS),
            I.ID_AW_SLAB: _thick(I.AW_SLAB_THICKNESS), I.ID_AW_COUNTERTOP: _thick(I.AW_CT_THICKNESS),
            I.ID_AW_RAILING: _railing, I.ID_AW_BEAM: _beam, I.ID_AW_MOLDING: _molding}


def readout(obj, length):
    """The object's readout line, or "" (an object it doesn't describe, or can't read)."""
    describe = DESCRIBE.get(aw_host.type_id(obj))
    if describe is None:
        return ""
    try:
        return describe(obj, length)
    except Exception:  # a readout must never break the panel drawing it
        return ""
