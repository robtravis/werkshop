"""aw_stair for Cinema 4D: the parts of core/aw_stair.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_groups_c4d
import aw_stair  # noqa: F401
from aw_stair import *  # noqa: F401,F403


def change_key(op):
    import c4d
    kids = tuple((k.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX | c4d.DIRTYFLAGS_CACHE), k.GetDeformMode())
                 for k in op.GetChildren() if k.GetInfo() & c4d.OBJECT_ISSPLINE)
    return (op.GetName(), op.GetDirty(c4d.DIRTYFLAGS_DATA), kids)


# Panel button -------------------------------------------------------------------

def add_for_selection(doc):
    """Panel button Stair: a Spline stair along each selected spline (moved under it,
    laid flat), else a straight stair at the origin. One undo step."""
    import c4d
    import aw_floor
    import aw_floor_c4d
    import aw_ids as I
    import aw_materials
    import aw_panel
    import aw_slab
    import aw_slab_c4d
    splines = aw_panel.selected_splines(doc)
    made = []
    doc.StartUndo()
    for sp in splines or [None]:
        st = c4d.BaseObject(I.ID_AW_STAIR)
        st.SetName(aw_slab_c4d.next_name(doc, "Stair"))
        if sp is None:
            doc.InsertObject(st)
        else:
            doc.InsertObject(st, sp.GetUp(), sp)
            st[I.AW_STAIR_SHAPE] = SPLINE
            mg = sp.GetMg()
            aw_floor_c4d._lay_flat(doc, sp)
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, sp)
            sp.Remove()
            sp.InsertUnderLast(st)
            sp.SetMg(mg)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, st)
        aw_materials.apply_defaults(doc, st)
        aw_groups_c4d.file(doc, st)  # into its group: null and layer (aw_groups_c4d)
        made.append(st)
    doc.EndUndo()
    doc.SetActiveObject(made[0], c4d.SELECTION_NEW)
    c4d.EventAdd()
    return made
