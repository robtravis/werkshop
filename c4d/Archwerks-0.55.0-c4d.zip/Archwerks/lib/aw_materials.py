"""Archwerks wall materials: one slot per part of a wall, kept as material tags.

A Wall's Materials tab has a link per part (Exterior, Interior, Top, Bottom,
Start, End, Reveals; aw_ids.AW_WALL_MATERIAL_SLOTS). Each filled slot is an
ordinary material tag on the wall, restricted to the polygon selection of that
name (aw_wall_c4d.GROUPS), so it bakes like any other tag. Archwerks owns those tags
(marked with MARK) and keeps them in step with the slots: a filled slot gets a
tag, an emptied one loses it, a changed one is updated. They sit after every
other tag, so a material tag the user puts on the whole wall shows wherever no
slot is filled.

Tags are never created while C4D is setting the parameter: the wall marks itself
(mark) and the draw watcher syncs it on the next scene change (flush). Sync only
reads the slots, so Undo on a slot puts the tags back too.
"""
import c4d

import aw_ids as I

MARK = I.ID_ARCHWERKS  # set in a material tag's own data: this tag belongs to a wall slot
SLOT_IDS = {pid for _name, pid in I.AW_WALL_MATERIAL_SLOTS}
OPENING_SLOT_IDS = {pid for _name, pid in I.AW_OPENING_MATERIAL_SLOTS}
SLAB_SLOT_IDS = {pid for _name, pid in I.AW_SLAB_MATERIAL_SLOTS}


def slots(op):
    """The material slots of a Wall, an AW Opening (Frame, Sash, Glass, Sill) or a
    Slab (Top, Bottom, Edge)."""
    t = op.GetType()
    if t == I.ID_AW_OPENING:
        return I.AW_OPENING_MATERIAL_SLOTS
    if t == I.ID_AW_DOOR:
        return I.AW_DOOR_MATERIAL_SLOTS
    if t == I.ID_AW_FIREPLACE:
        return I.AW_FP_MATERIAL_SLOTS
    if t == I.ID_AW_WALL_PANELS:
        return I.AW_PNL_MATERIAL_SLOTS
    if t == I.ID_AW_SLAB:
        return I.AW_SLAB_MATERIAL_SLOTS
    if t == I.ID_AW_MOLDING:
        return I.AW_MOLDING_MATERIAL_SLOTS
    if t == I.ID_AW_ROOF:
        return I.AW_ROOF_MATERIAL_SLOTS
    if t in (I.ID_AW_FLOOR, I.ID_AW_CEILING):
        return I.AW_FLOOR_MATERIAL_SLOTS
    if t == I.ID_AW_STAIR:
        return I.AW_STAIR_MATERIAL_SLOTS
    if t == I.ID_AW_CABINET:
        return I.AW_CAB_MATERIAL_SLOTS
    if t == I.ID_AW_COUNTERTOP:
        return I.AW_CT_MATERIAL_SLOTS
    if t == I.ID_AW_SINK:
        return ()  # its countertop builds it, in the countertop's Sink and Cooktop materials
    if t == I.ID_AW_BEAM:
        return I.AW_BEAM_MATERIAL_SLOTS
    if t == I.ID_AW_RAILING:
        return I.AW_RAIL_MATERIAL_SLOTS
    if t == I.ID_AW_ROOF_CUTTER:
        return ()  # a guide: it has no surface of its own
    if t == I.ID_AW_CUTTER:
        return ()  # it wears its wall's materials (aw_cutter_c4d.finish)
    return I.AW_WALL_MATERIAL_SLOTS + I.AW_WALL_OVERRIDE_SLOTS  # its Segment Overrides' too

_pending = []  # walls whose slots changed since the last flush


def mark(op):
    """A slot on this wall changed: sync it at the next scene change."""
    if not any(o == op for o in _pending if o.IsAlive()):
        _pending.append(op)


def pending():
    return bool(_pending)


def flush():
    """Sync every wall marked since the last flush. Returns how many were synced."""
    walls, _pending[:] = list(_pending), []
    n = 0
    for op in walls:
        if op.IsAlive() and op.GetDocument() is not None:
            sync(op)
            n += 1
    if n:
        c4d.EventAdd()
    return n


def ours(tag):
    return tag.GetType() == c4d.Ttexture and tag.GetDataInstance().GetBool(MARK)


def slot_tags(op):
    """{selection name: our material tag} on a wall."""
    return {t[c4d.TEXTURETAG_RESTRICTION]: t for t in op.GetTags() if ours(t)}


def sync(op):
    """Make the wall's slot tags match its slots: one per filled slot, restricted to
    its part, after every other tag."""
    have = slot_tags(op)
    for name, pid in slots(op):
        mat = op[pid]
        tag = have.pop(name, None)
        if mat is None:
            if tag is not None:
                tag.Remove()
            continue
        if tag is None:
            tag = c4d.BaseTag(c4d.Ttexture)
            tag.GetDataInstance().SetBool(MARK, True)
            tag[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_UVW
            tag[c4d.TEXTURETAG_RESTRICTION] = name
        else:
            tag.Remove()  # re-inserted last, below
        tag.SetName(name)
        tag[c4d.TEXTURETAG_MATERIAL] = mat
        op.InsertTag(tag, op.GetLastTag())
    for tag in have.values():  # a slot that no longer exists
        tag.Remove()


# Default materials: a small Redshift set shipped in res/aw_materials.c4d, copied into
# a scene the first time it's needed (only those it hasn't got, matched by name, so
# edited copies are kept) and dropped into the empty slots of walls and windows that
# Archwerks makes.
LIBRARY = "aw_materials.c4d"
# The tables are in the core, shared with Blender (aw_matdefaults).
from aw_matdefaults import CEILING_DEFAULTS, DEFAULTS, FLOOR_DEFAULTS  # noqa: E402,F401


def library_path():
    import os
    here = os.path.dirname(os.path.abspath(__file__))  # .../plugins/Archwerks/lib
    return os.path.join(os.path.dirname(here), "res", LIBRARY)


def _point_textures(mat, folder):
    """A library material's textures named bare (aw_chain_screen.png, beside the library in
    res/) given their full path, so the copy in a scene finds them."""
    import os
    import maxon
    try:
        graph = mat.GetNodeMaterialReference().GetGraph(maxon.Id("com.redshift3d.redshift4c4d.class.nodespace"))
    except Exception:
        return
    port = "com.redshift3d.redshift4c4d.nodes.core.texturesampler.tex0"
    samplers = []
    graph.GetViewRoot().GetChildren(lambda n: (samplers.append(n) if "texturesampler" in str(n.GetId()) else None) or True,
                                    maxon.NODE_KIND.NODE)
    if not samplers:
        return
    with graph.BeginTransaction() as t:
        for node in samplers:
            p = node.GetInputs().FindChild(port).FindChild("path")
            name = str(p.GetPortValue() or "")
            bare = name.split("://", 1)[-1].lstrip("/")  # stored as relative:///name
            if bare and "/" not in bare and not name.startswith("file:"):
                p.SetPortValue(maxon.Url("file:///" + os.path.join(folder, bare).lstrip("/")))
        t.Commit()


def ensure(doc, names):
    """{name: material} for these default materials, copying from the library into doc
    any that doc doesn't have yet. Missing library or material: left out."""
    have = {}
    m = doc.GetFirstMaterial()
    while m:
        have.setdefault(m.GetName(), m)
        m = m.GetNext()
    missing = [n for n in set(names) if n not in have]
    if missing:
        import os
        path = library_path()
        lib = c4d.documents.LoadDocument(path, c4d.SCENEFILTER_MATERIALS) if os.path.exists(path) else None
        if lib is not None:
            lm = lib.GetFirstMaterial()
            while lm:
                if lm.GetName() in missing and lm.GetName() not in have:
                    copy = lm.GetClone(c4d.COPYFLAGS_NONE)
                    _point_textures(copy, os.path.dirname(path))
                    doc.InsertMaterial(copy)
                    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, copy)
                    have[copy.GetName()] = copy
                lm = lm.GetNext()
    return {n: have[n] for n in names if n in have}




def defaults_for(op):
    import aw_matdefaults
    return aw_matdefaults.defaults_for(op.GetType(), op[I.AW_SLAB_TYPE] if op.GetType() == I.ID_AW_SLAB else 0)


def apply_defaults(doc, op):
    """Fill op's empty material slots with the defaults, and make its tags now."""
    table = defaults_for(op)
    if not table or doc is None:
        return
    mats = ensure(doc, list(table.values()))
    for name, pid in slots(op):
        if op[pid] is None and table.get(name) in mats:
            op[pid] = mats[table[name]]
    sync(op)
