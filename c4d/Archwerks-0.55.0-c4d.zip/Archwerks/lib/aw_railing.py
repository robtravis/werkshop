"""Archwerks railings and fences: posts, a handrail, infill and a bottom rail along
a path.

The path is a linked Stair (Side: Left, Right or Both, Inset in from its edge),
else the Railing's own child splines (open or closed, any number), heights and
all, so a fence can run up a slope. On a stair the path climbs along the line of
the nosings, level across a landing until the next flight's pitch line meets it
(the easing a handrail makes there), up to the floor above at the top.

Everything stands on the path and is measured up from it:
- Posts: at both ends, at every corner (a turn of 10 degrees or more) and, Post
  Spacing apart, evenly between (0: ends and corners only). Square or Round, Post
  Width, Post Above the handrail's top, with an optional cap.
- Handrail: its top at Height, Square, Round or a Custom profile (a linked
  spline), Width by Depth, swept along the path, mitred at its corners. It is its
  own part, apart from the horizontal rails.
- Bottom Rail: its underside at Infill Bottom, Width by Depth.
- Infill, between the bottom rail (or Infill Bottom) and the handrail's underside
  (or Height): Pickets (Square, Round or Board, Spacing apart centre to
  centre, evenly in each bay between posts; on a stair they stand on the treads;
  Top Straight or Dog-eared, both corners clipped Dog Ear long; with Stringers,
  rails Inset from the pickets' ends that they are fixed to, Behind, In Front or
  Centred through them),
  Rails (Count horizontal rails or boards, the lowest at the bottom, the highest
  at the top, Square or Round), or Panels (one per bay, Panel Thickness, Gap from
  each post: glass or solid, as its material says).

Built in the railing's own space. Plan points are (x, z); s is the distance along
the path in plan; heights in cm.
"""
import math

import aw_host
from aw_vec import Vec

import aw_stair as ST

SIDE_LEFT, SIDE_RIGHT, SIDE_BOTH = 0, 1, 2
SQUARE, ROUND, CUSTOM = 0, 1, 2
BOARD = 2  # a picket shape: a flat picket, Width along the path by Depth across
INFILL_NONE, PICKETS, RAILS, PANELS = 0, 1, 2, 3
STRAIGHT, DOG_EAR = 0, 1  # a picket's top
BEHIND, IN_FRONT, CENTRED = 0, 1, 2  # where a picket's stringers run: right of the path, left, or through
GROUPS = ("Posts", "Handrail", "Rails", "Pickets", "Panels")
CORNER = math.radians(10.0)
ROUND_SIDES = 12
CAP_OVER, CAP_T = 1.5, 2.0  # a post cap reaches this far past the post, this thick


class Path:
    """A railing's path: a polyline in plan (an aw_stair.Line) with a height at every
    point, and what it stands on (floor(s): the treads on a stair)."""

    def __init__(self, pts3, closed=False, floor=None):
        clean = []
        for p in pts3:
            if not clean or math.dist((p[0], p[2]), (clean[-1][0], clean[-1][2])) > 1e-6:
                clean.append(p)
        if closed and len(clean) > 2 and math.dist((clean[0][0], clean[0][2]), (clean[-1][0], clean[-1][2])) <= 1e-6:
            clean.pop()
        self.closed = closed and len(clean) >= 3
        loop = clean + [clean[0]] if self.closed else clean
        self.line = ST.Line([(p[0], p[2]) for p in loop])
        self.hs = [(s, p[1]) for s, p in zip(self.line.vs, loop)]
        self._floor = floor

    @property
    def total(self):
        return self.line.total

    def base(self, s):
        return ST.along(self.hs, s)

    def floor(self, s):
        return self._floor(s) if self._floor is not None else self.base(s)

    def n_at(self, s):
        """The plan's left normal at s (the bisector at a corner)."""
        line = self.line
        for i, v in enumerate(line.vs):
            if abs(v - s) < 1e-6:
                return self.mitre(i, 1.0, unit=True)
        return line.segs[line._seg(s, True)]["n"]

    def mitre(self, i, u, unit=False):
        """Offset u to the left at point i, mitred where the path turns: the vector
        from the point (unit: just its direction)."""
        segs, n = self.line.segs, len(self.line.pts)
        if self.closed and i in (0, n - 1):
            a, b = segs[-1]["n"], segs[0]["n"]
        elif i == 0:
            a = b = segs[0]["n"]
        elif i == n - 1:
            a = b = segs[-1]["n"]
        else:
            a, b = segs[i - 1]["n"], segs[i]["n"]
        k = 1.0 + a[0] * b[0] + a[1] * b[1]
        m = ((a[0] + b[0]) / k, (a[1] + b[1]) / k) if k > 1e-6 else a
        if unit:
            L = math.hypot(*m)
            return (m[0] / L, m[1] / L)
        return (m[0] * u, m[1] * u)

    def turn_at(self, i):
        segs, n = self.line.segs, len(self.line.pts)
        if self.closed and i in (0, n - 1):
            d1, d2 = segs[-1]["d"], segs[0]["d"]
        elif 0 < i < n - 1:
            d1, d2 = segs[i - 1]["d"], segs[i]["d"]
        else:
            return 0.0
        return math.atan2(d1[0] * d2[1] - d1[1] * d2[0], d1[0] * d2[0] + d1[1] * d2[1])

    def corners(self):
        """s of every corner: a turn of CORNER or more."""
        n = len(self.line.pts)
        out = [self.line.vs[i] for i in range(n - 1 if self.closed else n) if abs(self.turn_at(i)) >= CORNER]
        return out

    def point(self, s):
        for i, v in enumerate(self.line.vs):
            if abs(v - s) < 1e-6:
                return self.line.pts[i]
        return self.line.side(s, 0.0)


def post_stations(path, spacing):
    """s of every post: the ends (an open path), every corner and, spacing apart, evenly
    between (spacing 0: no more)."""
    marks = sorted(set(path.corners()))
    if not path.closed:
        marks = sorted({0.0, path.total} | set(marks))
    elif not marks:
        marks = [0.0]
    out = []
    pairs = list(zip(marks, marks[1:]))
    if path.closed:
        pairs.append((marks[-1], marks[0] + path.total))
    for a, b in pairs:
        out.append(a)
        if spacing > 1e-6:
            n = max(1, int(math.ceil((b - a) / spacing - 1e-9)))
            out += [a + (b - a) * j / n for j in range(1, n)]
    if not path.closed:
        out.append(marks[-1])
    return sorted({round(s % path.total if path.closed else s, 6) for s in out})


def bays(path, posts):
    """[(a, b)] the stretches between consecutive posts (or, with none, the whole path)."""
    if not posts:
        return [(0.0, path.total)]
    pairs = list(zip(posts, posts[1:]))
    if path.closed:
        pairs.append((posts[-1], posts[0] + path.total))
    return [(a, b) for a, b in pairs if b - a > 1e-6]


def picket_stations(a, b, spacing, end_posts=True):
    """s of the pickets in the bay a..b, evenly, at most spacing apart (not on its
    ends when posts stand there)."""
    n = max(1, int(math.ceil((b - a) / max(spacing, 1.0) - 1e-9)))
    js = range(1, n) if end_posts else range(0, n + 1)
    return [a + (b - a) * j / n for j in js]


def picket_profile(w, y0, y1, top, ear):
    """[(along, up)] counter-clockwise: a picket's face, Width across and y0..y1 up,
    its top square (Straight) or with both corners clipped at 45 degrees, ear long
    (Dog-eared)."""
    pts = [(-w / 2, y0), (w / 2, y0)]
    e = min(max(ear, 0.0), w / 2, y1 - y0) if top == DOG_EAR else 0.0
    if e > 1e-6:
        pts += [(w / 2, y1 - e), (w / 2 - e, y1), (-w / 2 + e, y1), (-w / 2, y1 - e)]
    else:
        pts += [(w / 2, y1), (-w / 2, y1)]
    out = []
    for q in pts:
        if not out or math.dist(q, out[-1]) > 1e-6:
            out.append(q)
    if math.dist(out[0], out[-1]) <= 1e-6:
        out.pop()
    return out


def stringer_offset(side, picket_depth, stringer_w):
    """How far left of the path a picket's stringers run (negative: right)."""
    reach = picket_depth / 2 + stringer_w / 2
    return {BEHIND: -reach, IN_FRONT: reach}.get(side, 0.0)


def rail_heights(bottom, top, count, size):
    """The centre heights of `count` rails `size` deep, the lowest at bottom, the
    highest at top, evenly between."""
    if count <= 0 or top - bottom < size:
        return []
    if count == 1:
        return [(bottom + top) / 2]
    return [bottom + size / 2 + (top - bottom - size) * j / (count - 1) for j in range(count)]


def stair_path(line, trs, rise, off):
    """(points [(x, y, z)], stair s at each, floor(s)) for a railing off to the left of
    a stair's walking line (negative: right), up the line of its nosings with an
    easing at each landing."""
    pts = []
    parts = ST.pieces(trs)
    for j, (sa, sb, kind, (k, c)) in enumerate(parts):
        if kind == "run":
            pts += [(sa, k * rise), (sb, (k + c) * rise)]
        else:
            pts.append((sa, k * rise))
            nxt = parts[j + 1] if j + 1 < len(parts) else None
            if nxt is not None and nxt[2] == "run":
                g = (nxt[1] - nxt[0]) / nxt[3][1]
                pts.append((max(sa, sb - g), k * rise))
            else:
                pts.append((sb, k * rise))
    hs = []
    for p in pts:
        if not hs or abs(p[0] - hs[-1][0]) > 1e-6:
            hs.append(p)
        else:
            hs[-1] = p
    stations = sorted({s for s, _y in hs} | {v for v in line.vs})
    corner = {line.vs[i]: i for i in range(1, len(line.pts) - 1)}
    out, ss = [], []
    for s in stations:
        x, z = line.corner(corner[s], off) if s in corner else line.side(s, off, s < line.total - 1e-9)
        out.append((x, ST.along(hs, s), z))
        ss.append(s)

    def floor(s_stair):
        if s_stair <= 1e-6:
            return 0.0  # the foot: the floor below
        if s_stair >= line.total - 1e-6:
            return (len(trs) + 1) * rise  # the head: the floor above
        for sa, sb, k, _kind in trs:
            if sa - 1e-6 <= s_stair <= sb + 1e-6:
                return k * rise
        return 0.0
    return out, ss, floor


# Building --------------------------------------------------------------------------

def _ring_prism(mesh, plan_pts, y0, y1, group):
    """A closed upright solid over a small plan outline (counter-clockwise)."""
    ring = [(x, z, 0.0) for x, z in plan_pts]
    ST._prism(mesh, ring, lambda _s: y1, lambda _s: y0, group, group, group, group)


def _footprint(centre, d, shape, w, depth=None):
    """A post's or picket's plan outline round centre, square to direction d."""
    depth = w if depth is None else depth
    if shape == ROUND:
        r = w / 2
        return [(centre[0] + r * math.cos(2 * math.pi * i / ROUND_SIDES),
                 centre[1] + r * math.sin(2 * math.pi * i / ROUND_SIDES)) for i in range(ROUND_SIDES)]
    n = (-d[1], d[0])
    hw, hd = w / 2, depth / 2
    return [(centre[0] + d[0] * a * hw + n[0] * b * hd, centre[1] + d[1] * a * hw + n[1] * b * hd)
            for a, b in ((-1, -1), (1, -1), (1, 1), (-1, 1))]


def _face_prism(mesh, centre, d, face, depth, group):
    """A closed solid: face [(along, up)] standing square across direction d at centre,
    depth thick across the path."""
    import aw_slab
    n = (-d[1], d[0])
    mesh.new_part()
    first = len(mesh.polys)
    rings = [[mesh.pt(centre[0] + d[0] * a + n[0] * k, y, centre[1] + d[1] * a + n[1] * k) for a, y in face]
             for k in (-depth / 2, depth / 2)]
    m = len(face)
    for i, j, k in aw_slab.triangulate(face):
        mesh.quad(rings[0][k], rings[0][j], rings[0][i], rings[0][i], group)
        mesh.quad(rings[1][i], rings[1][j], rings[1][k], rings[1][k], group)
    for j in range(m):
        k = (j + 1) % m
        mesh.quad(rings[0][j], rings[0][k], rings[1][k], rings[1][j], group)
    mesh._face_out(first)


def profile(shape, w, h, custom=None):
    """[(u, v)] counter-clockwise, centred: u across the path (left), v up."""
    if shape == CUSTOM and custom and len(custom) >= 3:
        us, vs = [p[0] for p in custom], [p[1] for p in custom]
        cu, cv = (min(us) + max(us)) / 2, (min(vs) + max(vs)) / 2
        pts = [(u - cu, v - cv) for u, v in custom]
        a = sum(p[0] * q[1] - q[0] * p[1] for p, q in zip(pts, pts[1:] + pts[:1]))
        return pts if a > 0 else pts[::-1]
    if shape == ROUND:
        return [(w / 2 * math.cos(2 * math.pi * i / ROUND_SIDES), h / 2 * math.sin(2 * math.pi * i / ROUND_SIDES))
                for i in range(ROUND_SIDES)]
    return [(-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)]


def sweep(mesh, path, prof, lift, group):
    """prof swept along the whole path, lift above it, kept upright, mitred at every
    turn; closed with end caps on an open path, joined round on a closed one."""
    import aw_slab
    n = len(path.line.pts) - (1 if path.closed else 0)
    if n < 2 or len(prof) < 3:
        return
    mesh.new_part()
    first = len(mesh.polys)
    rings = []
    for i in range(n):
        x, z = path.line.pts[i]
        y = path.hs[i][1] + lift
        ring = []
        for u, v in prof:
            mx, mz = path.mitre(i, u)
            ring.append(mesh.pt(x + mx, y + v, z + mz))
        rings.append(ring)
    m = len(prof)
    count = n if path.closed else n - 1
    for i in range(count):
        a, b = rings[i], rings[(i + 1) % n]
        for j in range(m):
            k = (j + 1) % m
            mesh.quad(a[j], a[k], b[k], b[j], group)
    if not path.closed:
        for i, j, k in aw_slab.triangulate(prof):
            mesh.quad(rings[0][k], rings[0][j], rings[0][i], rings[0][i], group)
            mesh.quad(rings[-1][i], rings[-1][j], rings[-1][k], rings[-1][k], group)
    mesh._face_out(first)


def build_path(mesh, path, s):
    """Everything along one path."""
    posts = post_stations(path, s["post_spacing"]) if s["posts"] else []
    pw = s["post_w"]
    hr_h = s["handrail_h"] if s["handrail"] else 0.0
    top = s["height"] - hr_h  # the infill's top: the handrail's underside
    bottom = s["infill_bottom"]
    if s["bottom_rail"]:
        sweep(mesh, path, profile(SQUARE, s["bottom_w"], s["bottom_h"]), bottom + s["bottom_h"] / 2, "Rails")
        bottom += s["bottom_h"]
    if s["handrail"]:
        prof = profile(s["handrail_shape"], s["handrail_w"], hr_h, s.get("custom"))
        sweep(mesh, path, prof, s["height"] - hr_h / 2, "Handrail")
    for st in posts:
        c = path.point(st)
        d = path.n_at(st)
        d = (d[1], -d[0])  # along the path
        y1 = path.base(st) + s["height"] + s["post_above"]
        y0 = min(path.floor(st), path.base(st))  # on a stair, down to the floor or the tread it stands on
        _ring_prism(mesh, _footprint(c, d, s["post_shape"], pw), y0, y1, "Posts")
        if s["post_cap"]:
            _ring_prism(mesh, _footprint(c, d, s["post_shape"], pw + 2 * CAP_OVER), y1, y1 + CAP_T, "Posts")
    infill = s["infill"]
    if infill == RAILS:
        for h in rail_heights(bottom, top, s["rails"], s["rail_h"]):
            sweep(mesh, path, profile(s["rail_shape"], s["rail_w"], s["rail_h"]), h, "Rails")
    elif infill in (PICKETS, PANELS):
        clear = pw / 2 if posts else 0.0
        if infill == PICKETS and s["stringers"] > 0:  # the rails the pickets are fixed to
            pd = s["picket_d"] if s["picket_shape"] == BOARD else s["picket_w"]
            u = stringer_offset(s["stringer_side"], pd, s["stringer_w"])
            prof = [(x + u, y) for x, y in profile(SQUARE, s["stringer_w"], s["stringer_h"])]
            for h in rail_heights(bottom + s["stringer_inset"], top - s["stringer_inset"], s["stringers"],
                                  s["stringer_h"]):
                sweep(mesh, path, prof, h, "Rails")
        for a, b in bays(path, posts):
            if infill == PICKETS:
                for bs in picket_stations(a, b, s["picket_spacing"], bool(posts)):
                    bs %= path.total if path.closed else float("inf")
                    c = path.point(bs)
                    d = path.n_at(bs)
                    d = (d[1], -d[0])
                    # on a stair's treads (Infill Bottom above them), else Infill Bottom above the path
                    y0 = (path.floor(bs) + s["infill_bottom"]) if not s["bottom_rail"] else path.base(bs) + bottom
                    y1 = path.base(bs) + top
                    if y1 - y0 <= 0.5:
                        continue
                    if s["picket_shape"] == ROUND or s["picket_top"] == STRAIGHT:
                        depth = s["picket_d"] if s["picket_shape"] == BOARD else None
                        shape = SQUARE if s["picket_shape"] == BOARD else s["picket_shape"]
                        _ring_prism(mesh, _footprint(c, d, shape, s["picket_w"], depth), y0, y1, "Pickets")
                    else:  # dog-eared: its face cut, then given its thickness
                        depth = s["picket_d"] if s["picket_shape"] == BOARD else s["picket_w"]
                        _face_prism(mesh, c, d, picket_profile(s["picket_w"], y0, y1, DOG_EAR, s["dog_ear"]),
                                    depth, "Pickets")
            else:
                sa, sb = a + clear + s["panel_gap"], b - clear - s["panel_gap"]
                if sb - sa < 1.0:
                    continue
                t = s["panel_t"]
                ring = _bay_ring(path, sa, sb, -t / 2, t / 2)
                ST._prism(mesh, ring, lambda x: path.base(x % path.total if path.closed else x) + top,
                          lambda x: path.base(x % path.total if path.closed else x) + bottom,
                          "Panels", "Panels", "Panels", "Panels")


def _bay_ring(path, sa, sb, lo, hi):
    """Line.ring for sa..sb, past the start of a closed path where a bay wraps round."""
    if not path.closed or sb <= path.total + 1e-9:
        return path.line.ring(sa, sb, lo, hi)
    shifted = ST.Line(path.line.pts[:-1] + path.line.pts)  # twice round: s past the end carries on
    return shifted.ring(sa, sb, lo, hi)


# Settings and sources (through the host, aw_host) ---------------------------------------------

def settings(op):
    import aw_ids as I
    v = lambda pid: aw_host.value(op, pid)  # noqa: E731
    return {"stair": aw_host.link(op, I.AW_RAIL_STAIR), "side": int(v(I.AW_RAIL_SIDE)), "inset": float(v(I.AW_RAIL_INSET)),
            "height": max(float(v(I.AW_RAIL_HEIGHT)), 1.0),
            "posts": bool(v(I.AW_RAIL_POSTS)), "post_spacing": max(float(v(I.AW_RAIL_POST_SPACING)), 0.0),
            "post_w": max(float(v(I.AW_RAIL_POST_W)), 0.5), "post_shape": int(v(I.AW_RAIL_POST_SHAPE)),
            "post_above": float(v(I.AW_RAIL_POST_ABOVE)), "post_cap": bool(v(I.AW_RAIL_POST_CAP)),
            "handrail": bool(v(I.AW_RAIL_HANDRAIL)), "handrail_shape": int(v(I.AW_RAIL_HANDRAIL_SHAPE)),
            "handrail_w": max(float(v(I.AW_RAIL_HANDRAIL_W)), 0.5),
            "handrail_h": max(float(v(I.AW_RAIL_HANDRAIL_H)), 0.5),
            "profile": aw_host.link(op, I.AW_RAIL_HANDRAIL_PROFILE),
            "infill": int(v(I.AW_RAIL_INFILL)), "infill_bottom": max(float(v(I.AW_RAIL_INFILL_BOTTOM)), 0.0),
            "picket_spacing": max(float(v(I.AW_RAIL_PICKET_SPACING)), 1.0),
            "picket_w": max(float(v(I.AW_RAIL_PICKET_W)), 0.3),
            "picket_d": max(float(v(I.AW_RAIL_PICKET_D)), 0.3),
            "picket_shape": int(v(I.AW_RAIL_PICKET_SHAPE)), "picket_top": int(v(I.AW_RAIL_PICKET_TOP)),
            "dog_ear": max(float(v(I.AW_RAIL_DOG_EAR)), 0.0),
            "stringers": max(int(v(I.AW_RAIL_STRINGERS)), 0), "stringer_w": max(float(v(I.AW_RAIL_STRINGER_W)), 0.3),
            "stringer_h": max(float(v(I.AW_RAIL_STRINGER_H)), 0.3),
            "stringer_inset": max(float(v(I.AW_RAIL_STRINGER_INSET)), 0.0),
            "stringer_side": int(v(I.AW_RAIL_STRINGER_SIDE)),
            "rails": max(int(v(I.AW_RAIL_RAILS)), 0), "rail_w": max(float(v(I.AW_RAIL_RAIL_W)), 0.3),
            "rail_h": max(float(v(I.AW_RAIL_RAIL_H)), 0.3), "rail_shape": int(v(I.AW_RAIL_RAIL_SHAPE)),
            "panel_t": max(float(v(I.AW_RAIL_PANEL_T)), 0.1), "panel_gap": max(float(v(I.AW_RAIL_PANEL_GAP)), 0.0),
            "bottom_rail": bool(v(I.AW_RAIL_BOTTOM)), "bottom_w": max(float(v(I.AW_RAIL_BOTTOM_W)), 0.3),
            "bottom_h": max(float(v(I.AW_RAIL_BOTTOM_H)), 0.3)}


def _alive(obj):
    return aw_host.alive(obj)


def custom_profile(spline):
    """[(u, v)] of a profile spline in its own plane (its XY), or None."""
    return aw_host.spline_points(spline)


def paths(op, s):
    """The railing's paths in its own space."""
    import aw_ids as I
    stair = s["stair"]
    if _alive(stair) and aw_host.type_id(stair) == I.ID_AW_STAIR:
        ss = ST.settings(stair)
        p = ST.plan(ss, ST.spline_path(stair) if ss["shape"] == ST.SPLINE else None)
        if p is None:
            return []
        line, trs, rise = p
        m = aw_host.relative(op, stair)
        reach = max(ss["width"] / 2 - s["inset"], 0.0)
        sides = {SIDE_LEFT: [reach], SIDE_RIGHT: [-reach], SIDE_BOTH: [reach, -reach]}[s["side"]]
        out = []
        for off in sides:
            pts, stair_s, floor = stair_path(line, trs, rise, off)
            world = [m * Vec(*q) for q in pts]
            path = Path([(q.x, q.y, q.z) for q in world])
            if len(path.line.pts) < 2:
                continue
            ys = [(v, ss_) for v, ss_ in zip(path.line.vs, _keep(pts, stair_s))]
            lift = m.off.y

            def tread(x, ys=ys, floor=floor, lift=lift):
                return floor(ST.along(ys, x)) + lift
            path._floor = tread
            out.append(path)
        return out
    closed, opened = aw_host.spline_paths(op, with_y=True)
    out = [Path(p, True) for p in closed if len(p) >= 3] + [Path(p) for p in opened if len(p) >= 2]
    return [p for p in out if p.total > 1e-6]


def _keep(pts, values):
    """values for the points Path keeps (it drops a point standing on the last in plan)."""
    out = []
    last = None
    for p, v in zip(pts, values):
        if last is None or math.dist((p[0], p[2]), (last[0], last[2])) > 1e-6:
            out.append(v)
            last = p
    return out


def build(op):
    from aw_mesh import MeshBuilder
    s = settings(op)
    s["custom"] = custom_profile(s["profile"]) if s["handrail_shape"] == CUSTOM else None
    ps = paths(op, s)
    if not ps:
        return None
    mesh = MeshBuilder(GROUPS)
    for p in ps:
        build_path(mesh, p, s)
    return mesh.build(aw_host.name(op))


# Presets and the panel ------------------------------------------------------------

IN = 2.54
PRESET_FIELDS = ("height", "inset", "posts", "post_spacing", "post_w", "post_shape", "post_above", "post_cap",
                 "handrail", "handrail_shape", "handrail_w", "handrail_h", "infill", "infill_bottom",
                 "picket_spacing", "picket_w", "picket_d", "picket_shape", "picket_top", "dog_ear", "stringers",
                 "stringer_w", "stringer_h", "stringer_inset", "stringer_side", "rails", "rail_w", "rail_h",
                 "rail_shape", "panel_t", "panel_gap", "bottom_rail", "bottom_w", "bottom_h")


def _preset(label, **values):
    return {"label": label, "object": "railing", "key": "Railing", "values": values}


PRESETS = (
    _preset("Stair spindles", height=36 * IN, posts=True, post_spacing=0.0, post_w=3.5 * IN, post_above=4 * IN,
            post_cap=True, handrail=True, handrail_shape=ROUND, handrail_w=2 * IN, handrail_h=2 * IN,
            infill=PICKETS, infill_bottom=0.0, picket_spacing=4 * IN, picket_w=1.25 * IN,
            picket_shape=SQUARE, picket_top=STRAIGHT, stringers=0, bottom_rail=False),
    _preset("Glass balustrade", height=42 * IN, posts=True, post_spacing=48 * IN, post_w=2 * IN, post_above=0.0,
            post_cap=False, handrail=True, handrail_shape=SQUARE, handrail_w=2 * IN, handrail_h=1.5 * IN,
            infill=PANELS, infill_bottom=3 * IN, panel_t=0.5 * IN, panel_gap=1 * IN, bottom_rail=False),
    _preset("Cable rail", height=36 * IN, posts=True, post_spacing=48 * IN, post_w=2.5 * IN, post_above=0.0,
            post_cap=False, handrail=True, handrail_shape=SQUARE, handrail_w=3.5 * IN, handrail_h=1.5 * IN,
            infill=RAILS, rails=10, rail_w=0.25 * IN, rail_h=0.25 * IN, rail_shape=ROUND, infill_bottom=3 * IN,
            bottom_rail=False),
    _preset("Picket fence", height=42 * IN, posts=True, post_spacing=96 * IN, post_w=3.5 * IN, post_above=2 * IN,
            post_cap=True, handrail=False, infill=PICKETS, infill_bottom=2 * IN, picket_spacing=5.5 * IN,
            picket_w=3.5 * IN, picket_d=0.75 * IN, picket_shape=BOARD, picket_top=DOG_EAR, dog_ear=0.75 * IN,
            stringers=2, stringer_w=1.5 * IN, stringer_h=3.5 * IN, stringer_inset=6 * IN, stringer_side=BEHIND,
            bottom_rail=False),
    _preset("Slat fence", height=72 * IN, posts=True, post_spacing=96 * IN, post_w=3.5 * IN, post_above=0.0,
            post_cap=False, handrail=False, infill=RAILS, rails=12, rail_w=0.75 * IN, rail_h=5.5 * IN,
            rail_shape=SQUARE, infill_bottom=2 * IN, bottom_rail=False),
    _preset("Ranch fence", height=48 * IN, posts=True, post_spacing=96 * IN, post_w=5 * IN, post_above=4 * IN,
            post_cap=False, handrail=False, infill=RAILS, rails=3, rail_w=1.5 * IN, rail_h=5.5 * IN,
            rail_shape=SQUARE, infill_bottom=12 * IN, bottom_rail=False),
)


def param_ids():
    import aw_ids as I
    return tuple((f, getattr(I, "AW_RAIL_" + {"post_spacing": "POST_SPACING", "post_w": "POST_W",
                                               "post_shape": "POST_SHAPE", "post_above": "POST_ABOVE",
                                               "post_cap": "POST_CAP", "handrail_shape": "HANDRAIL_SHAPE",
                                               "handrail_w": "HANDRAIL_W", "handrail_h": "HANDRAIL_H",
                                               "infill_bottom": "INFILL_BOTTOM", "picket_spacing": "PICKET_SPACING",
                                               "picket_w": "PICKET_W", "picket_d": "PICKET_D",
                                               "picket_shape": "PICKET_SHAPE", "picket_top": "PICKET_TOP",
                                               "stringer_w": "STRINGER_W", "stringer_h": "STRINGER_H",
                                               "stringer_inset": "STRINGER_INSET", "stringer_side": "STRINGER_SIDE",
                                               "rail_w": "RAIL_W",
                                               "rail_h": "RAIL_H", "rail_shape": "RAIL_SHAPE", "panel_t": "PANEL_T",
                                               "panel_gap": "PANEL_GAP", "bottom_rail": "BOTTOM",
                                               "bottom_w": "BOTTOM_W", "bottom_h": "BOTTOM_H"}.get(f, f.upper())))
                 for f in PRESET_FIELDS)


def apply_preset(op, preset):
    """Set a railing's settings from a preset (what it leaves out stays)."""
    for name, pid in param_ids():
        if name in preset["values"]:
            aw_host.set_value(op, pid, preset["values"][name])
