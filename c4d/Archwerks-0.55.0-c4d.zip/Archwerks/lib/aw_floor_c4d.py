"""aw_floor for Cinema 4D: the parts of core/aw_floor.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_groups_c4d
import aw_floor  # noqa: F401
from aw_floor import *  # noqa: F401,F403


def change_key(op):
    import c4d
    kids = tuple((k.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX | c4d.DIRTYFLAGS_CACHE), k.GetDeformMode())
                 for k in op.GetChildren() if k.GetInfo() & c4d.OBJECT_ISSPLINE)
    return (op.GetName(), op.GetDirty(c4d.DIRTYFLAGS_DATA), kids)


def _from_wall(doc, wall, kind):
    """A Floor (Ceiling) on the wall's outer perimeter, one editable spline per room,
    its Elevation at the wall's base (on its top, for a Ceiling)."""
    import c4d
    import aw_ids as I
    import aw_slab
    import aw_slab_c4d
    import aw_wall_c4d
    wp = aw_wall_c4d.wall_path(wall)
    if wp is None:
        return None
    plan, w0, w1, height, _s = wp
    obj = c4d.BaseObject(I.ID_AW_CEILING if kind == CEILING else I.ID_AW_FLOOR)
    obj.SetName(aw_slab_c4d.next_name(doc, "Ceiling" if kind == CEILING else "Floor"))
    obj[I.AW_FLOOR_ELEVATION] = height if kind == CEILING else 0.0
    for n, ring in enumerate(aw_slab.outlines(plan, aw_slab.fit_offset(aw_slab.FIT_OUTSIDE, w0, w1))):
        sp = c4d.SplineObject(len(ring), c4d.SPLINETYPE_LINEAR)
        sp.SetAllPoints([c4d.Vector(x, 0, z) for x, z in ring])
        sp[c4d.SPLINEOBJECT_CLOSED] = True
        sp.SetName("Outline.%03d" % (n + 1))
        sp.Message(c4d.MSG_UPDATE)
        sp.InsertUnderLast(obj)
    doc.InsertObject(obj, wall.GetUp(), wall)
    obj.SetMg(c4d.Matrix(wall.GetMg()))
    return obj


def _lay_flat(doc, spline):
    """A spline primitive drawn upright (C4D draws them in XY) laid on the floor."""
    import c4d
    if spline.GetType() == c4d.Ospline:
        return
    try:
        if spline[c4d.PRIM_PLANE] != c4d.PRIM_PLANE_XZ:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, spline)
            spline[c4d.PRIM_PLANE] = c4d.PRIM_PLANE_XZ
    except (AttributeError, TypeError):
        pass


def add_for_selection(doc, kind):
    """Panel button: a Floor (or Ceiling) for each selected Wall, from its rooms; else
    one shaped by the selected splines (moved under it, laid flat); else an empty
    one to draw with the Spline Pen. One undo step. Returns what it made."""
    import c4d
    import aw_ids as I
    import aw_materials
    import aw_panel
    import aw_slab
    import aw_slab_c4d
    sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
    walls = [o for o in sel if o.GetType() == I.ID_AW_WALL]
    splines = aw_panel.selected_splines(doc)
    if not walls and not splines:
        return [aw_panel.start_floor(doc, kind)]
    made = []
    doc.StartUndo()
    for wall in walls:
        obj = _from_wall(doc, wall, kind)
        if obj is not None:
            doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, obj)
            made.append(obj)
    if splines and not walls:
        obj = c4d.BaseObject(I.ID_AW_CEILING if kind == CEILING else I.ID_AW_FLOOR)
        obj.SetName(aw_slab_c4d.next_name(doc, "Ceiling" if kind == CEILING else "Floor"))
        doc.InsertObject(obj, splines[0].GetUp(), splines[0].GetPred())
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, obj)
        for sp in splines:
            mg = sp.GetMg()
            _lay_flat(doc, sp)
            doc.AddUndo(c4d.UNDOTYPE_DELETEOBJ, sp)
            sp.Remove()
            sp.InsertUnderLast(obj)
            sp.SetMg(mg)
            doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, sp)
        made.append(obj)
    for obj in made:
        aw_materials.apply_defaults(doc, obj)
        aw_groups_c4d.file(doc, obj)  # into its group: null and layer (aw_groups_c4d)
    doc.EndUndo()
    if made:
        doc.SetActiveObject(made[0], c4d.SELECTION_NEW)
    c4d.EventAdd()
    return made
