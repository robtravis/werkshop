"""The Archwerks panel's buttons, drawn as Blender's Sidebar draws its own, so the two panels
match: the icon leading at the left edge, the label centred clear of it, pressed in (the
active colour) when it is the choice. Cinema 4D's own BitmapButton centres an icon and
its label together, and can't be told otherwise, so these are user areas.

Grid(dialog) lays them out two-up, as the suite's grids are: add(label, act, icon, on)
for each, and act() runs on a click. Colours are Cinema 4D's theme's, so they follow it.
"""
import c4d

HEIGHT = 22  # px: a row, as Blender's buttons at 1.2 scale


class IconButton(c4d.gui.GeUserArea):
    def __init__(self, label, act, icon=None, on=False, enabled=True):
        super().__init__()
        self.label, self.act, self.on, self.enabled, self.hot = label, act, on, enabled, False
        self.icon = c4d.gui.GetIcon(icon) if isinstance(icon, int) else icon

    def GetMinSize(self):
        return 40, HEIGHT

    def DrawMsg(self, x1, y1, x2, y2, msg):
        self.OffScreenOn()
        w, h = self.GetWidth(), self.GetHeight()
        self.DrawSetPen(c4d.COLOR_BG)
        self.DrawRectangle(0, 0, w, h)
        if not self.enabled:
            pen = c4d.COLOR_BG_BUTTON_DISABLED
        elif self.on:
            pen = c4d.COLOR_ICONS_BG_ACTIVE
        else:
            pen = c4d.COLOR_BG_BUTTON_HIGHLIGHTED if self.hot else c4d.COLOR_BG_BUTTON
        self.DrawSetPen(pen)
        self.DrawRectangle(2, 1, w - 3, h - 2)  # a pixel in from each corner: rounded at this size
        self.DrawRectangle(1, 2, w - 2, h - 3)
        left = 6
        if self.icon:
            s = h - 6
            self.DrawBitmap(self.icon["bmp"], left, 3, s, s, self.icon["x"], self.icon["y"], self.icon["w"],
                            self.icon["h"], c4d.BMP_ALLOWALPHA | c4d.BMP_NORMALSCALED)
            left += s + 4
        if not self.enabled:
            text = c4d.COLOR_TEXT_DISABLED
        else:
            text = c4d.COLOR_TEXT_SELECTED if self.on else c4d.COLOR_TEXT
        self.DrawSetTextCol(text, c4d.COLOR_TRANS)
        label = self.label
        while len(label) > 1 and self.DrawGetTextWidth(label) > w - left - 4:  # clipped, as Blender's: "Firepla..."
            label = label[:-2] + "…" if not label.endswith("…") else label[:-2] + "…"
        tw = self.DrawGetTextWidth(label)
        self.DrawText(label, max(left, (w - tw) // 2), (h - self.DrawGetFontHeight()) // 2)

    def InputEvent(self, msg):
        if (self.enabled and msg[c4d.BFM_INPUT_DEVICE] == c4d.BFM_INPUT_MOUSE
                and msg[c4d.BFM_INPUT_CHANNEL] == c4d.BFM_INPUT_MOUSELEFT):
            if self.act is not None:
                self.act()
            return True
        return False

    def Message(self, msg, result):
        mid = msg.GetId()
        if mid == c4d.BFM_GETCURSORINFO and not self.hot:  # the mouse is over it: lit
            self.hot = True
            self.Redraw()
        elif mid == c4d.BFM_CURSORINFO_REMOVE and self.hot:  # it left: Cinema 4D says so, nothing polled
            self.hot = False
            self.Redraw()
        return super().Message(msg, result)


class Grid:
    """Buttons two-up in dialog: begin() a grid, add() each, end(). The dialog keeps the
    user areas alive (Cinema 4D only holds them while something else does)."""

    def __init__(self, dialog, next_id, keep):
        self.dialog, self.next_id, self.keep = dialog, next_id, keep

    def begin(self, columns=2):
        self.dialog.GroupBegin(0, c4d.BFH_SCALEFIT, columns, 0)
        self.dialog.GroupSpace(2, 2)

    def add(self, label, act, icon=None, on=False, enabled=True):
        ua = IconButton(label, act, icon, on, enabled)
        self.keep.append(ua)
        self.dialog.AttachUserArea(ua, self.dialog.AddUserArea(self.next_id(), c4d.BFH_SCALEFIT, 0, HEIGHT))
        return ua

    def end(self):
        self.dialog.GroupEnd()
