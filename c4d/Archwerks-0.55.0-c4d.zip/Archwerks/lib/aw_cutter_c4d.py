"""aw_cutter for Cinema 4D: the parts of core/aw_cutter.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_cutter  # noqa: F401
from aw_cutter import *  # noqa: F401,F403


def finish(op, wall, obj):
    """Dress the fill in its wall's materials: a copy of each of the wall's material
    tags (its slot tags are restricted to Exterior, Interior, Reveals, as the fill's
    selections are named)."""
    import c4d
    if wall is None or obj is None:
        return
    for tag in wall.GetTags():
        if tag.GetType() == c4d.Ttexture:
            obj.InsertTag(tag.GetClone(c4d.COPYFLAGS_NONE), obj.GetLastTag())
