"""Archwerks handles for doors and windows.

Every handle is built in its own frame: the origin where it meets the leaf, +Z
standing out of the leaf face, +X the way a lever points (towards the hinge on a
door; down on a window), +Y the third way. place() puts that frame on a face, so
the same shape serves both faces of a leaf (mirrored on the back one) and
windows as well as doors. Round parts are lathes, so they read as turned metal.

Types: Lever (round rose and neck, a tapered round lever with a rounded end),
Modern Lever (square rose, flat bar lever), Knob (round), Plate Lever (a lever on
a tall backplate with a lock cylinder below), Pull Bar (a round bar on two
standoffs, for barn doors), Flush Pull (set into the face, for pocket doors),
and Custom: any object you link, modelled the same way (its axis where it meets
the leaf, sticking out along +Z, a lever along +X), taken as it is in the scene
(read by the host: aw_host.custom_mesh).
Sizes in cm.
"""
LEVER, MODERN, KNOB, PLATE, PULL, FLUSH, CUSTOM = 0, 1, 2, 3, 4, 5, 6
NAMES = ("Lever", "Modern Lever", "Knob", "Plate Lever", "Pull Bar", "Flush Pull", "Custom")
WINDOW_TYPES = (LEVER, MODERN, CUSTOM)   # what a window offers, in that order

SEGMENTS = 24


def place(origin, lever, normal, up):
    """to_world for a handle at origin (x, y, z) whose lever runs along `lever`, which
    stands out along `normal`, and whose own +Y runs along `up` (unit 3-tuples at
    right angles). `up` is given, not worked out, so a handle is never upside down:
    a plate's lock stays below its lever on both leaves of a pair and on both faces.
    Where that makes the frame a mirror image, the builder turns faces back out."""
    ox, oy, oz = origin
    lx, ly, lz = lever
    nx, ny, nz = normal
    sx, sy, sz = up

    def to_world(x, y, z):
        return (ox + lx * x + sx * y + nx * z, oy + ly * x + sy * y + ny * z, oz + lz * x + sz * y + nz * z)
    return to_world


def _shift(to_world, dx=0.0, dy=0.0, dz=0.0):
    return lambda x, y, z: to_world(x + dx, y + dy, z + dz)


def _along_x(to_world, dz):
    """A lathe frame whose axis runs along the handle's +X, dz out from the face."""
    return lambda a, b, h: to_world(h, a, b + dz)


def _along_y(to_world, dx, dz):
    return lambda a, b, h: to_world(a + dx, h, b + dz)


def _box(mesh, to_world, x0, x1, y0, y1, z0, z1, group, bevel=0.0):
    """A box in the handle's frame (its faces may chamfer by bevel at the front)."""
    corners = {}
    for i, x in enumerate((x0, x1)):
        for j, y in enumerate((y0, y1)):
            for k, z in enumerate((z0, z1)):
                d = bevel if k == 1 else 0.0
                corners[(i, j, k)] = to_world(x + (d if i == 0 else -d), y + (d if j == 0 else -d), z)
    first = len(mesh.polys)
    mesh.hexa(corners, group)
    mesh._face_out(first)


ROSE = [(0, 0), (2.7, 0), (2.7, 0.5), (2.4, 0.9), (1.2, 1.2), (1.05, 4.6), (0, 5.4)]
KNOB_PROFILE = [(0, 0), (3.0, 0), (3.0, 0.45), (2.6, 0.9), (1.3, 1.2), (1.0, 2.8), (1.4, 3.3), (2.3, 3.9),
                (2.85, 4.7), (3.05, 5.6), (2.9, 6.6), (2.4, 7.5), (1.5, 8.1), (0, 8.35)]
ARM = [(0, -1.0), (0.8, -0.9), (1.0, -0.4), (0.95, 3.0), (0.82, 10.5), (0.88, 11.3), (0.7, 12.0), (0.35, 12.4),
       (0, 12.5)]
CYLINDER = [(0, 0), (1.1, 0), (1.1, 0.9), (0.9, 1.0), (0, 1.0)]
STANDOFF = [(0, 0), (1.6, 0), (1.6, 0.3), (0.8, 0.6), (0.8, 3.6), (0, 3.6)]
BAR = [(0, -15.0), (0.7, -14.9), (1.1, -14.5), (1.2, -13.8), (1.2, 13.8), (1.1, 14.5), (0.7, 14.9), (0, 15.0)]


def build(mesh, kind, to_world, group="Handle", custom=None):
    """One handle into mesh, in the frame to_world (see place)."""
    if kind == CUSTOM and custom:
        points, polys = custom
        mesh.add_mesh(points, polys, to_world, group)
        return
    if kind == KNOB:
        mesh.lathe(KNOB_PROFILE, to_world, group, SEGMENTS)
    elif kind == MODERN:
        _box(mesh, to_world, -2.6, 2.6, -2.6, 2.6, 0.0, 0.9, group, bevel=0.3)       # square rose
        _box(mesh, to_world, -1.0, 1.0, -1.0, 1.0, 0.9, 5.4, group)                  # neck
        _box(mesh, to_world, -1.0, 12.5, -0.9, 0.9, 4.4, 5.6, group, bevel=0.25)     # flat lever
    elif kind == PLATE:
        _box(mesh, to_world, -2.5, 2.5, -14.0, 3.5, 0.0, 0.8, group, bevel=0.25)     # backplate, lock below
        mesh.lathe([(0, 0.8), (1.15, 0.8), (1.05, 4.6), (0, 5.4)], to_world, group, SEGMENTS)  # neck
        mesh.lathe(ARM, _along_x(to_world, 5.0), group, SEGMENTS)
        mesh.lathe([(0, 0.8), (1.0, 0.8), (1.0, 1.3), (0, 1.3)], _shift(to_world, 0.0, -10.0), group, SEGMENTS)
    elif kind == PULL:
        for y in (-12.0, 12.0):
            mesh.lathe(STANDOFF, _shift(to_world, 0.0, y), group, SEGMENTS)
        mesh.lathe(BAR, _along_y(to_world, 0.0, 4.6), group, SEGMENTS)
    elif kind == FLUSH:  # a recessed oval cup, standing proud a hair so it shows
        mesh.lathe([(0, -0.25), (1.9, -0.25), (2.0, 0.0), (1.9, 0.15), (0, 0.15)],
                   lambda a, b, h: to_world(a, b * 3.0, h), group, SEGMENTS)
    else:  # LEVER
        mesh.lathe(ROSE, to_world, group, SEGMENTS)
        mesh.lathe(ARM, _along_x(to_world, 4.6), group, SEGMENTS)


def reach(kind):
    """How far a handle stands out of the face, cm (for laying things out)."""
    return {KNOB: 8.4, PULL: 5.8, FLUSH: 0.2, MODERN: 5.6}.get(kind, 5.9)
