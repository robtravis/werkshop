"""Archwerks drawing style: the one place every viewport colour and size lives.

Walls use style B (blue, arrowheads, dashed extension lines). A selected opening
switches to style D (its own measurements in orange, the wall's pushed back).
Both share the same shapes, so lines, labels and grips read as one system.

Colours are (r, g, b) in 0..1. Sizes are in points (1x screen pixels): aw_draw
multiplies them by the display's pixel ratio (2 on Retina), so they stay the same
size at any zoom and look the same on any screen.
"""

ROLES = {
    "wall": {"line": (0.55, 0.85, 1.00), "ext": (0.37, 0.56, 0.66),
             "pill": (0.10, 0.27, 0.35), "text": (0.81, 0.94, 1.00)},
    "focus": {"line": (1.00, 0.62, 0.30), "ext": (0.78, 0.48, 0.24),
              "pill": (1.00, 0.62, 0.30), "text": (0.23, 0.11, 0.00)},
    # anything measured in degrees (corner angles, slopes): purple, so it never reads as a length
    "angle": {"line": (0.80, 0.68, 1.00), "ext": (0.55, 0.47, 0.70),
              "pill": (0.27, 0.18, 0.42), "text": (0.94, 0.90, 1.00)},
    "dim": {"line": (0.42, 0.50, 0.54), "ext": (0.30, 0.34, 0.36),
            "pill": (0.23, 0.25, 0.27), "text": (0.60, 0.66, 0.70)},
    # a label being typed into: the same dark pill and light text as every other
    # label (switching to dark-on-light made the same font look thinner), a little
    # brighter, inside a rounded orange outline
    "edit": {"line": (1.00, 0.62, 0.30), "ext": (1.00, 0.62, 0.30),
             "pill": (0.14, 0.36, 0.47), "text": (1.00, 1.00, 1.00), "ring": (1.00, 0.62, 0.30)},
}
EDIT_RING = 1.5  # points: width of the edited label's orange outline

ARROW_LEN = 8.0     # arrowhead length
ARROW_HALF = 3.5    # arrowhead half width
DASH = 4.0          # extension line dash
DASH_GAP = 3.0      # extension line gap

LABEL_PT = 10.5     # label text size, in points
LABEL_PAD_X = 5     # pill padding either side of the text
LABEL_PAD_Y = 2     # pill padding above and below the text
LABEL_OFFSET = 4.0  # space between a dimension line and its pill

GRIP = (1.00, 0.71, 0.30)      # grip arrows
GRIP_HOT = (1.00, 0.90, 0.65)  # the grip under the mouse
FOCUS_GRIP = (1.00, 0.52, 0.18)      # an opening's own grips: the focus orange,
FOCUS_GRIP_HOT = (1.00, 0.78, 0.55)  # same arrow shape as the wall's
GRIP_EDGE = (0.16, 0.10, 0.03)
GRIP_LEN = 14.0
GRIP_HALF = 6.5

# Viewport display colours, after Archipack's solid-shading look (Rob prefers blue): walls a light blue,
# windows white. Set on each new Wall and AW Opening (Basic > Display Color, on the
# object itself: C4D draws a generator's geometry in the generator's colour), so
# they show wherever no material is applied; renders ignore them.
WALL_DISPLAY = (0.62, 0.74, 0.86)
WINDOW_DISPLAY = (0.97, 0.97, 0.97)


def set_display(op, rgb):
    """Give op a viewport display colour for wherever no material is applied (Basic >
    Use Color: Automatic; Always would hide its materials in the viewport)."""
    import c4d
    op[c4d.ID_BASEOBJECT_USECOLOR] = c4d.ID_BASEOBJECT_USECOLOR_AUTOMATIC
    op[c4d.ID_BASEOBJECT_COLOR] = c4d.Vector(*rgb)
