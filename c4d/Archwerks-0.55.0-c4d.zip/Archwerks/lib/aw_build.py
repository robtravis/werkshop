"""Archwerks build-on animation: when each part of a wall is standing.

Pure (no c4d), so the timing is tested outside Cinema 4D. A wall's Build setting
(0..1) is keyed like any parameter; the wall always builds its full mesh and
then moves points by these rules, so it has the same points on every frame
(needed for deformation motion blur and for a clean point-cache bake).

  Rise:  each piece's walls come up from the floor: nothing stands above its level,
         and a piece that hasn't started folds onto its centre line (not even a
         footprint shows).
  Trace: walls extrude; everything past the front is folded onto the front's
         cross-section. All Together and Run by Run: each run has one front that
         travels from its first point round every corner. Segment by Segment:
         each segment extrudes from its own start corner, in turn.

Pieces follow Order: everything together, one run after another, or one segment
after another. Stagger is how much pieces wait for each other: 0 all start
together, 1 strictly one after the next.
"""

RISE, TRACE = 0, 1
TOGETHER, RUNS, SEGMENTS = 0, 1, 2
EDGE = 0.5  # cm: Segment by Segment Rise adds a column this far in from each segment end


def smooth(t):
    """Ease in and out."""
    t = min(max(t, 0.0), 1.0)
    return t * t * (3 - 2 * t)


def piece(progress, i, n, stagger):
    """How far piece i of n is built (0..1, eased) at overall progress 0..1."""
    if n <= 1:
        return smooth(progress)
    duration = 1.0 / (1.0 + (n - 1) * stagger)
    return smooth((progress - i * stagger * duration) / duration)


class Timing:
    """progress, style, order, stagger: the wall's Build settings. run_segments: the
    number of segments in each run, in order."""

    def __init__(self, progress, style, order, stagger, run_segments):
        self.progress = min(max(progress, 0.0), 1.0)
        self.style, self.stagger = style, min(max(stagger, 0.0), 1.0)
        self.order = order
        self.run_segments = list(run_segments)
        self._first = [sum(self.run_segments[:r]) for r in range(len(self.run_segments))]

    def done(self):
        return self.progress >= 1.0

    def _of(self, r, k):
        """(piece index, piece count) for global segment k of run r."""
        if self.order == RUNS:
            return r, len(self.run_segments)
        if self.order == SEGMENTS:
            return k, sum(self.run_segments)
        return 0, 1

    def rise(self, r, k):
        """Rise: the fraction of the wall height standing on segment k of run r."""
        i, n = self._of(r, k)
        return piece(self.progress, i, n, self.stagger)

    def trace(self, r):
        """Trace, one front per run: the fraction of run r's length that stands."""
        i, n = self._of(r, self._first[r] if r < len(self._first) else 0)
        return piece(self.progress, i, n, self.stagger)

    def trace_segment(self, r, k):
        """Trace, Segment by Segment: the fraction of segment k (of run r) that stands."""
        i, n = self._of(r, k)
        return piece(self.progress, i, n, self.stagger)


# Windows and doors -------------------------------------------------------------------------
# Built with their wall, its build front moves their points as it moves the wall's
# (aw_openings.follow_wall). Built on their own (Build With: Own), opening() moves the
# points of the finished window to where its own Build has them, in one of five
# styles. Like a wall, a window keeps every point on every frame.

PARTS, DROP, RISE_IN, SLIDE, SCALE = 0, 1, 2, 3, 4
DROP_BY = 60.0   # cm a dropping window starts above its place
SLIDE_BY = 60.0  # cm a sliding window starts outside its place (out past the Exterior face, -Z)
# Parts in Order: what comes first. A part named in no stage comes last.
STAGES = (("Hearth", "Back", "Firebox"), ("Casing", "Trim", "Sill", "SillIn", "Step", "Surround"), ("Mantel",),
          ("Frame", "Grate"), ("Sash", "Leaf", "Panel", "Logs", "Log Ends"), ("Insert Frame", "Screen"), ("Glass",),
          ("Handle",))  # a fireplace's parts in among a window's and a door's (only the ones it has count)


def share(progress, i, n, stagger):
    """How far item i of n has got (0..1, not eased) at overall progress 0..1, each
    waiting for the one before by stagger (0: all together, 1: one after the next)."""
    progress = min(max(progress, 0.0), 1.0)
    if n <= 1:
        return progress
    duration = 1.0 / (1.0 + (n - 1) * stagger)
    return min(max((progress - i * stagger * duration) / duration, 0.0), 1.0)


def _pieces(builder):
    """[(point indices, group)] of the builder's separate solids (points joined by faces)."""
    parent = list(range(len(builder.points)))

    def root(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    group_of = {}
    for name, faces in builder.groups.items():
        for f in faces:
            group_of[f] = name
    face_group = {}
    for f, quad in enumerate(builder.polys):
        a = root(quad[0])
        for b in quad[1:]:
            rb = root(b)
            if rb != a:
                parent[rb] = a
        face_group[quad[0]] = group_of.get(f)
    pieces = {}
    for i in range(len(builder.points)):
        pieces.setdefault(root(i), []).append(i)
    out = []
    for r, idx in pieces.items():
        group = next((face_group[i] for i in idx if face_group.get(i)), None)
        out.append((idx, group))
    return out


def _stage(group):
    for n, names in enumerate(STAGES):
        if group in names:
            return n
    return len(STAGES)


def opening(builder, progress, style, stagger):
    """Move a finished window's or door's points (builder, in its own frame: x along the
    wall, y up, z across, the Exterior towards -Z) to where its own Build has them."""
    progress = min(max(progress, 0.0), 1.0)
    pts = builder.points
    if progress >= 1.0 or not pts:
        return
    if style == PARTS:
        pieces = _pieces(builder)
        stages = sorted({_stage(g) for _idx, g in pieces})
        for idx, group in pieces:
            t = smooth(share(progress, stages.index(_stage(group)), len(stages), stagger))
            cx = sum(pts[i].x for i in idx) / len(idx)
            cy = sum(pts[i].y for i in idx) / len(idx)
            cz = sum(pts[i].z for i in idx) / len(idx)
            for i in idx:  # each solid grows out of its own middle
                p = pts[i]
                p.x, p.y, p.z = cx + (p.x - cx) * t, cy + (p.y - cy) * t, cz + (p.z - cz) * t
        return
    t = smooth(progress)
    if t <= 0.0:  # not started: every point at the middle, so nothing shows
        cx, cy, cz = (sum(getattr(p, a) for p in pts) / len(pts) for a in "xyz")
        for p in pts:
            p.x, p.y, p.z = cx, cy, cz
        return
    if style == DROP:
        for p in pts:
            p.y += (1.0 - t) * DROP_BY
    elif style == RISE_IN:
        y0 = min(p.y for p in pts)
        for p in pts:
            p.y = y0 + (p.y - y0) * t
    elif style == SCALE:  # the whole window grows out of its middle
        cx, cy, cz = ((min(getattr(p, a) for p in pts) + max(getattr(p, a) for p in pts)) / 2 for a in "xyz")
        for p in pts:
            p.x, p.y, p.z = cx + (p.x - cx) * t, cy + (p.y - cy) * t, cz + (p.z - cz) * t
    else:  # SLIDE
        for p in pts:
            p.z -= (1.0 - t) * SLIDE_BY
