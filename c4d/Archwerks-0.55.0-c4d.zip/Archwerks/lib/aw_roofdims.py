"""Archwerks roof dimensions: the labels and grips a Roof and a Roof Cutter show in
AW Edit Dimensions, and what typing into them or dragging them does.

A Roof shows, while it is selected:
- each roof plane's pitch, on the plane (typed in degrees or as a pitch, 5:12;
  on a wall roof taking its pitch from the walls, typing one turns that off);
- the Eave Overhang and Rake Overhang, each on the first edge of its kind, from
  the outline (the walls' face, or the roof's own spline) out to the roof's edge;
- an axis roof's Width Left and Width Right, across its first stretch;
- the length of every side of the roof's own splines (typing one moves that
  side's end point along it: on an open spline every later point moves too).
A draft roof shows its planes' pitches only (its mesh sets them).

Grips (in the edit tool only, like a Wall's): one at the end of each overhang and
width line, and a corner grip on every point of the roof's own splines, which
moves it on the roof's eave plane.

A Roof Cutter shows its Width and Length (a Circle its Width across) with a grip
at the end of each.

The layouts are aw_dims layouts (aw_draw draws them, aw_edit applies what is
typed). Built in the roof's faces' space (aw_roof.faces), then carried into the
roof's own space by `to`.
"""
import math

import aw_dims as D
import aw_roof as R

SIDE_OUT = 40.0     # cm a side's length line sits beyond the roof's edge
LABEL_LIFT = 2.0    # cm a pitch label floats above the roof's top
CUT_OUT = 30.0      # cm a cutter's lines sit beyond its outline


def _dim(kind, value, a, b, **extra):
    return D._dim(kind, "wall", "x", value, a, b, **extra)


def _ext(edge, line):
    return D._ext(edge, line, "wall")


def _identity(p):
    return p


def layout(meta, splines=(), to=_identity):
    """(layout, grips) for a roof built with this meta (aw_roof.build fills it).
    splines: the roof's own editable splines, [{"child", "pts": [(x, y, z)], "closed",
    "linear"}] in its own space. grips: [(position, direction, kind, action)], kind
    "arrow" or "corner" (moves on a plane; direction is its normal)."""
    s = meta.get("settings") or {}
    pieces, frames = meta.get("pieces") or [], meta.get("frames") or {}
    thick = s.get("thick", 0.0)
    dims, ext, grips = [], [], []
    draft = meta.get("source") == "draft"

    def T(p):
        return tuple(to(p))

    # each plane's pitch, on the plane
    for fid, fr in sorted(frames.items()):
        own = [poly for e, poly in pieces if e == fid]
        if not own:
            continue
        poly = max(own, key=lambda q: abs(R.area(q)))
        cx = sum(p[0] for p in poly) / len(poly)
        cz = sum(p[1] for p in poly) / len(poly)
        y = fr.y((cx, cz)) + thick + LABEL_LIFT
        at = T((cx, y, cz))
        edit = None if draft else {"do": "roof_pitch", "scale": meta.get("scale", {}).get(fid, 1.0)}
        dims.append(_dim("slope", math.degrees(math.atan(fr.tan)), at, at, anchor="centre", edit=edit))

    # the overhangs, on the first edge of each kind
    done = set()
    for ol in meta.get("outlines", []):
        pts, kinds, outs = ol["pts"], ol["kinds"], ol["outs"]
        n = len(pts)
        for i in range(n):
            what = "eave" if kinds[i] == R.EAVE else "rake"
            if what in done or (what == "eave" and ol["type"] == "axis"):
                continue  # an axis roof's eaves have no overhang setting: its widths are the roof's edge
            nn, _d, _c = R._line(pts[i], pts[(i + 1) % n])
            o = (-nn[0], -nn[1])
            m = ((pts[i][0] + pts[(i + 1) % n][0]) / 2, (pts[i][1] + pts[(i + 1) % n][1]) / 2)
            b2 = (m[0] + o[0] * outs[i], m[1] + o[1] * outs[i])
            if what == "eave":
                y = ol["y_edge"]
            else:  # level across a gable edge: the roof's underside just inside it
                y = R.height_at(pieces, (b2[0] - o[0] * 0.05, b2[1] - o[1] * 0.05))
                y = ol["y_edge"] if y is None else y
            a, b = (m[0], y, m[1]), (b2[0], y, b2[1])
            dims.append(_dim(what, outs[i], T(a), T(b), grips=("b",), out=_dir(to, (0.0, -1.0, 0.0), a),
                             edit={"do": "roof_" + what}))
            grips.append((T(b), _dir(to, (o[0], 0.0, o[1]), b), "arrow", {"set": what, "from": T(a)}))
            done.add(what)

    # an axis roof's widths, across its first stretch
    axes = [ol for ol in meta.get("outlines", []) if ol["type"] == "axis"]
    if axes:
        ol = axes[0]
        p0, p1 = ol["path"][0], ol["path"][1]
        nn, _d, _c = R._line(p0, p1)
        m = ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2)
        y = ol["y_edge"]
        for what, sign, w in (("width_l", 1.0, s.get("width_l", 0.0)), ("width_r", -1.0, s.get("width_r", 0.0))):
            o = (nn[0] * sign, nn[1] * sign)
            a, b = (m[0], y, m[1]), (m[0] + o[0] * w, y, m[1] + o[1] * w)
            dims.append(_dim("axis_width", w, T(a), T(b), grips=("b",), out=_dir(to, (0.0, -1.0, 0.0), a),
                             edit={"do": "roof_" + what}))
            grips.append((T(b), _dir(to, (o[0], 0.0, o[1]), b), "arrow", {"set": what, "from": T(a)}))

    # the roof's own splines: every side's length, a corner grip on every point
    y = s.get("elevation", 0.0) + s.get("offset", 0.0)
    for sp in splines:
        P = [(p[0], p[2]) for p in sp["pts"]]
        if len(P) < 2:
            continue
        closed = sp["closed"] and len(P) >= 3
        ccw = R.area(P) > 0 if closed else True
        reach = (s.get("eave", 0.0) if closed else s.get("width_r", 0.0)) + SIDE_OUT
        count = len(P) if closed else len(P) - 1
        for k in range(count if sp.get("linear", True) else 0):
            p, q = P[k], P[(k + 1) % len(P)]
            if math.dist(p, q) < 1e-6:
                continue
            nn, _d, _c = R._line(p, q)
            sign = -1.0 if (not closed or ccw) else 1.0  # outside: right of the run, or away from the room
            o = (nn[0] * sign, nn[1] * sign)
            a = (p[0] + o[0] * reach, y, p[1] + o[1] * reach)
            b = (q[0] + o[0] * reach, y, q[1] + o[1] * reach)
            dims.append(_dim("side", math.dist(p, q), a, b, out=(o[0], 0.0, o[1]),
                             edit={"do": "roof_side", "child": sp["child"], "k": k}))
            ext.append(_ext((p[0], y, p[1]), a))
            if closed or k == count - 1:
                ext.append(_ext((q[0], y, q[1]), b))
        for i, (x, z) in enumerate(P):
            grips.append(((x, y, z), (0.0, 1.0, 0.0), "corner", {"point": (sp["child"], i)}))
    return {"dims": dims, "ext": ext, "outline": None, "grips": True}, grips


def _dir(to, d, at):
    """Direction d at point at, carried into the roof's space by `to`."""
    a = to(at)
    b = to((at[0] + d[0], at[1] + d[1], at[2] + d[2]))
    return tuple(bb - aa for aa, bb in zip(a, b))


def cutter_layout(shape, w, l):  # noqa: E741
    """(layout, grips) for a Roof Cutter in its own space (flat in XZ, centred)."""
    dims, ext, grips = [], [], []
    if shape == R.CUT_CUSTOM:
        return {"dims": [], "ext": [], "outline": None, "grips": True}, []
    half_l = w / 2 if shape == R.CUT_CIRCLE else l / 2
    z = -half_l - CUT_OUT
    dims.append(_dim("cut_width", w, (-w / 2, 0.0, z), (w / 2, 0.0, z), grips=("b",), out=(0.0, 0.0, -1.0),
                     edit={"do": "cut_width"}))
    ext += [_ext((-w / 2, 0.0, 0.0 if shape == R.CUT_CIRCLE else -half_l), (-w / 2, 0.0, z)),
            _ext((w / 2, 0.0, 0.0 if shape == R.CUT_CIRCLE else -half_l), (w / 2, 0.0, z))]
    grips.append(((w / 2, 0.0, z), (1.0, 0.0, 0.0), "arrow", {"set": "cut_width"}))
    if shape == R.CUT_RECTANGLE:
        x = w / 2 + CUT_OUT
        dims.append(_dim("cut_length", l, (x, 0.0, -l / 2), (x, 0.0, l / 2), grips=("b",), out=(1.0, 0.0, 0.0),
                         edit={"do": "cut_length"}))
        ext += [_ext((w / 2, 0.0, -l / 2), (x, 0.0, -l / 2)), _ext((w / 2, 0.0, l / 2), (x, 0.0, l / 2))]
        grips.append(((x, 0.0, l / 2), (0.0, 0.0, 1.0), "arrow", {"set": "cut_length"}))
    return {"dims": dims, "ext": ext, "outline": None, "grips": True}, grips


def pitch_for(degrees, scale):
    """The roof's Pitch (degrees) that gives a plane whose slope is `scale` times the
    Pitch's this slope."""
    if not 0.0 < degrees < 89.5:
        raise ValueError("a pitch must be between 0 and 89.5 degrees")
    return math.degrees(math.atan(math.tan(math.radians(degrees)) / max(scale, 1e-6)))


def move_side(pts, closed, k, value):
    """pts ([(x, y, z)]) with side k made `value` long by moving its end point along it:
    on a closed spline only that point, on an open one every later point too."""
    if value <= 0:
        raise ValueError("must be more than 0")
    n = len(pts)
    i, j = k, (k + 1) % n
    d = [pts[j][c] - pts[i][c] for c in (0, 2)]
    L = math.hypot(*d)
    if L < 1e-6:
        raise ValueError("that side has no length")
    dx, dz = d[0] / L * (value - L), d[1] / L * (value - L)
    moved = [j] if closed else list(range(j, n))
    out = list(pts)
    for m in moved:
        out[m] = (pts[m][0] + dx, pts[m][1], pts[m][2] + dz)
    return out


# Through the host (aw_host) -----------------------------------------------------


def cutter_grips(op):
    import aw_host
    import aw_ids as I
    v = lambda pid: aw_host.value(op, pid)  # noqa: E731
    return cutter_layout(int(v(I.AW_RCUT_SHAPE)), float(v(I.AW_RCUT_WIDTH)), float(v(I.AW_RCUT_LENGTH)))
