"""Archwerks Floors and Ceilings drawn from their own splines.

A Floor (or Ceiling) takes its shape from the splines under it, so it is edited
with Cinema 4D's own point tools rather than following a wall (that is the
Slab). Every closed loop of every child spline counts, curves included (their
interpolated line, not just their points), laid flat on the object's floor
plane: a loop inside another is a hole (a stair opening), one inside a hole is
an island again, and so on. Open loops are left out.

A Floor's top sits at Elevation and it is Thickness deep below it; a Ceiling's
underside sits at Elevation and it stands Thickness above it.

The outline maths (nest, bridge, triangulate) is pure, so it is tested outside C4D.
"""
import math

import aw_host

FLOOR, CEILING = 0, 1
GROUPS = ("Top", "Bottom", "Edge")


def area(pts):
    return sum(x0 * z1 - x1 * z0 for (x0, z0), (x1, z1) in zip(pts, pts[1:] + pts[:1])) / 2


def clean(pts):
    """Repeated points (and a repeated first point at the end) dropped."""
    out = []
    for p in pts:
        if not out or math.dist(p, out[-1]) > 1e-4:
            out.append((float(p[0]), float(p[1])))
    while len(out) > 1 and math.dist(out[0], out[-1]) <= 1e-4:
        out.pop()
    return out


def _inside(p, poly):
    """Even-odd: True when point p is inside polygon poly."""
    x, z = p
    hit = False
    n = len(poly)
    for i in range(n):
        (x0, z0), (x1, z1) = poly[i], poly[(i + 1) % n]
        if (z0 > z) != (z1 > z) and x < x0 + (z - z0) * (x1 - x0) / (z1 - z0):
            hit = not hit
    return hit


def nest(loops):
    """[(outline, [holes])] from closed loops: each loop's depth is how many others
    enclose it; even depths are outlines (counter-clockwise), odd ones holes
    (clockwise) of the outline just outside them."""
    loops = [clean(l) for l in loops]
    loops = [l for l in loops if len(l) >= 3 and abs(area(l)) > 1e-4]
    depth, parent = [], []
    for i, l in enumerate(loops):
        enclosing = [j for j, m in enumerate(loops) if j != i and _inside(l[0], m) and abs(area(m)) > abs(area(l))]
        depth.append(len(enclosing))
        parent.append(min(enclosing, key=lambda j: abs(area(loops[j]))) if enclosing else None)
    out = {}
    for i, l in enumerate(loops):
        if depth[i] % 2 == 0:
            out[i] = (l if area(l) > 0 else l[::-1], [])
    for i, l in enumerate(loops):
        if depth[i] % 2 == 1 and parent[i] in out:
            out[parent[i]][1].append(l if area(l) < 0 else l[::-1])
    return [out[i] for i in sorted(out)]


def _cross(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def _segments_cross(a, b, c, d):
    """True when segments ab and cd cross properly (touching at an end doesn't count)."""
    d1, d2, d3, d4 = _cross(c, d, a), _cross(c, d, b), _cross(a, b, c), _cross(a, b, d)
    return (d1 * d2 < -1e-9) and (d3 * d4 < -1e-9)


def bridge(outline, holes):
    """One polygon (a list of points, holes joined to the outline by bridges, each
    bridge walked both ways) and, for each of its points, its (ring, index): ring 0
    the outline, 1.. the holes. Holes go in from the rightmost one, each joined at
    its rightmost point to the nearest outline point it can see."""
    rings = [outline] + holes
    poly = [(0, i) for i in range(len(outline))]
    def pt(ref):
        return rings[ref[0]][ref[1]]
    order = sorted(range(1, len(rings)), key=lambda r: -max(x for x, _z in rings[r]))
    for r in order:
        hole = rings[r]
        m = max(range(len(hole)), key=lambda i: (hole[i][0], -hole[i][1]))
        mp = hole[m]
        edges = [(pt(poly[i]), pt(poly[(i + 1) % len(poly)])) for i in range(len(poly))]
        for rr in rings[1:]:
            edges += [(rr[i], rr[(i + 1) % len(rr)]) for i in range(len(rr))]
        best = None
        for k, ref in enumerate(poly):
            p = pt(ref)
            if math.dist(p, mp) < 1e-9:
                continue
            if any(_segments_cross(mp, p, a, b) for a, b in edges):
                continue
            dist = math.dist(p, mp)
            if best is None or dist < best[0]:
                best = (dist, k)
        if best is None:
            continue  # nothing visible: leave the hole out rather than break the floor
        k = best[1]
        loop = [(r, (m + i) % len(hole)) for i in range(len(hole) + 1)]  # round the hole, back to m
        poly = poly[:k + 1] + loop + [poly[k]] + poly[k + 1:]
    return [pt(ref) for ref in poly], poly


def triangulate(pts):
    """Ear clipping for a simple counter-clockwise polygon that may touch itself
    along bridges (repeated points): [(i, j, k)] into pts. A point sitting exactly
    on a candidate ear's corner doesn't stop it."""
    idx = list(range(len(pts)))
    tris = []
    guard = 0
    while len(idx) > 3 and guard < 100000:
        guard += 1
        n = len(idx)
        for e in range(n):
            i, j, k = idx[(e - 1) % n], idx[e], idx[(e + 1) % n]
            a, b, c = pts[i], pts[j], pts[k]
            if _cross(a, b, c) <= 1e-9:
                continue
            blocked = False
            for m in idx:
                if m in (i, j, k):
                    continue
                p = pts[m]
                if p in (a, b, c):
                    continue
                if _cross(a, b, p) >= -1e-9 and _cross(b, c, p) >= -1e-9 and _cross(c, a, p) >= -1e-9:
                    blocked = True
                    break
            if blocked:
                continue
            tris.append((i, j, k))
            idx.pop(e)
            break
        else:
            break
    if len(idx) == 3:
        tris.append(tuple(idx))
    return tris


def levels(kind, elevation, thick):
    """(bottom, top) of the slab."""
    t = max(thick, 0.1)
    return (elevation, elevation + t) if kind == CEILING else (elevation - t, elevation)


# Building (needs Cinema 4D) ----------------------------------------------------

def settings(op):
    import aw_ids as I
    return (CEILING if aw_host.type_id(op) == I.ID_AW_CEILING else FLOOR,
            float(aw_host.value(op, I.AW_FLOOR_ELEVATION)), float(aw_host.value(op, I.AW_FLOOR_THICKNESS)))


def loops(op):
    """Every closed loop of every child spline, (x, z) in op's space, curves sampled."""
    return aw_host.spline_paths(op)[0]


def build(op):
    """The floor's mesh in its own space, or None with no closed loop."""
    from aw_mesh import MeshBuilder
    kind, elevation, thick = settings(op)
    bottom, top = levels(kind, elevation, thick)
    mesh = MeshBuilder(GROUPS)
    for outline, holes in nest(loops(op)):
        mesh.new_part()
        first = len(mesh.polys)
        rings = [outline] + holes
        tp = [[mesh.pt(x, top, z) for x, z in ring] for ring in rings]
        bt = [[mesh.pt(x, bottom, z) for x, z in ring] for ring in rings]
        pts, refs = bridge(outline, holes)
        for i, j, k in triangulate(pts):  # counter-clockwise from above, as C4D winds an upward face
            (ri, ii), (rj, ij), (rk, ik) = refs[i], refs[j], refs[k]
            mesh.quad(tp[ri][ii], tp[rk][ik], tp[rj][ij], tp[rj][ij], "Top")
            mesh.quad(bt[ri][ii], bt[rj][ij], bt[rk][ik], bt[rk][ik], "Bottom")
        for r, ring in enumerate(rings):
            n = len(ring)
            for e in range(n):
                f = (e + 1) % n
                mesh.quad(tp[r][e], tp[r][f], bt[r][f], bt[r][e], "Edge")
        mesh._face_out(first)
    return mesh.build(aw_host.name(op)) if mesh.polys else None
