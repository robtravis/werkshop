"""The shared command list (core/aw_commands) in Cinema 4D: what each command does here,
and the Archwerks menu in the main menu bar built from it, a submenu per group.

A Cinema 4D menu entry is a registered command, so each command needs a plugin id
(aw_ids.COMMAND_IDS); one without an id yet is left out of the menu. A command that picks
from presets (Window, Cabinet...) opens a popup of them at the mouse, as the Archwerks
panel's preset buttons do in one click.
"""
import c4d

import aw_commands as K
import aw_ids as I


def _place(kind):
    def run(doc):
        import aw_place
        _pick(doc, aw_place.all_presets(kind), lambda p: aw_place.choose(doc, p))
    return run


def _pick(doc, presets, act, label=lambda p: p["label"]):
    """A popup of presets at the mouse; act(the chosen one)."""
    if not presets:
        c4d.gui.MessageDialog("No presets yet.")
        return
    bc = c4d.BaseContainer()
    for i, p in enumerate(presets):
        bc.InsData(c4d.FIRST_POPUP_ID + i, label(p))
    got = c4d.gui.ShowPopupDialog(cd=None, bc=bc, x=c4d.MOUSEPOS, y=c4d.MOUSEPOS)
    if got and got >= c4d.FIRST_POPUP_ID and got - c4d.FIRST_POPUP_ID < len(presets):
        act(presets[got - c4d.FIRST_POPUP_ID])


def _wall(doc):
    import aw_panel
    _pick(doc, aw_panel.PRESETS, lambda p: aw_panel.start_wall(doc, p), label=lambda p: p[0])


def _walls_from_spline(doc):
    c4d.CallCommand(I.ID_AW_WALLS_FROM_SPLINE)


def _floor(kind):
    def run(doc):
        import aw_floor
        import aw_floor_c4d
        import aw_panel
        if aw_panel.selected_splines(doc) or _selected_walls(doc):
            aw_floor_c4d.add_for_selection(doc, kind)
        else:
            aw_panel.start_floor(doc, kind)
    return run


def _selected_walls(doc):
    return [o for o in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE) if o.GetType() == I.ID_AW_WALL]


def _slab(doc):
    import aw_slab
    import aw_slab_c4d
    aw_slab_c4d.add_for_selection(doc, aw_slab.FLOOR)


def _stair(doc):
    import aw_stair_c4d
    aw_stair_c4d.add_for_selection(doc)


def _railing(doc):
    import aw_place
    import aw_railing_c4d
    _pick(doc, aw_place.all_presets(aw_place.RAILING), lambda p: aw_railing_c4d.add_for_selection(doc, p))


def _beam(doc):
    import aw_beam_c4d
    aw_beam_c4d.add(doc)


def _molding(crown):
    def run(doc):
        import aw_molding_c4d
        aw_molding_c4d.add_for_selection(doc, aw_molding_c4d.CROWN if crown else aw_molding_c4d.BASE)
    return run


def _wall_panels(doc):
    import aw_panels_c4d
    aw_panels_c4d.add_for_selection(doc)


def _countertop(doc):
    import aw_counter_c4d
    aw_counter_c4d.add_countertop(doc)


def _sink(doc):
    import aw_counter_c4d
    _pick(doc, list(aw_counter_c4d.SINK_PRESETS), lambda p: aw_counter_c4d.add_sink(doc, p))


def _add_pull(doc):
    import aw_panel
    aw_panel.Panel._add_pull(None, doc)


def _roof(doc):
    import aw_roof_c4d
    aw_roof_c4d.add_for_selection(doc)


def _roof_cutter(doc):
    import aw_roof_c4d
    aw_roof_c4d.add_cutter(doc)


def _tool(pid):
    def run(doc):
        doc.SetAction(pid)
        c4d.EventAdd()
    return run


def _floor_plan(doc):
    c4d.CallCommand(I.ID_AW_FLOOR_PLAN)


def _tidy(doc):
    import aw_groups_c4d
    n = aw_groups_c4d.tidy(doc)
    c4d.gui.StatusSetText("Sorted %d Archwerks objects into the Archwerks groups" % n)


LAYOUT_FILE = "Archwerks.l4d"


def _workspace(doc):
    """The Archwerks layout: yours, if you saved one as Archwerks.l4d in your layout folder
    (Window > Customization > Save Layout As); else this one arranged in place: a Top plan
    view beside Perspective, and the Archwerks panel."""
    import os
    folder = os.path.join(c4d.storage.GeGetC4DPath(c4d.C4D_PATH_LIBRARY_USER), "layout")
    saved = os.path.join(folder, LAYOUT_FILE)
    if os.path.isfile(saved) and c4d.documents.LoadFile(saved):
        return
    c4d.CallCommand(13622)  # 2 Views Side-by-Side
    for i, projection in ((0, c4d.Ptop), (1, c4d.Pperspective)):  # left, right
        bd = doc.GetBaseDraw(i)
        if bd is not None:  # a view's projection is its editor camera's
            bd.GetEditorCamera()[c4d.CAMERA_PROJECTION] = projection
    c4d.CallCommand(I.ID_AW_PANEL)
    c4d.EventAdd()
    c4d.gui.StatusSetText("Archwerks layout: arrange it as you like, then Window > Customization > Save Layout As, "
                          "named %s in your layout folder, and this command opens it from then on" % LAYOUT_FILE)


def _actions():
    import aw_floor
    import aw_place
    return {"wall": _wall, "walls_from_spline": _walls_from_spline, "floor": _floor(aw_floor.FLOOR),
            "ceiling": _floor(aw_floor.CEILING), "slab": _slab, "stair": _stair, "railing": _railing, "beam": _beam,
            "window": _place(aw_place.WINDOW), "door": _place(aw_place.DOOR), "archway": _place(aw_place.CUTTER),
            "fireplace": _place(aw_place.FIREPLACE), "baseboard": _molding(False), "crown": _molding(True),
            "wall_panels": _wall_panels, "cabinet": _place(aw_place.CABINET), "countertop": _countertop,
            "sink": _sink, "add_pull": _add_pull, "roof": _roof, "roof_cutter": _roof_cutter,
            "edit_dimensions": _tool(I.ID_AW_EDIT_TOOL), "floor_plan": _floor_plan,
            "scale_plan": _tool(I.ID_AW_SCALE_PLAN_TOOL), "tidy": _tidy, "workspace": _workspace}


def run(key, doc):
    """Do command key in doc."""
    action = _actions().get(key)
    if action is None:
        c4d.gui.StatusSetText("Archwerks: %s isn't in Cinema 4D yet" % K.BY_KEY[key]["label"])
        return
    action(doc)


def ids():
    """{command key: the plugin id its menu entry runs}: the commands registered for this
    plugin (aw_ids.COMMAND_IDS) and the four that have their own plugins."""
    out = {"walls_from_spline": I.ID_AW_WALLS_FROM_SPLINE, "floor_plan": I.ID_AW_FLOOR_PLAN,
           "edit_dimensions": I.ID_AW_EDIT_TOOL, "scale_plan": I.ID_AW_SCALE_PLAN_TOOL}
    out.update(I.COMMAND_IDS)
    return out


def menu():
    """The Archwerks menu: the panel, then a submenu per group of the commands with ids."""
    have = ids()
    top = c4d.BaseContainer()
    top.InsData(c4d.MENURESOURCE_SUBTITLE, "Archwerks")
    for key in K.TOP:
        if key in have:
            top.InsData(c4d.MENURESOURCE_COMMAND, "PLUGIN_CMD_%d" % have[key])
    top.InsData(c4d.MENURESOURCE_COMMAND, "PLUGIN_CMD_%d" % I.ID_AW_PANEL)
    top.InsData(c4d.MENURESOURCE_SEPARATOR, True)
    for _key, label, cmds in K.for_host("c4d"):
        entries = [c for c in cmds if c["key"] in have]
        if not entries:
            continue
        sub = c4d.BaseContainer()
        sub.InsData(c4d.MENURESOURCE_SUBTITLE, label)
        for c in entries:
            sub.InsData(c4d.MENURESOURCE_COMMAND, "PLUGIN_CMD_%d" % have[c["key"]])
        top.InsData(c4d.MENURESOURCE_SUBMENU, sub)
    return top
