"""Archwerks dimension editing, host-neutral: what typing a value into a wall's
dimension does, and the typing itself.

wall_edit() turns a typed value into changes: path points moved (in the wall's
space, the core's axes: y is a point's rise above the wall's Height) and settings
set. A host applies them (Cinema 4D: src/aw_edit.py, with its undo; Blender:
blender/labels.py) and rebuilds. It raises ValueError for a value that makes no
sense; the host shows that and changes nothing.

The typing part (InlineEdit and its parsers) turns keystrokes into a value, the
same in both hosts. Pure, so tests run without either.
"""
import math

import aw_ids as I

TOL = 1e-3

# Edits wall_edit() answers; anything else (roofs, cabinets, openings...) stays with its host.
WALL_EDITS = ("path_segment", "point_rise", "point_height", "segment_slope", "corner_angle",
              "wall_height", "wall_thickness")


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _segment_length(plan, points, k, value):
    """Make path segment k `value` long by moving its end point along it. On an open
    run every later point of that run moves with it, so the rest of the run keeps its
    shape; on a closed run only that corner moves. Other runs never move."""
    if not 0 <= k < len(plan.segments):
        raise ValueError("no such segment")
    seg = plan.segments[k]
    i, j = seg["ia"], seg["ib"]
    d = _sub(points[j], points[i])
    n = math.sqrt(sum(c * c for c in d))
    if n < 1e-6:
        raise ValueError("that segment has no length")
    delta = tuple(c / n * (value - n) for c in d)
    run = plan.runs[seg["run"]]
    ids = plan.ids[seg["run"]]
    moved = [j] if run.closed else ids[ids.index(j):]
    return {m: tuple(p + q for p, q in zip(points[m], delta)) for m in moved}, "segment %d" % (k + 1)


def _point_rise(points, height, i, rise):
    """Point i's y (its rise above the wall's Height) set to rise."""
    if not 0 <= i < len(points):
        raise ValueError("no such point")
    if height + rise < I.MIN_SIZE:
        raise ValueError("would put the wall below the floor there")
    x, _y, z = points[i]
    return {i: (x, rise, z)}, "point %d rise" % (i + 1)


def _slope(plan, points, height, k, degrees):
    """Give segment k this slope by moving its higher end; the lower end stays."""
    if not 0 < degrees < 89.5:
        raise ValueError("a slope must be between 0 and 89.5 degrees")
    if not 0 <= k < len(plan.segments):
        raise ValueError("no such segment")
    seg = plan.segments[k]
    low, i = (seg["ha"], seg["ib"]) if seg["hb"] >= seg["ha"] else (seg["hb"], seg["ia"])
    run = seg.get("u1", seg["length"]) - seg.get("u0", 0.0)  # the rake runs between the outside corners
    rise = low + math.tan(math.radians(degrees)) * (run if run > 1e-6 else seg["length"])
    moved, _label = _point_rise(points, height, i, rise)
    return moved, "segment %d slope" % (k + 1)


def _corner_turn(plan, points, k_in, degrees):
    """Make the corner after segment k_in turn this far (signed, left +, as Archipack;
    see aw_dims.corner_turn) by swinging the next segment round the corner, keeping
    its length. On an open run every later point swings with it, so the rest of the
    run keeps its shape; on a closed run only the next corner moves, so the loop
    stays closed."""
    import aw_dims
    if not -179.5 <= degrees <= 179.5:
        raise ValueError("a corner turns between -179.5 and 179.5 degrees (left +, right -)")
    match = [c for c in aw_dims.corners(plan) if c[0] == k_in]
    if not match:
        raise ValueError("that corner changed; select the wall again")
    _k_in, k_out, now = match[0]
    seg_out = plan.segments[k_out]
    turn = math.radians(degrees - now)  # more turn = the next wall swings left (towards +n)
    c, s = math.cos(turn), math.sin(turn)
    pivot = seg_out["a"]
    run = plan.runs[seg_out["run"]]
    ids = plan.ids[seg_out["run"]]
    moved = [seg_out["ib"]] if run.closed else ids[ids.index(seg_out["ib"]):]
    out = {}
    for m in moved:
        px, py, pz = points[m]
        x, z = px - pivot[0], pz - pivot[1]
        out[m] = (pivot[0] + x * c - z * s, py, pivot[1] + x * s + z * c)
    return out, "corner %d angle" % (k_in + 1)


def _meet(p, d, q, e):
    """Where the line p + s d meets the line q + t e, or None when they are parallel."""
    den = d[0] * e[1] - d[1] * e[0]
    if abs(den) < 1e-9:
        return None
    s = ((q[0] - p[0]) * e[1] - (q[1] - p[1]) * e[0]) / den
    return (p[0] + d[0] * s, p[1] + d[1] * s)


def move_side(a, b, before, after, shift):
    """A side a..b (plan points (x, z)) moved by shift (x, z), staying parallel to itself:
    each end slides along the side that meets it (from before to a, from b to after),
    so a rectangle stays a rectangle and an angled corner keeps its angle. An end with
    no neighbour (an open run's), or one along the side itself, moves straight by shift.
    Returns (a', b')."""
    d = (b[0] - a[0], b[1] - a[1])
    a1 = (a[0] + shift[0], a[1] + shift[1])
    out = []
    for end, other in ((a, before), (b, after)):
        moved = (end[0] + shift[0], end[1] + shift[1])
        if other is not None:
            hit = _meet(a1, d, other, (end[0] - other[0], end[1] - other[1]))
            if hit is not None:
                moved = hit
        out.append(moved)
    return out[0], out[1]


def side_ends(plan, k):
    """(point id before segment k's start, segment k's start id, its end id, the point id
    after its end) of a Plan: the ids of the side's neighbours None at an open run's ends."""
    seg = plan.segments[k]
    run = plan.runs[seg["run"]]
    ks = [j for j, s in enumerate(plan.segments) if s["run"] == seg["run"]]
    i = ks.index(k)
    prev = ks[i - 1] if i > 0 else (ks[-1] if run.closed and len(ks) > 2 else None)
    nxt = ks[i + 1] if i + 1 < len(ks) else (ks[0] if run.closed and len(ks) > 2 else None)
    return (plan.segments[prev]["ia"] if prev is not None else None, seg["ia"], seg["ib"],
            plan.segments[nxt]["ib"] if nxt is not None else None)


def rise_neighbours(plan, i):
    """[(point id, plan distance)] of the points either side of point i along its run (one
    at an open run's end), from plan's segments."""
    out = []
    for seg in plan.segments:
        if seg["ib"] == i:
            out.append((seg["ia"], seg["length"]))
        elif seg["ia"] == i:
            out.append((seg["ib"], seg["length"]))
    return out


def rise_targets(plan, i):
    """[(rise, why, neighbour id or None)] the rise of point i can snap to: 0 (Flat, at the
    wall's own height), each neighbour's rise (Level: the top edge to it flat, 0 degrees),
    and, between two neighbours, the rise where the two top edges meeting at i are square
    to each other (Perpendicular: a 45 degree gable when they're alike). Two top edges at
    slopes (r - a) / La and (r - b) / Lb are perpendicular when the slopes multiply to 1,
    so r solves (r - a)(r - b) = La Lb, the root above both."""
    heights = getattr(plan, "heights", None) or []
    rise = lambda j: heights[j] if 0 <= j < len(heights) else 0.0  # noqa: E731
    out = [(0.0, "Flat", None)]
    nbrs = rise_neighbours(plan, i)
    out += [(rise(j), "Level", j) for j, _L in nbrs]
    if len(nbrs) == 2:
        (ja, la), (jb, lb) = nbrs
        a, b = rise(ja), rise(jb)
        out.append(((a + b + math.sqrt((a - b) ** 2 + 4 * la * lb)) / 2, "Perpendicular", None))
    return out


def snap_rise(plan, i, rise, tol):
    """(rise, (why, neighbour id or None)) of point i: rise moved to the nearest of
    rise_targets within tol, else as it is with None."""
    best = None
    for target, why, j in rise_targets(plan, i):
        d = abs(target - rise)
        if d <= tol and (best is None or d < best[0]):
            best = (d, target, (why, j))
    return (best[1], best[2]) if best else (rise, None)


def wall_edit(edit, value, plan, height, points):
    """What typing value into a wall's dimension changes: {"points": {i: (x, y, z)},
    "params": {id: value}, "label": "segment 2"}. plan: the wall's aw_path.Plan;
    points: every path point (x, rise, z) in the wall's space, in plan order.
    Raises ValueError."""
    do = edit["do"]
    moved, params = {}, {}
    if do == "point_rise":  # how much taller (or shorter) than the wall's Height; can be negative
        moved, label = _point_rise(points, height, edit["i"], value)
    elif do == "segment_slope":
        moved, label = _slope(plan, points, height, edit["k"], value)
    elif do == "corner_angle":
        moved, label = _corner_turn(plan, points, edit["k"], value)
    elif value < I.MIN_SIZE:
        raise ValueError("must be more than 0")
    elif do == "path_segment":
        moved, label = _segment_length(plan, points, edit["k"], value)
    elif do == "point_height":  # the real height there
        moved, label = _point_rise(points, height, edit["i"], value - height)
    elif do in ("wall_height", "wall_thickness"):
        params[I.AW_WALL_HEIGHT if do == "wall_height" else I.AW_WALL_THICKNESS] = value
        label = "wall %s" % do[5:]
    else:
        raise ValueError("unknown edit %r" % do)
    return {"points": moved, "params": params, "label": label}


# Inline typing: a clicked label turns into a small text field drawn in the viewport.

UNITS_CM = {"mm": 0.1, "cm": 1.0, "m": 100.0, "km": 100000.0, "in": 2.54, '"': 2.54, "ft": 30.48, "'": 30.48,
            "yd": 91.44, "mi": 160934.4}
TYPABLE = set("0123456789.,-+ ") | set("mcikftnydi\"'") | set(":/\u00b0")
DEG = "\u00b0"


def parse_angle(text):
    """A typed slope in degrees: "22.5" or "22.5\u00b0", or a pitch, rise over run,
    "5:12" or "5/12" (5 up for every 12 across). Raises ValueError."""
    import math
    t = text.strip().replace(",", ".").replace(" ", "").rstrip(DEG)
    if not t:
        raise ValueError("nothing typed")
    for sep in (":", "/"):
        if sep in t:
            a, _, b = t.partition(sep)
            try:
                rise, run = float(a), float(b)
            except ValueError:
                raise ValueError("%r is not a pitch" % text)
            if run <= 0:
                raise ValueError("a pitch needs a run above 0")
            return math.degrees(math.atan2(rise, run))
    try:
        return float(t)
    except ValueError:
        raise ValueError("%r is not an angle" % text)


def unit_of(label_text):
    """The unit suffix a label shows ("cm" in "400 cm", "m" in "4.2 m"); "cm" if none."""
    tail = label_text.strip().lstrip("0123456789.,-+ ").strip()
    return tail if tail in UNITS_CM else "cm"


def parse_length(text, default_unit="cm"):
    """A typed length in cm. "120" uses default_unit; "1.2 m", "1200mm", "120cm" and
    "4ft" carry their own. A comma works as a decimal point. Raises ValueError."""
    t = text.strip().replace(",", ".").replace(" ", "")
    if not t:
        raise ValueError("nothing typed")
    unit = default_unit
    for u in sorted(UNITS_CM, key=len, reverse=True):  # "mm" before "m"
        if t.endswith(u):
            unit, t = u, t[: -len(u)]
            break
    try:
        number = float(t)
    except ValueError:
        raise ValueError("%r is not a length" % text)
    return number * UNITS_CM[unit]


COUNT = "beams"  # a count label's suffix


class InlineEdit:
    """Keystrokes for one label being edited. The text starts as the label's current
    number, selected, so the first character typed replaces it (as in a selected
    text field) and Backspace edits it instead."""

    def __init__(self, label_text):
        self.count = label_text.strip().endswith(COUNT)  # a whole number of things: "5 beams"
        if self.count:
            self.angle, self.unit, self.text, self.fresh = False, COUNT, label_text.strip()[:-len(COUNT)].strip(), True
            return
        self.angle = label_text.strip().endswith(DEG)  # a slope: degrees or a pitch
        if self.angle:
            self.unit, self.text, self.fresh = DEG, label_text.strip()[:-1].strip(), True
            return
        self.unit = unit_of(label_text)
        self.text = label_text.strip()[: len(label_text.strip()) - len(self.unit)].strip() \
            if label_text.strip().endswith(self.unit) else label_text.strip()
        self.fresh = True  # the whole text is selected

    def key(self, name, char=""):
        """name: "enter", "escape", "backspace", or "char" with char. Returns
        "commit", "cancel", or None (keep editing)."""
        if name == "enter":
            return "commit"
        if name == "escape":
            return "cancel"
        if name == "backspace":
            self.text = "" if self.fresh else self.text[:-1]
        elif name == "char" and char and all(c in TYPABLE for c in char):
            self.text = char if self.fresh else self.text + char
        else:
            return None  # anything else is ignored while editing
        self.fresh = False
        return None

    def value(self):
        if self.count:
            try:
                n = int(round(float(self.text.replace(",", "."))))
            except ValueError:
                raise ValueError("type a whole number")
            if n < 1:
                raise ValueError("needs at least 1")
            return float(n)
        return parse_angle(self.text) if self.angle else parse_length(self.text, self.unit)

    def shown(self):
        """What the field shows: the text, its unit when none was typed, and a cursor."""
        if self.count:
            return "%s %s|" % (self.text, COUNT) if self.text else "|"
        if self.angle:
            typed = ":" in self.text or "/" in self.text or self.text.endswith(DEG)
            return "%s%s|" % (self.text, "" if typed or not self.text else DEG)
        typed_unit = any(self.text.replace(" ", "").endswith(u) for u in UNITS_CM)
        return "%s%s|" % (self.text, "" if typed_unit or not self.text else " " + self.unit)
