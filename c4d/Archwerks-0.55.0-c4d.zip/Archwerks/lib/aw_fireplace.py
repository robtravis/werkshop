"""Archwerks fireplace geometry: what a Fireplace builds in and on its wall.

A Fireplace sits under a Wall like a window or door and shares their size parameters
(Width, Height, Sill Height, Start Offset): they are its firebox opening, which the
wall cuts through, so it places, grips and dimensions as they do. Built in its own
space like a door: the opening spans x0..x1 by y0..y1 and the wall runs z -thick/2
(Outside) .. +thick/2. Side puts it on the Inside face (+z, the default) or the Outside.

Its parts, all on that side (sizes in cm):
- Surround: a flat stone face round the opening, Surround Width beside it and Surround
  Top over it, standing Surround Depth off the wall, down to the hearth; its opening is
  Shape (Rectangle, Rounded Corners with Radius, Top Round, Top Elliptic with Rise), with
  a raised border (Bead) round it. Below an opening raised off the hearth, an apron.
  With a Facing its opening is its own, Opening Width by Opening Height from the hearth
  (the Shape is its), and a flat stone facing Facing Depth off the wall fills it round
  the firebox's plain rectangular opening, as a big cast-stone surround often has.
- Mantel: a shelf across the surround's top, past its face and ends, on a bed step.
- Hearth: a slab on the floor in front, past each side of the surround, and inside the
  firebox up to the opening's bottom.
- Firebox: lined with Liner thick brick, Depth deep from the wall face, its back
  Splay narrower each side. The hole through the wall is closed behind it (Back): flush
  with the wall's far face, or as a box standing out from it (a chimney) when the
  firebox is deeper than the wall; Keep Inside Wall keeps it (and its lining) within
  the wall's thickness instead. The grate and logs keep behind the screen's folds.
- Insert: a Grate (bars with upturned fingers, on legs), Logs on it, glass Doors (a Pair
  or Bifold, in a frame on the opening's face, with knobs; Doors Open swings them out)
  and a Screen of hanging chains behind them (Screen Open draws it back to the sides): two
  pleated curtains whose chains are their material's cut-out, so it stays a few faces.
"""
import math

import aw_cutter as C

GROUPS = ("Surround", "Mantel", "Hearth", "Firebox", "Back", "Grate", "Logs", "Log Ends", "Insert Frame", "Glass",
          "Screen", "Handle")
INSIDE, OUTSIDE = 0, 1
RECTANGLE, ROUNDED, ROUND, ELLIPTIC = range(4)
SHAPE_NAMES = ("Rectangle", "Rounded Corners", "Top Round", "Top Elliptic")
_CUTTER_SHAPE = {RECTANGLE: C.RECTANGLE, ROUNDED: C.ROUNDED, ROUND: C.ROUND, ELLIPTIC: C.ELLIPTIC}
NO_DOORS, PAIR, BIFOLD = 0, 1, 2

FRAME_W = 3.8    # the insert's frame
FRAME_D = 2.5    # how far it stands out of the opening
DOOR_W = 1.6     # a door's own frame round its glass
GLASS_T = 0.5
DOOR_SWING = math.radians(95.0)  # a pair at Doors Open 1
FOLD = math.radians(80.0)        # a bifold's leaves at Doors Open 1
KNOB = 2.2
BAR = 1.6        # the grate's bars
GRATE_LEGS = 7.0
FINGER = 9.0     # its bars' upturned fronts
LOG_R = 6.5
CHAIN_TILE = (1.5, 2.56)  # cm: one chain across, two links down: one tile of AW Chain Screen's cut-out
PLEAT = 10.0        # cm of curtain to a pleat
PLEAT_DEPTH = 0.6   # how deep its folds are, hung straight
SCREEN_BACK = 3.0   # how far behind the opening's face the chains hang
CLEAR = 1.5         # cm the grate and logs keep from the screen's folds and the firebox's back
GATHER = 0.85       # how much of its width a curtain gives up when drawn back


class Style:
    """Everything a fireplace is built from, besides its opening."""
    FIELDS = (("side", INSIDE), ("shape", ROUNDED), ("radius", 15.24), ("rise", 20.0), ("resolution", 32),
              ("surround", True), ("surround_side", 20.32), ("surround_top", 25.4), ("surround_d", 5.08),
              ("bead_w", 7.62), ("bead_d", 1.27),
              ("facing", False), ("facing_w", 116.84), ("facing_h", 101.6), ("facing_d", 2.54),
              ("mantel", True), ("shelf_t", 6.35), ("shelf_d", 7.62), ("shelf_side", 5.08), ("bed_h", 3.81),
              ("hearth", True), ("hearth_d", 50.8), ("hearth_side", 15.24), ("hearth_t", 2.54),
              ("depth", 50.8), ("liner", 10.16), ("splay", 10.16), ("inside_wall", False),
              ("grate", True), ("logs", 3), ("doors", NO_DOORS), ("doors_open", 0.0), ("screen", False),
              ("screen_open", 0.0))

    def __init__(self, **values):
        for name, default in self.FIELDS:
            setattr(self, name, values.pop(name, default))
        if values:
            raise TypeError("unknown fireplace settings: %s" % ", ".join(values))

    def key(self):
        return tuple(getattr(self, name) for name, _d in self.FIELDS)


def _jitter(i, k):
    """A steady pseudo-random number in -1..1 (the same on every rebuild)."""
    x = math.sin(i * 12.9898 + k * 78.233) * 43758.5453
    return (x - math.floor(x)) * 2.0 - 1.0


def _ccw(pts):
    out = []
    for p in pts:
        if not out or math.dist(p, out[-1]) > 1e-4:
            out.append(p)
    while len(out) > 1 and math.dist(out[0], out[-1]) <= 1e-4:
        out.pop()
    a = sum(xa * yb - xb * ya for (xa, ya), (xb, yb) in zip(out, out[1:] + out[:1]))
    return out if a > 0 else out[::-1]


def opening_top(x0, x1, y1, s, grow=0.0):
    """[(x, y)] left to right across the top of the opening's shape, grown by grow all
    round (the bead's outer edge); a Rectangle's two top corners."""
    w = x1 - x0 + 2 * grow
    radius = s.radius + grow if s.radius > 0 else 0.0
    if s.shape == ROUND and s.radius > 0:
        radius = max(radius, w / 2)
    cs = C.Style(shape=_CUTTER_SHAPE.get(s.shape, C.RECTANGLE), radius=radius, rise=s.rise + grow,
                 resolution=s.resolution)
    top = C.top_curve(x0 - grow, x1 + grow, y1 + grow, cs)
    return top or [(x0 - grow, y1 + grow), (x1 + grow, y1 + grow)]


def frame_top(x0, x1, y1, s):
    """Where a rectangular insert's top can go: the opening's top, or under an arch, at
    its springing line (with a Facing the firebox's opening is a plain rectangle)."""
    if getattr(s, "facing", False):
        return y1
    top = opening_top(x0, x1, y1, s)
    return min(top[0][1], top[-1][1]) if s.shape in (ROUND, ELLIPTIC) else y1


class _Builder:
    """Places parts given in (x, y, d), d out from the fireplace's wall face (into the
    room +, into the wall -), as the opening's (x, y, z)."""

    def __init__(self, mesh, thick, side):
        self.m, self.half = mesh, thick / 2
        self.sz = -1.0 if side == OUTSIDE else 1.0

    def z(self, d):
        return self.sz * (self.half + d)

    def box(self, x0, x1, y0, y1, d0, d1, group):
        za, zb = sorted((self.z(d0), self.z(d1)))
        self.m.box(min(x0, x1), max(x0, x1), min(y0, y1), max(y0, y1), za, zb, group)

    def prism(self, poly, d0, d1, group):
        """A solid: the outline poly [(x, y)] from d0 out to d1."""
        import aw_slab
        poly = _ccw(poly)
        if len(poly) < 3:
            return
        m = self.m
        m.new_part()
        first = len(m.polys)
        a = [m.pt(x, y, self.z(d0)) for x, y in poly]
        b = [m.pt(x, y, self.z(d1)) for x, y in poly]
        for i, j, k in aw_slab.triangulate(poly):
            m.quad(a[k], a[j], a[i], a[i], group)
            m.quad(b[i], b[j], b[k], b[k], group)
        n = len(poly)
        for e in range(n):
            f = (e + 1) % n
            m.quad(a[e], b[e], b[f], a[f], group)
        m._face_out(first)

    def face(self, pts, normal, group):
        """One face through pts [(x, y, d)], turned to face normal (x, y, d)."""
        m = self.m
        q = [(x, y, self.z(d)) for x, y, d in pts]
        nx, ny, nz = normal[0], normal[1], normal[2] * self.sz
        ux, uy, uz = (q[1][i] - q[0][i] for i in range(3))
        vx, vy, vz = (q[2][i] - q[0][i] for i in range(3))
        cross = (uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx)
        if cross[0] * nx + cross[1] * ny + cross[2] * nz < 0:
            q = q[::-1]
        m.new_part()
        idx = [m.pt(*p) for p in q]
        if len(idx) == 3:
            idx.append(idx[2])
        m.quad(idx[0], idx[1], idx[2], idx[3], group)

    def turned_box(self, hx, hd, angle, u0, u1, y0, y1, t0, t1, group):
        """A box u0..u1 along a leaf turned angle out of the wall plane about the upright
        at (hx, hd) (+angle towards the room), t0..t1 across it (toward the room +)."""
        c, s = math.cos(angle), math.sin(angle)

        def at(u, t):
            return hx + u * c - t * s, hd + u * s + t * c
        corners = {}
        for i, u in enumerate((u0, u1)):
            for k, t in enumerate((t0, t1)):
                x, d = at(u, t)
                for j, y in enumerate((y0, y1)):
                    corners[(i, j, k)] = (x, y, self.z(d))
        first = len(self.m.polys)
        self.m.hexa(corners, group)
        self.m._face_out(first)

    def log(self, cx, cy, cd, length, r, yaw, seed):
        """A rough log along x turned yaw about the vertical, centred at (cx, cy, cd):
        bark round it (Logs), end grain on its ends (Log Ends)."""
        m, sides, rings = self.m, 10, 5
        c, s = math.cos(yaw), math.sin(yaw)

        def put(u, a, rr):
            y, t = cy + rr * math.sin(a), rr * math.cos(a)
            return (cx + u * c - t * s, y, self.z(cd + u * s + t * c))
        m.new_part()
        first = len(m.polys)
        grid = []
        for i in range(rings):
            u = -length / 2 + length * i / (rings - 1)
            row = []
            for k in range(sides):
                rr = r * (1.0 + 0.08 * _jitter(seed * 31 + i, k))
                row.append(m.pt(*put(u, 2 * math.pi * k / sides, rr)))
            grid.append(row)
        for i in range(rings - 1):
            for k in range(sides):
                kk = (k + 1) % sides
                m.quad(grid[i][k], grid[i][kk], grid[i + 1][kk], grid[i + 1][k], "Logs")
        for row, u in ((grid[0], -length / 2), (grid[-1], length / 2)):
            centre = m.pt(*put(u, 0.0, 0.0))
            for k in range(sides):
                m.quad(centre, row[k], row[(k + 1) % sides], row[(k + 1) % sides], "Log Ends")
        m._face_out(first)


def surround_opening(x0, x1, y1, s, base):
    """(x0, x1, top) of the surround's opening: the firebox's, or with a Facing, Opening
    Width by Opening Height from the hearth, centred on it (never smaller than the firebox's)."""
    if not s.facing:
        return x0, x1, y1
    w = max(s.facing_w, (x1 - x0) + 2.0)
    h = max(s.facing_h, (y1 - base) + 2.0)
    cx = (x0 + x1) / 2
    return cx - w / 2, cx + w / 2, base + h


def _surround(b, x0, x1, y0, y1, s, base, fb):
    side, top = max(s.surround_side, 0.5), max(s.surround_top, 0.5)
    sx0, sx1, sy1 = surround_opening(x0, x1, y1, s, base)
    low = base if s.facing else fb  # with a facing its opening comes down to the hearth; the facing fills it
    xl, xr, H = sx0 - side, sx1 + side, sy1 + top
    d = max(s.surround_d, 0.2)
    inner = [(sx0, low)] + opening_top(sx0, sx1, sy1, s) + [(sx1, low)]
    b.prism([(xl, base), (sx0, base)] + inner + [(sx1, base), (xr, base), (xr, H), (xl, H)], 0.0, d, "Surround")
    if not s.facing and fb - base > 0.01:  # an opening raised off the hearth: the face below it
        b.box(x0, x1, base, fb, 0.0, d, "Surround")
    bw = min(max(s.bead_w, 0.0), side * 0.8, top * 0.8)
    if s.bead_d > 0.01 and bw > 0.1:  # the raised border round the opening
        outer = [(sx0 - bw, base)] + opening_top(sx0, sx1, sy1, s, bw) + [(sx1 + bw, base)]
        band = outer + [(sx1, base), (sx1, low)] + inner[::-1][1:-1] + [(sx0, low), (sx0, base)]
        b.prism(band, d, d + s.bead_d, "Surround")
    if s.facing:
        _facing(b, x0, x1, y1, sx0, sx1, sy1, s, base, fb)
    return xl, xr, H, d + max(s.bead_d, 0.0)


def _facing(b, x0, x1, y1, sx0, sx1, sy1, s, base, fb):
    """The flat stone between the surround's opening and the firebox's, Facing Depth off the
    wall (behind the surround's face), down to the hearth."""
    d = min(max(s.facing_d, 0.2), max(s.surround_d, 0.4) - 0.1)
    b.prism([(sx0, base)] + opening_top(sx0, sx1, sy1, s) + [(sx1, base), (x1, base), (x1, y1), (x0, y1), (x0, base)],
            0.0, d, "Surround")
    if fb - base > 0.01:  # a firebox raised off the hearth: the facing below it
        b.box(x0, x1, base, fb, 0.0, d, "Surround")


def _firebox(b, x0, x1, y0, y1, thick, s, fb):
    L = min(max(s.liner, 0.5), (x1 - x0) / 3, (y1 - fb) / 3)
    depth = max(s.depth, L + 1.0)
    if s.inside_wall:  # no deeper than its wall, its lining too: no chimney box out the back
        L = min(L, thick / 3)
        depth = min(depth, thick - L)
    sp = min(max(s.splay, 0.0), (x1 - x0) / 2 - L - 2.0)
    ia, ib, top = x0 + L, x1 - L, y1 - L
    ba, bb, back = ia + sp, ib - sp, -depth
    face = b.face
    # its lining's front, round the opening
    face([(x0, fb, 0), (ia, fb, 0), (ia, top, 0), (x0, y1, 0)], (0, 0, 1), "Firebox")
    face([(ib, fb, 0), (x1, fb, 0), (x1, y1, 0), (ib, top, 0)], (0, 0, 1), "Firebox")
    face([(x0, y1, 0), (ia, top, 0), (ib, top, 0), (x1, y1, 0)], (0, 0, 1), "Firebox")
    # inside: the splayed sides, the back, the floor and the top, all facing in
    face([(ia, fb, 0), (ba, fb, back), (ba, top, back), (ia, top, 0)], (1, 0, 0), "Firebox")
    face([(ib, fb, 0), (ib, top, 0), (bb, top, back), (bb, fb, back)], (-1, 0, 0), "Firebox")
    face([(ba, fb, back), (bb, fb, back), (bb, top, back), (ba, top, back)], (0, 0, 1), "Firebox")
    face([(ia, fb, 0), (ib, fb, 0), (bb, fb, back), (ba, fb, back)], (0, 1, 0), "Hearth")
    face([(ia, top, 0), (ba, top, back), (bb, top, back), (ib, top, 0)], (0, -1, 0), "Firebox")
    if fb - y0 > 0.01:  # the firebox's floor, up to the opening's bottom
        b.box(x0, x1, y0, fb, -thick, 0.0, "Hearth")
    if depth + L <= thick + 0.01:  # the hole closed behind it, flush with the wall's far face
        face([(x0, y0, -thick), (x1, y0, -thick), (x1, y1, -thick), (x0, y1, -thick)], (0, 0, -1), "Back")
    else:  # deeper than the wall: a box out of its far face (a chimney's back), open to the wall
        e = -(depth + L)
        face([(x0, y0, e), (x1, y0, e), (x1, y1, e), (x0, y1, e)], (0, 0, -1), "Back")
        face([(x0, y0, -thick), (x0, y0, e), (x0, y1, e), (x0, y1, -thick)], (-1, 0, 0), "Back")
        face([(x1, y0, -thick), (x1, y1, -thick), (x1, y1, e), (x1, y0, e)], (1, 0, 0), "Back")
        face([(x0, y1, -thick), (x0, y1, e), (x1, y1, e), (x1, y1, -thick)], (0, 1, 0), "Back")
        face([(x0, y0, -thick), (x1, y0, -thick), (x1, y0, e), (x0, y0, e)], (0, -1, 0), "Back")
    return ia, ib, ba, bb, top, back


def _grate(b, cx, half, fb, front, back, s):
    """The grate, centred at cx, half wide, from front to back; returns its top."""
    n = max(3, int(2 * half / 5.0))
    ytop = fb + GRATE_LEGS + BAR
    for i in range(n):
        x = cx - half + 2 * half * i / (n - 1)
        b.box(x - BAR / 2, x + BAR / 2, fb + GRATE_LEGS, ytop, back, front, "Grate")
        b.box(x - BAR / 2, x + BAR / 2, ytop, ytop + FINGER, front - BAR, front, "Grate")
    for d in (front - 3.0, back + 3.0):
        b.box(cx - half - 1.0, cx + half + 1.0, fb + GRATE_LEGS - BAR, fb + GRATE_LEGS, d - BAR / 2, d + BAR / 2,
              "Grate")
        for x in (cx - half, cx + half):
            b.box(x - BAR / 2, x + BAR / 2, fb, fb + GRATE_LEGS - BAR, d - BAR / 2, d + BAR / 2, "Grate")
    return ytop


def _logs(b, cx, half, rest, front, back, count):
    """count logs on the grate (or the hearth at rest): two side by side, the rest on top,
    each wholly between front and back (a log turned across reaches forward with its
    end: it turns less, or sits back, rather than reach into the screen or the back wall)."""
    mid, gap = (front + back) / 2, (front - back) * 0.22
    length = 2 * half * 1.15
    spots = [(cx - 1.5, rest + LOG_R, mid + gap, 0.05), (cx + 1.5, rest + LOG_R * 0.95, mid - gap, -0.07),
             (cx, rest + LOG_R * 2.55, mid, 0.28), (cx - half * 0.3, rest + LOG_R * 3.6, mid + gap * 0.4, -0.45),
             (cx + half * 0.35, rest + LOG_R * 3.4, mid - gap * 0.6, 0.6)]
    room = (front - back) / 2
    for i, (x, y, d, yaw) in enumerate(spots[:max(0, min(count, len(spots)))]):
        r = min(LOG_R * (1.0 - 0.08 * i + 0.06 * _jitter(i, 7)), room * 0.95)  # thinner in a shallow firebox
        ln = length * (1.0 - 0.12 * (i >= 2))
        most = max(room - r, 0.0) / (ln / 2)  # how far round it can turn and still fit
        if abs(math.sin(yaw)) > most:
            yaw = math.copysign(math.asin(min(most, 1.0)), yaw)
        reach = r + abs(math.sin(yaw)) * ln / 2
        d = min(max(d, back + reach), front - reach) if front - back > 2 * reach else mid
        b.log(x, y, d, ln, r, yaw, i + 1)


def _doors(b, x0, x1, fb, ftop, s):
    """The insert: a frame on the opening's face and glass doors in it."""
    fw, fd = FRAME_W, FRAME_D
    b.box(x0, x0 + fw, fb, ftop, 0.0, fd, "Insert Frame")
    b.box(x1 - fw, x1, fb, ftop, 0.0, fd, "Insert Frame")
    b.box(x0 + fw, x1 - fw, ftop - fw, ftop, 0.0, fd, "Insert Frame")
    b.box(x0 + fw, x1 - fw, fb, fb + fw * 0.6, 0.0, fd, "Insert Frame")
    ia, ib, y0, y1 = x0 + fw, x1 - fw, fb + fw * 0.6, ftop - fw
    t = min(max(s.doors_open, 0.0), 1.0)
    leaves = 2 if s.doors == BIFOLD else 1
    width = (ib - ia) / 2 / leaves
    for side in (-1, 1):  # the left door hinges at ia, the right at ib, both swinging out
        hx = ia if side < 0 else ib
        hd = fd
        if leaves == 1:
            pieces = [(hx, hd, (DOOR_SWING * t) if side < 0 else math.pi - DOOR_SWING * t)]
        else:
            a = FOLD * t
            first = a if side < 0 else math.pi - a
            ex, ed = hx + width * math.cos(first), hd + width * math.sin(first)
            pieces = [(hx, hd, first), (ex, ed, -a if side < 0 else math.pi + a)]
        for n, (px, pd, ang) in enumerate(pieces):
            _leaf(b, px, pd, ang, width, y0, y1, knob=(n == len(pieces) - 1), facing=1.0 if side < 0 else -1.0)


def _leaf(b, hx, hd, ang, width, y0, y1, knob, facing):
    """One glass door width wide from its hinge at (hx, hd), turned ang (0: along +x).
    facing: +1 when the leaf's +t side is the room side (a left door), -1 for a right one."""
    w, t = DOOR_W, 1.2

    def tb(u0, u1, ya, yb, t0, t1, group):
        ta, tz = sorted((t0 * facing, t1 * facing))
        b.turned_box(hx, hd, ang, u0, u1, ya, yb, ta, tz, group)
    tb(0.0, w, y0, y1, 0.0, t, "Insert Frame")
    tb(width - w, width, y0, y1, 0.0, t, "Insert Frame")
    tb(w, width - w, y0, y0 + w, 0.0, t, "Insert Frame")
    tb(w, width - w, y1 - w, y1, 0.0, t, "Insert Frame")
    tb(w, width - w, y0 + w, y1 - w, (t - GLASS_T) / 2, (t + GLASS_T) / 2, "Glass")
    if knob:  # near its free edge, on the room side
        ty = (y0 + y1) / 2
        tb(width - w - KNOB - 1.0, width - w - 1.0, ty - KNOB / 2, ty + KNOB / 2, t, t + KNOB, "Handle")


def screen_reach(ia, ib):
    """How far a drawn-back screen's folds reach either side of where it hangs."""
    half = (ib - ia) / 2
    n = max(2, int(round(half / PLEAT)))
    run = half / (2 * n)
    step = half * (1.0 - GATHER) / (2 * n)
    return (math.sqrt(max(run * run - step * step, 0.0)) + PLEAT_DEPTH) / 2


def _screen(b, ia, ib, fb, top, s):
    """A chain screen behind the doors: two curtains hung from a rod, meeting in the middle,
    each a pleated sheet whose chains are its material's cut-out (AW Chain Screen, mapped a
    chain to a CHAIN_TILE), not geometry: a few faces, however wide the fireplace. Drawn back
    (Screen Open), a curtain gathers to its side in deeper pleats, its chains' length kept."""
    d = -SCREEN_BACK
    rod_y = top - 1.5
    b.box(ia, ib, rod_y, rod_y + 1.2, d - 0.6, d + 0.6, "Screen")
    t = min(max(s.screen_open, 0.0), 1.0)
    half = (ib - ia) / 2
    width = half * (1.0 - GATHER * t)
    n = max(2, int(round(half / PLEAT)))          # pleats each side
    step = width / (2 * n)
    run = half / (2 * n)                          # the sheet's own length between folds
    deep = math.sqrt(max(run * run - step * step, 0.0)) + PLEAT_DEPTH  # gathered: deeper folds
    m = b.m
    y0, y1 = fb + 0.5, rod_y
    tu, tv = 100.0 / CHAIN_TILE[0], 100.0 / CHAIN_TILE[1]  # one tile of the texture per chain, link pair
    for side, start in ((1.0, ia), (-1.0, ib)):
        m.new_part()
        cols = []
        for i in range(2 * n + 1):
            x = start + side * step * i
            dd = d + (deep / 2 if i % 2 else -deep / 2)
            cols.append((m.pt(x, y0, b.z(dd)), m.pt(x, y1, b.z(dd)), run * i))
        for (a0, a1, ua), (c0, c1, uc) in zip(cols, cols[1:]):
            uv = [(ua * tu, y0 * tv), (uc * tu, y0 * tv), (uc * tu, y1 * tv), (ua * tu, y1 * tv)]
            if side < 0:
                m.quad(c0, a0, a1, c1, "Screen", [uv[1], uv[0], uv[3], uv[2]])
            else:
                m.quad(a0, c0, c1, a1, "Screen", uv)


def build(name, x0, x1, y0, y1, thick, style=None, custom=None):
    """The fireplace for an opening x0..x1 by y0..y1 in a wall thick deep."""
    from aw_mesh import MeshBuilder
    s = style or Style()
    mesh = MeshBuilder(GROUPS)
    b = _Builder(mesh, thick, s.side)
    base = max(s.hearth_t, 0.1) if s.hearth else 0.0
    fb = max(y0, base)  # the firebox's floor
    if s.surround:
        xl, xr, H, front = _surround(b, x0, x1, y0, y1, s, base, fb)
    else:
        xl, xr, H, front = x0, x1, y1, 0.0
    if s.mantel:
        ss, sd = max(s.shelf_side, 0.0), max(s.shelf_d, 0.0)
        b.box(xl - ss, xr + ss, H, H + max(s.shelf_t, 0.5), 0.0, front + sd, "Mantel")
        if s.bed_h > 0.01:
            b.box(xl - ss / 2, xr + ss / 2, H - s.bed_h, H, 0.0, front + sd / 2, "Mantel")
    if s.hearth:
        hs = max(s.hearth_side, 0.0)
        b.box(xl - hs, xr + hs, 0.0, base, 0.0, max(s.hearth_d, front + 1.0), "Hearth")
    ia, ib, ba, bb, top, back = _firebox(b, x0, x1, y0, y1, thick, s, fb)
    cx = (x0 + x1) / 2
    half = max(min((bb - ba) / 2 * 0.8, (ib - ia) / 2 * 0.62), 6.0)
    front_lim = -(SCREEN_BACK + screen_reach(ia, ib) + CLEAR) if s.screen else -CLEAR  # clear of the screen
    back_lim = back + CLEAR
    front_g = min(back * 0.18, front_lim)
    back_g = max(back * 0.82, back_lim)
    if front_g - back_g < 8.0:  # a shallow firebox: the grate takes what there is
        front_g, back_g = front_lim, min(back_lim, front_lim - 8.0)
    rest = fb
    if s.grate:
        rest = _grate(b, cx, half, fb, front_g, back_g, s)
    if s.logs:
        _logs(b, cx, half, rest, front_g, back_g, int(s.logs))
    if s.screen:
        _screen(b, ia, ib, fb, top, s)
    if s.doors in (PAIR, BIFOLD):
        _doors(b, x0, x1, fb, frame_top(x0, x1, y1, s), s)
    return mesh.build(name)


def settings(op):
    """The Style of a Fireplace; parameters it predates read as their defaults."""
    import aw_host
    import aw_ids as I
    defaults = dict(Style.FIELDS)
    values = {}
    for name, pid in I.AW_FP_STYLE_PARAMS:
        v = aw_host.value(op, pid)
        values[name] = defaults[name] if v is None else type(defaults[name])(v)
    return Style(**values)


def custom_handle(op):
    return None, None  # nothing linked
