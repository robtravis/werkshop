"""Archwerks' Cinema 4D host: what the core (archwerks/core) asks of the application,
answered for Cinema 4D, and registered with aw_host when this module loads. What
belongs to one kind of object is registered by its own adapter (aw_wall_c4d: the
wall's curves and cutters).
"""
import c4d

import aw_host
import aw_lib
from aw_mat import Mat
from aw_vec import Vec


# Custom handles: the linked object's polygons, in its own space.

def custom_mesh(obj):
    """(points, polys) of everything obj shows, in obj's own space (its generators'
    and deformers' results, its child objects), or None with nothing to show."""
    if obj is None or not obj.IsAlive():
        return None
    inv = ~obj.GetMg()
    points, polys = [], []

    def add(poly):
        m = inv * poly.GetMg()
        base = len(points)
        points.extend(m * p for p in poly.GetAllPoints())
        for cp in poly.GetAllPolygons():
            polys.append((base + cp.a, base + cp.b, base + cp.c, base + cp.d))

    def walk(o):
        while o is not None:
            dc, cache = o.GetDeformCache(), o.GetCache()
            if dc is not None:
                walk(dc)
            elif cache is not None:
                walk(cache)
            elif not o.GetBit(c4d.BIT_CONTROLOBJECT) and o.GetType() == c4d.Opolygon:
                add(o)
            if not (cache is not None and o.GetInfo() & c4d.OBJECT_INPUT):  # a generator's inputs are in its cache
                walk(o.GetDown())
            o = o.GetNext() if o is not obj else None
    walk(obj)
    return (points, polys) if polys else None


def custom_key(obj):
    """Changes whenever the linked object (or anything under it) does."""
    if obj is None or not obj.IsAlive():
        return None
    return (obj.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX | c4d.DIRTYFLAGS_CACHE),
            obj.GetHDirty(c4d.HDIRTYFLAGS_OBJECT | c4d.HDIRTYFLAGS_OBJECT_HIERARCHY))


def spline_paths(op, skip=(), with_y=False):
    """([closed loops], [open runs]) of op's child splines, (x, z) in op's space
    ((x, y, z) with_y), curves sampled evenly by length; children whose type is in
    skip are passed over."""
    import c4d
    closed_out, open_out = [], []
    for child in op.GetChildren():
        if not child.GetInfo() & c4d.OBJECT_ISSPLINE or not child.GetDeformMode() or child.GetType() in skip:
            continue
        real = child.GetRealSpline()
        if real is None:
            continue
        ml = child.GetMl()
        closed_all = bool(real.IsClosed())
        n = real.GetPointCount()
        count = real.GetSegmentCount()
        segs = [real.GetSegment(k) for k in range(count)] if count else [{"cnt": n, "closed": closed_all}]
        curved = real.GetInterpolationType() != c4d.SPLINETYPE_LINEAR
        sh = None
        if curved:
            sh = c4d.utils.SplineHelp()
            if not sh.InitSplineWith(real, c4d.SPLINEHELPFLAGS_USERDEFORMERS):
                sh = None
        off = 0
        for k, seg in enumerate(segs):
            cnt = seg["cnt"]
            closed = bool(seg["closed"] or closed_all)
            if sh is not None:  # sampled along the curve, evenly by length
                steps = max(16, min(512, cnt * 12))
                ts = [i / steps for i in range(steps)] + ([] if closed else [1.0])
                pts = [ml * sh.GetPosition(t, k, True) for t in ts]
            else:
                pts = [ml * real.GetPoint(off + i) for i in range(cnt)]
            (closed_out if closed else open_out).append([(p.x, p.y, p.z) if with_y else (p.x, p.z) for p in pts])
            off += cnt
        if sh is not None:
            sh.FreeSpline()
    return closed_out, open_out


def _stored(obj, pid):
    return obj[pid]


def _name(obj):
    return obj.GetName()


def _alive(obj):
    return obj is not None and obj.IsAlive()


def _type_id(obj):
    return obj.GetType() if obj is not None else None


def to_mat(m):
    """A c4d.Matrix as the core's aw_mat.Mat."""
    v = lambda p: Vec(p.x, p.y, p.z)  # noqa: E731
    return Mat(v(m.off), v(m.v1), v(m.v2), v(m.v3))


def to_vec(p):
    return Vec(p.x, p.y, p.z)


def to_matrix(m):
    """The core's aw_mat.Mat as a c4d.Matrix."""
    v = lambda p: c4d.Vector(p.x, p.y, p.z)  # noqa: E731
    return c4d.Matrix(v(m.off), v(m.v1), v(m.v2), v(m.v3))


def _local_matrix(obj):
    return to_mat(obj.GetMl())


def _relative(obj, other):
    return to_mat(~obj.GetMg() * other.GetMg())


def _spline_points(spline):
    if not _alive(spline) or not spline.GetInfo() & c4d.OBJECT_ISSPLINE:
        return None
    real = spline.GetRealSpline()
    if real is None or real.GetPointCount() < 3:
        return None
    return [(p.x, p.y) for p in real.GetAllPoints()]


def _children(obj):
    return [c for c in obj.GetChildren() if c.GetDeformMode()]


def _curve_points(obj):
    for child in obj.GetChildren():
        real = child.GetRealSpline() if child.GetInfo() & c4d.OBJECT_ISSPLINE else None
        if real is not None and real.GetPointCount() >= 3:
            ml = child.GetMl()
            return [(p.x, p.y, p.z) for p in (ml * q for q in real.GetAllPoints())]
    return None


def scan(doc, type_id):
    """Every object of that type in doc, depth first."""
    out = []
    stack = [doc.GetFirstObject()] if doc is not None else []
    while stack:
        o = stack.pop()
        while o:
            if o.GetType() == type_id:
                out.append(o)
            if o.GetDown():
                stack.append(o.GetDown())
            o = o.GetNext()
    return out


def _objects(obj, type_id):
    return scan(obj.GetDocument(), type_id)


def _object_list(obj, pid):
    lst, doc = obj[pid], obj.GetDocument()
    if lst is None or doc is None:
        return []
    out = [lst.ObjectFromIndex(doc, i) for i in range(lst.GetObjectCount())]
    return [o for o in out if o is not None and o.IsAlive()]


def _undo_change(obj):
    doc = obj.GetDocument()
    if doc is not None:
        doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)


def _move(obj, vec, undo=False):
    if undo:
        _undo_change(obj)
    mg = obj.GetMg()
    mg.off += c4d.Vector(vec.x, vec.y, vec.z)
    obj.SetMg(mg)


def _animated(obj, pid):
    return obj.FindCTrack(c4d.DescID(c4d.DescLevel(pid, c4d.DTYPE_REAL, 0))) is not None


def _sample_curve(spline):
    if not _alive(spline):
        return None
    real = spline.GetRealSpline() if hasattr(spline, "GetRealSpline") else None
    if real is None:
        return None
    sh = c4d.utils.SplineHelp()
    if not sh.InitSplineWith(real, c4d.SPLINEHELPFLAGS_USERDEFORMERS | c4d.SPLINEHELPFLAGS_RETAINLINEOBJECT):
        return None
    n = max(8, min(256, real.GetPointCount() * 8))
    pts = [sh.GetPosition(i / n, 0) for i in range(n)]
    sh.FreeSpline()
    return [(p.x, p.y, p.z) for p in pts]


def _shown_points(obj):
    cache = obj.GetCache()
    if cache is None or cache.GetType() != c4d.Opolygon:
        return None
    ml = obj.GetMl() * cache.GetMl()
    return [(p.x, p.y, p.z) for p in (ml * q for q in cache.GetAllPoints())]


def _set_value(obj, pid, v, undo=False):
    if undo:
        _undo_change(obj)
    obj[pid] = v


def _pull_library():
    import aw_pulls_c4d
    return aw_pulls_c4d.library()


aw_host.register(stored=_stored, link=_stored, custom_mesh=custom_mesh, custom_key=custom_key,
                 mesh_object=aw_lib.to_object, name=_name, spline_paths=spline_paths, alive=_alive, type_id=_type_id,
                 relative=_relative, local_matrix=_local_matrix, spline_points=_spline_points, set_value=_set_value,
                 pull_library=_pull_library, children=_children, curve_points=_curve_points,
                 parent=lambda obj: obj.GetUp(), world_matrix=lambda obj: to_mat(obj.GetMg()), objects=_objects,
                 object_list=_object_list, move=_move, undo_change=_undo_change, animated=_animated,
                 sample_curve=_sample_curve, shown_points=_shown_points)
