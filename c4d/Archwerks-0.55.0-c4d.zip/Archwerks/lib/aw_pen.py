"""Archwerks pen: the plan-view maths of drawing a path point by point, as Cinema 4D's
Spline Pen does: where the next point lands (snapped to a point or onto an edge,
lined up with the last point along X or Y, lined up with any other point, or held to
45 degree steps), and the typed length and angle that place one exactly.

Pure (no host), so it is tested on its own. Points are (x, y) on the floor plane in
any one unit; the snap tolerance is in that unit too (a host turns its pixel
threshold into one at the cursor). Angles are degrees counter-clockwise from +X.
Typed lengths come back in centimetres, the core's unit.
"""
import math
import re

LOCK_STEP = 45.0     # degrees between the directions a held Shift allows
LAST_BIAS = 0.5      # the last point's own X/Y lines win over another point's this much sooner

# Centimetres per unit a length may be typed in.
UNITS = {"mm": 0.1, "cm": 1.0, "m": 100.0, "km": 100000.0,
         "in": 2.54, '"': 2.54, "ft": 30.48, "'": 30.48, "yd": 91.44}
_FEET = ("ft", "'")
_TOKEN = re.compile(r"\s*([+-]?(?:\d+\.?\d*|\.\d+)(?:\s*/\s*\d+)?)\s*(mm|cm|km|m|in|ft|yd|\"|')?", re.I)


def _dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def _unit(v):
    n = math.hypot(v[0], v[1])
    return (v[0] / n, v[1] / n) if n > 1e-12 else None


class Pick:
    """Where the next point goes: point, the index of the target it landed on (or None),
    the guides that put it there, each {"axis": "x" or "y" (a line along world X or Y
    through ref) or "dir" (the locked direction from ref), "ref": (x, y), "last": True
    when ref is the last point}, the edge ((x, y), (x, y)) it landed on (or None), and
    kind: "point", "edge", "perpendicular" or None (free, or only lined up)."""

    def __init__(self, point, target=None, guides=(), edge=None, kind=None):
        self.point = (float(point[0]), float(point[1]))
        self.target = target
        self.guides = list(guides)
        self.edge = edge
        self.kind = kind if kind is not None else ("point" if target is not None else None)


def solve(cursor, last, targets, tol, lock=False, edges=(), perpendicular=False, onto=True):
    """The Pick for the cursor at (x, y). last: the stroke's last point (None before the
    first); targets: the points it may snap to and line up with; tol: how near counts;
    edges: segments ((x, y), (x, y)) it may snap onto (a wall's faces, a path's runs).
    A target within tol wins. Held to 45 degrees (lock): the locked line, stopping where
    it crosses an edge or another point's X or Y line. Else X and Y each line up on their
    own with the nearest point within tol (the last point first), so two can meet; and
    near an edge the point goes onto it: square to it from the last point (perpendicular),
    or where a guide crosses it, or straight across from the cursor. onto=False: edges
    only take a perpendicular (Blender's Edge Perpendicular without Edge)."""
    cursor = (float(cursor[0]), float(cursor[1]))
    near = [(i, _dist(cursor, p)) for i, p in enumerate(targets) if _dist(cursor, p) <= tol]
    if near and not (lock and last is not None):
        i = min(near, key=lambda n: n[1])[0]
        return Pick(targets[i], i)
    edge = _nearest_edge(cursor, edges, tol)
    if last is None:
        return Pick(edge[0], None, (), edge[1], "edge") if edge and onto else Pick(cursor)
    if lock:
        return _locked(cursor, last, targets, tol, edges if onto else ())
    x, y = cursor
    guides = []
    best_x = _nearest(cursor, last, targets, tol, 0)
    best_y = _nearest(cursor, last, targets, tol, 1)
    if best_x is not None:  # x taken from a point: a line along world Y through it
        x = best_x[0]
        guides.append({"axis": "y", "ref": best_x, "last": best_x == tuple(last)})
    if best_y is not None:
        y = best_y[1]
        guides.append({"axis": "x", "ref": best_y, "last": best_y == tuple(last)})
    if edge is None:
        return Pick((x, y), None, guides)
    q, (a, b) = edge
    if perpendicular:
        f = _foot(last, a, b)
        if f is not None and _dist(cursor, f) <= tol:
            return Pick(f, None, (), (a, b), "perpendicular")
    if not onto:
        return Pick((x, y), None, guides)
    best = None
    for g in guides:  # a guide's line across the edge
        d = (1.0, 0.0) if g["axis"] == "x" else (0.0, 1.0)
        hit = _cross(g["ref"], d, a, b)
        if hit is not None and _dist(cursor, hit[0]) <= tol and (best is None or _dist(cursor, hit[0]) < best[0]):
            best = (_dist(cursor, hit[0]), hit[0], g)
    if best is not None:
        return Pick(best[1], None, [best[2]], (a, b), "edge")
    return Pick(q, None, (), (a, b), "edge")


def _closest(p, a, b):
    """The point of segment a..b nearest p."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    n = dx * dx + dy * dy
    u = 0.0 if n < 1e-18 else min(max(((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / n, 0.0), 1.0)
    return (a[0] + dx * u, a[1] + dy * u)


def _nearest_edge(cursor, edges, tol):
    """(the nearest point on the nearest edge within tol, that edge), or None."""
    best = None
    for a, b in edges:
        q = _closest(cursor, a, b)
        d = _dist(cursor, q)
        if d <= tol and (best is None or d < best[0]):
            best = (d, q, (tuple(a), tuple(b)))
    return (best[1], best[2]) if best else None


def _foot(p, a, b):
    """The foot of the perpendicular from p on segment a..b, or None when it falls outside."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    n = dx * dx + dy * dy
    if n < 1e-18:
        return None
    u = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / n
    if u < -1e-9 or u > 1 + 1e-9:
        return None
    return (a[0] + dx * u, a[1] + dy * u)


def _cross(p, d, a, b):
    """(point, s) where the line p + s d crosses segment a..b, or None (parallel, or off it)."""
    ex, ey = b[0] - a[0], b[1] - a[1]
    den = d[0] * ey - d[1] * ex
    if abs(den) < 1e-12:
        return None
    wx, wy = a[0] - p[0], a[1] - p[1]
    s = (wx * ey - wy * ex) / den
    u = (wx * d[1] - wy * d[0]) / den
    if u < -1e-9 or u > 1 + 1e-9:
        return None
    return (p[0] + d[0] * s, p[1] + d[1] * s), s


def _nearest(cursor, last, targets, tol, j):
    """The point whose coordinate j is nearest the cursor's, within tol (last first)."""
    best, best_d = None, None
    for p, bias in [(tuple(last), LAST_BIAS)] + [(tuple(t), 1.0) for t in targets]:
        d = abs(cursor[j] - p[j])
        if d > tol:
            continue
        d *= bias
        if best_d is None or d < best_d - 1e-12:
            best, best_d = (float(p[0]), float(p[1])), d
    return best


def lock_direction(last, cursor):
    """The unit direction from last nearest the cursor's, in LOCK_STEP steps."""
    a = math.degrees(math.atan2(cursor[1] - last[1], cursor[0] - last[0]))
    a = round(a / LOCK_STEP) * LOCK_STEP
    r = math.radians(a)
    return (round(math.cos(r), 12), round(math.sin(r), 12))


def _locked(cursor, last, targets, tol, edges=()):
    d = lock_direction(last, cursor)
    t = max((cursor[0] - last[0]) * d[0] + (cursor[1] - last[1]) * d[1], 0.0)
    guides = [{"axis": "dir", "ref": (float(last[0]), float(last[1])), "last": True}]
    best = None  # (distance along the line from the cursor's, t, target hit, extra guide, edge)
    for i, p in enumerate(targets):  # where the locked line crosses a point's X or Y line, if near
        for j, axis in ((0, "y"), (1, "x")):
            if abs(d[j]) < 1e-9:
                continue
            ti = (p[j] - last[j]) / d[j]
            if ti <= 1e-9 or abs(ti - t) > tol:
                continue
            on = (last[0] + d[0] * ti, last[1] + d[1] * ti)
            hit = i if _dist(on, p) <= 1e-6 else None
            if best is None or abs(ti - t) < best[0]:
                best = (abs(ti - t), ti, hit, {"axis": axis, "ref": (float(p[0]), float(p[1])), "last": False}, None)
    for a, b in edges:  # or where it crosses an edge
        hit = _cross(last, d, a, b)
        if hit is None or hit[1] <= 1e-9 or abs(hit[1] - t) > tol:
            continue
        if best is None or abs(hit[1] - t) < best[0]:
            best = (abs(hit[1] - t), hit[1], None, None, (tuple(a), tuple(b)))
    if best is not None:
        _gap, t, hit, guide, edge = best
        if guide is not None and hit is None:
            guides.append(guide)
        return Pick((last[0] + d[0] * t, last[1] + d[1] * t), hit, guides, edge, "edge" if edge else None)
    return Pick((last[0] + d[0] * t, last[1] + d[1] * t), None, guides)


def typed_point(last, toward, length, angle=None, prev=None, absolute=False):
    """The point length from last: turned angle degrees from the segment before (prev to
    last; left +, right -, as a corner's turn reads) when given, or heading angle degrees
    from +X when absolute or there is no segment before; else towards toward (the
    cursor's pick, so a Shift lock holds), else along +X. A negative length goes back."""
    if angle is not None:
        if prev is not None and not absolute and math.dist(prev, last) > 1e-9:
            angle = heading(prev, last) + angle
        r = math.radians(angle)
        d = (math.cos(r), math.sin(r))
    else:
        d = _unit((toward[0] - last[0], toward[1] - last[1])) if toward is not None else None
        d = d or (1.0, 0.0)
    return (last[0] + d[0] * length, last[1] + d[1] * length)


def turn(prev, last, point):
    """How far the path turns at last, from prev to point: degrees, left +, in (-180, 180]."""
    t = heading(last, point) - heading(prev, last)
    while t <= -180.0:
        t += 360.0
    while t > 180.0:
        t -= 360.0
    return t


def heading(a, b):
    """Degrees from +X of the segment a to b, in (-180, 180]."""
    h = math.degrees(math.atan2(b[1] - a[1], b[0] - a[0]))
    return 180.0 if h <= -180.0 + 1e-9 else h


# Typed input --------------------------------------------------------------------------------

def split_input(text):
    """(length text, angle text or None) of what was typed: "length" or "length,angle"
    (the angle a turn, or a heading from +X with @: "length,@angle")."""
    if "," in text:
        length, angle = text.split(",", 1)
        return length.strip(), angle.strip() or None
    return text.strip(), None


def _number(s):
    s = s.replace(" ", "")
    if "/" in s:
        a, b = s.split("/", 1)
        return float(a) / float(b) if float(b) else None
    return float(s)


def parse_length(text, bare_cm):
    """A typed length in centimetres, or None: numbers each with an optional unit
    (UNITS), summed, so 12' 6" and 1m 20cm work. A bare number is bare_cm cm each (the
    scene's display unit), except right after feet, where it means inches (12'6)."""
    text = text.strip()
    if not text:
        return None
    total, at, prev, sign = 0.0, 0, None, 1.0
    if text[0] in "+-":
        sign, text = (-1.0 if text[0] == "-" else 1.0), text[1:]
    while at < len(text):
        m = _TOKEN.match(text, at)
        if m is None or m.end() == at:
            return None
        try:
            v = _number(m.group(1))
        except ValueError:
            return None
        if v is None:
            return None
        unit = (m.group(2) or "").lower()
        if unit:
            total += v * UNITS[unit]
        elif prev in _FEET:
            total += v * UNITS["in"]
        else:
            total += v * bare_cm
        prev, at = unit, m.end()
        while at < len(text) and text[at] in " +":
            at += 1
    return sign * total


def parse_angle(text):
    """A typed angle in degrees (an optional trailing d or degree sign), or None."""
    if text is None:
        return None
    t = text.strip().rstrip("d").rstrip("°").strip()
    try:
        return float(t)
    except ValueError:
        return None


def parse(text, bare_cm):
    """(length cm, angle degrees or None, absolute) of typed text, or None when it won't
    read; absolute: the angle was typed with @, a heading from +X rather than a turn."""
    length, angle = split_input(text)
    cm = parse_length(length, bare_cm)
    if cm is None:
        return None
    absolute = angle is not None and angle.startswith("@")
    if absolute:
        angle = angle[1:].strip() or None
        if angle is None:
            return None
    a = parse_angle(angle)
    if angle is not None and a is None:
        return None
    return cm, a, absolute


def format_length(cm, unit, digits=2):
    """cm shown in unit (a UNITS key, "ft-in" for feet and inches, or "" for plain
    numbers at 1 cm each: the caller scales those), trailing zeros dropped."""
    def num(v):
        s = ("%%.%df" % digits) % v
        return s.rstrip("0").rstrip(".") if "." in s else s
    if unit == "ft-in":
        inches = cm / UNITS["in"]
        sign = "-" if inches < 0 else ""
        inches = abs(inches)
        feet = int(inches // 12)
        rest = inches - feet * 12
        if round(rest, digits) >= 12:
            feet, rest = feet + 1, 0.0
        return "%s%d' %s\"" % (sign, feet, num(rest))
    if not unit:
        return num(cm)
    label = {'"': "in", "'": "ft"}.get(unit, unit)
    return "%s %s" % (num(cm / UNITS[unit]), label)
