"""AW Draw: a Wall's (Railing's, Floor's, Roof's...) path drawn point by point, as
Blender's Archwerks Draw tool draws it (blender/pen.py), on the same core
(core/aw_pen.py), so the two snap, line up and take typed lengths the same way.
It takes over from Cinema 4D's Spline Pen, which has no inference or typed
lengths, and which leaves the document in Points mode.

The panel (aw_panel._arm_pen) starts it with an object and an empty spline in it;
each click on the floor (the plane at the object's base) adds a point to that
spline, and the object rebuilds as the points come. Where the point lands: snapped
to any Archwerks path's point within SNAP_PX, lined up with the last point along X
or Z (a red or blue guide) or with any other path point (a dashed inference guide),
or held to 45 degree steps with Shift; Ctrl: no snapping. With Cinema 4D's Snapping
on, Point snaps to walls' corners as built, Edge onto their faces and paths' runs,
Edge Midpoint to their middles and Perpendicular square to them. Typing a length (or
length,angle) and Return places the point exactly; a bare number is in the display
unit, the angle is the corner's turn (left +, right -; @angle: a heading from +X).
Backspace takes the last point back, clicking the first point closes the run, Escape
or Return ends the run; the next click starts another run in the same object, or
continues an open end of it. Escape again leaves the tool (for Move).

Points are kept as (x, z) on the floor plane, Cinema 4D's plan.
"""
import math

import c4d

import aw_ids as I
import aw_pen

SNAP_PX = 10.0
DOT_PX = 3
RING_PX = 9
TYPING = set("0123456789.,-+@'\"/ abcdefghijklmnopqrstuvwxyz°")
PATH_TYPES = (I.ID_AW_WALL, I.ID_AW_RAILING, I.ID_AW_FLOOR, I.ID_AW_CEILING, I.ID_AW_MOLDING, I.ID_AW_ROOF,
              I.ID_AW_WALL_PANELS, I.ID_AW_COUNTERTOP)
LOOP_TYPES = (I.ID_AW_FLOOR, I.ID_AW_CEILING, I.ID_AW_COUNTERTOP)  # closed outlines
_UNIT_KEYS = {c4d.UNIT_KM: "km", c4d.UNIT_M: "m", c4d.UNIT_CM: "cm", c4d.UNIT_MM: "mm", c4d.UNIT_YARD: "yd",
              c4d.UNIT_FEET: "ft", c4d.UNIT_INCH: "in"}

S = {"owner": None}  # the stroke in progress and what it draws into; see arm()


def registered():
    return c4d.plugins.FindPlugin(I.ID_AW_DRAW_TOOL, c4d.PLUGINTYPE_TOOL) is not None


def arm(doc, owner, spline):
    """Start drawing into spline, under owner (made by the panel, empty)."""
    S.clear()
    S.update(owner=owner, spline=spline, made_empty=spline, snaps=None)
    _reset()
    doc.SetAction(I.ID_AW_DRAW_TOOL)
    c4d.EventAdd()


def _reset():
    S.update(started=False, pts=[], base=[], base_world=[], base_closed=False, prepend=False, closed=False, typed="",
             pick=aw_pen.Pick((0.0, 0.0)), close_hit=False, cursor_px=None, written=None)


def _alive(o):
    try:
        return o is not None and o.IsAlive()
    except (AttributeError, ReferenceError):
        return False


def active():
    return _alive(S.get("owner"))


# Where things are --------------------------------------------------------------------------

def plane_y():
    return S["owner"].GetMg().off.y


def floor_at(bd, x, y):
    """The (x, z) on the floor plane under view pixel (x, y), or None."""
    import aw_place
    a, v = aw_place._ray(bd, x, y)
    if abs(v.y) < 1e-9:
        return None
    t = (plane_y() - a.y) / v.y
    if t <= 0:
        return None
    p = a + v * t
    return (p.x, p.z)


def px_at(bd, p):
    s = bd.WS(c4d.Vector(p[0], plane_y(), p[1]))
    return (s.x, s.y) if s.z > 0 or bd[c4d.BASEDRAW_DATA_PROJECTION] != c4d.Pperspective else None


def _spline_world(sp):
    mg = sp.GetMg()
    return [mg * sp.GetPoint(i) for i in range(sp.GetPointCount())]


def _path_splines(doc):
    """[(owner, spline)] of every Archwerks path in doc (its splines under it)."""
    out, stack = [], [doc.GetFirstObject()]
    while stack:
        o = stack.pop()
        while o:
            if o.GetType() in PATH_TYPES:
                for ch in o.GetChildren():
                    if ch.CheckType(c4d.Ospline):
                        out.append((o, ch))
            if o.GetDown():
                stack.append(o.GetDown())
            o = o.GetNext()
    return out


def _wall_outline(wall):
    """(corners, faces) of a wall as built, at its base: its cache's points and edges."""
    corners, faces = {}, {}

    def walk(o):
        while o:
            if o.GetType() == c4d.Opolygon and o.GetPointCount():
                mg = o.GetMg()
                pts = [mg * p for p in o.GetAllPoints()]
                base = min(p.y for p in pts)
                at = {i: (round(p.x, 4), round(p.z, 4)) for i, p in enumerate(pts) if p.y - base < 1e-2}
                for v in at.values():
                    corners[v] = True
                for poly in o.GetAllPolygons():
                    ids = [poly.a, poly.b, poly.c] + ([] if poly.c == poly.d else [poly.d])
                    for a, b in zip(ids, ids[1:] + ids[:1]):
                        if a in at and b in at and at[a] != at[b]:
                            faces[tuple(sorted((at[a], at[b])))] = True
            walk(o.GetDown())
            o = o.GetNext()
    walk(wall.GetCache())
    return list(corners), list(faces)


def snap_set(doc):
    """What a stroke snaps to, as blender/pen.snap_set: path points always; with
    Snapping on, walls' corners (Point), faces and runs (Edge, Perpendicular), their
    middles (Edge Midpoint)."""
    snap = c4d.modules.snap
    others, segs = [], []
    for owner, sp in _path_splines(doc):
        pts = [(p.x, p.z) for p in _spline_world(sp)]
        closed = sp.IsClosed()
        for i, p in enumerate(pts):
            end = None if closed else ("first" if i == 0 else "last" if i == len(pts) - 1 else None)
            others.append((p, (sp, i), end, owner))
        segs += list(zip(pts, pts[1:] + (pts[:1] if closed and len(pts) > 2 else [])))
    on = snap.IsSnapEnabled(doc)
    mode = (lambda m: on and snap.IsSnapEnabled(doc, m))  # noqa: E731
    corners, faces = [], []
    if on:
        for owner, _sp in _path_splines(doc):
            if owner.GetType() == I.ID_AW_WALL:
                c, f = _wall_outline(owner)
                corners += c
                faces += f
    edges = faces + segs
    if mode(c4d.SNAPMODE_POINT):
        others += [(p, None, None, None) for p in corners]
    if mode(c4d.SNAPMODE_EDGEMID):
        others += [(((a[0] + b[0]) / 2, (a[1] + b[1]) / 2), None, None, None) for a, b in edges]
    perpendicular, onto = mode(c4d.SNAPMODE_ORTHO), mode(c4d.SNAPMODE_EDGE)
    return {"others": others, "edges": edges if (perpendicular or onto) else [],
            "perpendicular": perpendicular, "onto": onto}


# The stroke --------------------------------------------------------------------------------

def _chain():
    return S["base_world"] + S["pts"] if S["started"] else []


def _last():
    c = _chain()
    return c[-1] if c else None


def _targets():
    """(points to snap to, index of the stroke's first point among them or None)."""
    own = S["spline"] if S["started"] else None
    pts = [t[0] for t in S["snaps"]["others"] if t[1] is None or t[1][0] != own]
    chain = _chain()
    first = len(pts) if len(chain) >= 2 else None
    return pts + chain[:-1], first


def _bare_cm():
    unit = c4d.GetWorldContainerInstance().GetInt32(c4d.WPREF_UNITS_BASIC)
    return aw_pen.UNITS.get(_UNIT_KEYS.get(unit, "cm"), 1.0)


def _typed_point():
    last = _last()
    if not S["typed"] or last is None:
        return None
    r = aw_pen.parse(S["typed"], _bare_cm())
    if r is None:
        return None
    chain = _chain()
    prev = chain[-2] if len(chain) >= 2 else None
    return aw_pen.typed_point(last, S["pick"].point, r[0], r[1], prev=prev, absolute=r[2])


def update(doc, bd, x=None, y=None, shift=False, ctrl=False):
    """Solve the pick at view pixel (x, y) (None: where the cursor last was) and show the
    floating point in the spline."""
    if S.get("snaps") is None:
        S["snaps"] = snap_set(doc)
    if x is not None:
        S["cursor_px"] = (x, y)
    if S["cursor_px"] is None:
        return
    cursor = floor_at(bd, *S["cursor_px"])
    if cursor is None:
        return
    far = floor_at(bd, S["cursor_px"][0] + SNAP_PX, S["cursor_px"][1])
    tol = math.dist(cursor, far) if far is not None else 0.0
    targets, first = _targets()
    snaps = S["snaps"]
    if ctrl:
        S["pick"] = aw_pen.Pick(cursor)
    else:
        S["pick"] = aw_pen.solve(cursor, _last(), targets, tol, lock=shift, edges=snaps["edges"],
                                 perpendicular=snaps["perpendicular"], onto=snaps["onto"])
    S["close_hit"] = first is not None and S["pick"].target == first and len(_chain()) >= 3
    if S["started"]:
        floating = None if S["close_hit"] else (_typed_point() or S["pick"].point)
        _write(floating)


def _write(floating=None):
    """The stroke into its spline (floating: the point following the cursor, too)."""
    sp = S["spline"]
    flat = S["pts"] + ([floating] if floating is not None and not S["closed"] else [])
    new = flat[::-1] if S["prepend"] else flat
    world = (new + S["base"]) if S["prepend"] else (S["base"] + new)
    key = (tuple(world), S["closed"])
    if key == S["written"]:
        return
    S["written"] = key
    inv = ~sp.GetMg()
    y = plane_y()
    sp.ResizeObject(len(world))
    for i, (px, pz) in enumerate(world):
        sp.SetPoint(i, inv * c4d.Vector(px, y, pz))
    loop = S["owner"].GetType() in LOOP_TYPES and len(world) >= 3  # an outline shows filled as it's drawn
    sp[c4d.SPLINEOBJECT_CLOSED] = S["closed"] or S["base_closed"] or loop
    sp.Message(c4d.MSG_UPDATE)
    S["owner"].Message(c4d.MSG_UPDATE)


def _committed(doc):
    """Put the spline back to its committed points (no floating one) and take an undo
    step of it: the click that follows changes it."""
    _write(None)
    doc.AddUndo(c4d.UNDOTYPE_CHANGE, S["spline"])


def _new_run(doc):
    """Another run in the owner: a new spline, named as the panel names them."""
    import aw_panel
    sp = c4d.SplineObject(0, c4d.SPLINETYPE_LINEAR)
    sp.SetName(aw_panel.next_run_name(S["owner"]))
    sp.InsertUnderLast(S["owner"])
    sp.SetMg(c4d.Matrix(S["owner"].GetMg()))
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, sp)
    return sp


def _start(doc):
    """The first click of a run: continue an open end of the owner's when it lands on
    one, else the empty spline it was started with, else a new run."""
    pick = S["pick"]
    snaps = S["snaps"]["others"]
    end = None
    if pick.target is not None and pick.target < len(snaps):
        t = snaps[pick.target]
        if t[2] is not None and t[3] is not None and t[3] == S["owner"]:
            end = t
    S["base"], S["base_world"], S["prepend"], S["base_closed"] = [], [], False, False
    if end is not None:
        sp = end[1][0]
        world = [(p.x, p.z) for p in _spline_world(sp)]
        S["spline"], S["base"], S["prepend"] = sp, world, end[2] == "first"
        S["base_world"] = world[::-1] if S["prepend"] else world
        doc.AddUndo(c4d.UNDOTYPE_CHANGE, sp)
        S["pts"] = []
    else:
        empty = S.get("made_empty")
        if _alive(empty) and empty.GetPointCount() == 0:
            S["spline"] = empty
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, empty)
        else:
            S["spline"] = _new_run(doc)
        S["pts"] = [pick.point]
    S["started"] = True
    S["written"] = None
    doc.SetActiveObject(S["owner"], c4d.SELECTION_NEW)
    _write()


def click(doc, bd, x, y, shift=False, ctrl=False):
    """A click at view pixel (x, y): a point (one undo step). True when it closed the run."""
    update(doc, bd, x, y, shift, ctrl)
    S["typed"] = ""
    doc.StartUndo()
    try:
        if not S["started"]:
            _start(doc)
            return False
        _committed(doc)
        if S["close_hit"]:
            S["closed"] = True
            _write()
            _end_run()
            return True
        p = S["pick"].point
        last = _last()
        if last is not None and math.dist(p, last) < 1e-6:
            return False
        S["pts"].append(p)
        _write()
        return False
    finally:
        doc.EndUndo()
        c4d.EventAdd()


def _end_run():
    """The run is done: the next click starts another (snapping to this one too)."""
    loop = S["owner"].GetType() in LOOP_TYPES
    if S["started"] and loop and len(_chain()) >= 3:
        S["closed"] = True
    _write()
    _reset()
    S["snaps"] = None


def key(doc, bd, channel, char, shift=False, ctrl=False):
    """A key while drawing; False: not the tool's (Cinema 4D's own then)."""
    if channel == c4d.KEY_ESC:
        if S["typed"]:
            S["typed"] = ""
        elif S["started"]:
            doc.StartUndo()
            _committed(doc)
            _end_run()
            doc.EndUndo()
        else:
            leave(doc)
            doc.SetAction(c4d.ID_MODELING_MOVE)
        c4d.EventAdd()
        return True
    if channel == c4d.KEY_ENTER:
        doc.StartUndo()
        _committed(doc)
        if S["typed"] and S["started"]:
            p = _typed_point()
            S["typed"] = ""
            if p is not None:
                S["pts"].append(p)
                S["pick"] = aw_pen.Pick(p)
                _write()
        elif S["started"]:
            _end_run()
        doc.EndUndo()
        c4d.EventAdd()
        return True
    if channel == c4d.KEY_BACKSPACE:
        if S["typed"]:
            S["typed"] = S["typed"][:-1]
        elif S["started"] and S["pts"]:
            doc.StartUndo()
            _committed(doc)
            S["pts"].pop()
            if not S["pts"] and not S["base"]:
                _reset()
            _write()
            doc.EndUndo()
        update(doc, bd, shift=shift, ctrl=ctrl)
        c4d.EventAdd()
        return True
    if char and char.lower() in TYPING and S["started"]:
        S["typed"] += char
        update(doc, bd, shift=shift, ctrl=ctrl)
        c4d.EventAdd()
        return True
    return False


def leave(doc):
    """The tool is put down: the run in progress ends where it is, and an object the
    panel made that nothing was drawn into goes again."""
    if not active():
        S.clear()
        S["owner"] = None
        return
    if S["started"]:
        S["floating"] = None
        _write(None)
    owner = S["owner"]
    drawn = any(ch.CheckType(c4d.Ospline) and ch.GetPointCount() >= 2 for ch in owner.GetChildren())
    if not drawn and owner.GetDocument() is not None:
        doc.StartUndo()
        doc.AddUndo(c4d.UNDOTYPE_DELETEOBJ, owner)
        owner.Remove()
        doc.EndUndo()
    S.clear()
    S["owner"] = None
    c4d.EventAdd()


# Drawing ------------------------------------------------------------------------------------

def _line(bd, a, b, colour, dashed=False):
    bd.SetPen(c4d.Vector(*colour))
    if not dashed:
        bd.DrawLine2D(c4d.Vector(a[0], a[1], 0), c4d.Vector(b[0], b[1], 0))
        return
    n = math.dist(a, b)
    if n < 1:
        return
    step, on = 10.0, 6.0
    d = ((b[0] - a[0]) / n, (b[1] - a[1]) / n)
    t = 0.0
    while t < n:
        e = min(t + on, n)
        bd.DrawLine2D(c4d.Vector(a[0] + d[0] * t, a[1] + d[1] * t, 0), c4d.Vector(a[0] + d[0] * e, a[1] + d[1] * e, 0))
        t += step


def _dot(bd, p, colour, r=DOT_PX):
    bd.SetPen(c4d.Vector(*colour))
    for k in range(r + 1):
        bd.DrawCircle2D(int(p[0]), int(p[1]), k)


def draw(doc, bd):
    """The guides, the rubber band, the points, the snap ring and the readout."""
    import aw_draw
    if not active() or bd != doc.GetActiveBaseDraw():
        return
    bd.SetMatrix_Screen()
    pick = S["pick"]
    point = _chain()[0] if S["close_hit"] else (_typed_point() or pick.point)
    p_px = px_at(bd, point)
    last = _last()
    last_px = px_at(bd, last) if last is not None else None
    frame = bd.GetFrame()
    reach = (frame["cr"] - frame["cl"]) + (frame["cb"] - frame["ct"])
    band = (1.0, 1.0, 1.0)
    for g in pick.guides:
        ref_px = px_at(bd, g["ref"])
        if ref_px is None or p_px is None:
            continue
        if g["axis"] == "dir":
            _line(bd, ref_px, p_px, (1.0, 0.8, 0.2), dashed=True)
        elif g["last"]:  # the last point's own X or Z: the axis across the view, as Cinema 4D's
            colour = (0.9, 0.3, 0.3) if g["axis"] == "x" else (0.35, 0.55, 1.0)
            d = (p_px[0] - ref_px[0], p_px[1] - ref_px[1])
            n = math.hypot(*d)
            if n > 1e-6:
                d = (d[0] / n * reach, d[1] / n * reach)
                _line(bd, (ref_px[0] - d[0], ref_px[1] - d[1]), (ref_px[0] + d[0], ref_px[1] + d[1]),
                      tuple(c * 0.6 for c in colour))
            band = colour
        else:
            _line(bd, ref_px, p_px, (1.0, 0.45, 1.0), dashed=True)
            _dot(bd, ref_px, (1.0, 0.45, 1.0))
    if last_px is not None and p_px is not None and not S["closed"]:
        _line(bd, last_px, p_px, band)
    for c in _chain():
        q = px_at(bd, c)
        if q is not None:
            _dot(bd, q, (1.0, 1.0, 1.0))
    if pick.edge is not None and not S["close_hit"]:
        a, b = px_at(bd, pick.edge[0]), px_at(bd, pick.edge[1])
        if a is not None and b is not None:
            _line(bd, a, b, (0.3, 0.85, 1.0))
    if p_px is not None and (pick.target is not None or pick.edge is not None or S["close_hit"]):
        colour = (0.3, 1.0, 0.4) if S["close_hit"] else ((0.3, 0.85, 1.0) if pick.target is None else (1.0, 0.85, 0.2))
        bd.SetPen(c4d.Vector(*colour))
        bd.DrawCircle2D(int(p_px[0]), int(p_px[1]), RING_PX)
    if p_px is not None:
        text = None
        if last is not None:
            length = math.dist(last, point)
            chain = _chain()
            degrees = aw_pen.turn(chain[-2], last, point) if len(chain) >= 2 and math.dist(chain[-2], last) > 1e-9 \
                else aw_pen.heading(last, point)
            text = "%s   %s°" % (aw_draw.fmt_length(length), ("%.1f" % degrees).rstrip("0").rstrip("."))
            if S["typed"]:
                text = "%s   (%s)" % (S["typed"], text)
        if S["close_hit"]:
            text = "Close"
        if text:
            bd.DrawHUDText(int(p_px[0] + 14), int(p_px[1] + 10), text)


def status():
    name = S["owner"].GetName() if active() else "path"
    typed = ("   Typed: %s" % S["typed"]) if S.get("typed") else ""
    return ("AW Draw %s%s   Click: point   Type a length (or length,turn), Return: place it   Shift: 45°   "
            "Ctrl: no snapping   Backspace: back a point   Click the first point: close   Escape: end the run, "
            "again: done" % (name, typed))
