"""The placing card's catalogs: standard US windows, doors and cabinets, as a few short
choices instead of one long preset list. A window is a Style and a Size; a door an
Operation, a Style, a Width and a Height; a cabinet a Type, a Configuration, a Height
(the types that come in more than one) and a Width. Each choice narrows the next: a
Double door offers 48, 60 and 72 in, a 1 Door base 9 to 24 in.

Both hosts draw the card from this (Blender's a popup, Cinema 4D's a dialog) and turn
the choices into an ordinary preset (aw_placing's shape) with preset(), so placing
works as it does for a built-in one. Sizes are nominal, in inches, written 36 x 60.

choices: {row key: option id}; normalize() fills in a row left out or no longer
offered (a Width after the Operation changed) with that row's default.
"""
import math

import aw_cabinet as C
import aw_cutter as CU
import aw_door as D
import aw_ids as I
import aw_placing as A
import aw_window as W

IN = 2.54
HEAD = 80  # in: where windows' heads line up, as doors' (6'8"), so a window's sill is HEAD - its height
MIN_SILL = 12  # in: a tall window's sill, its head going up instead


def _inch(n):
    return ("%g" % n).replace(".5", "½") if n != int(n) else "%d" % n


def size_label(w, h):
    return "%s × %s" % (_inch(w), _inch(h))


# Windows ---------------------------------------------------------------------------------

WINDOW_STYLES = (("double_hung", "Double-hung"), ("casement", "Casement"), ("slider", "Slider"),
                 ("picture", "Picture"))
WINDOW_SIZES = {  # (width, height) in, the common US sizes of each
    "double_hung": ((24, 36), (24, 48), (28, 54), (30, 48), (30, 60), (32, 60), (36, 48), (36, 60), (36, 72)),
    "casement": ((24, 36), (24, 48), (30, 48), (30, 60), (48, 48), (72, 48)),
    "slider": ((36, 24), (48, 36), (60, 36), (60, 48), (72, 48)),
    "picture": ((36, 36), (48, 48), (60, 48), (72, 48), (72, 60)),
}
WINDOW_DEFAULTS = {"style": "double_hung", "size": "36x60"}


def _window_values(style, w, h):
    v = {"handle": W.HANDLE_INSIDE}
    if style == "double_hung":
        v["kind"] = W.DOUBLE_HUNG
    elif style == "casement":
        v.update(kind=W.CASEMENT, leaves_1=max(1, int(round(w / 24.0))))  # 48 in: a pair, 72: three
    elif style == "slider":
        v.update(kind=W.SLIDING, leaves_1=2)
    else:
        v = {"kind": W.FIXED}
    v.update(width=w * IN, height=h * IN, sill=max(HEAD - h, MIN_SILL) * IN)
    return v


# Doors -----------------------------------------------------------------------------------

DOOR_OPERATIONS = (("single", "Single"), ("double", "Double"), ("barn", "Barn"), ("pocket", "Pocket"),
                   ("patio", "Patio Slider"), ("cased", "Cased Opening"))
DOOR_SIDES = (("interior", "Interior"), ("exterior", "Exterior"))
DOOR_STYLES = (("six_panel", "6 Panel"), ("two_panel", "2 Panel"), ("shaker", "Shaker"), ("flat", "Flat"),
               ("half_lite", "Half Lite"), ("glass", "Full Lite"), ("ten_lite", "10 Lite"), ("full_lite", "15 Lite"))
DOOR_WIDTHS = {"single": (24, 28, 30, 32, 36), "double": (48, 60, 72), "barn": (30, 32, 36, 42),
               "pocket": (24, 28, 30, 32, 36), "patio": (60, 72, 96),
               "cased": (30, 36, 48, 60, 72)}  # total, a pair's both leaves
DOOR_HEIGHTS = (80, 96)
DOOR_DEFAULTS = {"operation": "single", "side": "interior", "style": "six_panel", "width": "30", "height": "80"}

_DOOR_STYLE_VALUES = {
    "six_panel": dict(model=D.BEVEL, panels_h=2, panels_v=3, distrib=D.COLONIAL),
    "two_panel": dict(model=D.PANEL, panels_h=1, panels_v=2),
    "shaker": dict(model=D.PANEL, panels_h=1, panels_v=1),
    "flat": dict(model=D.FLAT),
    "half_lite": dict(model=D.HALF_LITE, panels_h=1, panels_v=2),
    "glass": dict(model=D.GLASS, panels_h=1, panels_v=1, border=10.0),
    "ten_lite": dict(model=D.GLASS, panels_h=2, panels_v=5, spacing=2.5, border=10.0),
    "full_lite": dict(model=D.GLASS, panels_h=3, panels_v=5, spacing=2.5, border=10.0),
}
_DOOR_OPERATION_VALUES = {
    "single": dict(kind=D.HINGED, leaves=1),
    "double": dict(kind=D.HINGED, leaves=2, handle_type=D.LEVER),
    "barn": dict(kind=D.SLIDING, leaves=1, layout=D.FIT, handle_type=D.PULL),
    "pocket": dict(kind=D.POCKET, leaves=1, layout=D.FIT, handle_side=D.HANDLE_BOTH, handle_type=D.FLUSH),
    "cased": dict(kind=D.HINGED, shape=D.CASED),
}
_EXTERIOR = dict(leaf_d=4.45, open_side=D.OPEN_INSIDE, step=True, sill_on=True)


def _hinged(op):
    return op in ("single", "double")


def _has_style(op):
    return op not in ("cased", "patio")  # a cased opening has no leaf; a patio slider is all glass


PATIO = "patio"  # placed as a window: a Sliding one standing on the floor, its frame and glass the window's


# Cabinets --------------------------------------------------------------------------------

CABINET_TYPES = (("base", "Base"), ("upper", "Upper"), ("tall", "Tall"), ("vanity", "Vanity"))
_TYPE_IDS = {"base": C.BASE, "upper": C.UPPER, "tall": C.TALL, "vanity": C.VANITY}
CABINET_CONFIGS = {
    "base": (("one_door", "1 Door"), ("two_door", "2 Door"), ("drawers3", "3 Drawer"), ("drawers4", "4 Drawer"),
             ("sink", "Sink Base"), ("farmhouse", "Farmhouse Sink"), ("open", "Open"), ("blind", "Blind Corner"),
             ("lazy_susan", "Lazy Susan")),
    "upper": (("one_door", "1 Door"), ("two_door", "2 Door"), ("glass", "Glass Doors"), ("open", "Open"),
              ("blind", "Blind Corner"), ("diagonal", "Diagonal Corner")),
    "tall": (("pantry", "Pantry"), ("oven", "Oven")),
    "vanity": (("sink", "Sink"), ("drawers", "Drawers")),
}
CABINET_HEIGHTS = {"upper": (30, 36, 42), "tall": (84, 90, 96), "vanity": (31.5, 34.5)}  # base: 34 1/2 only
CABINET_WIDTHS = {
    ("base", "one_door"): (9, 12, 15, 18, 21, 24), ("base", "two_door"): (24, 27, 30, 33, 36, 42),
    ("base", "drawers3"): (12, 15, 18, 21, 24, 30), ("base", "drawers4"): (12, 15, 18, 21, 24),
    ("base", "sink"): (30, 33, 36), ("base", "farmhouse"): (30, 33, 36), ("base", "open"): (12, 18, 24),
    ("base", "blind"): (36, 39, 42, 45, 48), ("base", "lazy_susan"): (33, 36),
    ("upper", "one_door"): (9, 12, 15, 18, 21, 24), ("upper", "two_door"): (24, 27, 30, 33, 36),
    ("upper", "glass"): (24, 30, 36), ("upper", "open"): (12, 24, 30, 36), ("upper", "blind"): (24, 27, 30, 36),
    ("upper", "diagonal"): (24,),
    ("tall", "pantry"): (18, 24, 30, 36), ("tall", "oven"): (27, 30, 33),
    ("vanity", "sink"): (24, 30, 36, 48), ("vanity", "drawers"): (12, 15, 18),
}
CABINET_FRONTS = (("shaker", "Shaker"), ("slab", "Slab"))
_FRONT_IDS = {"shaker": C.SHAKER, "slab": C.SLAB}
CABINET_DEFAULTS = {"type": "base", "config": "two_door", "height": "34.5", "width": "36", "front": "shaker"}


def _cabinet_zones(kind, config):
    z = C._zones
    return {
        ("base", "one_door"): z((C.DOOR_LEFT,), (C.DRAWER, 6 * IN)),
        ("base", "two_door"): z((C.DOOR_PAIR,), (C.DRAWER, 6 * IN, 2)),
        ("base", "drawers3"): z((C.DRAWER, 12 * IN), (C.DRAWER, 10 * IN), (C.DRAWER,)),
        ("base", "drawers4"): z((C.DRAWER, 9 * IN), (C.DRAWER, 7 * IN), (C.DRAWER, 7 * IN), (C.DRAWER,)),
        ("base", "sink"): z((C.DOOR_PAIR,), (C.SINK, 6 * IN)),
        ("base", "farmhouse"): z((C.DOOR_PAIR,), (C.EMPTY, 10 * IN)),
        ("base", "open"): z((C.OPEN, 0.0, 1, 1)),
        ("base", "blind"): z((C.DOOR_LEFT,), (C.DRAWER, 6 * IN)),
        ("base", "lazy_susan"): z((C.DOOR_LEFT,)),
        ("upper", "one_door"): z((C.DOOR_LEFT,)),
        ("upper", "two_door"): z((C.DOOR_PAIR,)),
        ("upper", "glass"): z((C.DOOR_PAIR, 0.0, 1, 0, True)),
        ("upper", "open"): z((C.OPEN, 0.0, 1, 2)),
        ("upper", "blind"): z((C.DOOR_LEFT,)),
        ("upper", "diagonal"): z((C.DOOR_LEFT,)),
        ("tall", "pantry"): z((C.DOOR_PAIR, 48 * IN), (C.DOOR_PAIR,)),
        ("tall", "oven"): z((C.DRAWER, 12 * IN), (C.OPEN, 30 * IN, 1, 0), (C.DOOR_PAIR,)),
        ("vanity", "sink"): z((C.DOOR_PAIR,), (C.SINK, 6 * IN)),
        ("vanity", "drawers"): z((C.DRAWER, 10 * IN), (C.DRAWER, 8 * IN), (C.DRAWER,)),
    }[(kind, config)]


_CABINET_EXTRA = {
    ("base", "blind"): dict(blind=C.BLIND_LEFT, blind_w=24 * IN),
    ("upper", "blind"): dict(blind=C.BLIND_LEFT, blind_w=13 * IN),
    ("base", "lazy_susan"): {"corner": C.PIE_CUT, "return": 36 * IN},
    ("upper", "diagonal"): {"corner": C.DIAGONAL, "return": 24 * IN},
}


# Cutouts: a shaped hole through the wall, walked through or passed through ----------------

CUTOUT_SHAPES = (("rectangle", "Rectangle"), ("round", "Round Arch"), ("segmental", "Segmental"),
                 ("elliptic", "Elliptic"), ("gothic", "Gothic"), ("rounded", "Rounded Corners"))
CUTOUT_TYPES = (("walk", "Walk-through"), ("pass", "Pass-through"))
CUTOUT_WIDTHS = {"walk": (30, 36, 48, 60, 72), "pass": (24, 30, 36, 48, 60)}
CUTOUT_HEIGHTS = {"walk": (80, 84, 96), "pass": (18, 24, 30, 36)}
PASS_SILL = 42  # in: a pass-through's sill, over a counter
CUTOUT_DEFAULTS = {"shape": "rectangle", "type": "walk", "width": "36", "height": "80"}
_CUTOUT_SHAPE_IDS = {"rectangle": CU.RECTANGLE, "round": CU.ROUND, "segmental": CU.ROUND, "elliptic": CU.ELLIPTIC,
                     "gothic": CU.POINTED, "rounded": CU.ROUNDED}


def _cutout_values(shape, w):
    """A shape's settings at w in wide: a segmental arch's radius its width (a flatter arc
    than the round arch's half), a gothic arch's its width, an elliptic one rising 12 in."""
    v = {"shape": _CUTOUT_SHAPE_IDS[shape], "radius": 0.0}
    if shape in ("segmental", "gothic"):
        v["radius"] = w * IN
    elif shape == "elliptic":
        v["rise"] = 12 * IN
    return v


# Fireplaces: aw_placing's own five, at the usual firebox widths ------------------------------

FIREPLACE_STYLES = (("Rounded", "Plain"), ("Doors", "With Doors"), ("Facing", "With Facing"), ("Arched", "Arched"),
                    ("Plain", "Firebox Only"))  # aw_placing.FIREPLACE_PRESETS keys
FIREPLACE_WIDTHS = (30, 36, 42, 48)
FIREPLACE_DEFAULTS = {"style": "Rounded", "width": "36"}


# Build: walls, stairs, railings, trim, roofs and beams. Their cards set an object's settings
# (by parameter id) as its tool makes it: drawn (a wall, a railing, trim or a roof with
# nothing selected) or added to the selection (trim along the selected walls, a stair along
# a spline). A Railing's card is its presets (aw_railing.PRESETS), as both hosts add them.

WALL, STAIR, RAILING, BASEBOARD, CROWN, ROOF, BEAM = "wall", "stair", "railing", "baseboard", "crown", "roof", "beam"
BUILD = (WALL, STAIR, RAILING, BASEBOARD, CROWN, ROOF, BEAM)

WALL_TYPES = (("exterior", "Exterior"), ("interior", "Interior"), ("half", "Half Wall"))
WALL_THICKNESS = {"exterior": (6, 8, 10), "interior": (4.5, 6), "half": (4.5, 6)}
WALL_HEIGHTS = {"exterior": (96, 108, 120), "interior": (96, 108, 120), "half": (36, 42)}  # in: 8, 9, 10 ft
_WALL_ALIGN = {"exterior": I.AW_ALIGN_INSIDE, "interior": I.AW_ALIGN_CENTER, "half": I.AW_ALIGN_CENTER}
WALL_DEFAULTS = {"type": "exterior", "thickness": "8", "height": "108"}
_WALL_TYPE_DEFAULTS = {"exterior": {"thickness": "8", "height": "108"}, "interior": {"thickness": "4.5", "height": "108"},
                       "half": {"thickness": "4.5", "height": "42"}}

STAIR_SHAPES = (("straight", "Straight"), ("l", "L"), ("u", "U"), ("spline", "Along Spline"))
STAIR_WIDTHS = (36, 42, 48)
STAIR_DEFAULTS = {"shape": "straight", "width": "36"}

RAILING_DEFAULTS = {"style": "0"}  # aw_railing.PRESETS index

BASEBOARD_PROFILES = (("square", "Square"), ("rounded", "Rounded"), ("ogee", "Ogee"), ("quarter", "Quarter Round"),
                      ("cove", "Cove"))
BASEBOARD_HEIGHTS = (3.25, 4.25, 5.25, 7.25)
BASEBOARD_DEFAULTS = {"profile": "ogee", "height": "5.25"}
CROWN_PROFILES = (("crown", "Crown"), ("cove", "Cove"), ("ogee", "Ogee"))
CROWN_SIZES = (3.625, 4.25, 5.25)
CROWN_DEFAULTS = {"profile": "crown", "size": "4.25"}

ROOF_SHAPES = (("auto", "Auto"), ("hip", "Hip"), ("gable", "Gable"), ("shed", "Shed"))
ROOF_PITCHES = (4, 6, 8, 12)  # in 12
ROOF_DEFAULTS = {"shape": "auto", "pitch": "6"}

BEAM_SECTIONS = (("rectangle", "Rectangle"), ("rounded", "Rounded"), ("round", "Round"), ("ibeam", "I-Beam"))
BEAM_DEFAULTS = {"section": "rectangle"}


def _feet(n):
    return "%d ft" % (n // 12) if n % 12 == 0 and n >= 72 else _inch(n) + " in"


def _railings():
    import aw_railing
    return tuple(("%d" % i, p["label"].title()) for i, p in enumerate(aw_railing.PRESETS))


def _build_rows(kind, c):
    unit = lambda n: _inch(n) + " in"  # noqa: E731
    if kind == WALL:
        return [("type", "Type", WALL_TYPES), ("thickness", "Thickness", _opts(WALL_THICKNESS[c["type"]], unit)),
                ("height", "Height", _opts(WALL_HEIGHTS[c["type"]], _feet))]
    if kind == STAIR:
        return [("shape", "Shape", STAIR_SHAPES), ("width", "Width", _opts(STAIR_WIDTHS, unit))]
    if kind == RAILING:
        return [("style", "Style", _railings())]
    if kind == BASEBOARD:
        return [("profile", "Profile", BASEBOARD_PROFILES), ("height", "Height", _opts(BASEBOARD_HEIGHTS, unit))]
    if kind == CROWN:
        return [("profile", "Profile", CROWN_PROFILES), ("size", "Size", _opts(CROWN_SIZES, unit))]
    if kind == ROOF:
        return [("shape", "Shape", ROOF_SHAPES), ("pitch", "Pitch", _opts(ROOF_PITCHES, lambda n: "%d/12" % n))]
    return [("section", "Section", BEAM_SECTIONS)]


def _build_preset(kind, c):
    """{"label", "object": kind, "settings": {parameter id: value}} (a Railing: its aw_railing preset)."""
    import aw_molding as M
    import aw_roof as R
    import aw_stair as S
    if kind == RAILING:
        import aw_railing
        return dict(aw_railing.PRESETS[int(c["style"])], card=dict(c))
    if kind == WALL:
        v = {I.AW_WALL_THICKNESS: float(c["thickness"]) * IN, I.AW_WALL_HEIGHT: float(c["height"]) * IN,
             I.AW_WALL_ALIGN: _WALL_ALIGN[c["type"]]}
    elif kind == STAIR:
        v = {I.AW_STAIR_SHAPE: {"straight": S.STRAIGHT, "l": S.L_SHAPE, "u": S.U_SHAPE, "spline": S.SPLINE}[c["shape"]],
             I.AW_STAIR_WIDTH: float(c["width"]) * IN}
    elif kind == BASEBOARD:
        v = {I.AW_MOLDING_TYPE: M.BASE, I.AW_MOLDING_HEIGHT: float(c["height"]) * IN,
             I.AW_MOLDING_PROFILE: {"square": M.SQUARE, "rounded": M.ROUNDED, "ogee": M.OGEE, "quarter": M.QUARTER,
                                    "cove": M.COVE}[c["profile"]]}
    elif kind == CROWN:
        size = float(c["size"]) * IN
        v = {I.AW_MOLDING_TYPE: M.CROWN, I.AW_MOLDING_HEIGHT: size, I.AW_MOLDING_DEPTH: size,
             I.AW_MOLDING_PROFILE: {"crown": M.CROWN_OGEE, "cove": M.COVE, "ogee": M.OGEE}[c["profile"]]}
    elif kind == ROOF:
        v = {I.AW_ROOF_SHAPE: {"auto": R.SHAPE_AUTO, "hip": R.SHAPE_HIP, "gable": R.SHAPE_GABLE,
                               "shed": R.SHAPE_SHED}[c["shape"]],
             I.AW_ROOF_PITCH: math.atan(float(c["pitch"]) / 12.0)}
    else:
        v = {I.AW_BEAM_SECTION: [o[0] for o in BEAM_SECTIONS].index(c["section"])}
    return {"label": label(kind, c), "object": kind, "settings": v, "card": dict(c)}


def _build_label(kind, c):
    name = lambda options, key: dict(options)[c[key]]  # noqa: E731
    if kind == WALL:
        return "%s Wall, %s in, %s" % (name(WALL_TYPES, "type").replace(" Wall", ""), _inch(float(c["thickness"])),
                                      _feet(float(c["height"])))
    if kind == STAIR:
        return "%s Stair, %s in" % (name(STAIR_SHAPES, "shape"), c["width"])
    if kind == RAILING:
        return name(_railings(), "style")
    if kind == BASEBOARD:
        return "%s in %s Baseboard" % (_inch(float(c["height"])), name(BASEBOARD_PROFILES, "profile"))
    if kind == CROWN:
        return "%s in %s Crown" % (_inch(float(c["size"])), name(CROWN_PROFILES, "profile"))
    if kind == ROOF:
        return "%s Roof, %s/12" % (name(ROOF_SHAPES, "shape"), c["pitch"])
    return "%s Beam" % name(BEAM_SECTIONS, "section")


# The cards -------------------------------------------------------------------------------

def _ids(numbers):
    return ["%g" % n for n in numbers]


def _opts(numbers, fmt=_inch):
    return tuple(("%g" % n, fmt(n)) for n in numbers)


def rows(kind, choices):
    """[(row key, label, ((option id, label), ...))]: the card's rows for these choices
    (normalized), each offering only what fits the rows above it."""
    c = normalize(kind, choices)
    if kind in BUILD:
        return _build_rows(kind, c)
    if kind == A.WINDOW:
        return [("style", "Style", WINDOW_STYLES),
                ("size", "Size", tuple(("%dx%d" % s, size_label(*s)) for s in WINDOW_SIZES[c["style"]]))]
    if kind == A.DOOR:
        out = [("operation", "Operation", DOOR_OPERATIONS)]
        if _hinged(c["operation"]):
            out.append(("side", "Side", DOOR_SIDES))
        if _has_style(c["operation"]):
            out.append(("style", "Style", DOOR_STYLES))
        out.append(("width", "Width", _opts(DOOR_WIDTHS[c["operation"]], lambda n: _inch(n) + " in")))
        out.append(("height", "Height", _opts(DOOR_HEIGHTS, lambda n: _inch(n) + " in")))
        return out
    if kind == A.CABINET:
        out = [("type", "Type", CABINET_TYPES), ("config", "Configuration", CABINET_CONFIGS[c["type"]])]
        if c["type"] in CABINET_HEIGHTS:
            out.append(("height", "Height", _opts(CABINET_HEIGHTS[c["type"]], lambda n: _inch(n) + " in")))
        out.append(("width", "Width", _opts(CABINET_WIDTHS[(c["type"], c["config"])], lambda n: _inch(n) + " in")))
        if c["config"] not in ("open",):
            out.append(("front", "Front", CABINET_FRONTS))
        return out
    if kind == A.CUTTER:
        return [("shape", "Shape", CUTOUT_SHAPES), ("type", "Type", CUTOUT_TYPES),
                ("width", "Width", _opts(CUTOUT_WIDTHS[c["type"]], lambda n: _inch(n) + " in")),
                ("height", "Height", _opts(CUTOUT_HEIGHTS[c["type"]], lambda n: _inch(n) + " in"))]
    if kind == A.FIREPLACE:
        return [("style", "Style", FIREPLACE_STYLES),
                ("width", "Width", _opts(FIREPLACE_WIDTHS, lambda n: _inch(n) + " in"))]
    raise ValueError("no card for %r" % kind)


DEFAULTS = {A.WINDOW: WINDOW_DEFAULTS, A.DOOR: DOOR_DEFAULTS, A.CABINET: CABINET_DEFAULTS, A.CUTTER: CUTOUT_DEFAULTS,
            A.FIREPLACE: FIREPLACE_DEFAULTS, WALL: WALL_DEFAULTS, STAIR: STAIR_DEFAULTS, RAILING: RAILING_DEFAULTS,
            BASEBOARD: BASEBOARD_DEFAULTS, CROWN: CROWN_DEFAULTS, ROOF: ROOF_DEFAULTS, BEAM: BEAM_DEFAULTS}
PLACING = (A.WINDOW, A.DOOR, A.CUTTER, A.FIREPLACE, A.CABINET)  # placed on a wall by the place tool
KINDS = tuple(DEFAULTS)


def normalize(kind, choices):
    """choices with every row filled in: one left out, or not offered any more, takes its
    default if that is offered, else the row's first option. Rows are settled top down,
    so a Width is checked against the Operation as it now is."""
    c = dict(DEFAULTS[kind])
    c.update({k: str(v) for k, v in (choices or {}).items() if k in c})

    def settle(key, options, prefer=None):
        ids = [o[0] for o in options]
        if c[key] in ids:
            return
        near = _nearest(c[key], ids)  # a size not offered: the nearest one that is
        c[key] = near if near is not None else (prefer if prefer in ids else ids[0])

    if kind == A.WINDOW:
        settle("style", WINDOW_STYLES)
        settle("size", [("%dx%d" % s, "") for s in WINDOW_SIZES[c["style"]]], WINDOW_DEFAULTS["size"])
    elif kind == A.DOOR:
        settle("operation", DOOR_OPERATIONS)
        settle("side", DOOR_SIDES)
        settle("style", DOOR_STYLES)
        if c["operation"] == "double" and c["width"] not in _ids(DOOR_WIDTHS["double"]):
            c["width"] = "%g" % (2 * float(c["width"]))  # a pair of what it was: a 30 in single, a 60 in pair
        settle("width", _opts(DOOR_WIDTHS[c["operation"]]), "30" if c["operation"] != "double" else "60")
        settle("height", _opts(DOOR_HEIGHTS))
    elif kind == A.CABINET:
        settle("type", CABINET_TYPES)
        settle("config", CABINET_CONFIGS[c["type"]])
        settle("height", _opts(CABINET_HEIGHTS.get(c["type"], (34.5,))))
        settle("width", _opts(CABINET_WIDTHS[(c["type"], c["config"])]))
        settle("front", CABINET_FRONTS)
    elif kind == A.CUTTER:
        settle("shape", CUTOUT_SHAPES)
        settle("type", CUTOUT_TYPES)
        settle("width", _opts(CUTOUT_WIDTHS[c["type"]]))
        settle("height", _opts(CUTOUT_HEIGHTS[c["type"]]))
    elif kind == A.FIREPLACE:
        settle("style", FIREPLACE_STYLES)
        settle("width", _opts(FIREPLACE_WIDTHS))
    elif kind in BUILD:
        if kind == WALL and c.get("type") in _WALL_TYPE_DEFAULTS:  # a type's own size, not the nearest
            for key, value in _WALL_TYPE_DEFAULTS[c["type"]].items():
                if c[key] not in _ids(WALL_THICKNESS[c["type"]] if key == "thickness" else WALL_HEIGHTS[c["type"]]):
                    c[key] = value
        for key, _label, options in _build_rows(kind, c):  # top down: a row's options follow the rows above
            settle(key, options)
    return c


def _numbers(oid):
    try:
        return [float(n) for n in str(oid).split("x")]
    except ValueError:
        return None


def _nearest(oid, ids):
    """The id of ids nearest oid, both sizes (36, 36x60); None if they aren't."""
    want = _numbers(oid)
    if not want:
        return None
    best = None
    for i in ids:
        have = _numbers(i)
        if not have or len(have) != len(want):
            return None
        d = sum((a - b) ** 2 for a, b in zip(have, want))
        if best is None or d < best[0]:
            best = (d, i)
    return best[1] if best else None


def label(kind, choices, settle=True):
    """What the choices make, in a few words: Double-hung 36 x 60, 30 in 6 Panel Door.
    settle=False: the choices as given (a size typed while placing, off the catalog)."""
    c = normalize(kind, choices) if settle else dict(DEFAULTS[kind], **choices)
    if kind in BUILD:
        return _build_label(kind, c)
    name = lambda options, key: dict(options)[c[key]]  # noqa: E731
    if kind == A.WINDOW:
        w, h = c["size"].split("x")
        return "%s %s" % (name(WINDOW_STYLES, "style"), size_label(float(w), float(h)))
    if kind == A.DOOR:
        width = _inch(float(c["width"])) + " in"
        if c["operation"] == "cased":
            return "%s Cased Opening" % width
        if c["operation"] == PATIO:
            return "%s Patio Slider" % width
        what = {"single": "Door", "double": "Double Door", "barn": "Barn Door", "pocket": "Pocket Door"}
        side = "Exterior " if _hinged(c["operation"]) and c["side"] == "exterior" else ""
        return "%s %s%s %s" % (width, side, name(DOOR_STYLES, "style"), what[c["operation"]])
    if kind == A.CUTTER:
        return "%s %s %s" % (size_label(float(c["width"]), float(c["height"])), name(CUTOUT_SHAPES, "shape"),
                             name(CUTOUT_TYPES, "type"))
    if kind == A.FIREPLACE:
        style = name(FIREPLACE_STYLES, "style")
        return "%s in Fireplace%s" % (_inch(float(c["width"])), "" if style == "Plain" else ", " + style)
    return "%s in %s %s" % (_inch(float(c["width"])), name(CABINET_TYPES, "type"),
                            name(CABINET_CONFIGS[c["type"]], "config"))


def preset(kind, choices):
    """The choices as a preset (aw_placing's shape) to place, as a built-in one is; a Build
    kind's: its settings by parameter id (_build_preset)."""
    c = normalize(kind, choices)
    if kind in BUILD:
        return _build_preset(kind, c)
    if kind == A.WINDOW:
        w, h = (float(n) for n in c["size"].split("x"))
        v = _window_values(c["style"], w, h)
        return {"label": label(kind, c), "object": A.WINDOW, "key": W.TYPE_KEYS[v["kind"]], "values": v,
                "card": dict(c)}
    if kind == A.DOOR and c["operation"] == PATIO:
        v = {"kind": W.SLIDING, "leaves_1": 2, "handle": W.HANDLE_INSIDE, "width": float(c["width"]) * IN,
             "height": float(c["height"]) * IN, "sill": 0.0}
        return {"label": label(kind, c), "object": A.WINDOW, "key": "PatioSlider", "name": "Door", "values": v,
                "card": dict(c)}
    if kind == A.DOOR:
        v = dict(_DOOR_OPERATION_VALUES[c["operation"]])
        if _has_style(c["operation"]):
            v.update(_DOOR_STYLE_VALUES[c["style"]])
        if _hinged(c["operation"]) and c["side"] == "exterior":
            v.update(_EXTERIOR)
        v.update(width=float(c["width"]) * IN, height=float(c["height"]) * IN, sill=0.0)
        return {"label": label(kind, c), "object": A.DOOR, "key": D.TYPE_KEYS[v["kind"]], "values": v,
                "card": dict(c)}
    if kind == A.CUTTER:
        w, h = float(c["width"]), float(c["height"])
        v = _cutout_values(c["shape"], w)
        v.update(width=w * IN, height=h * IN, sill=PASS_SILL * IN if c["type"] == "pass" else 0.0)
        return {"label": label(kind, c), "object": A.CUTTER, "key": CU.SHAPE_NAMES[v["shape"]].replace(" ", ""),
                "values": v, "card": dict(c)}
    if kind == A.FIREPLACE:
        base = next(p for p in A.FIREPLACE_PRESETS if p["key"] == c["style"])
        v = dict(base["values"], width=float(c["width"]) * IN)
        return dict(base, label=label(kind, c), values=v, card=dict(c))
    t = _TYPE_IDS[c["type"]]
    extra = dict(_CABINET_EXTRA.get((c["type"], c["config"]), {}))
    extra["style"] = _FRONT_IDS[c["front"]]
    p = C._cab(label(kind, c), t, float(c["width"]) * IN, _cabinet_zones(c["type"], c["config"]), **extra)
    if c["type"] in CABINET_HEIGHTS:
        p["values"]["height"] = float(c["height"]) * IN
    p["card"] = dict(c)
    return p


def parse_size(text):
    """A size typed while placing, in inches: "36x60" -> (36.0, 60.0), "30" -> (30.0, None)
    (a width alone: a door's or cabinet's); None until it reads as one."""
    t = text.lower().replace("×", "x").replace(" ", "").replace('"', "")
    if not t:
        return None
    parts = t.split("x")
    try:
        if len(parts) == 1:
            return float(parts[0]), None
        if len(parts) == 2 and parts[1]:
            return float(parts[0]), float(parts[1])
    except ValueError:
        return None
    return None


def resize(kind, p, w, h=None):
    """A copy of preset p at w (and h) inches: a window's sill follows its height, its
    head staying at HEAD; a casement gets the leaves its width calls for."""
    out = dict(p, values=dict(p["values"]))
    v = out["values"]
    if "card" in p:  # named for its new size
        c = dict(p["card"])
        if kind == A.WINDOW:
            ow, oh = c["size"].split("x")
            c["size"] = "%gx%g" % (w if w else float(ow), h if h else float(oh))
        else:
            c["width"] = "%g" % w if w else c["width"]
            if h and kind == A.DOOR or (h and kind == A.CABINET):
                c["height"] = "%g" % h
        out["card"], out["label"] = c, label(kind, c, settle=False)
    if w is not None and w > 0:
        v["width"] = w * IN
        if kind == A.WINDOW and v.get("kind") == W.CASEMENT:
            v["leaves_1"] = max(1, int(round(w / 24.0)))
    if h is not None and h > 0:
        v["height"] = h * IN
        if kind == A.WINDOW:
            v["sill"] = max(HEAD - h, MIN_SILL) * IN
    return out


# A placed one, read back ---------------------------------------------------------------------

_WINDOW_STYLE_OF = {W.DOUBLE_HUNG: "double_hung", W.CASEMENT: "casement", W.SLIDING: "slider", W.FIXED: "picture"}
_CABINET_TYPE_OF = {v: k for k, v in _TYPE_IDS.items()}
_FRONT_OF = {v: k for k, v in _FRONT_IDS.items()}


def _door_style_of(v):
    model, rows = int(v.get("model", D.FLAT)), int(v.get("panels_v", 1))
    if model == D.GLASS:  # one pane, 2 across (10 Lite), 3 across (15 Lite)
        cols = int(v.get("panels_h", 1))
        return "glass" if cols == 1 and rows == 1 else ("ten_lite" if cols == 2 else "full_lite")
    if model == D.BEVEL and rows >= 3:
        return "six_panel"
    if model == D.HALF_LITE:
        return "half_lite"
    if model in (D.PANEL, D.BEVEL):
        return "shaker" if rows == 1 else "two_panel"
    return "flat"


def choices_of(kind, values, stored=None):
    """The card's choices for a placed object, from its settings (values: {preset field:
    value}, as a preset holds them) and what the card stored on it when it was placed
    (stored: a cabinet's Configuration can't be read back from its zones). Sizes are as
    the object has them, on the catalog or not: label() them with settle=False."""
    c = dict(DEFAULTS[kind], **(stored or {}))
    inch = lambda field: "%g" % round(values.get(field, 0.0) / IN, 2)  # noqa: E731
    if kind == A.WINDOW:
        c["style"] = _WINDOW_STYLE_OF.get(int(values.get("kind", W.DOUBLE_HUNG)), "double_hung")
        c["size"] = "%sx%s" % (inch("width"), inch("height"))
    elif kind == A.DOOR:
        if int(values.get("shape", D.SINGLE_RABBET)) == D.CASED:
            c["operation"] = "cased"
        else:
            c["operation"] = {D.SLIDING: "barn", D.POCKET: "pocket"}.get(
                int(values.get("kind", D.HINGED)), "double" if int(values.get("leaves", 1)) == 2 else "single")
        c["side"] = "exterior" if values.get("step") and values.get("sill_on") else "interior"
        c["style"] = _door_style_of(values)
        c["width"], c["height"] = inch("width"), inch("height")
    elif kind == A.CUTTER:
        shape = int(values.get("shape", CU.ROUND))
        c["shape"] = {CU.RECTANGLE: "rectangle", CU.ELLIPTIC: "elliptic", CU.POINTED: "gothic",
                      CU.ROUNDED: "rounded"}.get(shape, "round")
        if shape == CU.ROUND and values.get("radius", 0.0) > values.get("width", 0.0) / 2 + 0.5:
            c["shape"] = "segmental"  # an arc wider than a half circle
        c["type"] = "pass" if values.get("sill", 0.0) > 1.0 else "walk"
        c["width"], c["height"] = inch("width"), inch("height")
    elif kind == A.FIREPLACE:
        c["width"] = inch("width")
    elif kind == A.CABINET:
        c["type"] = _CABINET_TYPE_OF.get(int(values.get("type", C.BASE)), "base")
        if c["config"] not in [o[0] for o in CABINET_CONFIGS[c["type"]]]:
            c["config"] = CABINET_CONFIGS[c["type"]][0][0]
        c["front"] = _FRONT_OF.get(int(values.get("style", C.SHAKER)), "shaker")
        c["width"], c["height"] = inch("width"), inch("height")
    return c


SIZE_ROWS = ("size", "width", "height")  # what changing them changes: the size alone


def changed(kind, current, key, option):
    """{preset field: value} to set when the card's row key is changed to option on an
    object whose choices are current (choices_of). A size row sets only that size (a
    window's sill following, its head staying put); any other row sets everything but
    the size, and the size too where the new choice doesn't come in it (a Single door
    of 30 in made Double: 60 in)."""
    if key in SIZE_ROWS:
        if kind == A.WINDOW:
            w, h = (float(n) for n in option.split("x"))
            return {"width": w * IN, "height": h * IN, "sill": max(HEAD - h, MIN_SILL) * IN}
        return {key: float(option) * IN}
    c = dict(current, **{key: option})
    settled = normalize(kind, c)
    v = preset(kind, settled)["values"]
    out = {k: val for k, val in v.items() if k not in ("width", "height", "sill")}
    if kind == A.CUTTER:
        if key == "type":
            out["sill"] = v["sill"]  # walked through, or over a counter
        if key == "shape" and "radius" in out and out["radius"]:  # a radius that is the cutout's own width
            out["radius"] = float(current["width"]) * IN
    for row in SIZE_ROWS:
        if row in c and settled[row] != c[row]:  # not offered any more: the new choice's own
            if row == "size":
                out.update({k: v[k] for k in ("width", "height", "sill")})
            else:
                out[row] = v[row]
    return out
