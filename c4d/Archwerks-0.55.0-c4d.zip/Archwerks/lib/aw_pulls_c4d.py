"""The pulls library for Cinema 4D: the user's own pulls, kept in a .c4d file (read
by aw_host.pull_library, added to from the panel)."""
import os

import c4d  # noqa: F401


_library = {"stamp": None, "items": []}


def library_path():
    return os.path.expanduser("~/Library/Application Support/Archwerks/pulls.c4d")


def library():
    """[(name, (points, polys))] of the pulls in the library file, read again when it
    changes; [] without one."""
    path = library_path()
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        _library.update(stamp=None, items=[])
        return []
    if stamp == _library["stamp"]:
        return _library["items"]
    import aw_host
    items = []
    doc = c4d.documents.LoadDocument(path, c4d.SCENEFILTER_OBJECTS, None)
    if doc is not None:
        doc.ExecutePasses(None, False, False, True, c4d.BUILDFLAGS_NONE)
        o = doc.GetFirstObject()
        while o:
            mesh = aw_host.custom_mesh(o)  # in its own space: its axis is the pull's frame
            if mesh:
                items.append((o.GetName(), mesh))
            o = o.GetNext()
    _library.update(stamp=stamp, items=items)
    return items


def add_to_library(obj):
    """Copy obj (and what is under it) into the user's pulls library, at the origin.
    Returns its name there."""
    import c4d
    path = library_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    doc = c4d.documents.LoadDocument(path, c4d.SCENEFILTER_OBJECTS, None) if os.path.exists(path) else None
    if doc is None:
        doc = c4d.documents.BaseDocument()
    names = set()
    o = doc.GetFirstObject()
    while o:
        names.add(o.GetName())
        o = o.GetNext()
    clone = obj.GetClone(c4d.COPYFLAGS_NONE)
    name, n = obj.GetName(), 2
    while name in names:
        name, n = "%s %d" % (obj.GetName(), n), n + 1
    clone.SetName(name)
    clone.SetMg(c4d.Matrix())
    doc.InsertObject(clone, None, doc.GetFirstObject() and _last(doc))
    ok = c4d.documents.SaveDocument(doc, path, c4d.SAVEDOCUMENTFLAGS_DONTADDTORECENTLIST, c4d.FORMAT_C4DEXPORT)
    if not ok:
        raise OSError("couldn't save " + path)
    return name


def _last(doc):
    o = doc.GetFirstObject()
    while o and o.GetNext():
        o = o.GetNext()
    return o
