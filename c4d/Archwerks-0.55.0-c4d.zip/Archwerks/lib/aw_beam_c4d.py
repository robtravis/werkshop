"""aw_beam for Cinema 4D: the parts of core/aw_beam.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_groups_c4d
import aw_beam  # noqa: F401
from aw_beam import *  # noqa: F401,F403


def change_key(op):
    import c4d
    s = settings(op)
    prof = s["profile"]
    pkey = prof.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_CACHE) if prof is not None and prof.IsAlive() else None
    return (op.GetName(), op.GetDirty(c4d.DIRTYFLAGS_DATA), pkey)


def add(doc):
    """Panel button Beam: a beam at the origin, selected, in AW Edit Dimensions."""
    import c4d
    import aw_ids as I
    import aw_materials
    import aw_slab
    import aw_slab_c4d
    b = c4d.BaseObject(I.ID_AW_BEAM)
    b.SetName(aw_slab_c4d.next_name(doc, "Beam"))
    doc.StartUndo()
    doc.InsertObject(b)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, b)
    aw_materials.apply_defaults(doc, b)
    aw_groups_c4d.file(doc, b)  # into its group: null and layer (aw_groups_c4d)
    doc.EndUndo()
    doc.SetActiveObject(b, c4d.SELECTION_NEW)
    doc.SetAction(I.ID_AW_EDIT_TOOL)
    c4d.EventAdd()
    return b
