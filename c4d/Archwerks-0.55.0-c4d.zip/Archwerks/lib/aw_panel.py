"""The Archwerks panel: a dockable window of presets and tools.

A wall preset adds a Wall with that preset's settings and an empty spline
inside it, selects the spline and starts C4D's Spline Pen, so the wall builds
as the points go down. Drawing walls turns the pen's Create New Splines on, so
every run, however it is finished (Escape or closing it), is its own spline;
`adopt` pulls each one into the wall as Run.01, Run.02, ... The pen's own
settings are put back when drawing ends (another tool is picked).
"""
import c4d

import aw_groups_c4d
import aw_ids as I

SPLINE_PEN = 440000149  # C4D's Spline Pen tool
PEN_TYPE, PEN_TYPE_LINEAR, PEN_NEW_SPLINES = 1100, 0, 1104  # its settings (MDATA_SPLINEPEN_*)

IN = 2.54  # cm per inch: presets are written in the units they are known by

# button label, thickness, height, align, name key (walls are named Wall.<key>.001, ...)
PRESETS = (
    ("Exterior", 8 * IN, 108 * IN, I.AW_ALIGN_INSIDE, "Exterior"),   # 8 in, 9 ft; trace the outside face
    ("Interior", 4.5 * IN, 108 * IN, I.AW_ALIGN_CENTER, "Interior"),  # 4.5 in, 9 ft; trace the centre line
    ("Half wall", 4.5 * IN, 42 * IN, I.AW_ALIGN_CENTER, "Half"),      # 4.5 in, 42 in
)


def _all_objects(doc):
    out, stack = [], [doc.GetFirstObject()]
    while stack:
        o = stack.pop()
        while o:
            out.append(o)
            if o.GetDown():
                stack.append(o.GetDown())
            o = o.GetNext()
    return out


def next_wall_name(doc, key=None):
    """Wall.<key>.NNN (Wall.NNN without a key), one past the highest already in the
    document, so walls count up per type with no spaces in their names."""
    prefix = "Wall.%s." % key if key else "Wall."
    highest = 0
    for o in _all_objects(doc):
        name = o.GetName()
        if name.startswith(prefix) and name[len(prefix):].isdigit():
            highest = max(highest, int(name[len(prefix):]))
    return "%s%03d" % (prefix, highest + 1)

_armed = None  # (wall, spline, splines already in the document) while a started wall waits for drawing
_pen_before = None  # the Spline Pen's (Type, Create New Splines) before wall drawing changed them


def _all_splines(doc):
    """Every editable spline in the document, in Object Manager order."""
    out, stack = [], [doc.GetFirstObject()]
    while stack:
        o = stack.pop()
        while o:
            if o.GetType() == c4d.Ospline:
                out.append(o)
            if o.GetDown():
                stack.append(o.GetDown())
            o = o.GetNext()
    return out


def _uid(obj):
    """An object's lasting identity. GetGUID() is NOT one: it changes whenever the
    spline's points do. The creator id stays through moves and edits."""
    u = obj.FindUniqueID(c4d.MAXON_CREATOR_ID)
    return bytes(u) if u is not None else id(obj)


def _spline_ids(doc):
    """Identities of every editable spline in the document."""
    return {_uid(o) for o in _all_splines(doc)}


RUN_NAME = "Run.%03d"  # the splines a wall is drawn with: Run.001, Run.002, ...


def next_run_name(wall):
    """The name for the next spline drawn into a wall: one past its highest Run.NNN."""
    highest = 0
    for child in wall.GetChildren():
        name = child.GetName()
        if name.startswith("Run.") and name[4:].isdigit():
            highest = max(highest, int(name[4:]))
    return RUN_NAME % (highest + 1)


def selected_splines(doc):
    """The selected splines that aren't already a wall's path."""
    return [o for o in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
            if o.GetInfo() & c4d.OBJECT_ISSPLINE and (o.GetUp() is None or o.GetUp().GetType() != I.ID_AW_WALL)]


def start_wall(doc, preset=None):
    """Add a wall from `preset` (None: the Wall object's own defaults) with an empty spline
    in it, ready for the Spline Pen. One undo step. Returns the wall."""
    wall = c4d.BaseObject(I.ID_AW_WALL)
    if preset is None:
        name = "new"
        wall.SetName(next_wall_name(doc))
    else:
        name, thick, height, align, key = preset
        wall.SetName(next_wall_name(doc, key))
        wall[I.AW_WALL_THICKNESS] = thick
        wall[I.AW_WALL_HEIGHT] = height
        wall[I.AW_WALL_ALIGN] = align
    spline = c4d.SplineObject(0, c4d.SPLINETYPE_LINEAR)
    spline.SetName(RUN_NAME % 1)
    doc.StartUndo()
    doc.InsertObject(wall)
    spline.InsertUnder(wall)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, wall)
    import aw_materials
    aw_materials.apply_defaults(doc, wall)  # default materials in its empty slots
    aw_groups_c4d.file(doc, wall)  # into its group: null and layer (aw_groups_c4d)
    doc.SetActiveObject(spline, c4d.SELECTION_NEW)
    doc.EndUndo()
    _arm_pen(doc, wall, spline)
    c4d.gui.StatusSetText("Draw the %s wall: click each corner, click the first point to close it"
                          % ("new" if preset is None else name.lower()))
    c4d.EventAdd()
    return wall


_mode_before = None  # the document's mode when the Spline Pen was armed (finish puts it back)


def _arm_pen(doc, owner, spline):
    """Start the Spline Pen drawing into owner (a Wall, Floor or Ceiling): every
    spline it makes is pulled in (adopt) until another tool is picked."""
    global _armed, _pen_before, _mode_before
    import aw_drawtool_c4d
    if aw_drawtool_c4d.registered():  # AW Draw: Blender's guides, snapping and typed lengths
        aw_drawtool_c4d.arm(doc, owner, spline)
        return
    _armed = (owner, spline, _spline_ids(doc))
    if _mode_before is None:  # the Spline Pen puts the document in Points mode: put back when drawing ends
        _mode_before = doc.GetMode()
    pen = c4d.plugins.GetToolData(doc, SPLINE_PEN)
    if pen is not None:  # straight segments, a new spline for every run
        if _pen_before is None:  # a second preset while drawing keeps the first one's saved settings
            _pen_before = (pen.GetInt32(PEN_TYPE), pen.GetBool(PEN_NEW_SPLINES))
        pen.SetInt32(PEN_TYPE, PEN_TYPE_LINEAR)
        pen.SetBool(PEN_NEW_SPLINES, True)
    doc.SetAction(SPLINE_PEN)


def start_floor(doc, kind):
    """A Floor (or Ceiling) with an empty spline in it, ready for the Spline Pen; one
    undo step. Close each outline (a loop drawn inside another is a hole)."""
    import aw_floor
    import aw_materials
    import aw_slab
    import aw_slab_c4d
    obj = c4d.BaseObject(I.ID_AW_CEILING if kind == aw_floor.CEILING else I.ID_AW_FLOOR)
    obj.SetName(aw_slab_c4d.next_name(doc, "Ceiling" if kind == aw_floor.CEILING else "Floor"))
    spline = c4d.SplineObject(0, c4d.SPLINETYPE_LINEAR)
    spline.SetName(RUN_NAME % 1)
    doc.StartUndo()
    doc.InsertObject(obj)
    spline.InsertUnder(obj)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, obj)
    aw_materials.apply_defaults(doc, obj)
    aw_groups_c4d.file(doc, obj)  # into its group: null and layer (aw_groups_c4d)
    doc.SetActiveObject(spline, c4d.SELECTION_NEW)
    doc.EndUndo()
    _arm_pen(doc, obj, spline)
    c4d.gui.StatusSetText("Draw the %s: click each corner, click the first point to close it; "
                          "draw another loop inside it for a hole" % obj.GetName().split(".")[0].lower())
    c4d.EventAdd()
    return obj


def finish(doc):
    """Wall drawing is over: stop pulling splines in and put the pen's settings back, and
    the document's mode (the pen leaves it in Points, where the Move tool can't select
    another object)."""
    global _armed, _pen_before, _mode_before
    _armed = None
    if _mode_before is not None:
        if doc is not None and doc.GetMode() in (c4d.Mpoints, c4d.Medges, c4d.Mpolygons) \
                and _mode_before not in (c4d.Mpoints, c4d.Medges, c4d.Mpolygons):
            doc.SetMode(_mode_before)
            c4d.EventAdd()
        _mode_before = None
    if _pen_before is not None:
        pen = c4d.plugins.GetToolData(doc, SPLINE_PEN)
        if pen is not None:
            pen.SetInt32(PEN_TYPE, _pen_before[0])
            pen.SetBool(PEN_NEW_SPLINES, _pen_before[1])
        _pen_before = None


def adopt(doc):
    """While a wall started from the panel is being drawn, pull every spline the
    Spline Pen makes into it and name it Run.NN. The pen makes a new spline for
    every run, sometimes beside the selected spline (so already inside the wall),
    sometimes at the top of the document, and with several splines selected, so
    this looks for every spline that did not exist when the wall started rather
    than at the selection. The first one takes the empty starting spline's place
    and name (Run.01). Only while the Spline Pen is still the tool: switching tools
    ends it. Called on every document change, by the plugin's draw watcher (and by
    the panel while it is open)."""
    if _armed is None:
        return
    wall, placeholder, before = _armed
    try:
        if not wall.IsAlive() or wall.GetDocument() != doc or doc.GetAction() != SPLINE_PEN:
            finish(doc)
            return
        new = [o for o in _all_splines(doc) if _uid(o) not in before]
        if not new:
            return
        for o in new:  # into the wall, staying where they are drawn
            before.add(_uid(o))
            if o.GetUp() != wall:
                mg = o.GetMg()
                o.Remove()
                o.InsertUnderLast(wall)
                o.SetMg(mg)
        # names in the wall's own order; the first takes the empty starting spline's
        uids = {_uid(o) for o in new}
        for o in wall.GetChildren():
            if _uid(o) not in uids:
                continue
            if placeholder is not None and placeholder.IsAlive() and placeholder.GetPointCount() == 0:
                name = placeholder.GetName()
                placeholder.Remove()
                placeholder = None
                _set_armed(wall, None, before)
                o.SetName(name)
            else:
                o.SetName(next_run_name(wall))
        changed = True
        if changed:
            c4d.EventAdd()
    except ReferenceError:
        finish(doc)


def _set_armed(wall, placeholder, before):
    global _armed
    _armed = (wall, placeholder, before)


# Panel buttons
B_FLOOR_PLAN, B_SCALE_PLAN, B_FROM_SPLINE, B_EDIT = 2000, 2001, 2002, 2003
B_PRESET = 2100  # + index into PRESETS
B_WINDOW = 2200  # + index into aw_place.all_presets() (built-in, then saved)
B_SAVE_WINDOW, B_DELETE_WINDOW, B_DUPLICATE = 2290, 2291, 2292  # for the selected window or door
B_DOOR = 2400  # + index into aw_place.all_presets(DOOR)
B_RAILING = 2500  # + index into aw_place.all_presets(RAILING)
B_CABINET = 2600  # + index into aw_place.all_presets(CABINET)
B_ADD_PULL = 2293  # the selected object into the pulls library
B_COUNTERTOP = 2294  # over the selected cabinets
B_SINK = 2700  # + index into aw_counter_c4d.SINK_PRESETS
G_WINDOWS = 2299
G_BODY = 2298  # the tab's tools, laid out again when the tab or a card choice changes
STATE = {"tab": "BUILD", "kind": {}, "choices": {}}  # the panel's tab, card and choices: kept across reloads
G_ROOT = 2999  # everything, so the whole panel can be laid out again  # the window buttons' group, rebuilt when a preset is saved or deleted
B_FLOOR, B_CEILING, B_BASEBOARD, B_CROWN = 2300, 2301, 2302, 2303
B_SPLINE_FLOOR, B_SPLINE_CEILING, B_ROOF = 2304, 2305, 2306  # a Wall's rooms, the selected splines, or draw one
B_ROOF_CUTTER = 2307  # under the selected Roof
B_STAIR = 2308  # along the selected spline, or a straight one
B_BEAM = 2309
B_PANELS = 2310  # on the selected Wall
B_TIDY = 2311  # every Archwerks object into its group null and layer (aw_groups_c4d.tidy)
B_LINKED_COPIES, B_MAKE_UNIQUE, B_SELECT_LINKED = 2312, 2313, 2314  # linked windows and doors (aw_link_c4d)


# Build cards that add to the selection: the command that adds one (aw_commands_c4d), what it
# makes, and the button. A railing is added by aw_railing_c4d with the card's preset.
BUILD_RUN = {"stair": "stair", "baseboard": "baseboard", "crown": "crown", "roof": "roof", "beam": "beam",
             "railing": "railing"}
BUILD_IDS = {"stair": I.ID_AW_STAIR, "baseboard": I.ID_AW_MOLDING, "crown": I.ID_AW_MOLDING, "roof": I.ID_AW_ROOF,
             "beam": I.ID_AW_BEAM, "railing": I.ID_AW_RAILING}
BUILD_ADD_LABELS = {"stair": "Add Stair", "baseboard": "Add Along Selected Walls", "crown": "Add Along Selected Walls",
                    "roof": "Add Over Selected Walls", "beam": "Add Beam", "railing": "Add (Selection, or Draw)"}
_ICONS = {}  # icon name: Cinema 4D's icon dict for a user area (the plugin's res/icons, as its commands')


def _icon(name):
    if name not in _ICONS:
        import os
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "res", "icons", name + ".png")
        bmp = c4d.bitmaps.BaseBitmap()
        ok = os.path.isfile(path) and bmp.InitWith(path)[0] == c4d.IMAGERESULT_OK
        _ICONS[name] = {"bmp": bmp, "x": 0, "y": 0, "w": bmp.GetBw(), "h": bmp.GetBh()} if ok else None
    return _ICONS[name]


class Panel(c4d.gui.GeDialog):
    """The dockable Archwerks panel."""

    def _section(self, title):
        self.AddStaticText(0, c4d.BFH_LEFT, name=title, borderstyle=c4d.BORDER_WITH_TITLE_BOLD)

    def CreateLayout(self):
        self.SetTitle("Archwerks")
        self.GroupBegin(G_ROOT, c4d.BFH_SCALEFIT | c4d.BFV_TOP, 1, 0)
        self._fill()
        self.GroupEnd()
        return True

    def refresh(self):
        """Lay the panel out again (new presets, or new panel code after a reload)."""
        self.LayoutFlushGroup(G_ROOT)
        self._fill()
        self.LayoutChanged(G_ROOT)

    # The panel is the Blender Sidebar's Create, drawn the same: a Build / Openings / Kitchen
    # tab row, the tab's groups of the shared command list (core/aw_commands, each with its
    # icon), and Window, Door, Cutout, Fireplace or Cabinet's placing card (core/aw_catalog)
    # under its buttons, each choice placing at once. The buttons are aw_buttons_c4d's,
    # drawn as Blender's. A selected object's settings are the Attribute Manager's.

    def _next_id(self):
        self._ids += 1
        return self._ids

    def _grid(self, columns=2):
        import aw_buttons_c4d
        g = aw_buttons_c4d.Grid(self, self._next_id, self._areas)
        g.begin(columns)
        return g

    def _fill(self):
        self._ids, self._areas = 6000, []
        self._windows, self._doors, self._cabinets, self._railings = [], [], [], []
        self.GroupBegin(0, c4d.BFH_SCALEFIT | c4d.BFV_TOP, 1, 0)
        self.GroupBorderSpace(8, 6, 8, 8)
        self.GroupSpace(0, 4)
        self.GroupBegin(G_BODY, c4d.BFH_SCALEFIT | c4d.BFV_TOP, 1, 0)
        self._body()
        self.GroupEnd()
        self.GroupEnd()

    def _body(self):
        import aw_commands as CMD
        self._areas = []
        self.GroupSpace(0, 4)
        tab = STATE["tab"]
        g = self._grid(len(CMD.TABS))
        for tid, label, _groups in CMD.TABS:
            g.add(label, lambda tid=tid: self._tab_chosen(tid), on=tid == tab)
        g.end()
        groups = [grp for grp in CMD.for_host("c4d") if grp[0] in dict((t[0], t[2]) for t in CMD.TABS)[tab]]
        shown = STATE["kind"].get(tab, CMD.CARD_DEFAULT.get(tab))
        for key, label, cmds in groups:
            if len(groups) > 1:
                self._section(label)
            g = self._grid()
            for cmd in cmds:
                kind = CMD.CARDS.get(cmd["key"])
                act = (lambda kind=kind: self._kind_chosen(kind)) if kind else \
                    (lambda key=cmd["key"]: self._run(key))
                g.add(cmd["label"], act, icon=_icon(cmd["icon"]), on=kind is not None and kind == shown)
            g.end()
            if shown is not None and shown in [CMD.CARDS.get(c["key"]) for c in cmds]:  # under the group its button is in
                self._card(shown)
                self._yours(shown)
        if tab != "BUILD":
            self._section("The selected window, door, railing or cabinet")
            g = self._grid(2)
            for bid, name in ((B_DUPLICATE, "Place Copies"), (B_LINKED_COPIES, "Place Linked Copies"),
                              (B_MAKE_UNIQUE, "Make Unique"), (B_SELECT_LINKED, "Select Linked"),
                              (B_SAVE_WINDOW, "Save Preset"), (B_DELETE_WINDOW, "Delete Preset")):
                g.add(name, lambda bid=bid: self.Command(bid, c4d.BaseContainer()))
            g.end()
        self.AddSeparatorH(0)
        tail = [CMD.BY_KEY[k] for k in CMD.TAIL]
        if tab == "BUILD":  # Cinema 4D's own: the plan and the dimensions
            tail = [c for _k, _l, cmds in CMD.for_host("c4d") if _k == "annotate" for c in cmds] + tail
        g = self._grid(1)
        for cmd in tail:
            g.add(cmd["label"], lambda key=cmd["key"]: self._run(key), icon=_icon(cmd["icon"]))
        g.end()

    def _run(self, key):
        import aw_commands_c4d
        aw_commands_c4d.run(key, c4d.documents.GetActiveDocument())

    def _card(self, kind):
        import aw_catalog as K
        c = K.normalize(kind, STATE["choices"].get(kind, {}))
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 1, 0, "", c4d.BFV_BORDERGROUP_FOLD_OPEN)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(6, 4, 6, 6)
        for key, label, options in K.rows(kind, c):
            self.AddStaticText(0, c4d.BFH_LEFT, name=label)
            g = self._grid()
            for oid, text in options:
                g.add(text, lambda key=key, oid=oid: self._choice_chosen(kind, key, oid), on=oid == c[key])
            g.end()
        self.AddStaticText(0, c4d.BFH_LEFT, name=K.label(kind, c))
        if kind == K.WALL:
            self.AddStaticText(0, c4d.BFH_LEFT, name="Press a choice, then draw in the view")
        elif kind in BUILD_RUN:
            g = self._grid(1)
            g.add(BUILD_ADD_LABELS[kind], lambda: self._add_build(kind))
            g.end()
        else:
            self.AddStaticText(0, c4d.BFH_LEFT, name="Hover a wall, click to place   Type a size: 36x60   Esc: stop")
        self.GroupEnd()

    def _yours(self, kind):
        """Saved presets of kind (Save preset), as buttons that place them."""
        import aw_place
        mine = aw_place.user_presets(kind)
        self._windows = mine
        if not mine:
            return
        self._section("Yours")
        g = self._grid()
        for i, p in enumerate(mine[:B_SAVE_WINDOW - B_WINDOW]):
            g.add(p["label"], lambda i=i: self.Command(B_WINDOW + i, c4d.BaseContainer()))
        g.end()

    def _rebuild_body(self):
        self.LayoutFlushGroup(G_BODY)
        self._body()
        self.LayoutChanged(G_BODY)

    def _place_card(self):
        """Place what the shown card's choices make (aw_place's tool, hovering a wall); a
        Wall card starts drawing a wall as it sets up; the other Build cards wait for Add."""
        import aw_catalog as K
        import aw_commands
        import aw_place
        tab = STATE["tab"]
        kind = STATE["kind"].get(tab, aw_commands.CARD_DEFAULT.get(tab))
        if kind is None:
            return
        doc = c4d.documents.GetActiveDocument()
        p = K.preset(kind, STATE["choices"].get(kind, {}))
        if kind == K.WALL:
            v = p["settings"]
            start_wall(doc, (p["label"], v[I.AW_WALL_THICKNESS], v[I.AW_WALL_HEIGHT], v[I.AW_WALL_ALIGN],
                             p["card"]["type"].title()))
        elif kind in K.PLACING:
            aw_place.choose(doc, p)

    def _add_build(self, kind):
        """Add: one of Build card kind on the selection (a railing, trim, a roof, a stair,
        a beam), set up as the card says. One undo step with what made it."""
        import aw_catalog as K
        doc = c4d.documents.GetActiveDocument()
        p = K.preset(kind, STATE["choices"].get(kind, {}))
        before = {_uid(o) for o in _all_objects(doc)}  # Python's wrappers are new each walk: their own ids
        if kind == K.RAILING:
            import aw_railing_c4d
            aw_railing_c4d.add_for_selection(doc, p)
            return
        self._run(BUILD_RUN[kind])
        made = [o for o in _all_objects(doc) if _uid(o) not in before and o.GetType() == BUILD_IDS[kind]]
        doc.StartUndo()
        for o in made:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE_SMALL, o)
            for pid, v in p["settings"].items():
                o[pid] = v
            o.Message(c4d.MSG_UPDATE)
        doc.EndUndo()
        c4d.EventAdd()

    def _tab_chosen(self, tab):
        STATE["tab"] = tab
        self._rebuild_body()
        if tab != "BUILD":
            self._place_card()
        else:  # off the cards: the place tool stops
            doc = c4d.documents.GetActiveDocument()
            if doc.GetAction() == I.ID_AW_PLACE_TOOL:
                doc.SetAction(c4d.ID_MODELING_MOVE)
                c4d.EventAdd()

    def _kind_chosen(self, kind):
        STATE["kind"][STATE["tab"]] = kind
        self._rebuild_body()
        self._place_card()

    def _choice_chosen(self, kind, key, value):
        import aw_catalog as K
        c = dict(STATE["choices"].get(kind, {}), **{key: value})
        STATE["choices"][kind] = K.normalize(kind, c)  # the rows below settle to what this one offers
        self._rebuild_body()
        self._place_card()

    def _rebuild_windows(self):
        self._rebuild_body()

    def _save_window(self, doc):
        import aw_place
        op = doc.GetActiveObject()
        if not (I.is_opening(op) or (op is not None and op.GetType() in (I.ID_AW_RAILING, I.ID_AW_CABINET))):
            c4d.gui.MessageDialog("Select a window, door, railing or cabinet first: Save preset keeps its settings.")
            return
        kind = aw_place._kind_of(op)
        name = c4d.gui.InputDialog("Save %s preset as" % kind, op.GetName())
        if not name:
            return
        if any(p["label"].lower() == name.strip().lower() for p in aw_place.user_presets(kind)):
            if not c4d.gui.QuestionDialog("Replace the saved preset %s?" % name.strip()):
                return
        try:
            aw_place.save_user_preset(name, op)
        except (ValueError, OSError) as e:
            c4d.gui.MessageDialog("Couldn't save the preset: %s" % e)
            return
        self._rebuild_windows()
        c4d.gui.StatusSetText("Saved %s preset %s" % (kind, name.strip()))

    def _delete_window(self):
        import aw_place
        saved = aw_place.user_presets()
        if not saved:
            c4d.gui.MessageDialog("No saved presets yet. Select a window, door or railing and click Save preset.")
            return
        menu = c4d.BaseContainer()
        for i, p in enumerate(saved):
            menu.InsData(c4d.FIRST_POPUP_ID + i, "%s: %s" % (aw_place.NAMES[p["object"]], p["label"]))
        pick = c4d.gui.ShowPopupDialog(cd=None, bc=menu, x=c4d.MOUSEPOS, y=c4d.MOUSEPOS)
        if pick < c4d.FIRST_POPUP_ID:
            return
        chosen = saved[pick - c4d.FIRST_POPUP_ID]
        label = chosen["label"]
        if c4d.gui.QuestionDialog("Delete the saved %s preset %s?" % (chosen["object"], label)):
            aw_place.delete_user_preset(label, chosen["object"])
            self._rebuild_windows()

    def _add_pull(self, doc):
        """The selected object into the pulls library, modelled at the origin: where it
        meets the front, sticking out along +Z, its length along +X."""
        import aw_pulls_c4d
        op = doc.GetActiveObject()
        if op is None:
            c4d.gui.MessageDialog("Select a pull or knob first. Model it at the origin: where it meets the front, "
                                  "sticking out along +Z, its length along +X.")
            return
        try:
            name = aw_pulls_c4d.add_to_library(op)
        except (OSError, RuntimeError) as e:
            c4d.gui.MessageDialog("Couldn't add it to the pulls library: %s" % e)
            return
        c4d.gui.StatusSetText("Added %s to the pulls library: pick it as a cabinet's Library pull" % name)
        c4d.EventAdd()

    def Command(self, cid, msg):
        doc = c4d.documents.GetActiveDocument()
        import aw_place
        if B_PRESET <= cid < B_PRESET + len(PRESETS):
            start_wall(doc, PRESETS[cid - B_PRESET])
        elif B_WINDOW <= cid < B_WINDOW + len(getattr(self, "_windows", ())):
            aw_place.choose(doc, self._windows[cid - B_WINDOW])
        elif B_DOOR <= cid < B_DOOR + len(getattr(self, "_doors", ())):
            aw_place.choose(doc, self._doors[cid - B_DOOR])
        elif B_CABINET <= cid < B_CABINET + len(getattr(self, "_cabinets", ())):
            aw_place.choose(doc, self._cabinets[cid - B_CABINET])
        elif cid == B_ADD_PULL:
            self._add_pull(doc)
        elif cid == B_COUNTERTOP:
            import aw_counter_c4d
            aw_counter_c4d.add_countertop(doc)
        elif B_SINK <= cid < B_SINK + 50:
            import aw_counter_c4d
            if cid - B_SINK < len(aw_counter_c4d.SINK_PRESETS):
                aw_counter_c4d.add_sink(doc, aw_counter_c4d.SINK_PRESETS[cid - B_SINK])
        elif B_RAILING <= cid < B_RAILING + len(getattr(self, "_railings", ())):
            import aw_railing
            import aw_railing_c4d
            aw_railing_c4d.add_for_selection(doc, self._railings[cid - B_RAILING])
        elif cid == B_DUPLICATE:
            aw_place.duplicate(doc)
        elif cid == B_LINKED_COPIES:
            aw_place.duplicate(doc, linked=True)
        elif cid in (B_MAKE_UNIQUE, B_SELECT_LINKED):
            import aw_link_c4d
            if cid == B_MAKE_UNIQUE:
                c4d.gui.StatusSetText("Made %d unique" % aw_link_c4d.make_unique(doc))
            else:
                c4d.gui.StatusSetText("Selected %d linked" % aw_link_c4d.select_linked(doc))
        elif cid == B_SAVE_WINDOW:
            self._save_window(doc)
        elif cid == B_DELETE_WINDOW:
            self._delete_window()
        elif cid == B_ROOF:
            import aw_roof_c4d
            aw_roof_c4d.add_for_selection(doc)
        elif cid == B_BEAM:
            import aw_beam
            import aw_beam_c4d
            aw_beam_c4d.add(doc)
        elif cid == B_STAIR:
            import aw_stair_c4d
            aw_stair_c4d.add_for_selection(doc)
        elif cid == B_ROOF_CUTTER:
            import aw_roof_c4d
            aw_roof_c4d.add_cutter(doc)
        elif cid in (B_SPLINE_FLOOR, B_SPLINE_CEILING):
            import aw_floor
            import aw_floor_c4d
            aw_floor_c4d.add_for_selection(doc, aw_floor.CEILING if cid == B_SPLINE_CEILING else aw_floor.FLOOR)
        elif cid == B_PANELS:
            import aw_panels_c4d
            aw_panels_c4d.add_for_selection(doc)
        elif cid in (B_BASEBOARD, B_CROWN):
            import aw_molding_c4d
            aw_molding_c4d.add_for_selection(doc, aw_molding_c4d.CROWN if cid == B_CROWN else aw_molding_c4d.BASE)
        elif cid in (B_FLOOR, B_CEILING):
            import aw_slab
            import aw_slab_c4d
            aw_slab_c4d.add_for_selection(doc, aw_slab.CEILING if cid == B_CEILING else aw_slab.FLOOR)
        elif cid == B_FLOOR_PLAN:
            c4d.CallCommand(I.ID_AW_FLOOR_PLAN)
        elif cid == B_SCALE_PLAN:
            doc.SetAction(I.ID_AW_SCALE_PLAN_TOOL)
            c4d.EventAdd()
        elif cid == B_FROM_SPLINE:  # the selected splines, or draw a new one
            if selected_splines(doc):
                c4d.CallCommand(I.ID_AW_WALLS_FROM_SPLINE)
            else:
                start_wall(doc)
        elif cid == B_EDIT:
            doc.SetAction(I.ID_AW_EDIT_TOOL)
            c4d.EventAdd()
        elif cid == B_TIDY:
            n = aw_groups_c4d.tidy(doc)
            c4d.gui.StatusSetText("Sorted %d Archwerks objects into the Archwerks groups" % n)
        return True

    def CoreMessage(self, mid, msg):
        import sys
        current = sys.modules[__name__].Panel
        if type(self) is not current:  # lib reloaded: an open panel takes the new code and layout
            self.__class__ = current
            self.refresh()
        if mid == c4d.EVMSG_CHANGE and _armed is not None:
            adopt(c4d.documents.GetActiveDocument())
        return super().CoreMessage(mid, msg)
