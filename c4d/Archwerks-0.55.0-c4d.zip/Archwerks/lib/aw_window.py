"""Archwerks window geometry: what an AW Opening draws inside its hole.

Laid out like Archipack's windows. The frame (Window Frame width and depth) is
either in the hole, set across the wall by Align (Outside, Center, Inside) and
Offset, or surface-mounted on the Exterior or Interior face, running Overflow
past the hole on every side. Inside it the window is Rows of leaves from the
bottom up, split by transoms; each row has its own Leaves (split by mullions),
Height (0 shares what's left; the top row always takes the rest), Fixed and
Handle. Every part is its own closed box.

Types:
- Double-hung: always two sashes, lower (row 1's Height, 0: half) and upper,
  overlapping at the meeting rail, the upper one outside; Leaves (row 1) puts
  units side by side. Open slides the lower sash up; Fixed on row 1 stops it.
- Casement: side-hinged leaves. A one-leaf row hinges on Hinge's side; with more,
  the outer leaves hinge on their outer sides and middle ones are fixed. Open
  swings them (Swing: out of the wall or into the room) up to 90 degrees, by
  rotating their points only, so the window has the same points however far
  open it is. A Fixed row keeps its leaves shut.
- Fixed: glass straight in the frame, no sash, in every row and leaf.
- Sliding: each row's 2 to 4 panels on two tracks, overlapping by a panel frame
  width. Open slides them: with 2, the left one over the right; with 3, the outer
  two over the middle; with 4, the middle two over the outer.

Parts: Frame Out (exterior casing round the hole, standing proud of the Outside
face), Sill Out (exterior sill), Sill In (interior stool), Frame In (interior
casing), Muntins (Columns x Rows lights in every pane, whatever the type),
Handles (on the free edge, at Handle Altitude or the middle of the leaf, on the
inside, outside or both).

Built in the opening's own space: the hole spans x0..x1 by y0..y1, and the wall
it sits in runs z -thick/2 (Outside) .. +thick/2. Sizes in cm.
"""
import math

import aw_handles as H
from aw_mesh import MeshBuilder

GROUPS = ("Frame", "Sash", "Glass", "Sill", "Trim", "Casing", "SillIn", "Handle", "Shutters", "Blinds")

GLASS_D = 0.6     # glass thickness
OPEN_MAX = 90.0   # degrees a casement leaf swings at Open 100%
MUNTIN_D = 0.6    # muntin depth as a share of the sash (or a fixed window's frame) depth
MAX_ROWS = 4

DOUBLE_HUNG, CASEMENT, FIXED, SLIDING = 0, 1, 2, 3
TYPE_KEYS = {DOUBLE_HUNG: "DoubleHung", CASEMENT: "Casement", FIXED: "Fixed", SLIDING: "Sliding"}
HINGE_LEFT, HINGE_RIGHT = 0, 1
OUTSIDE, CENTER, INSIDE = 0, 1, 2           # Align
IN_HOLE, MOUNT_EXTERIOR, MOUNT_INTERIOR = 0, 1, 2
SWING_OUT, SWING_IN = 0, 1
HANDLE_NONE, HANDLE_INSIDE, HANDLE_OUTSIDE, HANDLE_BOTH, HANDLE_AUTO = 0, 1, 2, 3, 4

ROW_FIELDS = tuple(("%s_%d" % (f, r + 1), d) for r in range(MAX_ROWS)
                   for f, d in (("leaves", 1), ("height", 0.0), ("fixed", False), ("handle", HANDLE_AUTO)))


class Style:
    """Everything a window is built from, besides its hole. Made by settings(op) from
    an AW Opening, or directly (all defaults: a closed double-hung, the original sizes)."""

    FIELDS = (("kind", DOUBLE_HUNG), ("hinge", HINGE_LEFT), ("opened", 0.0), ("swing", SWING_OUT),
              ("position", CENTER), ("offset", 0.0), ("mount", IN_HOLE), ("overflow", 6.0),
              ("rows", 1), ("handle", HANDLE_NONE), ("handle_alt", 0.0), ("handle_type", 0),
              ("frame_w", 6.0), ("frame_d", 10.0), ("sash_w", 5.0), ("sash_d", 3.5),
              ("frame_out", False), ("frame_out_w", 10.0), ("frame_out_d", 2.0), ("frame_out_offset", 0.0),
              ("frame_out_close", False),
              ("sill_on", True), ("sill_out", 4.0), ("sill_side", 5.0), ("sill_h", 4.0), ("sill_alt", 0.0),
              ("sill_in", False), ("sill_in_d", 2.54), ("sill_in_side", 2.54), ("sill_in_h", 2.54), ("sill_in_alt", 0.0),
              ("trim", False), ("trim_w", 7.0), ("trim_d", 2.0),
              ("muntins", False), ("muntin_cols", 2), ("muntin_rows", 2), ("muntin_w", 2.0),
              ("shutters", False), ("shutter_open", 0.7), ("shutter_leaves", 1), ("louver_w", 8.89),
              ("louver_tilt", 0.0), ("shutter_divider", False),
              ("blinds", 0), ("blind_open", 0.4), ("blind_mount", 0), ("blind_fold", 20.32)) + ROW_FIELDS

    def __init__(self, **values):
        if "leaves" in values:  # a single row's leaves, as before rows existed
            values["leaves_1"] = values.pop("leaves")
        for name, default in self.FIELDS:
            setattr(self, name, values.pop(name, default))
        if values:
            raise TypeError("unknown window settings: %s" % ", ".join(values))

    def key(self):
        """A value that changes whenever anything here does, for rebuild checks."""
        return tuple(getattr(self, name) for name, _d in self.FIELDS)

    def row(self, r):
        """(leaves, height, fixed, handle) of row r (0-based), the handle resolved."""
        n = r + 1
        handle = int(getattr(self, "handle_%d" % n))
        return (max(1, int(getattr(self, "leaves_%d" % n))), float(getattr(self, "height_%d" % n)),
                bool(getattr(self, "fixed_%d" % n)), int(self.handle) if handle == HANDLE_AUTO else handle)


# Parts ---------------------------------------------------------------------------

def _muntins(mesh, x0, x1, y0, y1, zc, depth, s):
    """Bars dividing the glass x0..x1 by y0..y1 into Columns x Rows lights."""
    if not s.muntins:
        return
    cols, rows, bw = max(1, int(s.muntin_cols)), max(1, int(s.muntin_rows)), max(s.muntin_w, 0.1)
    z0, z1 = zc - depth / 2, zc + depth / 2
    for i in range(1, cols):
        x = x0 + (x1 - x0) * i / cols
        mesh.box(x - bw / 2, x + bw / 2, y0, y1, z0, z1, "Sash")
    for j in range(1, rows):
        y = y0 + (y1 - y0) * j / rows
        for i in range(cols):  # between the vertical bars, so no two boxes overlap
            a = x0 + (x1 - x0) * i / cols + (bw / 2 if i else 0)
            b = x0 + (x1 - x0) * (i + 1) / cols - (bw / 2 if i < cols - 1 else 0)
            mesh.box(a, b, y - bw / 2, y + bw / 2, z0, z1, "Sash")


def _sash(mesh, x0, x1, y0, y1, z0, z1, s):
    """A rectangular sash (panel frame) with its glass and muntins."""
    w = s.sash_w
    mesh.box(x0, x0 + w, y0, y1, z0, z1, "Sash")
    mesh.box(x1 - w, x1, y0, y1, z0, z1, "Sash")
    mesh.box(x0 + w, x1 - w, y0, y0 + w, z0, z1, "Sash")
    mesh.box(x0 + w, x1 - w, y1 - w, y1, z0, z1, "Sash")
    zc = (z0 + z1) / 2
    mesh.box(x0 + w, x1 - w, y0 + w, y1 - w, zc - GLASS_D / 2, zc + GLASS_D / 2, "Glass")
    _muntins(mesh, x0 + w, x1 - w, y0 + w, y1 - w, zc, (z1 - z0) * MUNTIN_D, s)


def _handle(mesh, x, y, z0, z1, side, horizontal=False, kind=0, custom=None):
    """A handle at (x, y) on a sash's inside face (z1, side Inside), outside face (z0),
    or both: its lever pointing down (or along, for a sash lock). kind: aw_handles."""
    faces = []
    if side in (HANDLE_INSIDE, HANDLE_BOTH):
        faces.append((z1, 1))
    if side in (HANDLE_OUTSIDE, HANDLE_BOTH):
        faces.append((z0, -1))
    lever, up = ((1, 0, 0), (0, 1, 0)) if horizontal else ((0, -1, 0), (1, 0, 0))
    for z, d in faces:
        H.build(mesh, kind, H.place((x, y, z), lever, (0, 0, d), up), "Handle", custom)


def _handle_y(s, y0, y1):
    return y0 + s.handle_alt if 0 < s.handle_alt < y1 - y0 else (y0 + y1) / 2


def _swing(mesh, first, hx, hz, degrees, hinge_left, inward):
    """Turn the points from index first on about a vertical hinge at (hx, hz), so
    the leaf's free edge swings out of the wall (-z) or, inward, into the room."""
    a = math.radians(degrees) * (1 if hinge_left else -1) * (-1 if inward else 1)
    c, s = math.cos(a), math.sin(a)
    for p in mesh.points[first:]:
        dx, dz = p.x - hx, p.z - hz
        p.x, p.z = hx + c * dx + s * dz, hz - s * dx + c * dz


def frame_box(x0, x1, y0, y1, thick, s):
    """(fx0, fx1, fy0, fy1, fz0, fz1): the frame's outline and depth. In the hole it
    lines the hole, set by Align and Offset (kept in the wall); surface-mounted it
    stands on that face and runs Overflow past the hole all round."""
    depth = max(s.frame_d, 0.1)
    if s.mount in (MOUNT_EXTERIOR, MOUNT_INTERIOR):
        ov = max(s.overflow, 0.0)
        z0 = -thick / 2 - depth if s.mount == MOUNT_EXTERIOR else thick / 2
        return x0 - ov, x1 + ov, y0 - ov, y1 + ov, z0, z0 + depth
    depth = min(depth, thick)
    if s.position == OUTSIDE:
        z0 = -thick / 2
    elif s.position == INSIDE:
        z0 = thick / 2 - depth
    else:
        z0 = -depth / 2
    z0 = min(max(z0 + s.offset, -thick / 2), thick / 2 - depth)
    return x0, x1, y0, y1, z0, z0 + depth


def frame_depth(thick, s):
    """(z0, z1) of a frame in the hole (kept for callers that only need the depth)."""
    return frame_box(0, 1, 0, 1, thick, s)[4:]


def row_spans(y0, y1, t, s, n):
    """[(y0, y1)] of n rows from the bottom between y0 and y1, a transom t between each:
    rows with a Height keep it, the others (always the top one) share the rest."""
    avail = y1 - y0 - t * (n - 1)
    asked = [s.row(r)[1] if r < n - 1 else 0.0 for r in range(n)]
    fixed = sum(h for h in asked if h > 0)
    if fixed > avail - 1.0 * (n - sum(1 for h in asked if h > 0)):  # too tall: share evenly
        asked = [0.0] * n
        fixed = 0.0
    share = (avail - fixed) / max(1, sum(1 for h in asked if h <= 0))
    out, y = [], y0
    for h in asked:
        hh = h if h > 0 else share
        out.append((y, y + hh))
        y += hh + t
    return out


# The window ------------------------------------------------------------------------

def build(name, x0, x1, y0, y1, thick, style=None, custom=None):
    """The window for a hole x0..x1 by y0..y1 in a wall thick deep, as `style`
    (a Style; None: the defaults); custom: a Custom handle's (points, polys)."""
    s = style or Style()
    s._custom = custom
    mesh = MeshBuilder(GROUPS)
    face_out, face_in = -thick / 2, thick / 2
    fx0, fx1, fy0, fy1, fz0, fz1 = frame_box(x0, x1, y0, y1, thick, s)
    zc = (fz0 + fz1) / 2
    f = min(max(s.frame_w, 0.1), (fx1 - fx0) / 4, (fy1 - fy0) / 4)  # small openings keep a usable hole

    # frame round the window
    mesh.box(fx0, fx0 + f, fy0, fy1, fz0, fz1, "Frame")
    mesh.box(fx1 - f, fx1, fy0, fy1, fz0, fz1, "Frame")
    mesh.box(fx0 + f, fx1 - f, fy1 - f, fy1, fz0, fz1, "Frame")
    mesh.box(fx0 + f, fx1 - f, fy0, fy0 + f, fz0, fz1, "Frame")

    ix0, ix1, iy0, iy1 = fx0 + f, fx1 - f, fy0 + f, fy1 - f
    if s.kind == DOUBLE_HUNG:
        _hung(mesh, ix0, ix1, iy0, iy1, f, fz0, fz1, zc, s)
    else:
        n = max(1, min(MAX_ROWS, int(s.rows)))
        spans = row_spans(iy0, iy1, f, s, n)
        for r, (ry0, ry1) in enumerate(spans):
            if r > 0:  # the transom under this row
                mesh.box(ix0, ix1, ry0 - f, ry0, fz0, fz1, "Frame")
            leaves, _h, fixed, handle = s.row(r)
            if s.kind == SLIDING:
                _sliding(mesh, ix0, ix1, ry0, ry1, zc, s, leaves, fixed, handle)
            else:
                _leaves(mesh, ix0, ix1, ry0, ry1, f, fz0, fz1, zc, s, leaves, fixed or s.kind == FIXED, handle)

    _sills(mesh, x0, x1, y0, fx0, fx1, fy0, fz0, fz1, face_out, face_in, s)
    _casings(mesh, x0, x1, y0, y1, face_out, face_in, s)
    if s.shutters:  # plantation shutters on the room side: in front of a Frame In, over a stool
        import aw_shutters
        z = face_in + (max(s.trim_d, 0.1) if s.trim else 0.0)
        bottom = y0 + s.sill_in_alt if s.sill_in and s.mount != MOUNT_INTERIOR else y0
        aw_shutters.build(mesh, x0, x1, bottom, y1, z, s)
    if s.blinds:  # a Roman shade or roller blind, in the opening or on the wall over it
        import aw_blinds
        bottom = y0 + s.sill_in_alt if s.sill_in and s.mount != MOUNT_INTERIOR else y0
        aw_blinds.build(mesh, x0, x1, y0, y1, face_in, s, bottom)
    return mesh.build(name)


def _hung(mesh, ix0, ix1, iy0, iy1, f, fz0, fz1, zc, s):
    """Two sashes per unit, overlapping at the meeting rail; the upper one outside.
    Open slides the lower one up behind it."""
    units, lower_h, fixed, handle = s.row(0)
    sw, sd = max(s.sash_w, 0.1), max(s.sash_d, 0.1)
    w = (ix1 - ix0 - f * (units - 1)) / units
    if w <= 2 * sw + 1 or iy1 - iy0 <= 4 * sw + 1:
        return
    mid = iy0 + (lower_h if 2 * sw < lower_h < iy1 - iy0 - 2 * sw else (iy1 - iy0) / 2)
    travel = 0.0 if fixed else (iy1 - mid - sw) * min(max(s.opened, 0.0), 1.0)
    for i in range(units):
        ux0 = ix0 + i * (w + f)
        if i > 0:
            mesh.box(ux0 - f, ux0, iy0, iy1, fz0, fz1, "Frame")
        _sash(mesh, ux0, ux0 + w, mid - sw / 2, iy1, zc - sd, zc, s)
        _sash(mesh, ux0, ux0 + w, iy0 + travel, mid + sw / 2 + travel, zc, zc + sd, s)
        if handle != HANDLE_NONE:  # a sash lock on the lower sash's top rail
            _handle(mesh, ux0 + w / 2, mid + travel, zc, zc + sd, handle, True, s.handle_type, s._custom)


def _leaves(mesh, ix0, ix1, iy0, iy1, f, fz0, fz1, zc, s, n, fixed, handle):
    """One row of leaves across, a mullion between each. Casement leaves are sashes
    hinged and swung by Open; fixed ones (a Fixed row or window) are glass in the
    frame for the Fixed type, shut sashes otherwise."""
    n = max(1, min(6, n))
    w = (ix1 - ix0 - f * (n - 1)) / n
    glass_only = s.kind == FIXED
    if not glass_only and (w < 2 * s.sash_w + 1 or iy1 - iy0 < 2 * s.sash_w + 1):
        return  # too small for leaves: just the frame
    z0, z1 = zc - s.sash_d / 2, zc + s.sash_d / 2
    for i in range(n):
        lx0 = ix0 + i * (w + f)
        lx1 = lx0 + w
        if i > 0:  # the mullion before this leaf
            mesh.box(lx0 - f, lx0, iy0, iy1, fz0, fz1, "Frame")
        if glass_only:
            mesh.box(lx0, lx1, iy0, iy1, zc - GLASS_D / 2, zc + GLASS_D / 2, "Glass")
            _muntins(mesh, lx0, lx1, iy0, iy1, zc, (fz1 - fz0) * MUNTIN_D * 0.5, s)
            continue
        if fixed:
            hinge_left = None
        elif n == 1:
            hinge_left = s.hinge == HINGE_LEFT
        elif i == 0:
            hinge_left = True
        elif i == n - 1:
            hinge_left = False
        else:
            hinge_left = None  # a middle leaf: fixed
        first = len(mesh.points)
        _sash(mesh, lx0, lx1, iy0, iy1, z0, z1, s)
        if hinge_left is None:
            continue
        if handle != HANDLE_NONE:  # on the free edge's stile
            hx = lx1 - s.sash_w / 2 if hinge_left else lx0 + s.sash_w / 2
            _handle(mesh, hx, _handle_y(s, iy0, iy1), z0, z1, handle, False, s.handle_type, s._custom)
        if s.opened > 0:
            inward = s.swing == SWING_IN
            _swing(mesh, first, lx0 if hinge_left else lx1, z1 if inward else z0,
                   OPEN_MAX * min(s.opened, 1.0), hinge_left, inward)


def sliding_moves(n):
    """For n panels, how each one slides as Open goes to 1: -1 left, +1 right, 0 fixed."""
    if n == 2:
        return (1, 0)
    if n == 3:
        return (1, 0, -1)
    return (0, -1, 1, 0)


def _sliding(mesh, ix0, ix1, iy0, iy1, zc, s, n, fixed, handle):
    """Panels on two tracks (alternating, outside track first), each overlapping the
    next by a panel frame width, slid by Open (not in a Fixed row)."""
    n = max(2, min(4, n))
    lap = s.sash_w
    w = (ix1 - ix0 + lap * (n - 1)) / n
    if w < 2 * s.sash_w + 1 or iy1 - iy0 < 2 * s.sash_w + 1:
        return
    travel = 0.0 if fixed else (w - lap) * min(max(s.opened, 0.0), 1.0)
    for i, move in enumerate(sliding_moves(n)):
        x0 = ix0 + i * (w - lap) + move * travel
        z0 = zc - s.sash_d if i % 2 == 0 else zc
        _sash(mesh, x0, x0 + w, iy0, iy1, z0, z0 + s.sash_d, s)
        if move and handle != HANDLE_NONE:  # on the leading stile of a panel that slides
            hx = x0 + s.sash_w / 2 if move < 0 else x0 + w - s.sash_w / 2
            _handle(mesh, hx, _handle_y(s, iy0, iy1), z0, z0 + s.sash_d, handle, False, s.handle_type, s._custom)


def _sills(mesh, x0, x1, y0, fx0, fx1, fy0, fz0, fz1, face_out, face_in, s):
    """Sill Out from the frame out past the Outside face; Sill In (the stool) from
    the frame into the room. Under a frame mounted on that face, the sill runs
    under it. Under a casing (Frame Out, Frame In) a sill is sized from the casing,
    as a real one is: Overhang past the casing's ends (the horns), Depth past its
    face; otherwise from the hole and the wall face."""
    if s.sill_on:
        h = max(s.sill_h, 0.1)
        exterior = s.mount == MOUNT_EXTERIOR
        cased = s.frame_out and not exterior
        reach = max(s.frame_out_offset, 0.0) + max(s.frame_out_w, 0.1) if cased else 0.0
        proud = max(s.frame_out_d, 0.1) if cased else 0.0
        back = face_out if exterior else fz0
        front = (fz0 if exterior else face_out - proud) - s.sill_out
        ya = (fy0 if exterior else y0) + s.sill_alt
        a, b = (fx0, fx1) if exterior else (x0 - reach, x1 + reach)
        if front < back - 0.05:
            mesh.box(a - s.sill_side, b + s.sill_side, ya - h / 2, ya + h / 2, front, back, "Sill")
    if s.sill_in:
        h = max(s.sill_in_h, 0.1)
        interior = s.mount == MOUNT_INTERIOR
        cased = s.trim and not interior
        reach = max(s.trim_w, 0.1) if cased else 0.0
        proud = max(s.trim_d, 0.1) if cased else 0.0
        back = face_in if interior else fz1
        front = (fz1 if interior else face_in + proud) + s.sill_in_d
        ya = (fy0 if interior else y0) + s.sill_in_alt
        a, b = (fx0, fx1) if interior else (x0 - reach, x1 + reach)
        if front > back + 0.05:
            mesh.box(a - s.sill_in_side, b + s.sill_in_side, ya - h, ya, back, front, "SillIn")


def _casings(mesh, x0, x1, y0, y1, face_out, face_in, s):
    """Frame Out: casing round the hole standing proud of the Outside face, Offset
    from its edge, with a bottom piece if Close. Frame In: casing on the Inside
    face; over a Sill In its sides start on the stool and an apron hangs below it."""
    if s.frame_out:
        w, d, o = max(s.frame_out_w, 0.1), max(s.frame_out_d, 0.1), max(s.frame_out_offset, 0.0)
        za, zb = face_out - d, face_out
        if s.frame_out_close:
            bottom = y0 - o - w
        elif s.sill_on and s.mount != MOUNT_EXTERIOR:  # the sides stand on the sill
            bottom = y0 + s.sill_alt + max(s.sill_h, 0.1) / 2
        else:
            bottom = y0
        mesh.box(x0 - o - w, x0 - o, bottom, y1 + o + w, za, zb, "Casing")
        mesh.box(x1 + o, x1 + o + w, bottom, y1 + o + w, za, zb, "Casing")
        mesh.box(x0 - o, x1 + o, y1 + o, y1 + o + w, za, zb, "Casing")
        if s.frame_out_close:
            mesh.box(x0 - o, x1 + o, y0 - o - w, y0 - o, za, zb, "Casing")
    if s.trim:
        tw, td, za = max(s.trim_w, 0.1), max(s.trim_d, 0.1), face_in
        stool = s.sill_in and s.mount != MOUNT_INTERIOR
        if stool:  # sides stand on the stool; an apron below it
            top = y0 + s.sill_in_alt
            bottom = top - max(s.sill_in_h, 0.1)
            mesh.box(x0 - tw, x0, top, y1 + tw, za, za + td, "Trim")
            mesh.box(x1, x1 + tw, top, y1 + tw, za, za + td, "Trim")
            mesh.box(x0 - tw, x1 + tw, bottom - tw, bottom, za, za + td, "Trim")
        else:
            mesh.box(x0 - tw, x0, y0 - tw, y1 + tw, za, za + td, "Trim")
            mesh.box(x1, x1 + tw, y0 - tw, y1 + tw, za, za + td, "Trim")
            mesh.box(x0, x1, y0 - tw, y0, za, za + td, "Trim")
        mesh.box(x0, x1, y1, y1 + tw, za, za + td, "Trim")


def settings(op):
    """The Style of an AW Opening; parameters it predates read as their defaults."""
    import aw_host
    import aw_ids as I
    defaults = dict(Style.FIELDS)
    values = {}
    for name, pid in I.AW_OPENING_STYLE_PARAMS:
        v = aw_host.value(op, pid)
        values[name] = defaults[name] if v is None else type(defaults[name])(v)
    return Style(**values)


build_window = build  # the older name


def custom_handle(op):
    """(change key, (points, polys)) of a Custom handle's linked object, or (None, None)."""
    import aw_host
    import aw_ids as I
    if aw_host.value(op, I.AW_OPENING_HANDLE_TYPE) != H.CUSTOM:
        return None, None
    obj = aw_host.link(op, I.AW_OPENING_HANDLE_CUSTOM)
    return aw_host.custom_key(obj), aw_host.custom_mesh(obj)
