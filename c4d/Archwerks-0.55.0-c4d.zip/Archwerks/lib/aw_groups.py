"""How Archwerks objects are grouped in a scene, the same in every host: one Archwerks
group with a group per kind under it (Blender: collections; Cinema 4D: nulls, plus a
layer per group for the switches a collection has), each group one colour (a Blender
collection's colour tag, a Cinema 4D layer's colour), so Walls look the same in both.

Openings (windows, doors, holes, fireplaces) live under their wall in both hosts: they
take the Openings colour (and, in Cinema 4D, its layer) but never move out of the wall.
"""
import aw_ids as I

ROOT = "Archwerks"

# key: (name, Blender colour tag, RGB 0..1 for a Cinema 4D layer), in the order the groups appear.
# Blender's eight tags have no grey: Walls keep an untagged (grey) collection there.
GROUPS = (
    ("walls", "Walls", "NONE", (0.55, 0.62, 0.70)),
    ("openings", "Openings", "COLOR_05", (0.30, 0.56, 0.90)),
    ("floors", "Floors", "COLOR_08", (0.62, 0.45, 0.30)),
    ("ceilings", "Ceilings", "COLOR_08", (0.62, 0.45, 0.30)),
    ("trim", "Trim", "COLOR_03", (0.93, 0.80, 0.27)),
    ("roofs", "Roofs", "COLOR_01", (0.86, 0.30, 0.28)),
    ("beams", "Beams", "COLOR_02", (0.93, 0.58, 0.22)),
    ("stairs", "Stairs", "COLOR_04", (0.40, 0.72, 0.34)),
    ("railings", "Railings", "COLOR_04", (0.40, 0.72, 0.34)),
    ("cabinets", "Cabinets", "COLOR_06", (0.60, 0.42, 0.84)),
    ("other", "Other", "NONE", (0.60, 0.60, 0.60)),
)
BY_KEY = {key: (name, tag, rgb) for key, name, tag, rgb in GROUPS}

KIND_GROUP = {I.ID_AW_WALL: "walls", I.ID_AW_OPENING: "openings", I.ID_AW_DOOR: "openings",
              I.ID_AW_CUTTER: "openings", I.ID_AW_FIREPLACE: "openings",
              I.ID_AW_FLOOR: "floors", I.ID_AW_CEILING: "ceilings",
              I.ID_AW_MOLDING: "trim", I.ID_AW_WALL_PANELS: "trim",
              I.ID_AW_ROOF: "roofs", I.ID_AW_ROOF_CUTTER: "roofs", I.ID_AW_BEAM: "beams",
              I.ID_AW_STAIR: "stairs", I.ID_AW_RAILING: "railings",
              I.ID_AW_CABINET: "cabinets", I.ID_AW_COUNTERTOP: "cabinets", I.ID_AW_SINK: "cabinets"}

# Kinds that live under another Archwerks object (a wall, a roof, a countertop) and stay there.
NESTED = {I.ID_AW_OPENING, I.ID_AW_DOOR, I.ID_AW_CUTTER, I.ID_AW_FIREPLACE, I.ID_AW_ROOF_CUTTER, I.ID_AW_SINK}


def group_of(kind, ceiling=False):
    """The group key for an object of kind; a Slab goes with the Floors, or the Ceilings."""
    if kind == I.ID_AW_SLAB:
        return "ceilings" if ceiling else "floors"
    return KIND_GROUP.get(kind, "other")
