"""aw_cabinet for Cinema 4D: the parts of core/aw_cabinet.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_groups_c4d
import aw_cabinet  # noqa: F401
from aw_cabinet import *  # noqa: F401,F403


def change_key(op):
    import aw_ids as I
    import aw_pulls_c4d
    keys = tuple(aw_host.custom_key(op[pid]) for pid in (I.AW_CAB_DOOR_PULL_OBJ, I.AW_CAB_DRAWER_PULL_OBJ))
    return (op.GetName(), op.GetDirty(c4d.DIRTYFLAGS_DATA), keys, aw_pulls_c4d._library["stamp"], sink_over(op))


def draw(bd):
    import aw_draw
    h = aw_cabinet._hover
    if h is None or not (h.get("free") or aw_draw._alive(h["wall"])):
        return
    lay = layout()
    if lay:
        aw_draw.draw_layout(bd, c4d.Matrix() if h.get("free") else h["wall"].GetMg(), lay)


def place(doc):
    """Add the hovered cabinet; one undo step. Returns it, or None."""
    import aw_draw
    import aw_ids as I
    import aw_materials
    import aw_slab
    import aw_slab_c4d
    h = aw_cabinet._hover
    if h is None or not h["ok"] or not (h.get("free") or aw_draw._alive(h["wall"])):
        return None
    preset = h["preset"]
    op = c4d.BaseObject(I.ID_AW_CABINET)
    for name, pid in param_ids():
        if name in preset["values"]:
            op[pid] = preset["values"][name]
    op[I.AW_CAB_WIDTH] = h["u1"] - h["u0"]
    op.SetName(aw_slab_c4d.next_name(doc, "Cabinet." + preset.get("key", "Base")))
    origin, xa, za = frame_for(h["plan"], h["k"], h["u0"], h["u1"], h["w"], h["n_out"])
    m = c4d.Matrix(c4d.Vector(*origin), c4d.Vector(*xa), c4d.Vector(0, 1, 0), c4d.Vector(*za))
    wall = h["wall"]
    seg = h["plan"].segments[h["k"]]
    along = xa[0] * seg["d"][0] + xa[2] * seg["d"][1] > 0  # its left end (seen from the front) is at u0
    touch_lo, touch_hi = abs(h["u0"] - h["left"]) < 0.01, abs(h["u1"] - h["right"]) < 0.01
    left_touch, right_touch = (touch_lo, touch_hi) if along else (touch_hi, touch_lo)
    settle_ends(op, left_touch, right_touch)
    doc.StartUndo()
    if wall is None:  # free: on the floor, in the scene's own space
        doc.InsertObject(op)
        op.SetMg(m)
    else:
        doc.InsertObject(op, wall.GetUp(), wall)
        op.SetMg(wall.GetMg() * m)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, op)
    aw_materials.apply_defaults(doc, op)
    aw_groups_c4d.file(doc, op)  # into its group: null and layer (aw_groups_c4d)
    butt_neighbours(op)
    doc.EndUndo()
    aw_cabinet._hover = None
    c4d.gui.StatusSetText("Placed %s %s" % (op.GetName(), "on the floor" if wall is None else "on " + wall.GetName()))
    c4d.EventAdd()
    return op


def hover(doc, bd, x, y, preset, centre=False):
    """aw_cabinet.hover_at for the mouse at (x, y) in view bd, over doc's walls."""
    import aw_c4d
    import aw_place
    a, v = aw_place._ray(bd, x, y)
    parallel = bd[c4d.BASEDRAW_DATA_PROJECTION] != c4d.Pperspective
    import aw_ids as I
    return hover_at(aw_place._walls(doc), aw_c4d.to_vec(a), aw_c4d.to_vec(v), preset, centre, parallel,
                    aw_c4d.scan(doc, I.ID_AW_CABINET))


def watch(doc):
    """On a scene change: each of aw_cabinet.changes() carried out as one undo step;
    nothing while the animation plays."""
    import aw_c4d
    import aw_ids as I
    if doc is None or c4d.CheckIsRunning(c4d.CHECKISRUNNING_ANIMATIONRUNNING):
        return
    moved = 0
    for change in changes(aw_c4d.scan(doc, I.ID_AW_CABINET)):
        doc.StartUndo()
        moved += act(change)
        doc.EndUndo()
    if moved:
        c4d.EventAdd()
