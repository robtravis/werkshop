"""aw_molding for Cinema 4D: the parts of core/aw_molding.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_groups_c4d
import aw_molding  # noqa: F401
from aw_molding import *  # noqa: F401,F403


def change_key(op):
    import c4d
    import aw_wall_c4d
    s = settings(op)
    wall, custom = s["wall"], s["custom"]
    wkey = None
    if wall is not None and wall.IsAlive():
        m = ~op.GetMg() * wall.GetMg()
        wkey = (aw_wall_c4d.change_key(wall), tuple(round(x, 4) for vec in (m.off, m.v1, m.v2, m.v3)
                                                 for x in (vec.x, vec.y, vec.z)))
    ckey = None
    if s["profile"] == CUSTOM and custom is not None and custom.IsAlive():
        ckey = (custom.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_CACHE),
                custom.GetHDirty(c4d.HDIRTYFLAGS_OBJECT))
    kids = tuple(k.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX | c4d.DIRTYFLAGS_CACHE)
                 for k in op.GetChildren() if k.GetInfo() & c4d.OBJECT_ISSPLINE)  # its own path, with no wall
    return (op.GetName(), op.GetDirty(c4d.DIRTYFLAGS_DATA), wkey, ckey, kids)


def add_for_selection(doc, kind):
    """Panel button: a Baseboard (or Crown) on each selected Wall, after it, with the
    default material. One undo step. Returns them."""
    import c4d
    import aw_ids as I
    import aw_materials
    walls = [o for o in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE) if o.GetType() == I.ID_AW_WALL]
    if not walls:
        c4d.gui.MessageDialog("Select a Wall first: the molding follows its rooms.")
        return []
    made = []
    doc.StartUndo()
    for wall in walls:
        m = c4d.BaseObject(I.ID_AW_MOLDING)
        m.SetName(next_name(doc, "Crown" if kind == CROWN else "Baseboard"))
        m[I.AW_MOLDING_TYPE] = kind
        if kind == CROWN:  # a cove crown, 3.5 x 3.5 in
            m[I.AW_MOLDING_PROFILE], m[I.AW_MOLDING_HEIGHT], m[I.AW_MOLDING_DEPTH] = COVE, 8.89, 8.89
        m[I.AW_MOLDING_WALL] = wall
        doc.InsertObject(m, wall.GetUp(), wall)
        m.SetMg(c4d.Matrix(wall.GetMg()))
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, m)
        aw_materials.apply_defaults(doc, m)
        aw_groups_c4d.file(doc, m)  # into its group: null and layer (aw_groups_c4d)
        made.append(m)
    doc.EndUndo()
    doc.SetActiveObject(made[0], c4d.SELECTION_NEW)
    for m in made[1:]:
        doc.SetActiveObject(m, c4d.SELECTION_ADD)
    c4d.EventAdd()
    return made


def next_name(doc, base):
    import aw_slab_c4d
    return aw_slab_c4d.next_name(doc, base)
