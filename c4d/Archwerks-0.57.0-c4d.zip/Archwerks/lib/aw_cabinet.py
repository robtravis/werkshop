"""Archwerks cabinets: base, upper, tall and vanity cabinets, simple and light.

A Cabinet is a box of boards (sides, bottom, top, back) with its fronts. Its
origin is at the back, left and on the floor: it runs Width along +X, Depth
towards -Z (its front faces -Z) and up +Y. Base, tall and vanity cabinets stand
on a toe kick (Kick Height, set back Kick Setback); an upper hangs with its top
at Top.

The front is a stack of zones, bottom to top (Zones of them). Each is Door Left
or Door Right (the side its hinges are on), Door Pair, Flap (hinged at its top),
Drawer (Columns of them side by side), False Front, Open Shelves (Shelves of
them: the only zone with an inside to see) or Empty (no front: an appliance's
gap). A zone is Height tall, or (0) an equal share of what the fixed ones leave;
Glass gives its doors glass panels.

Fronts: Slab, Shaker (a frame Frame Width wide round a panel set back Panel
Recess) or Glass Shaker; drawers the same or always Slab (Drawer Style). Full
overlay (the fronts cover the box, Reveal apart) or Inset (in a face frame Face
Frame wide, Reveal round each). Open (0 to 100%) swings the doors and flaps open
and slides the drawers out: keyframe it.

Pulls: one setting for doors and flaps, another for drawers (aw_pulls types,
Size, a Library pull or a Custom object), placed by rule: on a door near its free
edge (Edge Inset), Vertical or Horizontal, at the top of a base or vanity door,
the bottom of an upper one, at hand height on a tall one (Auto), or where Position
says, End Inset from that end; on a flap at the middle of its bottom edge; on a
drawer centred or near its top (Top Inset), two of them on a drawer wider than Two
Pulls Over (0: never).

Placed like windows: pick a preset in the panel, hover a wall, click. The cabinet
backs onto the face under the mouse and snaps to the wall's ends and to other
cabinets on that face. Off the walls it stands free on the floor (an island), facing
the eye (R turns it a quarter), and backs onto a free cabinet's line beside it or
behind it, back to back. With Push Neighbours on, a width change moves the run it
touches (cabinets on the same face, at heights that overlap, end to end): Anchor
Left keeps its left end (seen from the front) and pushes the run on its right,
Right the mirror, Centre both ways half each. Bases and uppers are separate runs.
Sizes in cm (presets in inches).
"""
import math

import aw_host
from aw_vec import Vec

BASE, UPPER, TALL, VANITY = 0, 1, 2, 3
TYPE_NAMES = ("Base", "Upper", "Tall", "Vanity")
DOOR_LEFT, DOOR_RIGHT, DOOR_PAIR, FLAP, DRAWER, FALSE_FRONT, OPEN, EMPTY, SINK = range(9)
ZONE_NAMES = ("Door Left", "Door Right", "Door Pair", "Flap", "Drawer", "False Front", "Open Shelves", "Empty", "Sink")
# Sink: a sink base's top, a false front whose countertop gets a sink over it (aw_counter.auto_sinks)
SLAB, SHAKER, GLASS = 0, 1, 2
SAME, SLAB_DRAWERS = 0, 1
FULL, INSET = 0, 1
VERTICAL, HORIZONTAL = 0, 1
AUTO, TOP_POS, MIDDLE, BOTTOM_POS = 0, 1, 2, 3
CENTRE, NEAR_TOP = 0, 1
NO_BLIND, BLIND_LEFT, BLIND_RIGHT = 0, 1, 2
NO_CORNER, PIE_CUT, DIAGONAL = 0, 1, 2
CORNER_LEFT, CORNER_RIGHT = 0, 1
MAX_ZONES = 6
ZONE_FIELDS = ("kind", "height", "columns", "shelves", "glass")
GROUPS = ("Fronts", "Carcass", "Shelves", "Toe Kick", "Glass", "Pulls")
IN = 2.54
# a type's own sizes (width, height, depth, kick height, top), applied when Type changes
TYPE_DEFAULTS = {BASE: (18 * IN, 34.5 * IN, 24 * IN, 4 * IN, 0.0), UPPER: (30 * IN, 30 * IN, 12 * IN, 0.0, 84 * IN),
                 TALL: (24 * IN, 84 * IN, 24 * IN, 4 * IN, 0.0), VANITY: (30 * IN, 32 * IN, 21 * IN, 4 * IN, 0.0)}
GLASS_T = 0.4
HAND_HEIGHT = 38 * IN  # where a tall door's pull goes (Auto)
SWING = math.radians(95.0)
FLAP_SWING = math.radians(80.0)
SLIDE = 0.8  # how much of the box's depth a drawer comes out


# Layout (pure) -----------------------------------------------------------------------

def box_range(s):
    """(bottom, top) of the box: on its kick, or an upper hung by its top."""
    if s["type"] == UPPER:
        return s["top"] - s["height"], s["top"]
    return min(s["kick_h"], s["height"] - 1.0), s["height"]


def box_depth(s):
    """How deep the box is behind the fronts (the fronts make up the rest)."""
    return max(s["depth"] - s["front_t"], 1.0)


def zones(s):
    """[(zone dict, bottom, top)] bottom to top: fixed heights first (shrunk to fit),
    the rest shared by the others."""
    y0, y1 = box_range(s)
    zs = s["zones"][:max(1, min(s["zone_count"], MAX_ZONES))]
    total = y1 - y0
    fixed = sum(max(z["height"], 0.0) for z in zs if z["height"] > 1e-6)
    free = [z for z in zs if z["height"] <= 1e-6]
    scale = 1.0
    if fixed > total or (not free and fixed > 1e-6):
        scale = total / fixed
    share = (total - fixed * scale) / len(free) if free else 0.0
    out, at = [], y0
    for z in zs:
        h = z["height"] * scale if z["height"] > 1e-6 else share
        out.append((z, at, at + h))
        at += h
    return out


def fronts(s):
    """[front dict]: kind ("door", "flap", "drawer", "false"), hinge ("left", "right",
    "top" or None), rect (x0, x1, y0, y1) on the front, the zone's glass, and whether
    the zone is the bottom, top one; plus [face frame rects] for Inset."""
    W = s["width"]
    g = max(s["reveal"], 0.0)
    y_lo, y_hi = box_range(s)
    zs = zones(s)
    out, frame = [], []
    inset = s["overlay"] == INSET
    ff = min(max(s["face_frame"], 0.5), W / 4) if inset else 0.0
    if inset:  # stiles, then a rail under, between and over the zones
        frame += [(0.0, ff, y_lo, y_hi), (W - ff, W, y_lo, y_hi)]
        for i, (_z, a, _b) in enumerate(zs):
            lo = a if i == 0 else a - ff / 2
            frame.append((ff, W - ff, lo, a + (ff if i == 0 else ff / 2)))
        frame.append((ff, W - ff, y_hi - ff, y_hi))
    for i, (z, a, b) in enumerate(zs):
        kind = z["kind"]
        if kind in (OPEN, EMPTY):
            continue
        if inset:
            x0, x1 = ff + g, W - ff - g
            y0 = a + (ff if i == 0 else ff / 2) + g
            y1 = b - (ff if i == len(zs) - 1 else ff / 2) - g
            gap = 2 * g + ff  # between columns: a mullion
        else:
            x0, x1, y0, y1, gap = g / 2, W - g / 2, a + g / 2, b - g / 2, g
        if y1 - y0 < 0.5 or x1 - x0 < 0.5:
            continue
        cols = 2 if kind == DOOR_PAIR else (max(1, int(z["columns"])) if kind == DRAWER else 1)
        cw = (x1 - x0 - gap * (cols - 1)) / cols
        for c in range(cols):
            cx0 = x0 + c * (cw + gap)
            if inset and c > 0:
                frame.append((cx0 - gap + g, cx0 - g, y0 - g, y1 + g))
            rect = (cx0, cx0 + cw, y0, y1)
            if kind == DRAWER:
                f = {"kind": "drawer", "hinge": None}
            elif kind in (FALSE_FRONT, SINK):
                f = {"kind": "false", "hinge": None}
            elif kind == FLAP:
                f = {"kind": "flap", "hinge": "top"}
            elif kind == DOOR_PAIR:
                f = {"kind": "door", "hinge": "left" if c == 0 else "right"}
            else:
                f = {"kind": "door", "hinge": "left" if kind == DOOR_LEFT else "right"}
            f.update(rect=rect, glass=bool(z["glass"]), zone=i)
            out.append(f)
    return out, frame


def front_boxes(f, s):
    """[((x0, x1, y0, y1, z0, z1), group)] of a front, closed (Open 0): its face at
    z -Depth, Front Thickness deep."""
    x0, x1, y0, y1 = f["rect"]
    zf, t = -s["depth"], s["front_t"]
    style = GLASS if f["glass"] else s["style"]
    if f["kind"] in ("drawer", "false") and s["drawer_style"] == SLAB_DRAWERS:
        style = SLAB
    fw = min(s["frame_w"], (x1 - x0) / 3, (y1 - y0) / 3)
    if style == SLAB or fw < 1.0:
        return [((x0, x1, y0, y1, zf, zf + t), "Fronts")]
    out = [((x0, x0 + fw, y0, y1, zf, zf + t), "Fronts"), ((x1 - fw, x1, y0, y1, zf, zf + t), "Fronts"),
           ((x0 + fw, x1 - fw, y0, y0 + fw, zf, zf + t), "Fronts"), ((x0 + fw, x1 - fw, y1 - fw, y1, zf, zf + t), "Fronts")]
    if style == GLASS:
        zm = zf + t / 2
        out.append(((x0 + fw, x1 - fw, y0 + fw, y1 - fw, zm - GLASS_T / 2, zm + GLASS_T / 2), "Glass"))
    else:
        rec = min(max(s["panel_recess"], 0.1), t - 0.2)
        out.append(((x0 + fw, x1 - fw, y0 + fw, y1 - fw, zf + rec, zf + t), "Fronts"))
    return out


def drawer_box(f, s):
    """[box] a drawer's box behind its front (only built while the cabinet is open):
    two sides, a back and a bottom, inside the cabinet's sides."""
    x0, x1, y0, y1 = f["rect"]
    t = 1.2
    zf = -s["depth"] + s["front_t"]
    zb = zf + box_depth(s) * 0.9
    side = min(max(s["thickness"], 0.3), s["width"] / 4) + 1.3  # clear of the cabinet's side
    bx0, bx1 = max(x0, side), min(x1, s["width"] - side)
    by0, by1 = y0 + 1.5, max(y0 + 3.0, y1 - 2.5)
    if bx1 - bx0 < 3 * t:
        return []
    return [(bx0, bx0 + t, by0, by1, zf, zb), (bx1 - t, bx1, by0, by1, zf, zb),
            (bx0 + t, bx1 - t, by0, by1, zb - t, zb), (bx0 + t, bx1 - t, by0, by0 + t, zf, zb - t)]


def opener(f, s):
    """f(x, y, z) -> (x, y, z): where a point of front f goes, Open (0 to 1) open."""
    o = min(max(s["open"], 0.0), 1.0)
    if o <= 1e-6 or f["kind"] == "false":
        return lambda x, y, z: (x, y, z)
    x0, x1, y0, y1 = f["rect"]
    hz = -box_depth(s)  # the hinge line: the box's front edge
    if f["kind"] == "drawer":
        dz = -box_depth(s) * SLIDE * o
        return lambda x, y, z: (x, y, z + dz)
    if f["kind"] == "flap":
        a = FLAP_SWING * o
        c, sn = math.cos(a), math.sin(a)

        def flap(x, y, z):
            dy, dz = y - y1, z - hz
            return (x, y1 + c * dy - sn * dz, hz + sn * dy + c * dz)
        return flap
    a = SWING * o * (1 if f["hinge"] == "left" else -1)
    hx = x0 if f["hinge"] == "left" else x1
    c, sn = math.cos(a), math.sin(a)

    def door(x, y, z):
        dx, dz = x - hx, z - hz
        return (hx + c * dx + sn * dz, y, hz - sn * dx + c * dz)
    return door


def pulls(f, s):
    """[(origin, lever, up, kind, size, which)] the pulls of front f, closed, on its face
    (z -Depth), standing out along -Z; which: "door" or "drawer" (whose settings)."""
    x0, x1, y0, y1 = f["rect"]
    zf = -s["depth"]
    if f["kind"] == "false":
        return []
    import aw_pulls as P
    if f["kind"] == "drawer":
        kind, size = s["drawer_pull"], s["drawer_pull_size"]
        if kind == P.NONE:
            return []
        L = P.length(kind, size)
        horizontal = s["drawer_pull_orient"] == HORIZONTAL
        lever, up = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0)) if horizontal else ((0.0, 1.0, 0.0), (-1.0, 0.0, 0.0))
        if kind == P.EDGE:
            return [((((x0 + x1) / 2), y1, zf), (1.0, 0.0, 0.0), (0.0, 1.0, 0.0), kind, size, "drawer")]
        if s["drawer_pull_pos"] == NEAR_TOP:
            y = y1 - s["drawer_pull_top"] - (0.0 if horizontal else L / 2)
        else:
            y = (y0 + y1) / 2
        w = x1 - x0
        xs = [(x0 + x1) / 2]
        if s["drawer_two_over"] > 1e-6 and w >= s["drawer_two_over"]:
            xs = [x0 + w / 4, x0 + 3 * w / 4]
        return [((x, y, zf), lever, up, kind, size, "drawer") for x in xs]
    kind, size = s["door_pull"], s["door_pull_size"]
    if kind == P.NONE:
        return []
    L = P.length(kind, size)
    if f["kind"] == "flap":
        if kind == P.EDGE:
            return [(((x0 + x1) / 2, y0, zf), (1.0, 0.0, 0.0), (0.0, -1.0, 0.0), kind, size, "door")]
        return [(((x0 + x1) / 2, y0 + s["door_pull_end"], zf), (1.0, 0.0, 0.0), (0.0, 1.0, 0.0), kind, size, "door")]
    free_right = f["hinge"] == "left"
    edge_x = x1 if free_right else x0
    if kind == P.EDGE:  # a lip over the free edge
        y = _door_pull_y(s, y0, y1, L, True)
        out_dir = (1.0, 0.0, 0.0) if free_right else (-1.0, 0.0, 0.0)
        return [((edge_x, y, zf), (0.0, 1.0, 0.0), out_dir, kind, size, "door")]
    vertical = s["door_pull_orient"] == VERTICAL and kind not in P.KNOBS
    x = edge_x - s["door_pull_edge"] if free_right else edge_x + s["door_pull_edge"]
    if not vertical and kind not in P.KNOBS:  # a horizontal pull reaches in from the free edge
        x = edge_x - s["door_pull_edge"] - L / 2 if free_right else edge_x + s["door_pull_edge"] + L / 2
    y = _door_pull_y(s, y0, y1, L, vertical)
    lever, up = ((0.0, 1.0, 0.0), (-1.0, 0.0, 0.0)) if vertical else ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0))
    return [((x, y, zf), lever, up, kind, size, "door")]


def _door_pull_y(s, y0, y1, L, vertical):
    half = L / 2 if vertical else 0.0
    end = s["door_pull_end"]
    pos = s["door_pull_pos"]
    if pos == AUTO:
        pos = {UPPER: BOTTOM_POS, TALL: MIDDLE}.get(s["type"], TOP_POS)
        if s["type"] == TALL:
            return min(max(HAND_HEIGHT, y0 + end + half), y1 - end - half)
    if pos == TOP_POS:
        return y1 - end - half
    if pos == BOTTOM_POS:
        return y0 + end + half
    return (y0 + y1) / 2


def boards(s, frame=True):
    """[((x0, x1, y0, y1, z0, z1), group)] of the box: sides, bottom, top, back, the
    shelves of open zones (and a board closing each one off), the toe kick and (frame)
    an Inset face frame."""
    W, t = s["width"], min(max(s["thickness"], 0.3), s["width"] / 4)
    y0, y1 = box_range(s)
    cd = box_depth(s)
    out = [((0.0, t, y0, y1, -cd, 0.0), "Carcass"), ((W - t, W, y0, y1, -cd, 0.0), "Carcass"),
           ((t, W - t, y0, y0 + t, -cd, 0.0), "Carcass")] + \
        ([] if s.get("open_top") else [((t, W - t, y1 - t, y1, -cd, 0.0), "Carcass")]) + [  # no top under a sink
           ((t, W - t, y0 + t, y1 - t, -t, 0.0), "Carcass")]
    if s["type"] != UPPER and y0 > 0.5:
        out.append(((0.0, W, 0.0, y0, -cd + max(s["kick_setback"], 0.0), 0.0), "Toe Kick"))
    for z, a, b in zones(s):
        if z["kind"] != OPEN:
            continue
        if a > y0 + t + 1e-6:
            out.append(((t, W - t, a, a + t, -cd, -t), "Shelves"))
        if b < y1 - t - 1e-6:
            out.append(((t, W - t, b - t, b, -cd, -t), "Shelves"))
        n = max(int(z["shelves"]), 0)
        lo = a + (t if a > y0 + t + 1e-6 else t)
        hi = b - t
        for k in range(n):
            yc = lo + (hi - lo) * (k + 1) / (n + 1)
            out.append(((t, W - t, yc - t / 2, yc + t / 2, -cd, -t), "Shelves"))
    if frame and s["overlay"] == INSET:
        _fr, rects = fronts(s)
        out += [((fx0, fx1, fy0, fy1, -s["depth"], -cd), "Carcass") for fx0, fx1, fy0, fy1 in rects]
    return out


# The whole cabinet as parts (pure) -------------------------------------------------------

def _shifted(move, dx):
    return lambda x, y, z: (lambda p: (p[0] + dx, p[1], p[2]))(move(x, y, z))


def _ident_move(x, y, z):
    return (x, y, z)


def sides(s):
    """(left end panel, left filler, right filler, right end panel) widths: what stands
    between the cabinet's ends and its box."""
    t = max(s.get("end_t", 0.0), 0.1)
    return (t if s.get("end_l") else 0.0, max(s.get("filler_l", 0.0), 0.0), max(s.get("filler_r", 0.0), 0.0),
            t if s.get("end_r") else 0.0)


def parts(s):
    """([(kind, geometry, group, move)], [(origin, lever, up, pull kind, size, which,
    move)]): everything the cabinet is made of, in its own space. kind "box" (geometry
    (x0, x1, y0, y1, z0, z1)) or "prism" (geometry (outline [(x, z)], y0, y1)); move
    places a part's points (an open door's swing, a corner's leaves)."""
    if s.get("corner", NO_CORNER) != NO_CORNER:
        return corner_parts(s)
    W, D = s["width"], s["depth"]
    eL, fL, fR, eR = sides(s)
    bx0 = eL + fL
    bw = max(W - eL - fL - fR - eR, 4.0)
    sb = dict(s, width=bw)
    out, pl = [], []
    for b, group in boards(sb, frame=False):
        out.append(("box", (b[0] + bx0, b[1] + bx0) + b[2:], group, None))
    blind = s.get("blind", NO_BLIND)
    bwid = min(max(s.get("blind_w", 0.0), 0.0), bw - 4.0) if blind != NO_BLIND else 0.0
    fx0 = bx0 + (bwid if blind == BLIND_LEFT else 0.0)
    sf = dict(sb, width=bw - bwid)
    fs, frame = fronts(sf)
    cd = box_depth(s)
    for fx, fx1, fy0, fy1 in frame:
        out.append(("box", (fx + fx0, fx1 + fx0, fy0, fy1, -D, -cd), "Carcass", None))
    for f in fs:
        move = _shifted(opener(f, sf), fx0)
        for b, group in front_boxes(f, sf):
            out.append(("box", b, group, move))
        if f["kind"] == "drawer" and s["open"] > 1e-6:
            for b in drawer_box(f, sf):
                out.append(("box", b, "Carcass", move))
        for origin, lever, up, kind, size, which in pulls(f, sf):
            pl.append((origin, lever, up, kind, size, which, move))
    lo, hi = box_range(s)
    g = max(s["reveal"], 0.0)
    if bwid > 1e-6:  # the blind part: a plain panel where the other run's cabinet butts on
        x0, x1 = (bx0, bx0 + bwid - g / 2) if blind == BLIND_LEFT else (bx0 + bw - bwid + g / 2, bx0 + bw)
        out.append(("box", (x0, x1, lo + g / 2, hi - g / 2, -D, -cd), "Fronts", None))
    floor = 0.0 if s["type"] != UPPER else lo
    proud = max(s.get("end_proud", 0.0), 0.0)
    if eL > 0:
        out.append(("box", (0.0, eL, floor, hi, -D - proud, 0.0), "Fronts", None))
    if eR > 0:
        out.append(("box", (W - eR, W, floor, hi, -D - proud, 0.0), "Fronts", None))
    sbk = max(s["kick_setback"], 0.0)
    for x0, x1 in ((eL, eL + fL), (W - eR - fR, W - eR)):
        if x1 - x0 > 1e-6:  # a filler, and the kick under it
            out.append(("box", (x0, x1, lo, hi, -D, -cd), "Fronts", None))
            if s["type"] != UPPER and lo > 0.5:
                out.append(("box", (x0, x1, 0.0, lo, -cd + sbk, 0.0), "Toe Kick", None))
    return out, pl


def _offset_line(p0, p1, inward, dist):
    """The line p0-p1 moved dist towards inward (a unit vector): (point, direction)."""
    d = (p1[0] - p0[0], p1[1] - p0[1])
    return (p0[0] + inward[0] * dist, p0[1] + inward[1] * dist), d


def _cross_x(line, x):
    (px, pz), (dx, dz) = line
    return (x, pz + dz * (x - px) / dx) if abs(dx) > 1e-9 else (x, pz)


def _cross_z(line, z):
    (px, pz), (dx, dz) = line
    return (px + dx * (z - pz) / dz, z) if abs(dz) > 1e-9 else (px, z)


def corner_parts(s):
    """A corner cabinet backing onto two walls, its corner at its left end (Corner Side
    Left) or right: Pie Cut, an L Width along its own wall and Return along the other,
    two leaves meeting in the inside corner; Diagonal, one door across the corner."""
    W, R, D = s["width"], max(s.get("return", s["width"]), s["depth"] + 2.0), s["depth"]
    ft = s["front_t"]
    cd = box_depth(s)
    lo, hi = box_range(s)
    g = max(s["reveal"], 0.0)
    sbk = max(s["kick_setback"], 0.0)
    mirror = s.get("corner_side", CORNER_LEFT) == CORNER_RIGHT
    flip = (lambda x, y, z: (W - x, y, z)) if mirror else _ident_move

    def then(move):
        return lambda x, y, z: flip(*move(x, y, z))
    out, pl = [], []
    if s["corner"] == PIE_CUT:
        out.append(("prism", ([(0.0, 0.0), (W, 0.0), (W, -cd), (cd, -cd), (cd, -R), (0.0, -R)], lo, hi), "Carcass",
                    flip))
        if s["type"] != UPPER and lo > 0.5:
            k = cd - sbk
            out.append(("prism", ([(0.0, 0.0), (W, 0.0), (W, -k), (k, -k), (k, -R), (0.0, -R)], 0.0, lo), "Toe Kick",
                        flip))
        leaf_a = {"kind": "door", "hinge": "left", "rect": (cd, W - g / 2, lo + g / 2, hi - g / 2), "glass": False}
        leaf_b = {"kind": "door", "hinge": "right", "rect": (D, R - g / 2, lo + g / 2, hi - g / 2), "glass": False}
        turn_b = then(lambda x, y, z: (-z, y, -x))  # leaf B on the return's face: x = Depth, running along -Z
        for b, group in front_boxes(leaf_a, s):
            out.append(("box", b, group, flip))
        for b, group in front_boxes(leaf_b, s):
            out.append(("box", b, group, turn_b))
        for origin, lever, up, kind, size, which in pulls(leaf_a, s):
            pl.append((origin, lever, up, kind, size, which, flip))
        return out, pl
    # Diagonal: the corner cut off across its front
    p0, p1 = (W, -D), (D, -R)
    L = math.dist(p0, p1)
    e = ((p0[0] - p1[0]) / L, (p0[1] - p1[1]) / L)       # along the door, from the return's end
    n_out = (e[1], -e[0])                                   # out of the cabinet, into the room
    inner = _offset_line(p0, p1, (-n_out[0], -n_out[1]), ft)
    q0, q1 = _cross_x(inner, W), _cross_z(inner, -R)
    out.append(("prism", ([(0.0, 0.0), (W, 0.0), q0, q1, (0.0, -R)], lo, hi), "Carcass", flip))
    if s["type"] != UPPER and lo > 0.5:
        kick = _offset_line(p0, p1, (-n_out[0], -n_out[1]), ft + sbk)
        out.append(("prism", ([(0.0, 0.0), (W, 0.0), _cross_x(kick, W), _cross_z(kick, -R), (0.0, -R)], 0.0, lo),
                    "Toe Kick", flip))
    door = {"kind": "door", "hinge": "left", "rect": (g / 2, L - g / 2, lo + g / 2, hi - g / 2), "glass": False}
    place = then(lambda x, y, z: (p1[0] + e[0] * x - n_out[0] * (z + D), y, p1[1] + e[1] * x - n_out[1] * (z + D)))
    for b, group in front_boxes(door, s):
        out.append(("box", b, group, place))
    for origin, lever, up, kind, size, which in pulls(door, s):
        pl.append((origin, lever, up, kind, size, which, place))
    return out, pl


# AW Edit Dimensions ----------------------------------------------------------------------

DIM_OUT = 25.0  # cm the dimension lines stand off the cabinet


def dims_layout(s):
    """(layout, grips) for a selected cabinet in its own space: Width, Height, Depth, the
    kick or an upper's Top, every zone's height, a corner cabinet's Return, as labels
    (aw_dims format); grips [(position, direction, kind, action)] for the width (on its
    free end: a corner or blind cabinet's other end is in the corner), height, depth,
    return and on every boundary between zones. Labels keep out of the corner."""
    W, D = s["width"], s["depth"]
    lo, hi = y_range(s)
    zf = -D
    dims, ext, grips = [], [], []
    upper = s["type"] == UPPER
    pin = pinned_anchor(s)
    corner = s.get("corner", NO_CORNER) != NO_CORNER

    def dim(kind, value, a, b, out, edit, ends=()):
        dims.append({"kind": kind, "role": "wall", "axis": "x", "value": value, "a": a, "b": b, "out": out,
                     "grips": ends, "edit": edit})

    def leader(p, q):
        ext.append({"role": "wall", "a": p, "b": q})

    # two stacks of upright labels, one off each end; a stack whose end is in a corner moves to the other end
    def right_x(k):
        return -k * DIM_OUT if pin == ANCHOR_RIGHT else W + k * DIM_OUT

    def left_x(k):
        if pin == ANCHOR_LEFT:
            return W + (k + 1) * DIM_OUT
        return -(k + (1 if pin == ANCHOR_RIGHT else 0)) * DIM_OUT
    side_r = (-1.0 if pin == ANCHOR_RIGHT else 1.0, 0.0, 0.0)
    side_l = (1.0 if pin == ANCHOR_LEFT else -1.0, 0.0, 0.0)
    if corner:  # an L: width and return run along the tops of its two legs
        R = s["return"]
        dim("cab_width", W, (0.0, hi + 2.0, -D / 2), (W, hi + 2.0, -D / 2), (0.0, 1.0, 0.0), {"do": "cab_width"},
            ("a",) if pin == ANCHOR_RIGHT else ("b",))
        rx = D / 2 if pin == ANCHOR_LEFT else W - D / 2
        dim("cab_return", R, (rx, hi + 2.0, 0.0), (rx, hi + 2.0, -R), (0.0, 1.0, 0.0), {"do": "cab_return"}, ("b",))
    else:
        wy = hi + DIM_OUT if upper else 0.0
        wz = zf if upper else zf - DIM_OUT
        dim("cab_width", W, (0.0, wy, wz), (W, wy, wz), (0.0, 1.0, 0.0) if upper else (0.0, 0.0, -1.0),
            {"do": "cab_width"}, ("a",) if pin == ANCHOR_RIGHT else ("b",))
        for x in (0.0, W):
            leader((x, hi if upper else 0.0, zf), (x, wy, wz))
    hx = right_x(1)
    edge = 0.0 if pin == ANCHOR_RIGHT else W
    dim("cab_height", hi - lo, (hx, lo, zf), (hx, hi, zf), side_r, {"do": "cab_height"}, ("a",) if upper else ("b",))
    leader((edge, lo, zf), (hx, lo, zf))
    leader((edge, hi, zf), (hx, hi, zf))
    dx = right_x(0.5)
    dim("cab_depth", D, (dx, hi, 0.0), (dx, hi, zf), side_r, {"do": "cab_depth"}, ("b",))
    zx = left_x(1)
    near = W if pin == ANCHOR_LEFT else 0.0
    if upper:
        tx = left_x(2)
        dim("cab_top", s["top"], (tx, 0.0, zf), (tx, s["top"], zf), side_l, {"do": "cab_top"})
    else:
        b0, _t = box_range(s)
        if b0 > 0.5:
            dim("cab_kick", b0, (zx, 0.0, zf), (zx, b0, zf), side_l, {"do": "cab_kick"})
    zs = [] if corner else zones(s)  # a corner cabinet's leaves run its full height
    for i, (_z, a, b) in enumerate(zs):
        dim("cab_zone", b - a, (zx, a, zf), (zx, b, zf), side_l, {"do": "cab_zone", "i": i},
            ("b",) if i < len(zs) - 1 else ())
        leader((near, a, zf), (zx, a, zf))
    if zs:
        leader((near, zs[-1][2], zf), (zx, zs[-1][2], zf))
    mid = (lo + hi) / 2
    leg_x = ((D + W) / 2 if pin == ANCHOR_LEFT else (W - D) / 2) if corner else W / 2  # the long leg's free part
    if pin == ANCHOR_RIGHT:  # its right end is in the corner: it is sized from its left end
        grips.append(((0.0, mid, zf / 2), (-1.0, 0.0, 0.0), "arrow", {"set": "width_left"}))
    else:
        grips.append(((W, mid, zf / 2), (1.0, 0.0, 0.0), "arrow", {"set": "width"}))
    if upper:  # hung by its top: it deepens downwards
        grips.append(((leg_x, lo, zf / 2), (0.0, -1.0, 0.0), "arrow", {"set": "height"}))
    else:
        grips.append(((leg_x, hi, zf / 2), (0.0, 1.0, 0.0), "arrow", {"set": "height"}))
    grips.append(((leg_x, mid, zf), (0.0, 0.0, -1.0), "arrow", {"set": "depth"}))
    if corner:
        rx = D / 2 if pin == ANCHOR_LEFT else W - D / 2
        grips.append(((rx, mid, -s["return"]), (0.0, 0.0, -1.0), "arrow", {"set": "return"}))
    for i, (_z, a, b) in enumerate(zs[:-1]):
        grips.append(((zx, b, zf), (0.0, 1.0, 0.0), "arrow", {"set": "zone", "i": i}))
    return {"dims": dims, "ext": ext, "outline": None, "grips": True}, grips


def corner_limits(s, depth=None, ret=None, width=None):
    """A corner cabinet's depth kept short of its width and return (an L needs both
    legs longer than they are deep): the depth it can have."""
    d = s["depth"] if depth is None else depth
    w = s["width"] if width is None else width
    r = s.get("return", w) if ret is None else ret
    return max(min(d, w - 5.0, r - 5.0), 5.0)


def zone_heights_for(s, i, boundary):
    """{zone index: new height} that moves the top of zone i to boundary: zone i takes
    the height up to it, and the next zone, if its height is fixed, keeps its top."""
    zs = zones(s)
    z, a, b = zs[i]
    nxt = zs[i + 1] if i + 1 < len(zs) else None
    top = nxt[2] if nxt is not None else b
    boundary = min(max(boundary, a + 1.0), top - 1.0)
    out = {i: boundary - a}
    if nxt is not None and nxt[0]["height"] > 1e-6:
        out[i + 1] = top - boundary
    return out


def grip_value(act, p, s):
    """[(setting, value)] for a grip dragged to local point p (x, y, z); a zone setting
    is ("zone", (index, height))."""
    x, y, z = p
    what = act["set"]
    if what == "width":
        return [("width", max(x, 2.0))]
    if what == "width_left":  # its left end dragged: the right end (in the corner) stays
        return [("width_left", max(s["width"] - x, 2.0))]
    if what == "return":
        return [("return", max(-z, s["depth"] + 5.0))]
    if what == "height":
        if s["type"] == UPPER:
            return [("height", max(s["top"] - y, 2.0))]
        return [("height", max(y, 2.0))]
    if what == "depth":
        d = max(-z, 2.0)
        return [("depth", corner_limits(s, depth=d) if s.get("corner", NO_CORNER) != NO_CORNER else d)]
    return [("zone", (k, h)) for k, h in sorted(zone_heights_for(s, act["i"], y).items())]


# Building (through the host, aw_host) -------------------------------------------------

def _box(mesh, b, group, move=None):
    x0, x1, y0, y1, z0, z1 = b
    if x1 - x0 < 1e-4 or y1 - y0 < 1e-4 or z1 - z0 < 1e-4:
        return
    if move is None:
        mesh.box(x0, x1, y0, y1, z0, z1, group)
        return
    c = {(i, j, k): move((x0, x1)[i], (y0, y1)[j], (z0, z1)[k]) for i in (0, 1) for j in (0, 1) for k in (0, 1)}
    first = len(mesh.polys)
    mesh.hexa(c, group)
    mesh._face_out(first)


def build_from(name, s, customs=None):
    """The cabinet's mesh; customs: {"door": (points, polys), "drawer": ...} for
    Library and Custom pulls."""
    import aw_handles
    import aw_host
    import aw_pulls as P
    from aw_mesh import MeshBuilder
    customs = customs or {}
    mesh = MeshBuilder(GROUPS)
    boxes, pls = parts(s)
    for kind, geo, group, move in boxes:
        if kind == "box":
            _box(mesh, geo, group, move)
        else:
            _prism_y(mesh, geo[0], geo[1], geo[2], group, move or _ident_move)
    for origin, lever, up, kind, size, which, move in pls:
        o = move(*origin)
        lv = _dir(move, origin, lever)
        uv = _dir(move, origin, up)
        nv = _dir(move, origin, (0.0, 0.0, -1.0))
        P.build(mesh, kind, size, aw_handles.place(o, lv, nv, uv), "Pulls", customs.get(which))
    return mesh.build(name)


def _prism_y(mesh, poly, y0, y1, group, move):
    """A closed solid: outline poly [(x, z)] from y0 up to y1, placed by move."""
    import aw_slab
    if y1 - y0 < 1e-4 or len(poly) < 3:
        return
    a = sum(p[0] * q[1] - q[0] * p[1] for p, q in zip(poly, poly[1:] + poly[:1]))
    pts = poly if a > 0 else poly[::-1]
    mesh.new_part()
    first = len(mesh.polys)
    lo = [mesh.pt(*move(x, y0, z)) for x, z in pts]
    hi = [mesh.pt(*move(x, y1, z)) for x, z in pts]
    m = len(pts)
    for i, j, k in aw_slab.triangulate(pts):
        mesh.quad(lo[k], lo[j], lo[i], lo[i], group)
        mesh.quad(hi[i], hi[j], hi[k], hi[k], group)
    for i in range(m):
        j = (i + 1) % m
        mesh.quad(lo[i], lo[j], hi[j], hi[i], group)
    mesh._face_out(first)


def _dir(move, at, d):
    a = move(*at)
    b = move(at[0] + d[0], at[1] + d[1], at[2] + d[2])
    return tuple(bb - aa for aa, bb in zip(a, b))


FIELDS = (("type", "TYPE", int), ("width", "WIDTH", float), ("height", "HEIGHT", float), ("depth", "DEPTH", float),
          ("top", "TOP", float), ("kick_h", "KICK_H", float), ("kick_setback", "KICK_SETBACK", float),
          ("thickness", "THICKNESS", float), ("open", "OPEN", float), ("style", "STYLE", int),
          ("drawer_style", "DRAWER_STYLE", int), ("frame_w", "FRAME_W", float), ("front_t", "FRONT_T", float),
          ("overlay", "OVERLAY", int), ("reveal", "REVEAL", float), ("face_frame", "FACE_FRAME", float),
          ("panel_recess", "PANEL_RECESS", float), ("zone_count", "ZONES", int),
          ("door_pull", "DOOR_PULL", int), ("door_pull_size", "DOOR_PULL_SIZE", float),
          ("door_pull_orient", "DOOR_PULL_ORIENT", int), ("door_pull_pos", "DOOR_PULL_POS", int),
          ("door_pull_edge", "DOOR_PULL_EDGE", float), ("door_pull_end", "DOOR_PULL_END", float),
          ("door_pull_lib", "DOOR_PULL_LIB", int),
          ("drawer_pull", "DRAWER_PULL", int), ("drawer_pull_size", "DRAWER_PULL_SIZE", float),
          ("drawer_pull_orient", "DRAWER_PULL_ORIENT", int), ("drawer_pull_pos", "DRAWER_PULL_POS", int),
          ("drawer_pull_top", "DRAWER_PULL_TOP", float), ("drawer_two_over", "DRAWER_TWO_OVER", float),
          ("drawer_pull_lib", "DRAWER_PULL_LIB", int), ("end_l", "END_L", bool), ("end_r", "END_R", bool),
          ("end_t", "END_T", float), ("end_proud", "END_PROUD", float), ("filler_l", "FILLER_L", float),
          ("filler_r", "FILLER_R", float), ("blind", "BLIND", int), ("blind_w", "BLIND_W", float),
          ("corner", "CORNER", int), ("return", "RETURN", float), ("corner_side", "CORNER_SIDE", int))


def settings(op):
    import aw_ids as I
    s = {name: kind(aw_host.value(op, getattr(I, "AW_CAB_" + key))) for name, key, kind in FIELDS}
    s["zones"] = [{f: (float if f == "height" else int)(aw_host.value(op, I.cab_zone(i, k)))
                   for k, f in enumerate(ZONE_FIELDS)} for i in range(MAX_ZONES)]
    for z in s["zones"]:
        z["glass"] = bool(z["glass"])
    s["width"], s["height"], s["depth"] = max(s["width"], 2.0), max(s["height"], 2.0), max(s["depth"], 2.0)
    s["front_t"] = min(max(s["front_t"], 0.3), s["depth"] / 2)
    s["door_obj"], s["drawer_obj"] = aw_host.link(op, I.AW_CAB_DOOR_PULL_OBJ), aw_host.link(op, I.AW_CAB_DRAWER_PULL_OBJ)
    if s["corner"] != NO_CORNER:  # an L can't be deeper than its legs are long
        s["depth"] = corner_limits(s)
        s["return"] = max(s["return"], s["depth"] + 5.0)
    return s


def _customs(s):
    import aw_pulls as P
    out = {}
    lib = None
    for which in ("door", "drawer"):
        kind = s[which + "_pull"]
        if kind == P.CUSTOM:
            out[which] = aw_host.custom_mesh(s[which + "_obj"])
        elif kind == P.LIBRARY:
            lib = aw_host.pull_library() if lib is None else lib
            i = s[which + "_pull_lib"]
            out[which] = lib[i][1] if 0 <= i < len(lib) else None
    return out


def sink_over(op):
    """True when a sink's hole (in a countertop covering op) reaches over op's top: a
    sink base, whose box then has no top board (it would hide the bowl)."""
    import aw_counter as T
    import aw_ids as I
    s = None
    me = aw_host.ident(op)
    inv = None
    for ct in aw_host.objects(op, I.ID_AW_COUNTERTOP):
        if not any(aw_host.ident(c) == me for c in aw_host.object_list(ct, I.AW_CT_CABINETS)):
            continue
        for sk in aw_host.children(ct):
            if aw_host.type_id(sk) != I.ID_AW_SINK:
                continue
            ss = T.sink_settings(sk)
            hole = T.sink_hole(ss["mount"], ss["shape"], ss["width"], ss["length"], ss["radius"], ss["rim"])
            if not hole:
                continue
            s = s or settings(op)
            inv = inv or ~aw_host.world_matrix(op)
            m = inv * aw_host.world_matrix(sk)
            pts = [m * Vec(x, 0, z) for x, z in hole]
            xs, zs = [p.x for p in pts], [p.z for p in pts]
            if min(xs) < s["width"] and max(xs) > 0 and min(zs) < 0 and max(zs) > -s["depth"]:
                return True
    return False


def build(op):
    s = settings(op)
    s["open_top"] = sink_over(op)
    return build_from(aw_host.name(op), s, _customs(s))


# Neighbours: a width change pushes (or pulls) the cabinets touching it -------------------

TOUCH = 0.5  # cm: closer than this, two cabinets' ends touch
ANCHOR_LEFT, ANCHOR_CENTRE, ANCHOR_RIGHT = 0, 1, 2


def chain(start, others, rightwards):
    """Keys of the cabinets in a run touching each other from edge `start` on: going
    right, ones whose left end is at the edge (then their right ends, and so on);
    going left, the mirror. others: [(key, u0, u1)] along the cabinet's +X."""
    found, edges = [], [start]
    while edges:
        edge = edges.pop()
        for key, a, b in others:
            if key in found:
                continue
            if abs((a if rightwards else b) - edge) < TOUCH:
                found.append(key)
                edges.append(b if rightwards else a)
    return found


def shifts(u0, old_w, new_w, others, anchor):
    """(how far the cabinet itself moves along its +X, {key: how far each neighbour
    moves}) when its width goes from old_w to new_w: Anchor Left keeps its left end
    and pushes the run on its right; Right keeps its right end and pushes the run on
    its left; Centre splits the difference."""
    d = new_w - old_w
    right = chain(u0 + old_w, others, True)
    left = chain(u0, others, False)
    if anchor == ANCHOR_RIGHT:
        return -d, {k: -d for k in left}
    if anchor == ANCHOR_CENTRE:
        out = {k: d / 2 for k in right}
        out.update({k: -d / 2 for k in left})
        return -d / 2, out
    return 0.0, {k: d for k in right}


_seen = {}  # a cabinet's (width, origin) when last seen, by its identity: what the watcher compares


def neighbours(op, width=None):
    """[(cabinet, u0, u1)] of the other cabinets backing onto the same face as op, at
    heights that overlap it, along op's own +X (op's left end at 0)."""
    import aw_ids as I
    others = aw_host.objects(op, I.ID_AW_CABINET)
    if not others:
        return []
    s = settings(op)
    lo, hi = y_range(s)
    inv = ~aw_host.world_matrix(op)
    me = aw_host.ident(op)
    out = []
    for o in others:
        if aw_host.ident(o) == me:
            continue
        m = inv * aw_host.world_matrix(o)
        if m.v3.GetNormalized().z > 0.999 and m.v1.GetNormalized().x > 0.999 and abs(m.off.z) < 1.0:
            so = settings(o)
            olo, ohi = y_range(so)
            if olo + m.off.y < hi - 1e-6 and ohi + m.off.y > lo + 1e-6:
                out.append((o, m.off.x, m.off.x + so["width"]))
    return out


def pinned_anchor(s):
    """The anchor a corner or blind cabinet keeps (its corner end, against two walls),
    or None for any other cabinet."""
    if s.get("corner", NO_CORNER) != NO_CORNER:
        return ANCHOR_RIGHT if s.get("corner_side") == CORNER_RIGHT else ANCHOR_LEFT
    if s.get("blind", NO_BLIND) != NO_BLIND:
        return ANCHOR_RIGHT if s.get("blind") == BLIND_RIGHT else ANCHOR_LEFT
    return None


def choose_anchor(anchor, own_pin, pinned_left, pinned_right):
    """Which end stays put: a corner or blind cabinet's own corner end; otherwise the
    Anchor, turned round where the run it would push ends in a corner or blind cabinet
    (that can't move: the run grows away from it instead). None: nothing can move."""
    if own_pin is not None:
        return own_pin
    if anchor == ANCHOR_LEFT and pinned_right:
        return None if pinned_left else ANCHOR_RIGHT
    if anchor == ANCHOR_RIGHT and pinned_left:
        return None if pinned_right else ANCHOR_LEFT
    if anchor == ANCHOR_CENTRE and (pinned_left or pinned_right):
        if pinned_left and pinned_right:
            return None
        return ANCHOR_LEFT if pinned_left else ANCHOR_RIGHT
    return anchor


def _move_along(o, vec, undo):
    aw_host.move(o, vec, undo)


def ripple(op, old_w, new_w, anchor=None, undo=True):
    """Move op and the run it touches for a width change from old_w to new_w (op's own
    width already set, or about to be). Returns how many neighbours moved."""
    import aw_ids as I
    if abs(new_w - old_w) < 1e-6 or not aw_host.value(op, I.AW_CAB_PUSH):
        _remember(op)
        return 0
    s = settings(op)
    if anchor is None:
        anchor = int(aw_host.value(op, I.AW_CAB_ANCHOR))
    near = neighbours(op)
    keyed = [(id(o), a, b) for o, a, b in near]
    pins = {id(o) for o, _a, _b in near if pinned_anchor(settings(o)) is not None}
    right = chain(old_w, keyed, True)
    left = chain(0.0, keyed, False)
    anchor = choose_anchor(anchor, pinned_anchor(s), any(k in pins for k in left), any(k in pins for k in right))
    if anchor is None:
        _remember(op)
        return 0
    me, moves = shifts(0.0, old_w, new_w, keyed, anchor)
    ax = aw_host.world_matrix(op).v1.GetNormalized()
    count = 0
    for o, _a, _b in near:
        d = moves.get(id(o))
        if d and id(o) not in pins:
            _move_along(o, ax * d, undo)
            _remember(o)
            count += 1
    if me:
        _move_along(op, ax * me, undo)
    _remember(op)
    return count


def round_corner_start(s):
    """Where (along the cabinet's -Z, from its back) the run on the other wall starts:
    at a pie cut's or diagonal's return, or a blind cabinet's front; None for others."""
    if s.get("corner", NO_CORNER) != NO_CORNER:
        return max(s.get("return", s["width"]), s["depth"] + 2.0)
    if s.get("blind", NO_BLIND) != NO_BLIND:
        return s["depth"]
    return None


def other_wall_run(op, start, s=None):
    """[cabinet] the run on the other wall of op's corner, end to end from `start` (how
    far out from op's back it begins) on: cabinets backing onto the wall at op's corner
    end, facing across op, at heights that overlap it."""
    import aw_ids as I
    s = s or settings(op)
    pin = pinned_anchor(s)
    if pin is None:
        return []
    corner_x = 0.0 if pin == ANCHOR_LEFT else s["width"]
    facing = 1.0 if pin == ANCHOR_LEFT else -1.0   # their fronts face away from that wall, across op
    lo, hi = y_range(s)
    inv = ~aw_host.world_matrix(op)
    me = aw_host.ident(op)
    found = []
    for o in aw_host.objects(op, I.ID_AW_CABINET):
        if aw_host.ident(o) == me:
            continue
        m = inv * aw_host.world_matrix(o)
        front = -m.v3.GetNormalized()
        if front.x * facing > 0.999 and abs(m.off.x - corner_x) < 1.0:
            so = settings(o)
            olo, ohi = y_range(so)
            if olo + m.off.y < hi - 1e-6 and ohi + m.off.y > lo + 1e-6:
                z0 = m.off.z
                z1 = (m * Vec(so["width"], 0, 0)).z
                found.append((o, min(z0, z1), max(z0, z1)))
    run = chain(start, [(id(o), -b, -a) for o, a, b in found], True)  # out along -Z: as distances from op's back
    return [o for o, _a, _b in found if id(o) in run]


def ripple_round(op, old_start, new_start, undo=True):
    """A corner or blind cabinet's return (or depth) went from old_start to new_start:
    the run on the other wall, which starts there, moves with it."""
    import aw_ids as I
    if abs(new_start - old_start) < 1e-6 or not aw_host.value(op, I.AW_CAB_PUSH):
        return 0
    run = other_wall_run(op, old_start)
    vec = aw_host.world_matrix(op).v3.GetNormalized() * -(new_start - old_start)  # away from op's back wall
    for o in run:
        _move_along(o, vec, undo)
        _remember(o)
    return len(run)


def _origin(op):
    p = aw_host.world_matrix(op).off
    return (round(p.x, 4), round(p.y, 4), round(p.z, 4))


def _remember(op):
    """What the watcher compares a cabinet with next time: (width, origin, where its
    other wall's run starts)."""
    s = settings(op)
    _seen[aw_host.ident(op)] = (s["width"], _origin(op), round_corner_start(s))


def changes(cabinets):
    """What the watcher acts on, from every cabinet in a scene on a scene change:
    [("width" or "round", cabinet, old, new)] for each whose width changed since it was
    last seen (an edit in the Attribute Manager, say: it pushes its run), or a corner or
    blind cabinet whose return (or depth) changed (it moves the run on the other wall).
    Not for an animated width, nor when the cabinet itself moved too: that is an undo
    or redo putting things back, and it put the run back as well. (The host runs each
    as one undo step, and none while the animation plays.)"""
    import aw_ids as I
    out = []
    for o in cabinets:
        key = aw_host.ident(o)
        old = _seen.get(key)
        _remember(o)
        now = _seen[key]
        if old is not None and old[1] == now[1]:
            if abs(old[0] - now[0]) > 1e-6 and not aw_host.animated(o, I.AW_CAB_WIDTH):
                out.append(("width", o, old[0], now[0]))
            if old[2] is not None and now[2] is not None and abs(old[2] - now[2]) > 1e-6:
                out.append(("round", o, old[2], now[2]))
    return out


def act(change):
    """Carry out one of changes(): how many cabinets moved."""
    what, o, old, new = change
    return ripple(o, old, new) if what == "width" else ripple_round(o, old, new)


def _set(op, name, value):
    import aw_ids as I
    if name == "zone":
        k, h = value
        aw_host.set_value(op, I.cab_zone(k, 1), h)
    else:
        aw_host.set_value(op, getattr(I, "AW_CAB_" + {"width": "WIDTH", "height": "HEIGHT", "depth": "DEPTH",
                                                      "top": "TOP", "kick": "KICK_H", "return": "RETURN"}[name]),
                          value)


def _runs_into_corner(op, width):
    """True when the run on op's right ends in a corner or blind cabinet."""
    near = neighbours(op)
    right = chain(width, [(id(o), a, b) for o, a, b in near], True)
    return any(pinned_anchor(settings(o)) is not None for o, _a, _b in near if id(o) in right)


def set_grip(op, i, p):
    s = settings(op)
    _lay, grips = dims_layout(s)
    if 0 <= i < len(grips):
        for name, value in grip_value(grips[i][3], (p.x, p.y, p.z), s):
            old_start = round_corner_start(s)
            if name == "width_left":  # dragged by its left end: the corner end stays, the cabinet grows left
                _set(op, "width", value)
                ripple(op, s["width"], value, ANCHOR_RIGHT)
                continue
            if name == "return":
                _set(op, "return", value)
                ripple_round(op, old_start, round_corner_start(settings(op)))
                _remember(op)
                continue
            if name == "width":  # dragged by its right end: the left stays, the run on the right moves
                if pinned_anchor(s) == ANCHOR_RIGHT or _runs_into_corner(op, s["width"]):
                    if value > s["width"]:
                        continue  # it can't grow into a corner (type a width to grow the other way)
                    _set(op, name, value)
                    _remember(op)
                    continue
                _set(op, name, value)
                ripple(op, s["width"], value, ANCHOR_LEFT)
            else:
                _set(op, name, value)
                if name == "depth" and old_start is not None:
                    ripple_round(op, old_start, round_corner_start(settings(op)))
                    _remember(op)


def apply(doc, op, edit, value):
    """A value typed into one of a cabinet's labels."""
    do = edit["do"]
    s = settings(op)
    if value < 0 or (value <= 0 and do != "cab_kick"):
        raise ValueError("must be more than 0")
    aw_host.undo_change(op)
    if do == "cab_zone":
        i = edit["i"]
        zs = zones(s)
        if i + 1 < len(zs):
            for k, h in zone_heights_for(s, i, zs[i][1] + value).items():
                _set(op, "zone", (k, h))
        else:  # the top zone: just its own height
            _set(op, "zone", (i, value))
        return "zone %d height" % (i + 1)
    name = do[4:]
    if name == "height" and s["type"] != UPPER and value <= s["kick_h"]:
        raise ValueError("must be taller than its kick")
    old_start = round_corner_start(s)
    if s.get("corner", NO_CORNER) != NO_CORNER:  # keep the L an L
        if name == "depth":
            value = corner_limits(s, depth=value)
        elif name == "return":
            value = max(value, s["depth"] + 5.0)
    _set(op, name, value)
    if name == "width":
        ripple(op, s["width"], value)
    elif name in ("depth", "return") and old_start is not None:
        ripple_round(op, old_start, round_corner_start(settings(op)))
    _remember(op)
    return "cabinet " + name


def apply_type_defaults(op):
    """After Type changes: that type's own sizes."""
    import aw_ids as I
    w, h, d, kick, top = TYPE_DEFAULTS.get(aw_host.value(op, I.AW_CAB_TYPE), TYPE_DEFAULTS[BASE])
    for pid, v in ((I.AW_CAB_HEIGHT, h), (I.AW_CAB_DEPTH, d), (I.AW_CAB_KICK_H, kick)):
        aw_host.set_value(op, pid, v)
    if top:
        aw_host.set_value(op, I.AW_CAB_TOP, top)


KNOB_MAX = 6.0  # cm: a Size above this is a pull's (centre to centre), below it a knob's (diameter)


def pull_size_for(kind, size):
    """The Size a pull of type kind should have, coming from size: kept while it suits
    the kind (a knob's diameter under KNOB_MAX, a pull's centre to centre over it),
    else the kind's standard one (aw_pulls.STANDARD_SIZES), so a 128 mm bar pull made a
    knob becomes a 1 1/4 in knob, not a 128 mm one. None: nothing to size (None,
    Library, Custom)."""
    import aw_pulls
    standard = aw_pulls.STANDARD_SIZES.get(kind)
    if standard is None:
        return None
    knob = kind in aw_pulls.KNOBS
    return size if (size <= KNOB_MAX) == knob else standard


def apply_pull_defaults(op, pid):
    """After the door or drawer Pull (pid) changes: a Size that suits the new kind."""
    import aw_ids as I
    size_pid = {I.AW_CAB_DOOR_PULL: I.AW_CAB_DOOR_PULL_SIZE, I.AW_CAB_DRAWER_PULL: I.AW_CAB_DRAWER_PULL_SIZE}[pid]
    size = pull_size_for(int(aw_host.value(op, pid)), aw_host.value(op, size_pid))
    if size is not None and abs(size - aw_host.value(op, size_pid)) > 1e-6:
        aw_host.set_value(op, size_pid, size)


# Presets ---------------------------------------------------------------------------------

def _zones(*zs):
    """zone values for a preset: (kind, height=0, columns=1, shelves=0, glass=False) each."""
    out = {"zone_count": len(zs)}
    for i, z in enumerate(zs):
        z = tuple(z) + (0.0, 1, 0, False)[len(z) - 1:]
        for k, f in enumerate(ZONE_FIELDS):
            out["zone_%d_%s" % (i, f)] = z[k]
    for i in range(len(zs), MAX_ZONES):
        out.update({"zone_%d_kind" % i: DOOR_LEFT, "zone_%d_height" % i: 0.0, "zone_%d_columns" % i: 1,
                    "zone_%d_shelves" % i: 0, "zone_%d_glass" % i: False})
    return out


def _cab(label, kind, width, zones_, **values):
    w, h, d, kick, top = TYPE_DEFAULTS[kind]
    v = {"type": kind, "width": width, "height": h, "depth": d, "kick_h": kick}
    if top:
        v["top"] = top
    v.update(zones_)
    v.update(values)
    return {"label": label, "object": "cabinet", "key": TYPE_NAMES[kind], "values": v}


PRESETS = (
    _cab("Base 1 door", BASE, 18 * IN, _zones((DOOR_LEFT,), (DRAWER, 6 * IN))),  # zones bottom to top
    _cab("Base 2 door", BASE, 36 * IN, _zones((DOOR_PAIR,), (DRAWER, 6 * IN, 2))),
    _cab("Base 3 drawer", BASE, 18 * IN, _zones((DRAWER, 12 * IN), (DRAWER, 10 * IN), (DRAWER,))),
    _cab("Sink base", BASE, 36 * IN, _zones((DOOR_PAIR,), (SINK, 6 * IN))),
    _cab("Farmhouse sink base", BASE, 36 * IN, _zones((DOOR_PAIR,), (EMPTY, 10 * IN))),  # the sink's apron fills the top
    _cab("Base open", BASE, 24 * IN, _zones((OPEN, 0.0, 1, 1))),
    _cab("Upper 1 door", UPPER, 15 * IN, _zones((DOOR_LEFT,))),
    _cab("Upper 2 door", UPPER, 30 * IN, _zones((DOOR_PAIR,))),
    _cab("Upper glass", UPPER, 30 * IN, _zones((DOOR_PAIR, 0.0, 1, 0, True))),
    _cab("Upper open", UPPER, 30 * IN, _zones((OPEN, 0.0, 1, 2))),
    _cab("Tall pantry", TALL, 24 * IN, _zones((DOOR_PAIR, 48 * IN), (DOOR_PAIR,))),
    _cab("Vanity sink", VANITY, 30 * IN, _zones((DOOR_PAIR,), (SINK, 6 * IN))),
    _cab("Vanity drawers", VANITY, 18 * IN, _zones((DRAWER, 10 * IN), (DRAWER, 8 * IN), (DRAWER,))),
    # corners: placed into an inside corner, they turn to it (blind and corner side set themselves)
    _cab("Blind base", BASE, 42 * IN, _zones((DOOR_LEFT,), (DRAWER, 6 * IN)), blind=BLIND_LEFT, blind_w=24 * IN),
    _cab("Blind upper", UPPER, 36 * IN, _zones((DOOR_LEFT,)), blind=BLIND_LEFT, blind_w=13 * IN),
    _cab("Lazy susan", BASE, 36 * IN, _zones((DOOR_LEFT,)), corner=PIE_CUT, **{"return": 36 * IN}),
    _cab("Corner upper", UPPER, 24 * IN, _zones((DOOR_LEFT,)), corner=DIAGONAL, **{"return": 24 * IN}),
)


def param_ids():
    """[(preset field, parameter id)] of everything a preset holds."""
    import aw_ids as I
    out = [(name, getattr(I, "AW_CAB_" + key)) for name, key, _k in FIELDS]
    for i in range(MAX_ZONES):
        out += [("zone_%d_%s" % (i, f), I.cab_zone(i, k)) for k, f in enumerate(ZONE_FIELDS)]
    return tuple(out)


# Placing on a wall ----------------------------------------------------------------------

SNAP = 10.0  # cm: how close an end comes to a wall's end or another cabinet before it snaps to it
_hover = None


def _hit(wall, a, v, reach=0.0, parallel=False):
    """(distance, segment, u, face offset w, a point on the cabinet's side, in wall space)
    where the mouse ray (from a along v, Vecs in the scene's space) first meets one of the
    wall's faces; or, meeting the floor first (a plan view looks straight down, never at a
    face), the floor within reach in front of a face: the face it is in front of.

    parallel: a parallel view (Front, Side), which sees through the whole room and can't
    say how deep the mouse is: the nearest room-side face (a closed run's inside, reached
    from the room) wins over a nearer outside one, so a cabinet goes in the room seen
    through its front wall, as in perspective. hit[0] then sorts room faces first."""
    import aw_wall
    wp = aw_wall.wall_path(wall)
    if wp is None:
        return None
    plan, w0, w1, height, _s = wp
    inv = ~aw_host.world_matrix(wall)
    la, lv = inv * a, inv.turn(v)
    best = None
    inside = max(w0, w1)  # closed runs turn counter-clockwise: the room is on +n (aw_path.Plan)
    for k, seg in enumerate(plan.segments):
        (ax, az), (dx, dz), (nx, nz) = seg["a"], seg["d"], seg["n"]
        den = lv.x * nx + lv.z * nz
        if abs(den) < 1e-9:
            continue
        room = parallel and w0 != w1 and plan.runs[seg["run"]].closed and den < 0
        for w in (w0, w1):
            t = ((ax + nx * w - la.x) * nx + (az + nz * w - la.z) * nz) / den
            if t <= 0:
                continue
            p = la + lv * t
            u = (p.x - ax) * dx + (p.z - az) * dz
            if -1 <= u <= seg["length"] + 1 and 0 <= p.y <= plan.top(k, u, height) + 1:
                key = t if room and w == inside else t + (_OUTSIDE if parallel else 0.0)
                if best is None or key < best[0]:
                    best = (key, k, u, w, (la.x, la.z))
    if reach > 0 and lv.y < -1e-9 and la.y > 0:
        t = -la.y / lv.y
        if best is None or t < best[0]:
            floor = _in_front(plan, w0, w1, la + lv * t, reach)
            if floor is not None:
                k, u, w, p = floor
                best = (t, k, u, w, p)
    return best


_OUTSIDE = 1.0e9  # added to an outside face's distance in a parallel view: any room face comes first


def _in_front(plan, w0, w1, p, reach):
    """(segment, u, face offset w, (x, z)) of the face the floor point p (wall space) is
    nearest in front of, within reach; None if it is in no face's reach (or in the wall)."""
    best = None
    for k, seg in enumerate(plan.segments):
        (ax, az), (dx, dz), (nx, nz) = seg["a"], seg["d"], seg["n"]
        u = (p.x - ax) * dx + (p.z - az) * dz
        if not 0.0 <= u <= seg["length"]:
            continue
        across = (p.x - ax) * nx + (p.z - az) * nz
        for w, out in ((w0, -1.0 if w0 < w1 else 1.0), (w1, 1.0 if w1 > w0 else -1.0)):
            t = (across - w) * out
            if 0.0 < t <= reach and (best is None or t < best[0]):
                best = (t, k, u, w)
    return None if best is None else (best[1], best[2], best[3], (p.x, p.z))


def _wall_spans(wall, k, plan, w, n_out, depth, walls):
    """[(u0, u1)] along this face of segment k that other walls take up in the strip
    depth deep in front of it: a side wall running into the room stops a cabinet."""
    import aw_wall
    seg = plan.segments[k]
    (ax, az), (dx, dz), (nx, nz) = seg["a"], seg["d"], seg["n"]
    side = 1.0 if nx * n_out[0] + nz * n_out[1] > 0 else -1.0
    inv = ~aw_host.world_matrix(wall)
    me = aw_host.ident(wall)
    out = []
    for other in walls:
        if aw_host.ident(other) == me:
            continue
        wp = aw_wall.wall_path(other)
        if wp is None:
            continue
        oplan, o0, o1, _h, _s = wp
        m = inv * aw_host.world_matrix(other)
        for oseg in oplan.segments:
            (bx, bz), (ex, ez), (mx, mz), length = oseg["a"], oseg["d"], oseg["n"], oseg["length"]
            quad = []
            for along, off in ((0.0, o0), (length, o0), (length, o1), (0.0, o1)):
                q = m * Vec(bx + ex * along + mx * off, 0.0, bz + ez * along + mz * off)
                quad.append(((q.x - ax) * dx + (q.z - az) * dz, ((q.x - ax) * nx + (q.z - az) * nz - w) * side))
            strip = _clip(_clip(quad, 0.5, 1.0), depth - 0.5, -1.0)
            if strip:
                us = [u for u, _t in strip]
                out.append((min(us), max(us)))
    return out


def _clip(poly, at, keep):
    """poly [(u, t)] cut to t >= at (keep 1) or t <= at (keep -1)."""
    out = []
    for i, p in enumerate(poly):
        q = poly[(i + 1) % len(poly)]
        pin, qin = (p[1] - at) * keep >= 0, (q[1] - at) * keep >= 0
        if pin:
            out.append(p)
        if pin != qin:
            f = (at - p[1]) / (q[1] - p[1])
            out.append((p[0] + (q[0] - p[0]) * f, at))
    return out


def y_range(values):
    """(bottom, top) a cabinet of these settings takes up on the wall."""
    if values["type"] == UPPER:
        return values["top"] - values["height"], values["top"]
    return 0.0, values["height"]


def footprint(s):
    """The cabinet's plan outline as a box in its own space: (x0, x1, z0, z1), its end
    panels' proud and a corner cabinet's return included."""
    if s.get("corner", NO_CORNER) != NO_CORNER:
        return 0.0, s["width"], -max(s.get("return", s["width"]), s["depth"]), 0.0
    proud = max(s.get("end_proud", 0.0), 0.0) if (s.get("end_l") or s.get("end_r")) else 0.0
    return 0.0, s["width"], -(s["depth"] + proud), 0.0


def _others(wall, k, plan, w, n_out, depth=60.0, skip=None):
    """[(u0, u1, y0, y1)] of the cabinets in the way of one backing onto this face of
    segment k, depth deep: those on the same face, and those reaching into that strip
    from another wall (a blind or corner cabinet in the corner), as spans along it."""
    import aw_ids as I
    return _strip(aw_host.objects(wall, I.ID_AW_CABINET), ~aw_host.world_matrix(wall), plan.segments[k], w,
                  n_out, depth, skip)


def _strip(cabinets, inv, seg, w, n_out, depth, skip=None):
    """_others for these cabinets, seg in the space inv takes the scene to (None: the
    scene's own, a free cabinet's line)."""
    out = []
    (ax, az), (dx, dz), (nx, nz) = seg["a"], seg["d"], seg["n"]
    side = 1.0 if nx * n_out[0] + nz * n_out[1] > 0 else -1.0
    skip = aw_host.ident(skip) if skip is not None else None
    for o in cabinets:
        if skip is not None and aw_host.ident(o) == skip:
            continue
        m = aw_host.world_matrix(o) if inv is None else inv * aw_host.world_matrix(o)
        so = settings(o)
        x0, x1, z0, z1 = footprint(so)
        us, ts = [], []
        for x, z in ((x0, z0), (x1, z0), (x1, z1), (x0, z1)):
            q = m * Vec(x, 0, z)
            us.append((q.x - ax) * dx + (q.z - az) * dz)
            ts.append(((q.x - ax) * nx + (q.z - az) * nz - w) * side)  # out from our face
        if max(ts) > 0.5 and min(ts) < depth - 0.5:
            lo, hi = y_range(so)
            lo, hi = lo + m.off.y, hi + m.off.y
            out.append((min(us), max(us), lo, hi))
    return out


def fit(u, width, c0, c1, others, centre=False):
    """(u0, u1, left, right, ok) for a cabinet width wide wanted centred at u between the
    wall's ends c0, c1 and the others' spans (each (u0, u1)): snapped to an end within
    SNAP, slid clear of a neighbour, centred between them with centre."""
    # a neighbour under the mouse counts as on whichever side of it the mouse is nearer
    lefts = [b for a, b in others if b <= u + 1e-6 or (a < u < b and u >= (a + b) / 2)]
    rights = [a for a, b in others if a >= u - 1e-6 or (a < u < b and u < (a + b) / 2)]
    left, right = max([c0] + lefts), min([c1] + rights)
    u = min(max(u, left), right)
    if centre:
        u = (left + right) / 2
    u0, u1 = u - width / 2, u + width / 2
    if abs(u0 - left) < SNAP:
        u0, u1 = left, left + width
    elif abs(u1 - right) < SNAP:
        u0, u1 = right - width, right
    if u0 < left - 1e-6:
        u0, u1 = left, left + width
    if u1 > right + 1e-6:
        u0, u1 = right - width, right
    ok = u0 >= left - 1e-6 and u1 <= right + 1e-6
    return u0, u1, left, right, ok


def hover_at(walls, a, v, preset, centre=False, parallel=False, cabinets=None):
    """Where a cabinet of this preset goes for a mouse ray from a along v (Vecs in the
    scene's space) over these walls: kept for layout() and the host's place(), and
    returned. parallel: the view has no depth (see _hit). Off every wall (or where the
    ray meets the floor before any wall), a free cabinet on the floor (_free), placed
    among these cabinets (None: the walls' scene's); None if the ray misses the floor too.
    _hover["wall"] is the wall it backs onto, None for a free one (its plan is then in
    the scene's own space)."""
    global _hover
    import aw_ids as I
    import aw_wall
    values = preset["values"]
    depth = values.get("depth", TYPE_DEFAULTS[values.get("type", BASE)][2])
    best = None
    for wall in walls:
        h = _hit(wall, a, v, reach=depth + 15.0, parallel=parallel)
        if h is not None and (best is None or h[0] < best[0][0]):  # the nearest wall's hit
            best = (h, wall)
    v_ = preset["values"]
    width = v_.get("width", TYPE_DEFAULTS[BASE][0])
    lo, hi = y_range({"type": v_.get("type", BASE), "height": v_.get("height", 0.0), "top": v_.get("top", 84 * IN)})
    floor = -a.y / v.y if v.y < -1e-9 and a.y > 0 else None
    if floor is not None and (best is None or (not parallel and floor < best[0][0] - 1.0)):
        if cabinets is None:
            cabinets = aw_host.objects(walls[0], I.ID_AW_CABINET) if walls else []
        _hover = _free(a + v * floor, v, preset, cabinets, centre, width, depth, lo, hi)
        return _hover
    if best is None:
        _hover = None
        return None
    (t, k, u, w, eye), wall = best
    plan, w0, w1, height, _sp = aw_wall.wall_path(wall)
    seg = plan.segments[k]
    p = (seg["a"][0] + seg["d"][0] * u + seg["n"][0] * w, seg["a"][1] + seg["d"][1] * u + seg["n"][1] * w)
    side = 1.0 if (eye[0] - p[0]) * seg["n"][0] + (eye[1] - p[1]) * seg["n"][1] > 0 else -1.0
    n_out = (seg["n"][0] * side, seg["n"][1] * side)
    c0, c1 = plan.clear_span(k, w0, w1)
    others = [(a, b) for a, b, y0, y1 in _others(wall, k, plan, w, n_out, depth)
              if y0 < hi - 1e-6 and y1 > lo + 1e-6]
    others += _wall_spans(wall, k, plan, w, n_out, depth, walls)
    u0, u1, left, right, ok = fit(u, width, c0, c1, others, centre)
    _hover = {"wall": wall, "plan": plan, "k": k, "w": w, "n_out": n_out, "u0": u0, "u1": u1, "left": left,
              "right": right, "ok": ok, "lo": lo, "hi": hi, "depth": depth, "preset": preset}
    return _hover


# Free cabinets (an island): on the floor, off every wall -----------------------------------

FAR = 1.0e6  # a free cabinet's line runs this far each way: no wall's end to stop it
turns = 0    # quarter turns R has added to a free cabinet's facing


class Line:
    """A straight stand-in for a wall's plan (aw_path.Plan): what a free cabinet backs
    onto, in the scene's own space. Segment 0 from a along d, its +n the way it faces."""

    def __init__(self, a, d, n):
        self.segments = [{"a": a, "d": d, "n": n, "length": 2 * FAR, "run": 0}]


def facing(v, quarter=0):
    """(x, z) a free cabinet's front faces for a view along v: back at the eye, squared
    to the nearest axis (straight down: -Z, towards a Front view's eye), quarter more
    quarter turns."""
    fx, fz = -v.x, -v.z
    if math.hypot(fx, fz) < 1e-6:
        fx, fz = 0.0, -1.0
    f = (math.copysign(1.0, fx), 0.0) if abs(fx) > abs(fz) else (0.0, math.copysign(1.0, fz))
    for _ in range(quarter % 4):
        f = (-f[1], f[0])
    return f


def snap_line(p, cabinets, width, depth, lo, hi):
    """(a, d, n_out) of the line a free cabinet centred at the floor point p (x, z)
    snaps to, or None: the back of the nearest upright cabinet within reach that it can
    stand beside (same back line, facing the same way) or behind (back to back)."""
    best = None
    for o in cabinets:
        m = aw_host.world_matrix(o)
        if m.v2.GetNormalized().y < 0.999:
            continue
        so = settings(o)
        olo, ohi = y_range(so)
        if not (olo + m.off.y < hi - 1e-6 and ohi + m.off.y > lo + 1e-6):
            continue
        xd = m.v1.GetNormalized()
        fd = -m.v3.GetNormalized()  # its front
        rx, rz = p[0] - m.off.x, p[1] - m.off.z
        along, out = rx * xd.x + rz * xd.z, rx * fd.x + rz * fd.z
        W, D = so["width"], so["depth"]
        if out < 0:  # behind it: back to back
            gap = -out - depth / 2
            dist = max(gap, 0.0 - along - width / 2, along - W - width / 2, 0.0)
            hit = ((m.off.x, m.off.z), (xd.x, xd.z), (-fd.x, -fd.z)) if dist < SNAP else None
        elif out < D + SNAP and (along < 0 or along > W):  # beside it
            dist = max(-along - width / 2, along - W - width / 2, 0.0)
            hit = ((m.off.x, m.off.z), (xd.x, xd.z), (fd.x, fd.z)) if dist < SNAP else None
        else:
            hit = None
        if hit is not None and (best is None or dist < best[0]):
            best = (dist, hit, W)
    return None if best is None else best[1] + (best[2],)


def _between(u, others):
    """u has a neighbour's span on both sides of it: a gap to centre in."""
    return any(b <= u + 1e-6 for _a, b in others) and any(a >= u - 1e-6 for a, _b in others)


def _free(p, v, preset, cabinets, centre, width, depth, lo, hi):
    """hover_at's _hover for a free cabinet centred on the floor point p (a Vec): backed
    onto a nearby cabinet's line (snap_line), else facing the eye (facing, R turns it),
    slid clear of the cabinets on its line."""
    snap = snap_line((p.x, p.z), cabinets, width, depth, lo, hi)
    if snap is not None:
        a0, d, n_out, their_w = snap
        line = Line(a0, d, n_out)
        u = (p.x - a0[0]) * d[0] + (p.z - a0[1]) * d[1]
    else:
        n_out = facing(v, turns)
        d = (n_out[1], -n_out[0])
        line = Line((p.x - n_out[0] * depth / 2, p.z - n_out[1] * depth / 2), d, n_out)
        u = 0.0
    others = [(a, b) for a, b, y0, y1 in _strip(cabinets, None, line.segments[0], 0.0, n_out, depth)
              if y0 < hi - 1e-6 and y1 > lo + 1e-6]
    # Shift centres it between neighbours on both sides; past the last one the line runs on
    # to FAR, and centring in that sent it half a FAR away
    u0, u1, left, right, ok = fit(u, width, -FAR, FAR, others, centre and _between(u, others))
    if snap is not None and not others:  # back to back: its ends line up with the one behind
        for shift in (0.0 - u0, their_w - u1, their_w / 2 - (u0 + u1) / 2):
            if abs(shift) < SNAP:
                u0, u1 = u0 + shift, u1 + shift
                break
    return {"wall": None, "free": True, "plan": line, "k": 0, "w": 0.0, "n_out": n_out, "u0": u0, "u1": u1,
            "left": left, "right": right, "ok": ok, "lo": lo, "hi": hi, "depth": depth, "preset": preset,
            "snapped": snap is not None}


def _at(plan, k, u, w, y=0.0):
    seg = plan.segments[k]
    return (seg["a"][0] + seg["d"][0] * u + seg["n"][0] * w, y, seg["a"][1] + seg["d"][1] * u + seg["n"][1] * w)


def layout():
    h = _hover
    if h is None:
        return None
    plan, k, w = h["plan"], h["k"], h["w"]
    face = w + 0.5 * (1 if h["n_out"][0] * plan.segments[k]["n"][0] + h["n_out"][1] * plan.segments[k]["n"][1] > 0
                      else -1)
    side = 1.0 if face > w else -1.0
    front = w + side * h.get("depth", 0.0)
    box = {(i, j, f): _at(plan, k, (h["u0"], h["u1"])[i], (face, front)[f], (h["lo"], h["hi"])[j])
           for i in (0, 1) for j in (0, 1) for f in (0, 1)}
    edges = [(box[(0, j, f)], box[(1, j, f)]) for j in (0, 1) for f in (0, 1)]  # the whole box's twelve
    edges += [(box[(i, 0, f)], box[(i, 1, f)]) for i in (0, 1) for f in (0, 1)]
    edges += [(box[(i, j, 0)], box[(i, j, 1)]) for i in (0, 1) for j in (0, 1)]
    dims = []
    if h["ok"]:
        out = (h["n_out"][0], 0.0, h["n_out"][1])
        y = h["lo"] + 2.0
        for a, b in ((h["left"], h["u0"]), (h["u1"], h["right"])):
            if 0.05 < b - a < FAR / 2:  # a free cabinet's ends with nothing beyond: no gap to show
                dims.append({"kind": "gap", "role": "focus", "axis": "x", "value": b - a,
                             "a": _at(plan, k, a, face, y), "b": _at(plan, k, b, face, y), "out": out})
        dims.append({"kind": "width", "role": "focus", "axis": "x", "value": h["u1"] - h["u0"],
                     "a": _at(plan, k, h["u0"], face, h["hi"] + 4.0), "b": _at(plan, k, h["u1"], face, h["hi"] + 4.0),
                     "out": (0.0, 1.0, 0.0)})
    return {"dims": dims, "ext": [], "edges": edges, "grips": False, "outline_role": "focus" if h["ok"] else "dim"}


def frame_for(plan, k, u0, u1, w, n_out):
    """(origin, x axis, z axis) in the wall's space for a cabinet spanning u0..u1 on that
    face: its back on the face, its front facing n_out, its left end at x 0."""
    seg = plan.segments[k]
    zx, zz = -n_out[0], -n_out[1]          # +Z: into the wall
    xx, xz = zz, -zx                        # +X: up x +Z (left-handed): to the right, seen from the front
    along = xx * seg["d"][0] + xz * seg["d"][1]
    u_left = u0 if along > 0 else u1
    origin = _at(plan, k, u_left, w)
    return origin, (xx, 0.0, xz), (zx, 0.0, zz)


def settle_ends(op, left_touch, right_touch):
    """A new cabinet's ends from what they touch (a wall's end, a neighbour, a corner
    cabinet's front): an exposed end gets an end panel; a corner cabinet turns its
    corner, and a blind one its blind panel, to the end that's in the corner (and a
    single door's hinges with it)."""
    import aw_ids as I
    v, put = aw_host.value, aw_host.set_value
    corner = int(v(op, I.AW_CAB_CORNER))
    if corner != NO_CORNER:
        if right_touch and not left_touch:
            put(op, I.AW_CAB_CORNER_SIDE, CORNER_RIGHT)
        return
    put(op, I.AW_CAB_END_L, not left_touch)
    put(op, I.AW_CAB_END_R, not right_touch)
    if int(v(op, I.AW_CAB_BLIND)) != NO_BLIND and right_touch and not left_touch:
        put(op, I.AW_CAB_BLIND, BLIND_RIGHT)
        for i in range(MAX_ZONES):  # its doors hinge on the blind side: turn them round too
            kind = v(op, I.cab_zone(i, 0))
            if kind in (DOOR_LEFT, DOOR_RIGHT):
                put(op, I.cab_zone(i, 0), DOOR_RIGHT if kind == DOOR_LEFT else DOOR_LEFT)


def butt_neighbours(op):
    """A cabinet just placed: a neighbour it now butts against loses its end panel
    there (each change an undo step)."""
    import aw_ids as I
    width = aw_host.value(op, I.AW_CAB_WIDTH)
    for o, a, b in neighbours(op):
        if abs(b) < TOUCH and aw_host.value(o, I.AW_CAB_END_R):
            aw_host.set_value(o, I.AW_CAB_END_R, False, undo=True)
        elif abs(a - width) < TOUCH and aw_host.value(o, I.AW_CAB_END_L):
            aw_host.set_value(o, I.AW_CAB_END_L, False, undo=True)
