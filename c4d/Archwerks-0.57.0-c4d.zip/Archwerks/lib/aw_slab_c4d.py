"""aw_slab for Cinema 4D: the parts of core/aw_slab.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_groups_c4d
import aw_slab  # noqa: F401
from aw_slab import *  # noqa: F401,F403


def change_key(op):
    """Changes whenever anything this slab is built from does: its settings, where it
    and its wall are, and the wall's own settings and splines."""
    import c4d
    import aw_wall_c4d
    kind, wall, fit, thick, offset = settings(op)
    wkey = None
    if wall is not None and wall.IsAlive():
        m = ~op.GetMg() * wall.GetMg()
        wkey = (aw_wall_c4d.shape_key(wall),  # its shape, not its windows
                tuple(round(v, 4) for vec in (m.off, m.v1, m.v2, m.v3) for v in (vec.x, vec.y, vec.z)))
    return (op.GetName(), op.GetDirty(c4d.DIRTYFLAGS_DATA), wkey)


def next_name(doc, base):
    """Floor.001, Ceiling.002, ...: one past the highest of that name in the document."""
    prefix, highest = base + ".", 0
    stack = [doc.GetFirstObject()]
    while stack:
        o = stack.pop()
        while o:
            n = o.GetName()
            if n.startswith(prefix) and n[len(prefix):].isdigit():
                highest = max(highest, int(n[len(prefix):]))
            if o.GetDown():
                stack.append(o.GetDown())
            o = o.GetNext()
    return "%s%03d" % (prefix, highest + 1)


def add_for_selection(doc, kind):
    """Panel button: a Floor (or Ceiling) linked to each selected Wall, placed just
    after it, with the default materials. One undo step. Returns the slabs."""
    import c4d
    import aw_ids as I
    import aw_materials
    walls = [o for o in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE) if o.GetType() == I.ID_AW_WALL]
    if not walls:
        c4d.gui.MessageDialog("Select a Wall first: the %s follows its rooms." % ("ceiling" if kind == CEILING else "floor"))
        return []
    made = []
    doc.StartUndo()
    for wall in walls:
        slab = c4d.BaseObject(I.ID_AW_SLAB)
        slab.SetName(next_name(doc, "Ceiling" if kind == CEILING else "Floor"))
        slab[I.AW_SLAB_TYPE] = kind
        slab[I.AW_SLAB_FIT] = FIT_OUTSIDE  # the walls' outer perimeter
        slab[I.AW_SLAB_WALL] = wall
        doc.InsertObject(slab, wall.GetUp(), wall)
        slab.SetMg(c4d.Matrix(wall.GetMg()))
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, slab)
        aw_materials.apply_defaults(doc, slab)
        aw_groups_c4d.file(doc, slab)  # into its group: null and layer (aw_groups_c4d)
        made.append(slab)
    doc.EndUndo()
    doc.SetActiveObject(made[0], c4d.SELECTION_NEW)
    for s in made[1:]:
        doc.SetActiveObject(s, c4d.SELECTION_ADD)
    c4d.EventAdd()
    return made
