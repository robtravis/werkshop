"""Archwerks placing windows and doors on walls, host-neutral: the presets, where the
mouse ray meets a wall's face, how a window of a preset's size fits there between
what is either side of it on that segment, and the preview (an aw_dims layout).

Cinema 4D's AW Place Window (src/aw_place.py) and Blender's place tool
(blender/place.py) both use it, so a click puts a window in the same place in
either. Pure: points are in the wall's own space, the core's axes (cm, +Y up).

A preset is a dict: {"label", "object", "key", "values"}, values being the
opening's settings by aw_window.Style field name plus "width", "height" and "sill"
(cm); anything a preset leaves out takes the parameter table's default.
"""
import aw_cutter as C
import aw_dims
import aw_door as D
import aw_fireplace as F
import aw_ids as I
import aw_params as P
import aw_window as W

IN = 2.54



WINDOW, DOOR, CUTTER, RAILING, CABINET = "window", "door", "cutter", "railing", "cabinet"
FIREPLACE = "fireplace"
OBJECT_IDS = {WINDOW: I.ID_AW_OPENING, DOOR: I.ID_AW_DOOR, CUTTER: I.ID_AW_CUTTER, RAILING: I.ID_AW_RAILING,
              CABINET: I.ID_AW_CABINET, FIREPLACE: I.ID_AW_FIREPLACE}
NAMES = {WINDOW: "Window", DOOR: "Door", CUTTER: "Cutout", RAILING: "Railing",
         CABINET: "Cabinet", FIREPLACE: "Fireplace"}  # placed as Window.<Type>.001, ...


HEAD = 80  # in: where windows' heads line up, as doors' do (6'8"), so a window's sill is HEAD less its height
MIN_SILL = 12  # in: a tall window's sill, its head going up instead


def head_sill(height):
    """A window's sill, cm, for its height (cm): its head at HEAD, its sill no lower than MIN_SILL."""
    return max(HEAD * IN - height, MIN_SILL * IN)


def _preset(label, kind, width, height, sill=None, **values):
    values.update(kind=kind, width=width, height=height, sill=head_sill(height) if sill is None else sill)
    return {"label": label, "object": WINDOW, "key": W.TYPE_KEYS[kind], "values": values}


def _door(label, kind, width, height=80 * IN, **values):
    values.update(kind=kind, width=width, height=height, sill=0.0)
    return {"label": label, "object": DOOR, "key": D.TYPE_KEYS[kind], "values": values}


PRESETS = (  # no handles (a window's Handle setting adds them)
    _preset("Casement", W.CASEMENT, 24 * IN, 48 * IN, leaves_1=1),
    _preset("Casement pair", W.CASEMENT, 48 * IN, 48 * IN, leaves_1=2),
    _preset("Casement triple", W.CASEMENT, 72 * IN, 48 * IN, leaves_1=3),
    _preset("Double-hung", W.DOUBLE_HUNG, 36 * IN, 60 * IN),
    _preset("Fixed", W.FIXED, 48 * IN, 48 * IN),
    _preset("Sliding", W.SLIDING, 60 * IN, 48 * IN, leaves_1=2),
    _preset("Casement + transom", W.CASEMENT, 36 * IN, 72 * IN, rows=2, leaves_1=1, height_1=48 * IN,
            fixed_2=True),
)
DOOR_PRESETS = (
    _door("Interior", D.HINGED, 32 * IN, model=D.PANEL, panels_v=2, handle_type=D.KNOB),
    _door("Exterior", D.HINGED, 36 * IN, leaf_d=4.45, model=D.BEVEL, panels_h=2, panels_v=3, open_side=D.OPEN_INSIDE,
          step=True, sill_on=True, handle_type=D.KNOB),
    _door("French pair", D.HINGED, 60 * IN, leaves=2, model=D.GLASS, panels_h=1, panels_v=5, spacing=2.5,
          border=10.0, handle_type=D.LEVER),
    _door("Barn", D.SLIDING, 36 * IN, model=D.PANEL, panels_v=1, layout=D.FIT, handle_type=D.PULL),
    _door("Pocket", D.POCKET, 30 * IN, layout=D.FIT, handle_side=D.HANDLE_BOTH, handle_type=D.FLUSH),
    _door("Cased opening", D.HINGED, 36 * IN, 84 * IN, shape=D.CASED),
    _door("Garage door", D.GARAGE, 16 * 12 * IN, 84 * IN, model=D.PANEL, panels_h=8, panels_v=4, leaf_d=4.5,
          handle_side=D.HANDLE_NONE, border=7.5, spacing=5.0),  # 16 x 7 ft, short panels
    _door("Single garage door", D.GARAGE, 9 * 12 * IN, 84 * IN, model=D.PANEL, panels_h=4, panels_v=4, leaf_d=4.5,
          handle_side=D.HANDLE_NONE, border=7.5, spacing=5.0),  # 9 x 7 ft
)


def _arch(label, shape, width, height, **values):
    values.update(shape=shape, width=width, height=height, sill=0.0)
    return {"label": label, "object": CUTTER, "key": C.SHAPE_NAMES[shape].replace(" ", ""), "values": values}


CUTTER_PRESETS = (  # shown with the doors
    _arch("Round arch", C.ROUND, 36 * IN, 84 * IN),
    _arch("Segmental arch", C.ROUND, 48 * IN, 84 * IN, radius=48 * IN),
    _arch("Elliptic arch", C.ELLIPTIC, 60 * IN, 84 * IN, rise=12 * IN),
    _arch("Gothic arch", C.POINTED, 36 * IN, 90 * IN, radius=36 * IN),
)


def _hole(label, key, width, height, sill, **values):
    values.update(shape=C.RECTANGLE, width=width, height=height, sill=sill)
    return {"label": label, "object": CUTTER, "key": key, "name": "Hole", "values": values}


HOLE_PRESETS = (  # a plain rectangular hole through the wall, off the floor: a Rectangle Archway with a sill
    _hole("Wall hole", "Wall", 24 * IN, 24 * IN, 36 * IN),
    _hole("Pass-through", "PassThrough", 48 * IN, 30 * IN, 42 * IN),
    _hole("Small hole", "Small", 12 * IN, 12 * IN, 48 * IN),
)


def _fire(label, key, width=36 * IN, height=30 * IN, **values):
    values.update(width=width, height=height, sill=0.0)
    return {"label": label, "object": FIREPLACE, "key": key, "values": values}


FIREPLACE_PRESETS = (  # placed on the face you click, facing you
    _fire("Fireplace", "Rounded"),
    _fire("Fireplace with doors", "Doors", doors=F.PAIR, screen=True),
    _fire("Fireplace with facing", "Facing", facing=True, screen=True, screen_open=1.0, radius=30.48),
    _fire("Arched fireplace", "Arched", shape=F.ROUND, radius=0.0, height=32 * IN),
    _fire("Firebox only", "Plain", shape=F.RECTANGLE, surround=False, mantel=False),
)


def placed_name(p):
    """What a placed preset is named after: Window, Door, Cutout, or the preset's own (Hole)."""
    return p.get("name") or NAMES[p.get("object", WINDOW)]


SIZE_PARAMS = (("width", I.AW_OPENING_WIDTH), ("height", I.AW_OPENING_HEIGHT), ("sill", I.AW_OPENING_SILL))
PRESET_PARAMS = SIZE_PARAMS + tuple(I.AW_OPENING_STYLE_PARAMS)  # a window's
DOOR_PARAMS = SIZE_PARAMS + tuple(I.AW_DOOR_STYLE_PARAMS)
CUTTER_PARAMS = SIZE_PARAMS + tuple(I.AW_CUTTER_STYLE_PARAMS)
FIREPLACE_PARAMS = SIZE_PARAMS + tuple(I.AW_FP_STYLE_PARAMS)

FIT = 0.5      # cm a placed window keeps from anything either side of it


def size(p):
    """(width, height, sill) of a preset, cm."""
    v, oid = p["values"], OBJECT_IDS[p.get("object", WINDOW)]
    return tuple(v.get(name, P.default(oid, pid)) for name, pid in SIZE_PARAMS)


def hit(plan, w0, w1, height, la, lv):
    """(distance along the ray, segment, u along it, height, face offset) where the ray from la along
    lv (both in the wall's space) first meets one of the wall's faces (Exterior or
    Interior), within a segment and below its top, or its top seen from above (a plan
    view looks straight down, never at a face): what is being pointed at, as seen;
    None if it misses. The face offset is w0 or w1 (None for the top)."""
    best = None
    if abs(lv[1]) > 1e-9:  # the top, at the wall's Height
        for k, seg in enumerate(plan.segments):
            (ax, az), (dx, dz), (nx, nz) = seg["a"], seg["d"], seg["n"]
            top = plan.top(k, seg["length"] / 2, height)
            t = (top - la[1]) / lv[1]
            if t <= 0:
                continue
            px, pz = la[0] + lv[0] * t, la[2] + lv[2] * t
            u = (px - ax) * dx + (pz - az) * dz
            w = (px - ax) * nx + (pz - az) * nz
            if -1 <= u <= seg["length"] + 1 and w0 - 1 <= w <= w1 + 1 and (best is None or t < best[0]):
                best = (t, k, u, top, None)
    for k, seg in enumerate(plan.segments):
        (ax, az), (dx, dz), (nx, nz) = seg["a"], seg["d"], seg["n"]
        den = lv[0] * nx + lv[2] * nz  # the ray against the segment's two faces (vertical planes)
        if abs(den) < 1e-9:
            continue
        for w in (w0, w1):
            t = ((ax + nx * w - la[0]) * nx + (az + nz * w - la[2]) * nz) / den
            if t <= 0:
                continue
            px, py, pz = la[0] + lv[0] * t, la[1] + lv[1] * t, la[2] + lv[2] * t
            u = (px - ax) * dx + (pz - az) * dz
            if -1 <= u <= seg["length"] + 1 and 0 <= py <= plan.top(k, u, height) + 1:
                if best is None or t < best[0]:
                    best = (t, k, u, py, w)
    return best


def side_for(h):
    """For a fireplace placed from fit() h: Outside (aw_fireplace) when the face pointed at
    is the wall's Outside one, else Inside, so it faces whoever placed it."""
    face, plan = h.get("face"), h["plan"]
    if face is None:
        return F.INSIDE
    outside = h["w0"] if plan.outside_is_w0() else h["w1"]
    return F.OUTSIDE if abs(face - outside) < 1e-6 else F.INSIDE


def fit(plan, w0, w1, height, k, u, rects, p, centre=False, face=None):
    """Where preset p's window goes on segment k with the mouse at u along it: {k, u, u0,
    u1, left, right, sill, head, ok, w_out}. rects: the openings already on that segment
    [(u0, u1, y0, y1)]. Shift (centre) centres it on the segment's clear span; a window
    that doesn't quite fit where pointed slides to fit between its neighbours; ok is
    False when it fits nowhere there (or would overlap one)."""
    width, wheight, sill = size(p)
    c0, c1 = plan.clear_span(k, w0, w1)
    if centre:
        u = (c0 + c1) / 2
    u0, u1 = u - width / 2, u + width / 2
    left = max([c0] + [r[1] for r in rects if r[1] <= u + 1e-6])
    right = min([c1] + [r[0] for r in rects if r[0] >= u - 1e-6])
    overlaps = any(r[0] < u1 - 1e-6 and r[1] > u0 + 1e-6 for r in rects)
    top = min(plan.top(k, u0, height), plan.top(k, u1, height))
    ok = (u0 >= left + FIT - 1e-6 and u1 <= right - FIT + 1e-6 and not overlaps and sill + wheight <= top - FIT)
    if not ok and not overlaps and width <= (right - left) - 2 * FIT:  # slide it to fit between its neighbours
        u = min(max(u, left + FIT + width / 2), right - FIT - width / 2)
        u0, u1 = u - width / 2, u + width / 2
        ok = sill + wheight <= min(plan.top(k, u0, height), plan.top(k, u1, height)) - FIT
    return {"k": k, "u": u, "u0": u0, "u1": u1, "left": left, "right": right,
            "sill": sill, "head": sill + wheight, "ok": ok, "w_out": w0, "plan": plan, "face": face, "w0": w0, "w1": w1, "preset": p}


def _at(plan, k, u, w, y=0.0):
    seg = plan.segments[k]
    return (seg["a"][0] + seg["d"][0] * u + seg["n"][0] * w, y, seg["a"][1] + seg["d"][1] * u + seg["n"][1] * w)


def preview_layout(h):
    """The preview of fit() h as an aw_dims layout in the wall's space: the window's
    outline on its Exterior face (grey where it can't go) and the distances either side."""
    if h is None:
        return None
    plan, k = h["plan"], h["k"]
    face = h["w_out"] - aw_dims.FRONT
    if h.get("face") is not None and p_object(h) == FIREPLACE:  # a fireplace: on the face it goes on
        face = h["face"] + (aw_dims.FRONT if h["face"] > (h["w0"] + h["w1"]) / 2 else -aw_dims.FRONT)
    corners = [_at(plan, k, h["u0"], face, h["sill"]), _at(plan, k, h["u1"], face, h["sill"]),
               _at(plan, k, h["u1"], face, h["head"]), _at(plan, k, h["u0"], face, h["head"])]
    dims = []
    if h["ok"]:
        line = h["w_out"] - aw_dims.CHAIN_OUT
        n = plan.segments[k]["n"]
        out = (-n[0], 0.0, -n[1])  # the Exterior side, where the labels go
        for a, b in ((h["left"], h["u0"]), (h["u1"], h["right"])):
            if b - a > 0.05:
                dims.append({"kind": "gap", "role": "focus", "axis": "x", "value": b - a,
                             "a": _at(plan, k, a, line), "b": _at(plan, k, b, line), "out": out})
        dims.append({"kind": "width", "role": "focus", "axis": "x", "value": h["u1"] - h["u0"],
                     "a": _at(plan, k, h["u0"], line), "b": _at(plan, k, h["u1"], line), "out": out})
    return {"dims": dims, "ext": [], "outline": corners, "grips": False, "outline_role": "focus" if h["ok"] else "dim"}


def p_object(h):
    return (h.get("preset") or {}).get("object", WINDOW)


def placed_at(h):
    """Where a window placed from fit() h sits in its wall's space: its axis on the path line
    at the middle of its span (Start Offset then -width/2), and that settings' values."""
    x, _y, z = _at(h["plan"], h["k"], (h["u0"] + h["u1"]) / 2, 0.0)
    return (x, 0.0, z)
