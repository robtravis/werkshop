"""aw_openings for Cinema 4D: the parts of core/aw_openings.py that need the application
(its objects, undo, change tracking), kept apart so the core stays host-neutral."""
import c4d  # noqa: F401

import aw_openings  # noqa: F401
import aw_wall_c4d
from aw_openings import *  # noqa: F401,F403


def wall_layout(wall, path_info):
    """What a Wall draws now: a selected child opening in focus, else the wall's own
    dimensions while it or a child is selected, else nothing."""
    for child in wall.GetChildren():
        if child.GetBit(c4d.BIT_ACTIVE) and not child.GetInfo() & c4d.OBJECT_ISSPLINE:
            lay = focus_layout(child)
            if lay:
                return lay
    if wall.GetBit(c4d.BIT_ACTIVE) or any(k.GetBit(c4d.BIT_ACTIVE) for k in wall.GetChildren()):
        layout = D.path_layout(*path_info)
        if int(wall[I.AW_WALL_OVERRIDES] or 0) > 0:  # numbered, to pick Segment Overrides by
            layout["dims"] = layout["dims"] + D.segment_labels(path_info[0], path_info[3])
        return layout
    return None


def topmost(bd, doc, x, y):
    """The objects at (x, y), front-most first: C4D's plain pick lists everything within
    its radius in no order, so a Wall behind a cabinet could come first and be selected."""
    vs = c4d.utils.ViewportSelect
    top = vs.PickObject(bd, doc, int(x), int(y), 4,
                        c4d.VIEWPORT_PICK_FLAGS_ALLOW_OGL | c4d.VIEWPORT_PICK_FLAGS_OGL_ONLY_TOPMOST)
    return list(top or []) or list(vs.PickObject(bd, doc, int(x), int(y), 4, c4d.VIEWPORT_PICK_FLAGS_NONE) or [])


def pick(bd, doc, x, y):
    """What a click at (x, y) in AW Edit Dimensions selects: a window when the click
    lands on one, its hole or anything it shows past it (casing, sills), on a
    wall's face (C4D's own picking only ever finds the Wall, since its windows live
    inside it), otherwise whatever C4D picks."""
    import aw_place
    picked = topmost(bd, doc, x, y)
    walls = [o for o in (picked or []) if o.GetType() == I.ID_AW_WALL] or (aw_place._walls(doc) if not picked else [])
    best = None
    for wall in walls:
        h = aw_place._hit(bd, wall, x, y)
        if h is None:
            continue
        t, k, u, hy = h[:4]
        wp = aw_wall_c4d.wall_path(wall)
        for child in wall.GetChildren():
            if child.GetInfo() & c4d.OBJECT_ISSPLINE or not child.GetDeformMode():
                continue
            for ck, u0, u1, y0, y1, _uc in aw_wall_c4d.path_openings(child, wp[0], wp[3]):  # a row: any of it
                if ck != k:
                    continue
                u0, u1, y0, y1 = reach(child, wp[0], k, u0, u1, y0, y1)
                if u0 <= u <= u1 and y0 <= hy <= y1 and (best is None or t < best[0]):
                    best = (t, child)
    if best is not None:
        return best[1]
    return picked[0] if picked else None


def grips(op):
    """aw_openings.grip_points as c4d.Vectors (they change only the opening's own size and
    place, so they work in any tool, C4D's Move included)."""
    f = place_of(op)
    if f is None or not aw_wall_c4d.grips_allowed(op):
        return []
    v = lambda p: c4d.Vector(p.x, p.y, p.z)  # noqa: E731
    return [(v(p), v(d)) for p, d in grip_points(op)]

