"""Archwerks parameters: every object's settings, the one table every host reads.

SPECS lists each object's parameters in panel order: a ("group", id, name) row
starts a tab (OBJECT is the object's own Object tab), a ("sub", id, name[, show])
row a section inside it, "sep" draws a line, and every other row is one parameter
(see the helpers below): its id, type, name, default, range and unit, the choices
of a cycle, what a link accepts, and the tests that grey it out (when) or leave it
out (show), plain functions of the object. A host draws its panel from this
(Cinema 4D's Attribute Manager: aw_desc; Blender's: the add-on) and gives new
objects the defaults; an object saved before a parameter existed has no value for
it, so code reads settings through aw_host.value, which falls back on default().

Parameter ids never change once used: scenes store values by id.
"""
import aw_host
import aw_ids as I

OBJECT = "object"         # the group id of an object's own Object tab (each host has its own)
MATERIAL, ANY_OBJECT = "material", "object"  # what a link accepts, besides an aw_ids object type
METER, PERCENT, DEGREE = "m", "%", "deg"
BIG = 1.0e20


def real(pid, name, default, unit=METER, lo=-BIG, hi=BIG, step=1.0, slider=False):
    return {"id": pid, "type": "real", "name": name, "default": default, "unit": unit, "min": lo, "max": hi,
            "step": step, "slider": slider}


def degrees(pid, name, default_degrees, hi_degrees=180.0):
    """An angle: degrees in the Attribute Manager, radians in the data."""
    import math
    return real(pid, name, math.radians(default_degrees), DEGREE, 0.0, math.radians(hi_degrees), math.radians(1.0))


def percent(pid, name, default):
    """0 to 100% in the Attribute Manager, 0 to 1 in the data (a slider)."""
    return real(pid, name, default, PERCENT, 0.0, 1.0, 0.01, True)


def integer(pid, name, default, lo=None, hi=None):
    return {"id": pid, "type": "int", "name": name, "default": default, "min": lo, "max": hi}


# Settings whose default has changed, by kind: {pid: what it was}. A host that keeps only
# the settings someone set (Blender) pins these on an object made before, so it doesn't
# change when its file opens, and writes them on a new one. Roofs have Dimensional
# Shingle tiles from 0.56; before, none (and Plain Tile's sizes). A standalone roof's
# eaves are on the plane it's drawn on from 0.56; before, 270 cm above it.
PREDATES = {}


def cycle(pid, name, default, options):
    """options: labels, (value, label) pairs, or a function giving them (a list that
    changes, read each time the Attribute Manager asks)."""
    return {"id": pid, "type": "int", "name": name, "default": default,
            "cycle": options if callable(options) else tuple(options)}


def boolean(pid, name, default):
    return {"id": pid, "type": "bool", "name": name, "default": default}


def link(pid, name, accept=(MATERIAL,)):
    return {"id": pid, "type": "link", "name": name, "default": None, "accept": tuple(accept)}


def object_list(pid, name):
    """A list of objects (an In/Exclude list): drag them in."""
    return {"id": pid, "type": "list", "name": name, "default": None}


def when(row, test):
    """row, greyed out in the Attribute Manager unless test(object) is true."""
    row["enable"] = test
    return row


def _type(op):
    return value(op, I.AW_OPENING_TYPE)


def _own_build(op):
    return value(op, I.AW_OPENING_BUILD_WITH) == I.AW_BUILD_OWN


def opening_build():
    """A window's or door's Animation group: with its wall's build-on, or its own."""
    return [
        ("group", 1390, "Animation"),  # the build-on: "Build" is Create's tab
        cycle(I.AW_OPENING_BUILD_WITH, "Build With", I.AW_BUILD_WITH_WALL, ("Wall", "Own")),
        when(percent(I.AW_OPENING_BUILD, "Build", 1.0), _own_build),
        when(cycle(I.AW_OPENING_BUILD_STYLE, "Style", I.AW_BUILD_PARTS,
                   ("Parts in Order", "Drop In", "Rise", "Slide In", "Scale Up")), _own_build),
        when(percent(I.AW_OPENING_BUILD_STAGGER, "Stagger", 0.5),
             lambda op: _own_build(op) and value(op, I.AW_OPENING_BUILD_STYLE) == I.AW_BUILD_PARTS),
        when(percent(I.AW_OPENING_BUILD_SEQUENCE, "Sequence", 0.5), _own_build),
    ]


def opening_light(default):
    """A window's or door's Light group: a portal in its opening, for interiors lit from outside."""
    return [("group", 1396, "Light"), boolean(I.AW_OPENING_PORTAL, "Light Portal", default)]


def _on(pid):
    return lambda op: bool(value(op, pid))


def _handle_names(window=False):
    """The handle types as (value, label) pairs: aw_handles' numbering, a window's few."""
    import aw_handles as H
    kinds = H.WINDOW_TYPES if window else range(len(H.NAMES))
    return tuple((k, H.NAMES[k]) for k in kinds)


def _door(op):
    return value(op, I.AW_DOOR_TYPE)


def _framed(op):
    return bool(value(op, I.AW_DOOR_FRAME))


def _cased(op):
    """A cased opening: a frame and no leaf."""
    return _framed(op) and value(op, I.AW_DOOR_SHAPE) == 2


def _stopped(op):
    return _framed(op) and _door(op) == 0 and not _cased(op)


def _panelled(op):
    return not _cased(op) and (value(op, I.AW_DOOR_MODEL) != 0 or _garage(op))  # a garage door's sections: always


def _garage(op):
    """A sectional overhead garage door: no hinge, leaves or handle."""
    return _door(op) == 3


def _handled(op):
    return not _cased(op) and not _garage(op) and value(op, I.AW_DOOR_HANDLE_SIDE) != 0


def _pull_names():
    import aw_pulls
    return aw_pulls.NAMES


def _library_names():
    import aw_pulls
    return aw_pulls.library_names()


def _pull_on(pid):
    return lambda op: value(op, pid) != 0


def _pull_is(pid, kind):
    return lambda op: value(op, pid) == kind


def _pull_sized(pid):
    return lambda op: value(op, pid) not in (0, 10, 11)


def _zone_shown(i):
    return lambda op: i < value(op, I.AW_CAB_ZONES)


def sink_rows(off):
    """A sink's settings, their ids moved by off: 0 on a Sink, I.CT_SINK on a countertop's
    Sinks tab, which sets every sink under it (aw_counter.CT_SINK_PIDS)."""
    return [
        cycle(I.AW_SINK_MOUNT + off, "Mount", 0, ("Undermount", "Drop-in", "Vessel", "Apron", "Cooktop")),
        cycle(I.AW_SINK_SHAPE + off, "Shape", 1, ("Rectangle", "Rounded", "Oval", "Round")),
        real(I.AW_SINK_WIDTH + off, "Width", 76.2, lo=2.0),
        when(real(I.AW_SINK_LENGTH + off, "Length", 45.72, lo=2.0), lambda op: value(op, I.AW_SINK_SHAPE + off) != 3),
        when(real(I.AW_SINK_RADIUS + off, "Radius", 2.54, lo=0.0), lambda op: value(op, I.AW_SINK_SHAPE + off) == 1),
        when(real(I.AW_SINK_DEPTH + off, "Bowl Depth", 22.86, lo=1.0),
             lambda op: value(op, I.AW_SINK_MOUNT + off) != 4),
        when(real(I.AW_SINK_WALL + off, "Wall", 0.6, lo=0.2), lambda op: value(op, I.AW_SINK_MOUNT + off) != 4),
        when(real(I.AW_SINK_RIM + off, "Rim", 2.54, lo=0.5), lambda op: value(op, I.AW_SINK_MOUNT + off) == 1),
    ]


def has_sinks(op):
    """Whether a countertop has a sink under it (its Sinks tab shows only then)."""
    import aw_host
    return any(aw_host.type_id(c) == I.ID_AW_SINK for c in aw_host.children(op))


def _zone_is(i, kinds):
    return lambda op: value(op, I.cab_zone(i, 0)) in kinds


def _linked(op, pid):
    return aw_host.alive(aw_host.link(op, pid))


def _roof_wall(op):
    return not _linked(op, I.AW_ROOF_DRAFT) and _linked(op, I.AW_ROOF_WALL)


def _roof_not_draft(op):
    return not _linked(op, I.AW_ROOF_DRAFT)


def _roof_own(op):
    """A standalone roof: shaped by its own splines (Elevation and the axis settings apply)."""
    return not _linked(op, I.AW_ROOF_DRAFT) and not _linked(op, I.AW_ROOF_WALL)


def _roof_edge_shown(i):
    def shown(op):
        import aw_roof
        return i < aw_roof.edge_count(op)
    return shown


def _in_hole(op):
    return not value(op, I.AW_OPENING_MOUNT)


def _rows_used(op):
    """How many Leaves tab rows apply: a double-hung always has two sashes."""
    return 2 if _type(op) == 0 else max(1, min(I.MAX_ROWS, int(value(op, I.AW_OPENING_ROWS) or 1)))


def _row_rows(r):
    """Row r's section (0-based) of the Leaves tab, shown only while it is used. On a
    double-hung the two rows are its Lower and Upper Sash, and only the lower one's
    Leaves (units side by side), Height, Fixed and Handle apply."""
    def shown(op):
        return r < _rows_used(op)

    def title(op):
        return ("Lower Sash", "Upper Sash")[r] if _type(op) == 0 and r < 2 else "Row %d" % (r + 1)

    def own(op):  # a setting of this row that applies on this type
        return _type(op) != 0 or r == 0
    return [("sub", 1360 + r, title, shown),
            show(when(integer(I.row_param(r, "leaves"), "Leaves", 1, 1, 6), own), shown),
            show(when(real(I.row_param(r, "height"), "Height", 0.0, lo=0.0),
                      lambda op: r < _rows_used(op) - 1), shown),
            show(when(boolean(I.row_param(r, "fixed"), "Fixed", False), lambda op: _type(op) != 2 and own(op)), shown),
            show(when(cycle(I.row_param(r, "handle"), "Handle", I.HANDLE_AUTO,
                            ("None", "Inside", "Outside", "Both", "As the Window")),
                      lambda op: _type(op) != 2 and own(op)), shown)]


def show(row, test):
    """row, left out of the Attribute Manager unless test(object) is true."""
    row["show"] = test
    return row


def materials(gid, slots):
    """A Materials tab with one material link per slot."""
    return [("group", gid, "Materials")] + [link(pid, name) for name, pid in slots]


def _override_shown(i):
    return lambda op: i < value(op, I.AW_WALL_OVERRIDES)


def _overrides():
    """A wall's Segment Overrides tab: how many, then each row's segment, face and material
    (its material link names the group its faces go to, "Override n": aw_wall.overrides)."""
    rows = [("group", 1450, "Segment Overrides"),
            integer(I.AW_WALL_OVERRIDES, "Overrides", 0, 0, I.MAX_OVERRIDES)]
    for i in range(I.MAX_OVERRIDES):
        shown = _override_shown(i)
        mat = show(link(I.wall_override(i, 2), "Material"), shown)
        mat["group"] = "Override %d" % (i + 1)
        rows += [("sub", 1460 + i, "Override %d" % (i + 1), shown),
                 show(integer(I.wall_override(i, 0), "Segment", 1, 1, 999), shown),
                 show(cycle(I.wall_override(i, 1), "Face", I.OVERRIDE_INTERIOR, ("Interior", "Exterior", "Both")), shown),
                 mat]
    return rows


def material_slots(kind):
    """[(group, parameter id)] of an object's material links: a link names its group, unless
    it says otherwise (a wall's override rows, "Override n")."""
    return [(p.get("group", p["name"]), p["id"]) for p in params(kind)
            if p["type"] == "link" and MATERIAL in p["accept"]]


SPECS = {
    I.ID_AW_WALL: [
        ("group", OBJECT, None),
        real(I.AW_WALL_HEIGHT, "Height", 270.0, lo=0.1),
        real(I.AW_WALL_THICKNESS, "Thickness", 20.0, lo=0.1),
        cycle(I.AW_WALL_ALIGN, "Align", I.AW_ALIGN_CENTER, ("Center", "Inside", "Outside")),
        "sep",
        boolean(I.AW_WALL_DIMS, "Show Dimensions", True),
        ("group", 1100, "Animation"),  # the build-on: "Build" is Create's tab
        percent(I.AW_WALL_BUILD, "Build", 1.0),
        cycle(I.AW_WALL_BUILD_STYLE, "Style", I.AW_BUILD_RISE, ("Rise", "Trace")),
        cycle(I.AW_WALL_BUILD_ORDER, "Order", I.AW_ORDER_TOGETHER, ("All Together", "Run by Run", "Segment by Segment")),
        percent(I.AW_WALL_BUILD_STAGGER, "Stagger", 0.5),
    ] + materials(1200, I.AW_WALL_MATERIAL_SLOTS) + _overrides(),
    I.ID_AW_OPENING: [
        ("group", OBJECT, None),
        cycle(I.AW_OPENING_TYPE, "Type", 0, ("Double-Hung", "Casement", "Fixed", "Sliding")),
        "sep",
        real(I.AW_OPENING_WIDTH, "Width", 120.0, lo=0.1),
        real(I.AW_OPENING_HEIGHT, "Height", 140.0, lo=0.1),
        real(I.AW_OPENING_SILL, "Sill Height", 63.2),  # its head at a door's, 6'8" (aw_placing.HEAD)
        "sep",
        real(I.AW_OPENING_START, "Start Offset", -60.0),
        integer(I.AW_OPENING_COUNT, "Count", 1, lo=1, hi=20),  # a row of windows, Spacing apart
        when(real(I.AW_OPENING_SPACING, "Spacing", 30.48, lo=0.0), lambda op: (value(op, I.AW_OPENING_COUNT) or 1) > 1),
        "sep",
        when(cycle(I.AW_OPENING_POSITION, "Align", 1, ("Outside", "Center", "Inside")), _in_hole),
        when(real(I.AW_OPENING_OFFSET, "Offset", 0.0), _in_hole),
        cycle(I.AW_OPENING_MOUNT, "Mount", 0, ("In the Hole", "Exterior", "Interior")),
        when(real(I.AW_OPENING_OVERFLOW, "Overflow", 6.0, lo=0.0), lambda op: not _in_hole(op)),
        ("group", 1340, "Leaves"),
        when(integer(I.AW_OPENING_ROWS, "Rows", 1, 1, I.MAX_ROWS), lambda op: _type(op) != 0),
        when(percent(I.AW_OPENING_OPEN, "Open", 0.0), lambda op: _type(op) != 2),
        when(cycle(I.AW_OPENING_SWING, "Swing", 0, ("Outside", "Inside")), lambda op: _type(op) == 1),
        when(cycle(I.AW_OPENING_HINGE, "Hinge", 0, ("Left", "Right")), lambda op: _type(op) == 1),
    ] + [row for r in range(I.MAX_ROWS) for row in _row_rows(r)] + [
        ("group", 1350, "Parts"),
        ("sub", 1300, "Window Frame"),
        real(I.AW_OPENING_FRAME_W, "Width", 6.0, lo=0.1),
        real(I.AW_OPENING_FRAME_D, "Depth", 10.0, lo=0.1),
        ("sub", 1301, "Panel Frame"),
        when(real(I.AW_OPENING_SASH_W, "Width", 5.0, lo=0.1), lambda op: _type(op) != 2),
        when(real(I.AW_OPENING_SASH_D, "Depth", 3.5, lo=0.1), lambda op: _type(op) != 2),
        ("sub", 1302, "Frame Out"),
        boolean(I.AW_OPENING_FRAME_OUT, "Frame Out", False),
        when(real(I.AW_OPENING_FRAME_OUT_W, "Width", 10.0, lo=0.1), _on(I.AW_OPENING_FRAME_OUT)),
        when(real(I.AW_OPENING_FRAME_OUT_D, "Depth", 2.0, lo=0.1), _on(I.AW_OPENING_FRAME_OUT)),
        when(real(I.AW_OPENING_FRAME_OUT_OFFSET, "Offset", 0.0, lo=0.0), _on(I.AW_OPENING_FRAME_OUT)),
        when(boolean(I.AW_OPENING_FRAME_OUT_CLOSE, "Close Bottom", False), _on(I.AW_OPENING_FRAME_OUT)),
        ("sub", 1310, "Sill Out"),
        boolean(I.AW_OPENING_SILL_ON, "Sill Out", True),
        when(real(I.AW_OPENING_SILL_OUT, "Depth", 4.0, lo=0.0), _on(I.AW_OPENING_SILL_ON)),
        when(real(I.AW_OPENING_SILL_SIDE, "Overhang", 5.0, lo=0.0), _on(I.AW_OPENING_SILL_ON)),
        when(real(I.AW_OPENING_SILL_H, "Thickness", 4.0, lo=0.1), _on(I.AW_OPENING_SILL_ON)),
        when(real(I.AW_OPENING_SILL_ALT, "Altitude", 0.0), _on(I.AW_OPENING_SILL_ON)),
        ("sub", 1311, "Sill In"),
        boolean(I.AW_OPENING_SILL_IN, "Sill In", False),
        when(real(I.AW_OPENING_SILL_IN_D, "Depth", 2.54, lo=0.0), _on(I.AW_OPENING_SILL_IN)),     # 1 in past the casing
        when(real(I.AW_OPENING_SILL_IN_SIDE, "Overhang", 2.54, lo=0.0), _on(I.AW_OPENING_SILL_IN)),  # 1 in horns
        when(real(I.AW_OPENING_SILL_IN_H, "Thickness", 2.54, lo=0.1), _on(I.AW_OPENING_SILL_IN)),
        when(real(I.AW_OPENING_SILL_IN_ALT, "Altitude", 0.0), _on(I.AW_OPENING_SILL_IN)),
        ("sub", 1330, "Frame In"),
        boolean(I.AW_OPENING_TRIM, "Frame In", False),
        when(real(I.AW_OPENING_TRIM_W, "Width", 7.0, lo=0.1), _on(I.AW_OPENING_TRIM)),
        when(real(I.AW_OPENING_TRIM_D, "Depth", 2.0, lo=0.1), _on(I.AW_OPENING_TRIM)),
        ("sub", 1320, "Muntins"),
        boolean(I.AW_OPENING_MUNTINS, "Muntins", False),
        when(integer(I.AW_OPENING_MUNTIN_COLS, "Columns", 2, 1, 12), _on(I.AW_OPENING_MUNTINS)),
        when(integer(I.AW_OPENING_MUNTIN_ROWS, "Rows", 2, 1, 12), _on(I.AW_OPENING_MUNTINS)),
        when(real(I.AW_OPENING_MUNTIN_W, "Bar Width", 2.0, lo=0.1), _on(I.AW_OPENING_MUNTINS)),
        ("sub", 1331, "Shutters"),
        boolean(I.AW_OPENING_SHUTTERS, "Shutters", False),
        when(percent(I.AW_OPENING_SHUTTER_OPEN, "Open", 0.7), _on(I.AW_OPENING_SHUTTERS)),
        when(integer(I.AW_OPENING_SHUTTER_LEAVES, "Leaves", 1, 1, 2), _on(I.AW_OPENING_SHUTTERS)),
        when(real(I.AW_OPENING_LOUVER_W, "Louver Width", 8.89, lo=2.0), _on(I.AW_OPENING_SHUTTERS)),
        when(percent(I.AW_OPENING_LOUVER_TILT, "Louver Tilt", 0.0), _on(I.AW_OPENING_SHUTTERS)),
        when(boolean(I.AW_OPENING_SHUTTER_DIVIDER, "Divider Rail", False), _on(I.AW_OPENING_SHUTTERS)),
        ("sub", 1333, "Blinds"),
        cycle(I.AW_OPENING_BLINDS, "Blinds", 0, ("None", "Roman Shade", "Roller Blind")),
        when(percent(I.AW_OPENING_BLIND_OPEN, "Open", 0.4), _on(I.AW_OPENING_BLINDS)),
        when(cycle(I.AW_OPENING_BLIND_MOUNT, "Mount", 0, ("Inside", "Outside")), _on(I.AW_OPENING_BLINDS)),
        when(real(I.AW_OPENING_BLIND_FOLD, "Fold Spacing", 20.32, lo=4.0),
             lambda op: value(op, I.AW_OPENING_BLINDS) == 1),
        ("sub", 1332, "Drapes"),
        cycle(I.AW_OPENING_DRAPES, "Drapes", 0, ("None", "Default", "Custom")),
        when(link(I.AW_OPENING_DRAPE_OBJ, "Drape Object", (ANY_OBJECT,)),
             lambda op: value(op, I.AW_OPENING_DRAPES) == I.DRAPES_CUSTOM),
        when(real(I.AW_OPENING_DRAPE_ROD, "Rod Height", 15.24), _on(I.AW_OPENING_DRAPES)),
        when(real(I.AW_OPENING_DRAPE_EXTEND, "Extend", 25.4), _on(I.AW_OPENING_DRAPES)),
        when(real(I.AW_OPENING_DRAPE_DROP, "Drop", 0.0), _on(I.AW_OPENING_DRAPES)),
        when(real(I.AW_OPENING_DRAPE_OFFSET, "Offset", 0.0, lo=0.0), _on(I.AW_OPENING_DRAPES)),
        when(percent(I.AW_OPENING_DRAPE_OPEN, "Open", 0.0), _on(I.AW_OPENING_DRAPES)),
        ("sub", 1303, "Handles"),
        when(cycle(I.AW_OPENING_HANDLE, "Side", 0, ("None", "Inside", "Outside", "Both")),
             lambda op: _type(op) != 2),
        when(cycle(I.AW_OPENING_HANDLE_TYPE, "Type", 0, _handle_names(window=True)),
             lambda op: _type(op) != 2 and value(op, I.AW_OPENING_HANDLE) != 0),
        when(real(I.AW_OPENING_HANDLE_ALT, "Altitude", 0.0, lo=0.0),
             lambda op: _type(op) != 2 and value(op, I.AW_OPENING_HANDLE) != 0),
        when(link(I.AW_OPENING_HANDLE_CUSTOM, "Custom", (ANY_OBJECT,)),
             lambda op: _type(op) != 2 and value(op, I.AW_OPENING_HANDLE_TYPE) == 6),
    ] + opening_light(True) + opening_build() + materials(1100, I.AW_OPENING_MATERIAL_SLOTS),
    I.ID_AW_DOOR: [
        ("group", OBJECT, None),
        cycle(I.AW_DOOR_TYPE, "Type", 0, ("Hinged", "Sliding", "Pocket", "Garage")),
        cycle(I.AW_DOOR_OPEN_SIDE, "Open", 0, ("Inside", "Outside")),
        when(cycle(I.AW_DOOR_HINGE, "Hinge", 0, ("Left", "Right")), lambda op: not _cased(op) and not _garage(op)),
        when(integer(I.AW_DOOR_LEAVES, "Door Leaf", 1, 1, 2), lambda op: not _cased(op) and not _garage(op)),
        "sep",
        real(I.AW_OPENING_WIDTH, "Width", 91.44, lo=0.1),
        real(I.AW_OPENING_HEIGHT, "Height", 203.2, lo=0.1),
        real(I.AW_OPENING_SILL, "Sill Height", 0.0),
        "sep",
        real(I.AW_OPENING_START, "Start Offset", -45.72),
        "sep",
        when(percent(I.AW_DOOR_OPEN, "Open", 0.0), lambda op: not _cased(op)),
        when(degrees(I.AW_DOOR_MAX_ANGLE, "Max Angle", 90.0), lambda op: _door(op) == 0 and not _cased(op)),
        ("sub", 1300, "Frame"),
        boolean(I.AW_DOOR_FRAME, "Frame", True),
        when(cycle(I.AW_DOOR_SHAPE, "Shape", 0, ("Single Rabbet", "Double Rabbet", "Cased Opening")), _framed),
        when(cycle(I.AW_DOOR_LAYOUT, "Layout", 0, ("Encompass", "Fit", "Inside", "In Front")), _framed),
        when(real(I.AW_DOOR_JAMB, "Jamb", 1.9, lo=0.1), _framed),
        when(real(I.AW_DOOR_STOP, "Stop", 1.3, lo=0.05), _stopped),
        when(real(I.AW_DOOR_STOP_W, "Stop Width", 3.8, lo=0.1), _stopped),
        when(real(I.AW_DOOR_RABBET, "Rabbet", 0.0, lo=0.0), lambda op: _door(op) == 0 and not _cased(op)),
        when(real(I.AW_DOOR_FACE, "Face", 5.715, lo=0.1), lambda op: _framed(op) and value(op, I.AW_DOOR_LAYOUT) in (0, 3)),
        when(real(I.AW_DOOR_BACKBEND, "Backbend", 1.905, lo=0.05),
             lambda op: _framed(op) and value(op, I.AW_DOOR_LAYOUT) in (0, 3)),
        when(real(I.AW_DOOR_JAMB_DEPTH, "Jamb Depth", 10.0, lo=0.1),
             lambda op: _framed(op) and value(op, I.AW_DOOR_LAYOUT) == 2),
        ("group", 1350, "Parts"),
        ("sub", 1310, "Door"),
        when(real(I.AW_DOOR_LEAF_D, "Depth", 3.5, lo=0.5), lambda op: not _cased(op)),
        when(cycle(I.AW_DOOR_MODEL, "Panels", 0, ("Flat", "Panel", "Bevel", "Glass", "Half Lite")), lambda op: not _cased(op)),
        when(cycle(I.AW_DOOR_DISTRIB, "Distribution", 0, ("Regular", "1/3 2/3", "Colonial")),
             lambda op: _panelled(op) and not _garage(op) and value(op, I.AW_DOOR_PANELS_V) >= 2),
        when(integer(I.AW_DOOR_PANELS_H, "# h", 1, 1, 12), _panelled),  # a garage door's: panels across a section
        when(integer(I.AW_DOOR_PANELS_V, "# v", 2, 1, 10), _panelled),  # and its sections
        when(real(I.AW_DOOR_PANEL_BOTTOM, "Bottom", 0.0, lo=0.0), lambda op: _panelled(op) and not _garage(op)),
        when(real(I.AW_DOOR_SPACING, "Spacing", 10.0, lo=0.5), _panelled),
        when(real(I.AW_DOOR_BORDER, "Border", 12.0, lo=1.0), _panelled),
        when(real(I.AW_DOOR_BEVEL, "Bevel", 0.5, lo=0.05), lambda op: _panelled(op) and value(op, I.AW_DOOR_MODEL) in (1, 2, 4)),
        ("sub", 1311, "Handle"),
        when(cycle(I.AW_DOOR_HANDLE_SIDE, "Side", 3, ("None", "Inside", "Outside", "Both")),
             lambda op: not _cased(op) and not _garage(op)),
        when(cycle(I.AW_DOOR_HANDLE_TYPE, "Type", 0, _handle_names()), _handled),
        when(link(I.AW_DOOR_HANDLE_CUSTOM, "Custom", (ANY_OBJECT,)),
             lambda op: _handled(op) and value(op, I.AW_DOOR_HANDLE_TYPE) == 6),
        when(real(I.AW_DOOR_HANDLE_ALT, "Altitude", 91.44, lo=0.0), _handled),
        ("sub", 1312, "Step"),
        boolean(I.AW_DOOR_STEP, "Step", False),
        when(real(I.AW_DOOR_STEP_H, "Height", 1.0, lo=0.05), _on(I.AW_DOOR_STEP)),
        ("sub", 1313, "Sill"),
        boolean(I.AW_DOOR_SILL, "Sill", False),
        when(real(I.AW_DOOR_SILL_W, "Width", 4.0, lo=0.0), _on(I.AW_DOOR_SILL)),
        when(real(I.AW_DOOR_SILL_D, "Depth", 4.0, lo=0.1), _on(I.AW_DOOR_SILL)),
        when(real(I.AW_DOOR_SILL_H, "Height", 3.0, lo=0.1), _on(I.AW_DOOR_SILL)),
    ] + opening_light(False) + opening_build() + materials(1100, I.AW_DOOR_MATERIAL_SLOTS),
    I.ID_AW_MOLDING: [
        ("group", OBJECT, None),
        cycle(I.AW_MOLDING_TYPE, "Type", 0, ("Base", "Crown")),
        link(I.AW_MOLDING_WALL, "Wall", (I.ID_AW_WALL,)),
        cycle(I.AW_MOLDING_SIDE, "Faces", 0, ("Inside", "Outside")),
        "sep",
        cycle(I.AW_MOLDING_PROFILE, "Profile", 0, ("Square", "Rounded", "Ogee", "Quarter Round", "Cove", "Crown",
                                                    "Custom")),
        when(link(I.AW_MOLDING_CUSTOM, "Profile Spline", (ANY_OBJECT,)), lambda op: value(op, I.AW_MOLDING_PROFILE) == 6),
        when(real(I.AW_MOLDING_HEIGHT, "Height", 10.16, lo=0.1), lambda op: value(op, I.AW_MOLDING_PROFILE) != 6),
        when(real(I.AW_MOLDING_DEPTH, "Depth", 1.6, lo=0.1), lambda op: value(op, I.AW_MOLDING_PROFILE) != 6),
        "sep",
        real(I.AW_MOLDING_OFFSET, "Offset", 0.0),
        real(I.AW_MOLDING_GAP, "Gap", 0.0),
        boolean(I.AW_MOLDING_BREAK, "Break at Openings", True),
    ] + materials(1100, I.AW_MOLDING_MATERIAL_SLOTS),
    I.ID_AW_ROOF: [
        ("group", OBJECT, None),
        link(I.AW_ROOF_WALL, "Wall", (I.ID_AW_WALL,)),
        link(I.AW_ROOF_DRAFT, "Draft", (ANY_OBJECT,)),
        when(real(I.AW_ROOF_ELEVATION, "Elevation", 0.0), _roof_own),  # on the plane it's drawn on (Offset lifts it)
        "sep",
        when(cycle(I.AW_ROOF_SHAPE, "Shape", 0, ("Auto", "Hip", "Gable", "Shed")), _roof_not_draft),
        when(integer(I.AW_ROOF_MAIN_EDGE, "Main Edge", 0, lo=0, hi=32),
             lambda op: _roof_not_draft(op) and value(op, I.AW_ROOF_SHAPE) in (2, 3)),
        when(boolean(I.AW_ROOF_PITCH_FROM_WALLS, "Pitch From Walls", True), _roof_wall),
        when(degrees(I.AW_ROOF_PITCH, "Pitch", 35.0, 85.0), _roof_not_draft),
        "sep",
        when(real(I.AW_ROOF_WIDTH_L, "Width Left", 300.0, lo=1.0), _roof_own),
        when(real(I.AW_ROOF_WIDTH_R, "Width Right", 300.0, lo=1.0), _roof_own),
        when(cycle(I.AW_ROOF_ENDS, "Ends", 0, ("Gable", "Hip")), _roof_own),
        "sep",
        real(I.AW_ROOF_EAVE, "Eave Overhang", 30.0, lo=0.0),
        real(I.AW_ROOF_RAKE, "Rake Overhang", 20.0, lo=0.0),
        real(I.AW_ROOF_THICKNESS, "Thickness", 20.0, lo=0.5),
        real(I.AW_ROOF_OFFSET, "Offset", 0.0),
        boolean(I.AW_ROOF_DIMS, "Dimensions", True),
        ("group", 1340, "Edges"),
    ] + [show(cycle(I.roof_edge(i), "Edge %d" % (i + 1), 0, ("Auto", "Eave", "Gable")), _roof_edge_shown(i))
         for i in range(32)] + [
        ("group", 1350, "Parts"),
        ("sub", 1300, "Fascia"),
        boolean(I.AW_ROOF_FASCIA, "Fascia", True),
        when(real(I.AW_ROOF_FASCIA_H, "Height", 20.0, lo=0.5), _on(I.AW_ROOF_FASCIA)),
        when(real(I.AW_ROOF_FASCIA_W, "Width", 2.5, lo=0.1), _on(I.AW_ROOF_FASCIA)),
        ("sub", 1301, "Bargeboard"),
        boolean(I.AW_ROOF_BARGE, "Bargeboard", True),
        when(real(I.AW_ROOF_BARGE_H, "Height", 20.0, lo=0.5), _on(I.AW_ROOF_BARGE)),
        when(real(I.AW_ROOF_BARGE_W, "Width", 2.5, lo=0.1), _on(I.AW_ROOF_BARGE)),
        ("sub", 1302, "Rafters"),
        boolean(I.AW_ROOF_RAFTERS, "Rafters", False),
        when(real(I.AW_ROOF_RAFTER_W, "Width", 4.5, lo=0.5), _on(I.AW_ROOF_RAFTERS)),
        when(real(I.AW_ROOF_RAFTER_H, "Height", 14.0, lo=0.5), _on(I.AW_ROOF_RAFTERS)),
        when(real(I.AW_ROOF_RAFTER_S, "Spacing", 40.64, lo=5.0), _on(I.AW_ROOF_RAFTERS)),
        ("sub", 1303, "Tiles"),
        boolean(I.AW_ROOF_TILES, "Tiles", True),  # a Dimensional Shingle's sizes (aw_roof.TILE_DEFAULTS)
        when(cycle(I.AW_ROOF_TILE_MODEL, "Model", 4, ((0, "Plain Tile"), (1, "Shingle"), (4, "Dimensional Shingle"),
                                                      (2, "Slate"), (3, "Standing Seam"))),
             _on(I.AW_ROOF_TILES)),
        when(real(I.AW_ROOF_TILE_W, "Width", 100.0, lo=5.0), _on(I.AW_ROOF_TILES)),  # a seamed roof's panels
        when(real(I.AW_ROOF_TILE_L, "Exposure", 14.3, lo=5.0),
             lambda op: value(op, I.AW_ROOF_TILES) and value(op, I.AW_ROOF_TILE_MODEL) != 3),
        when(real(I.AW_ROOF_TILE_T, "Thickness", 0.45, lo=0.2), _on(I.AW_ROOF_TILES)),  # a seamed roof's seams
        when(real(I.AW_ROOF_TILE_OVER, "Overhang", 2.0, lo=0.0, hi=15.0, step=0.1, slider=True),
             _on(I.AW_ROOF_TILES)),  # past the fascia and bargeboard
    ] + materials(1100, I.AW_ROOF_MATERIAL_SLOTS),
    I.ID_AW_ROOF_CUTTER: [
        ("group", OBJECT, None),
        cycle(I.AW_RCUT_MODE, "Mode", 0, ("Hole", "Keep Inside")),
        cycle(I.AW_RCUT_SHAPE, "Shape", 0, ("Rectangle", "Circle", "Custom")),
        when(real(I.AW_RCUT_WIDTH, "Width", 100.0, lo=0.1), lambda op: value(op, I.AW_RCUT_SHAPE) != 2),
        when(real(I.AW_RCUT_LENGTH, "Length", 100.0, lo=0.1), lambda op: value(op, I.AW_RCUT_SHAPE) == 0),
    ],
    I.ID_AW_STAIR: [
        ("group", OBJECT, None),
        cycle(I.AW_STAIR_SHAPE, "Shape", 0, ("Straight", "L", "U", "Spline")),
        real(I.AW_STAIR_HEIGHT, "Height", 270.0, lo=1.0),
        real(I.AW_STAIR_WIDTH, "Width", 100.0, lo=10.0),
        "sep",
        integer(I.AW_STAIR_STEPS, "Steps", 0, lo=0, hi=200),
        real(I.AW_STAIR_MAX_RISER, "Max Riser", 18.0, lo=1.0),
        when(real(I.AW_STAIR_GOING, "Going", 28.0, lo=5.0), lambda op: value(op, I.AW_STAIR_SHAPE) != 3),
        "sep",
        when(cycle(I.AW_STAIR_TURN, "Turn", 1, ("Left", "Right")), lambda op: value(op, I.AW_STAIR_SHAPE) in (1, 2)),
        when(integer(I.AW_STAIR_LANDING_AT, "Landing At", 0, lo=0, hi=200),
             lambda op: value(op, I.AW_STAIR_SHAPE) in (1, 2)),
        when(real(I.AW_STAIR_GAP, "Gap", 10.0, lo=0.0), lambda op: value(op, I.AW_STAIR_SHAPE) == 2),
        ("group", 1360, "Construction"),
        cycle(I.AW_STAIR_CONSTRUCTION, "Construction", 0, ("Closed", "Open")),
        when(cycle(I.AW_STAIR_UNDERSIDE, "Underside", 0, ("Sloped", "Solid")),
             lambda op: value(op, I.AW_STAIR_CONSTRUCTION) == 0),
        when(real(I.AW_STAIR_WAIST, "Waist", 15.0, lo=1.0),
             lambda op: value(op, I.AW_STAIR_CONSTRUCTION) == 0 and value(op, I.AW_STAIR_UNDERSIDE) == 0),
        real(I.AW_STAIR_TREAD_T, "Tread Thickness", 4.0, lo=0.5),
        real(I.AW_STAIR_NOSING, "Nosing", 3.0, lo=0.0),
        "sep",
        cycle(I.AW_STAIR_STRINGERS, "Stringers", 0, ("None", "Sides", "Centre")),
        when(real(I.AW_STAIR_STRINGER_W, "Thickness", 5.0, lo=0.5), lambda op: value(op, I.AW_STAIR_STRINGERS) != 0),
        when(real(I.AW_STAIR_STRINGER_D, "Depth", 25.0, lo=1.0), lambda op: value(op, I.AW_STAIR_STRINGERS) != 0),
        when(real(I.AW_STAIR_STRINGER_SPACING, "Spacing", 0.0, lo=0.0), lambda op: value(op, I.AW_STAIR_STRINGERS) == 1),
        when(real(I.AW_STAIR_STRINGER_ABOVE, "Above Nosing", 5.0),
             lambda op: value(op, I.AW_STAIR_STRINGERS) == 1 and not value(op, I.AW_STAIR_STRINGER_SPACING)),
    ] + materials(1100, I.AW_STAIR_MATERIAL_SLOTS),
    I.ID_AW_CABINET: [
        ("group", OBJECT, None),
        cycle(I.AW_CAB_TYPE, "Type", 0, ("Base", "Upper", "Tall", "Vanity")),
        real(I.AW_CAB_WIDTH, "Width", 45.72, lo=2.0),
        real(I.AW_CAB_HEIGHT, "Height", 87.63, lo=2.0),
        real(I.AW_CAB_DEPTH, "Depth", 60.96, lo=2.0),
        when(real(I.AW_CAB_TOP, "Top", 213.36), lambda op: value(op, I.AW_CAB_TYPE) == 1),
        when(real(I.AW_CAB_KICK_H, "Kick Height", 10.16, lo=0.0), lambda op: value(op, I.AW_CAB_TYPE) != 1),
        when(real(I.AW_CAB_KICK_SETBACK, "Kick Setback", 7.62, lo=0.0), lambda op: value(op, I.AW_CAB_TYPE) != 1),
        real(I.AW_CAB_THICKNESS, "Board", 1.91, lo=0.3),
        percent(I.AW_CAB_OPEN, "Open", 0.0),
        boolean(I.AW_CAB_DIMS, "Dimensions", True),
        boolean(I.AW_CAB_PUSH, "Push Neighbours", True),
        when(cycle(I.AW_CAB_ANCHOR, "Anchor", 0, ("Left", "Centre", "Right")), _on(I.AW_CAB_PUSH)),
        ("group", 1381, "Fronts"),
        cycle(I.AW_CAB_STYLE, "Style", 1, ("Slab", "Shaker", "Glass Shaker")),
        cycle(I.AW_CAB_DRAWER_STYLE, "Drawers", 0, ("Same", "Slab")),
        when(real(I.AW_CAB_FRAME_W, "Frame Width", 6.35, lo=0.5), lambda op: value(op, I.AW_CAB_STYLE) != 0),
        when(real(I.AW_CAB_PANEL_RECESS, "Panel Recess", 0.64, lo=0.1), lambda op: value(op, I.AW_CAB_STYLE) == 1),
        real(I.AW_CAB_FRONT_T, "Thickness", 1.91, lo=0.3),
        cycle(I.AW_CAB_OVERLAY, "Overlay", 0, ("Full", "Inset")),
        real(I.AW_CAB_REVEAL, "Reveal", 0.32, lo=0.0),
        when(real(I.AW_CAB_FACE_FRAME, "Face Frame", 3.81, lo=0.5), lambda op: value(op, I.AW_CAB_OVERLAY) == 1),
        "sep",
        ("sub", 1386, "Corner"),
        cycle(I.AW_CAB_CORNER, "Corner", 0, ("None", "Pie Cut", "Diagonal")),
        when(real(I.AW_CAB_RETURN, "Return", 91.44, lo=2.0), lambda op: value(op, I.AW_CAB_CORNER) != 0),
        when(cycle(I.AW_CAB_CORNER_SIDE, "Corner Side", 0, ("Left", "Right")), lambda op: value(op, I.AW_CAB_CORNER) != 0),
        when(cycle(I.AW_CAB_BLIND, "Blind", 0, ("None", "Left", "Right")), lambda op: value(op, I.AW_CAB_CORNER) == 0),
        when(real(I.AW_CAB_BLIND_W, "Blind Width", 60.96, lo=0.0),
             lambda op: value(op, I.AW_CAB_CORNER) == 0 and value(op, I.AW_CAB_BLIND) != 0),
        ("sub", 1387, "Ends"),
        when(boolean(I.AW_CAB_END_L, "End Panel Left", False), lambda op: value(op, I.AW_CAB_CORNER) == 0),
        when(boolean(I.AW_CAB_END_R, "End Panel Right", False), lambda op: value(op, I.AW_CAB_CORNER) == 0),
        when(real(I.AW_CAB_END_T, "Panel Thickness", 1.91, lo=0.1),
             lambda op: value(op, I.AW_CAB_END_L) or value(op, I.AW_CAB_END_R)),
        when(real(I.AW_CAB_END_PROUD, "Panel Proud", 0.0, lo=0.0),
             lambda op: value(op, I.AW_CAB_END_L) or value(op, I.AW_CAB_END_R)),
        when(real(I.AW_CAB_FILLER_L, "Filler Left", 0.0, lo=0.0), lambda op: value(op, I.AW_CAB_CORNER) == 0),
        when(real(I.AW_CAB_FILLER_R, "Filler Right", 0.0, lo=0.0), lambda op: value(op, I.AW_CAB_CORNER) == 0),
        ("sub", 1388, "Zones"),
        integer(I.AW_CAB_ZONES, "Zones", 2, lo=1, hi=6),
        ("sub", 1390, "Zone 1", _zone_shown(0)),
        cycle(I.cab_zone(0, 0), "Kind", 0, ("Door Left", "Door Right", "Door Pair", "Flap", "Drawer", "False Front",
                                                "Open Shelves", "Empty", "Sink")),
        real(I.cab_zone(0, 1), "Height", 0.0, lo=0.0),
        when(integer(I.cab_zone(0, 2), "Columns", 1, lo=1, hi=6), _zone_is(0, (4,))),
        when(integer(I.cab_zone(0, 3), "Shelves", 1, lo=0, hi=20), _zone_is(0, (6,))),
        when(boolean(I.cab_zone(0, 4), "Glass", False), _zone_is(0, (0, 1, 2, 3))),
        ("sub", 1391, "Zone 2", _zone_shown(1)),
        cycle(I.cab_zone(1, 0), "Kind", 0, ("Door Left", "Door Right", "Door Pair", "Flap", "Drawer", "False Front",
                                                "Open Shelves", "Empty", "Sink")),
        real(I.cab_zone(1, 1), "Height", 0.0, lo=0.0),
        when(integer(I.cab_zone(1, 2), "Columns", 1, lo=1, hi=6), _zone_is(1, (4,))),
        when(integer(I.cab_zone(1, 3), "Shelves", 1, lo=0, hi=20), _zone_is(1, (6,))),
        when(boolean(I.cab_zone(1, 4), "Glass", False), _zone_is(1, (0, 1, 2, 3))),
        ("sub", 1392, "Zone 3", _zone_shown(2)),
        cycle(I.cab_zone(2, 0), "Kind", 0, ("Door Left", "Door Right", "Door Pair", "Flap", "Drawer", "False Front",
                                                "Open Shelves", "Empty", "Sink")),
        real(I.cab_zone(2, 1), "Height", 0.0, lo=0.0),
        when(integer(I.cab_zone(2, 2), "Columns", 1, lo=1, hi=6), _zone_is(2, (4,))),
        when(integer(I.cab_zone(2, 3), "Shelves", 1, lo=0, hi=20), _zone_is(2, (6,))),
        when(boolean(I.cab_zone(2, 4), "Glass", False), _zone_is(2, (0, 1, 2, 3))),
        ("sub", 1393, "Zone 4", _zone_shown(3)),
        cycle(I.cab_zone(3, 0), "Kind", 0, ("Door Left", "Door Right", "Door Pair", "Flap", "Drawer", "False Front",
                                                "Open Shelves", "Empty", "Sink")),
        real(I.cab_zone(3, 1), "Height", 0.0, lo=0.0),
        when(integer(I.cab_zone(3, 2), "Columns", 1, lo=1, hi=6), _zone_is(3, (4,))),
        when(integer(I.cab_zone(3, 3), "Shelves", 1, lo=0, hi=20), _zone_is(3, (6,))),
        when(boolean(I.cab_zone(3, 4), "Glass", False), _zone_is(3, (0, 1, 2, 3))),
        ("sub", 1394, "Zone 5", _zone_shown(4)),
        cycle(I.cab_zone(4, 0), "Kind", 0, ("Door Left", "Door Right", "Door Pair", "Flap", "Drawer", "False Front",
                                                "Open Shelves", "Empty", "Sink")),
        real(I.cab_zone(4, 1), "Height", 0.0, lo=0.0),
        when(integer(I.cab_zone(4, 2), "Columns", 1, lo=1, hi=6), _zone_is(4, (4,))),
        when(integer(I.cab_zone(4, 3), "Shelves", 1, lo=0, hi=20), _zone_is(4, (6,))),
        when(boolean(I.cab_zone(4, 4), "Glass", False), _zone_is(4, (0, 1, 2, 3))),
        ("sub", 1395, "Zone 6", _zone_shown(5)),
        cycle(I.cab_zone(5, 0), "Kind", 0, ("Door Left", "Door Right", "Door Pair", "Flap", "Drawer", "False Front",
                                                "Open Shelves", "Empty", "Sink")),
        real(I.cab_zone(5, 1), "Height", 0.0, lo=0.0),
        when(integer(I.cab_zone(5, 2), "Columns", 1, lo=1, hi=6), _zone_is(5, (4,))),
        when(integer(I.cab_zone(5, 3), "Shelves", 1, lo=0, hi=20), _zone_is(5, (6,))),
        when(boolean(I.cab_zone(5, 4), "Glass", False), _zone_is(5, (0, 1, 2, 3))),
        ("group", 1382, "Pulls"),
        ("sub", 1383, "Doors"),
        cycle(I.AW_CAB_DOOR_PULL, "Pull", 1, _pull_names),
        when(real(I.AW_CAB_DOOR_PULL_SIZE, "Size", 3.18, lo=0.5), _pull_sized(I.AW_CAB_DOOR_PULL)),
        when(cycle(I.AW_CAB_DOOR_PULL_LIB, "Library Pull", 0, _library_names), _pull_is(I.AW_CAB_DOOR_PULL, 10)),
        when(link(I.AW_CAB_DOOR_PULL_OBJ, "Custom Pull", (ANY_OBJECT,)), _pull_is(I.AW_CAB_DOOR_PULL, 11)),
        when(cycle(I.AW_CAB_DOOR_PULL_ORIENT, "Orientation", 0, ("Vertical", "Horizontal")), _pull_on(I.AW_CAB_DOOR_PULL)),
        when(cycle(I.AW_CAB_DOOR_PULL_POS, "Position", 0, ("Auto", "Top", "Middle", "Bottom")), _pull_on(I.AW_CAB_DOOR_PULL)),
        when(real(I.AW_CAB_DOOR_PULL_EDGE, "Edge Inset", 5.08, lo=0.0), _pull_on(I.AW_CAB_DOOR_PULL)),
        when(real(I.AW_CAB_DOOR_PULL_END, "End Inset", 7.62, lo=0.0), _pull_on(I.AW_CAB_DOOR_PULL)),
        ("sub", 1384, "Drawers"),
        cycle(I.AW_CAB_DRAWER_PULL, "Pull", 5, _pull_names),
        when(real(I.AW_CAB_DRAWER_PULL_SIZE, "Size", 12.8, lo=0.5), _pull_sized(I.AW_CAB_DRAWER_PULL)),
        when(cycle(I.AW_CAB_DRAWER_PULL_LIB, "Library Pull", 0, _library_names), _pull_is(I.AW_CAB_DRAWER_PULL, 10)),
        when(link(I.AW_CAB_DRAWER_PULL_OBJ, "Custom Pull", (ANY_OBJECT,)), _pull_is(I.AW_CAB_DRAWER_PULL, 11)),
        when(cycle(I.AW_CAB_DRAWER_PULL_ORIENT, "Orientation", 1, ("Vertical", "Horizontal")),
             _pull_on(I.AW_CAB_DRAWER_PULL)),
        when(cycle(I.AW_CAB_DRAWER_PULL_POS, "Position", 0, ("Centre", "Near Top")), _pull_on(I.AW_CAB_DRAWER_PULL)),
        when(real(I.AW_CAB_DRAWER_PULL_TOP, "Top Inset", 3.81, lo=0.0),
             lambda op: value(op, I.AW_CAB_DRAWER_PULL) != 0 and value(op, I.AW_CAB_DRAWER_PULL_POS) == 1),
        when(real(I.AW_CAB_DRAWER_TWO_OVER, "Two Pulls Over", 76.2, lo=0.0), _pull_on(I.AW_CAB_DRAWER_PULL)),
    ] + materials(1100, I.AW_CAB_MATERIAL_SLOTS),
    I.ID_AW_COUNTERTOP: [
        ("group", OBJECT, None),
        object_list(I.AW_CT_CABINETS, "Cabinets"),
        real(I.AW_CT_THICKNESS, "Thickness", 3.18, lo=0.5),
        real(I.AW_CT_FRONT, "Front Overhang", 3.81, lo=0.0),
        real(I.AW_CT_BACK, "Back Overhang", 0.0, lo=0.0),
        real(I.AW_CT_SIDE, "Side Overhang", 2.54, lo=0.0),
        real(I.AW_CT_ELEVATION, "Elevation", 91.44),
        "sep",
        boolean(I.AW_CT_SPLASH, "Backsplash", True),
        when(real(I.AW_CT_SPLASH_H, "Backsplash Height", 10.16, lo=0.5), _on(I.AW_CT_SPLASH)),
        when(real(I.AW_CT_SPLASH_T, "Backsplash Thickness", 1.91, lo=0.3), _on(I.AW_CT_SPLASH)),
        boolean(I.AW_CT_WATERFALL, "Waterfall Ends", False),
        ("group", 1385, "Sinks", has_sinks),  # every sink under it at once (aw_counter.CT_SINK_PIDS)
    ] + sink_rows(I.CT_SINK) + [
        ("group", 1390, "Animation"),  # the wipe-on, as a wall's build-on
        percent(I.AW_CT_WIPE, "Wipe", 1.0),
        cycle(I.AW_CT_WIPE_DIR, "Wipe Direction", 0, ("Along the Run", "Along X", "Along Z")),
        boolean(I.AW_CT_WIPE_REVERSE, "Reverse", False),
    ] + materials(1100, I.AW_CT_MATERIAL_SLOTS),
    I.ID_AW_SINK: [("group", OBJECT, None)] + sink_rows(0),
    I.ID_AW_BEAM: [
        ("group", OBJECT, None),
        real(I.AW_BEAM_LENGTH, "Length", 400.0, lo=0.1),
        real(I.AW_BEAM_WIDTH, "Width", 8.89, lo=0.1),
        real(I.AW_BEAM_HEIGHT, "Height", 28.58, lo=0.1),
        cycle(I.AW_BEAM_ALIGN, "Align", 0, ("Bottom", "Centre", "Top")),
        "sep",
        cycle(I.AW_BEAM_SECTION, "Section", 0, ("Rectangle", "Rounded", "Round", "I-Beam", "Custom")),
        when(real(I.AW_BEAM_RADIUS, "Radius", 1.0, lo=0.0), lambda op: value(op, I.AW_BEAM_SECTION) == 1),
        when(real(I.AW_BEAM_FLANGE, "Flange", 1.5, lo=0.1), lambda op: value(op, I.AW_BEAM_SECTION) == 3),
        when(real(I.AW_BEAM_WEB, "Web", 1.0, lo=0.1), lambda op: value(op, I.AW_BEAM_SECTION) == 3),
        when(link(I.AW_BEAM_PROFILE, "Profile", (ANY_OBJECT,)), lambda op: value(op, I.AW_BEAM_SECTION) == 4),
        "sep",
        boolean(I.AW_BEAM_DIMS, "Dimensions", True),
        ("group", 1380, "Clones"),
        integer(I.AW_BEAM_COUNT, "Count", 1, lo=1, hi=1000),
        when(cycle(I.AW_BEAM_SPACING_MODE, "Spacing Mode", 0, ("Per Step", "Span")),
             lambda op: value(op, I.AW_BEAM_COUNT) > 1),
        when(real(I.AW_BEAM_SPACING, "Spacing", 40.64, lo=0.1),
             lambda op: value(op, I.AW_BEAM_COUNT) > 1 and value(op, I.AW_BEAM_SPACING_MODE) == 0),
        when(real(I.AW_BEAM_SPAN, "Span", 365.76, lo=0.1),
             lambda op: value(op, I.AW_BEAM_COUNT) > 1 and value(op, I.AW_BEAM_SPACING_MODE) == 1),
        "sep",
        integer(I.AW_BEAM_LAYERS, "Layers", 1, lo=1, hi=100),
        when(real(I.AW_BEAM_LAYER_SPACING, "Layer Spacing", 60.0, lo=0.1), lambda op: value(op, I.AW_BEAM_LAYERS) > 1),
    ] + materials(1100, I.AW_BEAM_MATERIAL_SLOTS),
    I.ID_AW_RAILING: [
        ("group", OBJECT, None),
        link(I.AW_RAIL_STAIR, "Stair", (I.ID_AW_STAIR,)),
        when(cycle(I.AW_RAIL_SIDE, "Side", 2, ("Left", "Right", "Both")), lambda op: _linked(op, I.AW_RAIL_STAIR)),
        when(real(I.AW_RAIL_INSET, "Inset", 5.0, lo=0.0), lambda op: _linked(op, I.AW_RAIL_STAIR)),
        real(I.AW_RAIL_HEIGHT, "Height", 91.44, lo=1.0),
        ("group", 1370, "Posts"),
        boolean(I.AW_RAIL_POSTS, "Posts", True),
        when(real(I.AW_RAIL_POST_SPACING, "Post Spacing", 0.0, lo=0.0), _on(I.AW_RAIL_POSTS)),
        when(cycle(I.AW_RAIL_POST_SHAPE, "Shape", 0, ("Square", "Round")), _on(I.AW_RAIL_POSTS)),
        when(real(I.AW_RAIL_POST_W, "Width", 8.89, lo=0.5), _on(I.AW_RAIL_POSTS)),
        when(real(I.AW_RAIL_POST_ABOVE, "Above Handrail", 10.0), _on(I.AW_RAIL_POSTS)),
        when(boolean(I.AW_RAIL_POST_CAP, "Cap", True), _on(I.AW_RAIL_POSTS)),
        ("group", 1371, "Handrail"),
        boolean(I.AW_RAIL_HANDRAIL, "Handrail", True),
        when(cycle(I.AW_RAIL_HANDRAIL_SHAPE, "Shape", 1, ("Square", "Round", "Custom")), _on(I.AW_RAIL_HANDRAIL)),
        when(real(I.AW_RAIL_HANDRAIL_W, "Width", 5.08, lo=0.5),
             lambda op: value(op, I.AW_RAIL_HANDRAIL) and value(op, I.AW_RAIL_HANDRAIL_SHAPE) != 2),
        when(real(I.AW_RAIL_HANDRAIL_H, "Depth", 5.08, lo=0.5), _on(I.AW_RAIL_HANDRAIL)),
        when(link(I.AW_RAIL_HANDRAIL_PROFILE, "Profile", (ANY_OBJECT,)),
             lambda op: value(op, I.AW_RAIL_HANDRAIL) and value(op, I.AW_RAIL_HANDRAIL_SHAPE) == 2),
        ("group", 1372, "Infill"),
        cycle(I.AW_RAIL_INFILL, "Infill", 1, ("None", "Pickets", "Rails", "Panels")),
        real(I.AW_RAIL_INFILL_BOTTOM, "Infill Bottom", 0.0, lo=0.0),
        when(cycle(I.AW_RAIL_PICKET_SHAPE, "Picket Shape", 0, ("Square", "Round", "Board")), lambda op: value(op, I.AW_RAIL_INFILL) == 1),
        when(real(I.AW_RAIL_PICKET_SPACING, "Spacing", 10.16, lo=1.0), lambda op: value(op, I.AW_RAIL_INFILL) == 1),
        when(real(I.AW_RAIL_PICKET_W, "Width", 3.18, lo=0.3), lambda op: value(op, I.AW_RAIL_INFILL) == 1),
        when(real(I.AW_RAIL_PICKET_D, "Thickness", 1.9, lo=0.3),
             lambda op: value(op, I.AW_RAIL_INFILL) == 1 and value(op, I.AW_RAIL_PICKET_SHAPE) == 2),
        when(cycle(I.AW_RAIL_PICKET_TOP, "Top", 0, ("Straight", "Dog-eared")),
             lambda op: value(op, I.AW_RAIL_INFILL) == 1 and value(op, I.AW_RAIL_PICKET_SHAPE) != 1),
        when(real(I.AW_RAIL_DOG_EAR, "Dog Ear", 1.9, lo=0.0),
             lambda op: value(op, I.AW_RAIL_INFILL) == 1 and value(op, I.AW_RAIL_PICKET_TOP) == 1
             and value(op, I.AW_RAIL_PICKET_SHAPE) != 1),
        when(integer(I.AW_RAIL_STRINGERS, "Stringers", 0, lo=0, hi=20), lambda op: value(op, I.AW_RAIL_INFILL) == 1),
        when(cycle(I.AW_RAIL_STRINGER_SIDE, "Stringer Side", 0, ("Behind", "In Front", "Centred")),
             lambda op: value(op, I.AW_RAIL_INFILL) == 1 and value(op, I.AW_RAIL_STRINGERS) > 0),
        when(real(I.AW_RAIL_STRINGER_W, "Stringer Width", 3.81, lo=0.3),
             lambda op: value(op, I.AW_RAIL_INFILL) == 1 and value(op, I.AW_RAIL_STRINGERS) > 0),
        when(real(I.AW_RAIL_STRINGER_H, "Stringer Depth", 8.89, lo=0.3),
             lambda op: value(op, I.AW_RAIL_INFILL) == 1 and value(op, I.AW_RAIL_STRINGERS) > 0),
        when(real(I.AW_RAIL_STRINGER_INSET, "Stringer Inset", 15.24, lo=0.0),
             lambda op: value(op, I.AW_RAIL_INFILL) == 1 and value(op, I.AW_RAIL_STRINGERS) > 0),
        when(integer(I.AW_RAIL_RAILS, "Rails", 3, lo=0, hi=100), lambda op: value(op, I.AW_RAIL_INFILL) == 2),
        when(cycle(I.AW_RAIL_RAIL_SHAPE, "Rail Shape", 0, ("Square", "Round")), lambda op: value(op, I.AW_RAIL_INFILL) == 2),
        when(real(I.AW_RAIL_RAIL_W, "Rail Width", 3.81, lo=0.3), lambda op: value(op, I.AW_RAIL_INFILL) == 2),
        when(real(I.AW_RAIL_RAIL_H, "Rail Depth", 8.89, lo=0.3), lambda op: value(op, I.AW_RAIL_INFILL) == 2),
        when(real(I.AW_RAIL_PANEL_T, "Panel Thickness", 1.27, lo=0.1), lambda op: value(op, I.AW_RAIL_INFILL) == 3),
        when(real(I.AW_RAIL_PANEL_GAP, "Gap", 2.54, lo=0.0), lambda op: value(op, I.AW_RAIL_INFILL) == 3),
        "sep",
        boolean(I.AW_RAIL_BOTTOM, "Bottom Rail", False),
        when(real(I.AW_RAIL_BOTTOM_W, "Width", 3.81, lo=0.3), _on(I.AW_RAIL_BOTTOM)),
        when(real(I.AW_RAIL_BOTTOM_H, "Depth", 3.81, lo=0.3), _on(I.AW_RAIL_BOTTOM)),
    ] + materials(1100, I.AW_RAIL_MATERIAL_SLOTS),
    I.ID_AW_FLOOR: [
        ("group", OBJECT, None),
        real(I.AW_FLOOR_ELEVATION, "Elevation", 0.0),
        real(I.AW_FLOOR_THICKNESS, "Thickness", 15.0, lo=0.1),
    ] + materials(1100, I.AW_FLOOR_MATERIAL_SLOTS),
    I.ID_AW_CEILING: [
        ("group", OBJECT, None),
        real(I.AW_FLOOR_ELEVATION, "Elevation", 274.32),
        real(I.AW_FLOOR_THICKNESS, "Thickness", 15.0, lo=0.1),
    ] + materials(1100, I.AW_FLOOR_MATERIAL_SLOTS),
    I.ID_AW_CUTTER: [
        ("group", OBJECT, None),
        cycle(I.AW_CUTTER_SHAPE, "Shape", 1, ("Rectangle", "Top Round", "Top Elliptic", "Top Oblique", "Pointed",
                                               "Full Circle", "Rounded Corners")),
        "sep",
        real(I.AW_OPENING_WIDTH, "Width", 91.44, lo=0.1),
        real(I.AW_OPENING_HEIGHT, "Height", 213.36, lo=0.1),
        real(I.AW_OPENING_SILL, "Sill Height", 0.0),
        "sep",
        real(I.AW_OPENING_START, "Start Offset", -45.72),
        "sep",
        when(integer(I.AW_CUTTER_RESOLUTION, "Resolution", 32, 4, 256), lambda op: value(op, I.AW_CUTTER_SHAPE) != 0),
        when(real(I.AW_CUTTER_RADIUS, "Radius", 0.0, lo=0.0), lambda op: value(op, I.AW_CUTTER_SHAPE) in (1, 4, 6)),
        when(real(I.AW_CUTTER_RISE, "Rise", 30.0, lo=0.0), lambda op: value(op, I.AW_CUTTER_SHAPE) in (2, 3)),
        boolean(I.AW_CUTTER_CUT_MOLDINGS, "Cut Moldings", True),
    ],
    I.ID_AW_WALL_PANELS: [
        ("group", OBJECT, None),
        link(I.AW_PNL_WALL, "Wall", (I.ID_AW_WALL,)),
        cycle(I.AW_PNL_SIDE, "Faces", 0, ("Inside", "Outside")),
        "sep",
        real(I.AW_PNL_BOTTOM, "Bottom", 25.4, lo=0.0),
        real(I.AW_PNL_TOP, "Top", 30.48, lo=0.0),
        when(real(I.AW_PNL_HEIGHT, "Height", 274.32, lo=1.0), lambda op: aw_host.link(op, I.AW_PNL_WALL) is None),
        real(I.AW_PNL_MARGIN, "Margin", 15.24, lo=0.0),
        real(I.AW_PNL_GAP, "Gap", 15.24, lo=0.0),
        real(I.AW_PNL_WIDTH, "Panel Width", 91.44, lo=5.0),
        real(I.AW_PNL_MIN_W, "Min Width", 20.32, lo=1.0),
        boolean(I.AW_PNL_BREAKS, "Stop at Openings", True),
        when(boolean(I.AW_PNL_AROUND, "Over and Under Openings", True), _on(I.AW_PNL_BREAKS)),
        ("sub", 1300, "Frame"),
        cycle(I.AW_PNL_PROFILE, "Profile", 1, ("Square", "Rounded", "Ogee", "Quarter Round", "Cove", "Crown",
                                                "Custom")),
        when(link(I.AW_PNL_CUSTOM, "Profile Spline", (ANY_OBJECT,)), lambda op: value(op, I.AW_PNL_PROFILE) == 6),
        when(real(I.AW_PNL_FRAME_W, "Frame Width", 3.81, lo=0.2), lambda op: value(op, I.AW_PNL_PROFILE) != 6),
        when(real(I.AW_PNL_FRAME_D, "Frame Depth", 1.91, lo=0.1), lambda op: value(op, I.AW_PNL_PROFILE) != 6),
        ("sub", 1301, "Flourishes"),
        cycle(I.AW_PNL_FLOURISH, "Flourishes", 1, ("None", "Top Corners", "All Corners")),
        when(cycle(I.AW_PNL_FLOURISH_KIND, "Kind", 0, ("Built-in", "Custom")), lambda op: value(op, I.AW_PNL_FLOURISH) != 0),
        when(link(I.AW_PNL_FLOURISH_OBJ, "Custom Flourish", (ANY_OBJECT,)),
             lambda op: value(op, I.AW_PNL_FLOURISH) != 0 and value(op, I.AW_PNL_FLOURISH_KIND) == 1),
        when(real(I.AW_PNL_FLOURISH_SIZE, "Size", 12.7, lo=0.5),
             lambda op: value(op, I.AW_PNL_FLOURISH) != 0 and value(op, I.AW_PNL_FLOURISH_KIND) == 0),
        when(real(I.AW_PNL_FLOURISH_D, "Relief", 1.0, lo=0.05),
             lambda op: value(op, I.AW_PNL_FLOURISH) != 0 and value(op, I.AW_PNL_FLOURISH_KIND) == 0),
        when(real(I.AW_PNL_FLOURISH_INSET, "Inset", 1.27, lo=0.0), lambda op: value(op, I.AW_PNL_FLOURISH) != 0),
    ] + materials(1100, I.AW_PNL_MATERIAL_SLOTS),
    I.ID_AW_FIREPLACE: [
        ("group", OBJECT, None),
        cycle(I.AW_FP_SIDE, "Side", 0, ("Inside", "Outside")),
        cycle(I.AW_FP_SHAPE, "Shape", 1, ("Rectangle", "Rounded Corners", "Top Round", "Top Elliptic")),
        when(real(I.AW_FP_RADIUS, "Radius", 15.24, lo=0.0), lambda op: value(op, I.AW_FP_SHAPE) in (1, 2)),
        when(real(I.AW_FP_RISE, "Rise", 20.0, lo=0.0), lambda op: value(op, I.AW_FP_SHAPE) == 3),
        when(integer(I.AW_FP_RESOLUTION, "Resolution", 32, 4, 256), lambda op: value(op, I.AW_FP_SHAPE) != 0),
        "sep",
        real(I.AW_OPENING_WIDTH, "Width", 91.44, lo=10.0),
        real(I.AW_OPENING_HEIGHT, "Height", 76.2, lo=10.0),
        real(I.AW_OPENING_SILL, "Sill Height", 0.0),
        "sep",
        real(I.AW_OPENING_START, "Start Offset", -45.72),
        ("sub", 1300, "Surround"),
        boolean(I.AW_FP_SURROUND, "Surround", True),
        when(real(I.AW_FP_SURROUND_SIDE, "Width", 20.32, lo=0.5), _on(I.AW_FP_SURROUND)),
        when(real(I.AW_FP_SURROUND_TOP, "Top", 25.4, lo=0.5), _on(I.AW_FP_SURROUND)),
        when(real(I.AW_FP_SURROUND_D, "Depth", 5.08, lo=0.2), _on(I.AW_FP_SURROUND)),
        when(real(I.AW_FP_BEAD_W, "Bead Width", 7.62, lo=0.0), _on(I.AW_FP_SURROUND)),
        when(real(I.AW_FP_BEAD_D, "Bead Depth", 1.27, lo=0.0), _on(I.AW_FP_SURROUND)),
        when(boolean(I.AW_FP_FACING, "Facing", False), _on(I.AW_FP_SURROUND)),
        when(real(I.AW_FP_FACING_W, "Opening Width", 116.84, lo=1.0),
             lambda op: value(op, I.AW_FP_SURROUND) and value(op, I.AW_FP_FACING)),
        when(real(I.AW_FP_FACING_H, "Opening Height", 101.6, lo=1.0),
             lambda op: value(op, I.AW_FP_SURROUND) and value(op, I.AW_FP_FACING)),
        when(real(I.AW_FP_FACING_D, "Facing Depth", 2.54, lo=0.2),
             lambda op: value(op, I.AW_FP_SURROUND) and value(op, I.AW_FP_FACING)),
        ("sub", 1301, "Mantel"),
        boolean(I.AW_FP_MANTEL, "Mantel", True),
        when(real(I.AW_FP_SHELF_T, "Thickness", 6.35, lo=0.5), _on(I.AW_FP_MANTEL)),
        when(real(I.AW_FP_SHELF_D, "Overhang", 7.62, lo=0.0), _on(I.AW_FP_MANTEL)),
        when(real(I.AW_FP_SHELF_SIDE, "Side Overhang", 5.08, lo=0.0), _on(I.AW_FP_MANTEL)),
        when(real(I.AW_FP_BED_H, "Bed", 3.81, lo=0.0), _on(I.AW_FP_MANTEL)),
        ("sub", 1302, "Hearth"),
        boolean(I.AW_FP_HEARTH, "Hearth", True),
        when(real(I.AW_FP_HEARTH_D, "Depth", 50.8, lo=1.0), _on(I.AW_FP_HEARTH)),
        when(real(I.AW_FP_HEARTH_SIDE, "Side", 15.24, lo=0.0), _on(I.AW_FP_HEARTH)),
        when(real(I.AW_FP_HEARTH_T, "Thickness", 2.54, lo=0.1), _on(I.AW_FP_HEARTH)),
        ("sub", 1303, "Firebox"),
        real(I.AW_FP_DEPTH, "Depth", 50.8, lo=5.0),
        real(I.AW_FP_LINER, "Liner", 10.16, lo=0.5),
        real(I.AW_FP_SPLAY, "Splay", 10.16, lo=0.0),
        boolean(I.AW_FP_INSIDE_WALL, "Keep Inside Wall", False),
        ("group", 1350, "Insert"),
        boolean(I.AW_FP_GRATE, "Grate", True),
        integer(I.AW_FP_LOGS, "Logs", 3, 0, 5),
        "sep",
        cycle(I.AW_FP_DOORS, "Doors", 0, ("None", "Pair", "Bifold")),
        when(percent(I.AW_FP_DOORS_OPEN, "Doors Open", 0.0), lambda op: value(op, I.AW_FP_DOORS) != 0),
        boolean(I.AW_FP_SCREEN, "Chain Screen", False),
        when(percent(I.AW_FP_SCREEN_OPEN, "Screen Open", 0.0), _on(I.AW_FP_SCREEN)),
    ] + opening_build() + materials(1100, I.AW_FP_MATERIAL_SLOTS),
    I.ID_AW_SLAB: [
        ("group", OBJECT, None),
        cycle(I.AW_SLAB_TYPE, "Type", 0, ("Floor", "Ceiling")),
        link(I.AW_SLAB_WALL, "Wall", (I.ID_AW_WALL,)),
        cycle(I.AW_SLAB_FIT, "Fit", 1, ("Inside Faces", "Outside Faces", "Spline")),  # the outer perimeter
        "sep",
        real(I.AW_SLAB_THICKNESS, "Thickness", 15.0, lo=0.1),
        real(I.AW_SLAB_OFFSET, "Offset", 0.0),
        when(boolean(I.AW_SLAB_FOLLOW, "Follow Wall Tops", True), lambda op: value(op, I.AW_SLAB_TYPE) == 1),
    ] + materials(1100, I.AW_SLAB_MATERIAL_SLOTS),
}

SEPARATOR_BASE = 1900  # separators need ids of their own; parameters never use 1900-1999


def params(kind):
    return [row for row in SPECS.get(kind, ()) if isinstance(row, dict)]


def default(kind, pid):
    for p in params(kind):
        if p["id"] == pid:
            return p["default"]
    return None


def value(op, pid):
    """op's value for pid, or its default when op predates that parameter."""
    return aw_host.value(op, pid)


def enabled(op, pid):
    """False while pid's `when` test fails (greyed out); None when it has none."""
    for p in params(aw_host.type_id(op)):
        if p["id"] == pid and "enable" in p:
            try:
                return bool(p["enable"](op))
            except Exception:
                return True
    return None


PREDATES[I.ID_AW_ROOF] = {I.AW_ROOF_TILES: False, I.AW_ROOF_TILE_MODEL: 0, I.AW_ROOF_TILE_W: 30.0,
                          I.AW_ROOF_TILE_L: 20.0, I.AW_ROOF_TILE_T: 1.8, I.AW_ROOF_ELEVATION: 270.0}
PREDATES[I.ID_AW_OPENING] = {I.AW_OPENING_SILL: 90.0}  # a window's head at a door's from 0.56
