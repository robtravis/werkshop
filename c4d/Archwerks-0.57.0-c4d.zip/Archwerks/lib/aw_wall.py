"""Archwerks Wall geometry.

A wall follows the splines among its children: every run of every spline is its
own piece of straight, mitred segments on the floor, with its Outside face on
the -n side of each segment (see aw_path). Every other child is an opening: an
AW Opening by its own settings, otherwise the child's position (relative to the
wall) is the opening centre and its size the opening size (a Cube's Size,
otherwise its bounding box), projected onto its nearest segment. Openings cut
the full thickness.

Plain functions; the host reads the wall's curves and openings (aw_host), and
its Wall object calls these (Cinema 4D's: aw_plugins.Wall, with aw_wall_c4d).
"""
import aw_build
import aw_host
import aw_ids
import aw_path
from aw_mat import Mat
from aw_mesh import MeshBuilder
from aw_vec import Vec

# The wall's parts, each a polygon selection a material slot (aw_materials) paints:
# Exterior and Interior faces, Top, Bottom, the Start and End of an open run, and
# the Reveals round openings. Named like the slots, so a baked file reads the same.
GROUPS = ("Exterior", "Interior", "Top", "Bottom", "Start", "End", "Reveals") + tuple(
    name for name, _pid in aw_ids.AW_WALL_OVERRIDE_SLOTS)  # Segment Overrides: "Override n"


def overrides(op):
    """{(segment, "Interior" or "Exterior"): "Override n"} from a wall's Segment Overrides,
    segments 0-based along every run in turn; a later row wins where two pick the same
    face. Rows without a material are left out (the face keeps its own)."""
    import aw_ids as I
    out = {}
    n = max(0, min(int(aw_host.value(op, I.AW_WALL_OVERRIDES) or 0), I.MAX_OVERRIDES))
    for i in range(n):
        if aw_host.link(op, I.wall_override(i, 2)) is None:
            continue
        seg = int(aw_host.value(op, I.wall_override(i, 0)) or 1) - 1
        face = int(aw_host.value(op, I.wall_override(i, 1)) or 0)
        faces = {I.OVERRIDE_INTERIOR: ("Interior",), I.OVERRIDE_EXTERIOR: ("Exterior",)}.get(face, ("Interior", "Exterior"))
        for f in faces:
            out[(seg, f)] = "Override %d" % (i + 1)
    return out


def build_path_wall(name, plan, height, w0, w1, seg_rects, build=None, overrides=None):
    """A wall along every run of an aw_path.Plan (or a single aw_path.Path), each run
    mitred and welded at its own joints and closed on its own; runs are separate
    solids in one object, never welded to each other.

    seg_rects: {segment index: [(u0, u1, y0, y1), ...]} openings along each segment,
    already clipped to that segment's clear span (global indices for a Plan).
    build: the wall's Build settings (build_settings), or None for a standing wall.
    overrides: {(segment, face): group} (aw_wall.overrides): those faces go to their group.
    The mesh is the same whatever Build's progress, so it keeps its points from
    frame to frame; only Style and Order change it."""
    mesh = MeshBuilder(GROUPS)
    mesh.optional = {name for name, _pid in aw_ids.AW_WALL_OVERRIDE_SLOTS}  # only those in use
    runs = getattr(plan, "runs", None)
    style, order = (build[1], build[2]) if build else (None, None)
    if runs is None:
        _add_run(mesh, plan, height, w0, w1, seg_rects, overrides=overrides)
    else:
        for r, path in enumerate(runs):
            ks = plan.run_segments(r)
            mesh.new_part()
            _add_run(mesh, path, height, w0, w1,
                     {local: seg_rects[k] for local, k in enumerate(ks) if k in seg_rects},
                     r=r, k0=ks[0] if ks else 0,
                     rises=[(plan.segments[k]["ha"], plan.segments[k]["hb"]) for k in ks],
                     edge=style == aw_build.RISE and order == aw_build.SEGMENTS,
                     seam=style == aw_build.TRACE and path.closed,
                     split=style == aw_build.TRACE and order == aw_build.SEGMENTS, overrides=overrides)
        if build:
            deform(plan, height, build, mesh.points, mesh.tags)
    return mesh.build(name)


def build_settings(op):
    """(progress 0..1, style, order, stagger 0..1) from a wall's Build group; walls
    made before it existed read as fully built."""
    def get(pid, default):
        v = aw_host.value(op, pid)
        return default if v is None else v
    return (float(get(aw_ids.AW_WALL_BUILD, 1.0)), int(get(aw_ids.AW_WALL_BUILD_STYLE, 0)),
            int(get(aw_ids.AW_WALL_BUILD_ORDER, 0)), float(get(aw_ids.AW_WALL_BUILD_STAGGER, 0.5)))


WINDOW_SINK = 0.2  # cm a window's flattened parts stay behind the wall's build front
STACK = 0.5  # cm: the band just behind the build front that unbuilt parts are packed into, in order


def _packed(front, value, end):
    """Where an unbuilt part at `value` (past the build front, towards `end`: the top
    for Rise, the run's end for Trace) goes: into the STACK band just behind the front,
    keeping its order, so the wall's own top or end is always the outermost surface
    and nothing lies in the same plane as anything else (no flicker)."""
    span = end - front
    t = min(max((value - front) / span, 0.0), 1.0) if span > 1e-6 else 1.0
    return front - STACK * (1.0 - t)


def deform(plan, height, build, points, tags, sink=0.0):
    """Move points (Vectors in the wall's space, changed in place) to where Build
    has them on this frame. tags: per point (run, global segment, distance along
    the run, offset across it), or None for a point that never moves. sink: how
    far behind the build front these points stop (a window's, so its flattened
    parts never lie in the same plane as the wall's and flicker against them)."""
    progress, style, order, stagger = build
    if progress >= 1.0:
        return
    timing = aw_build.Timing(progress, style, order, stagger, [len(p.segments) for p in plan.runs])
    for p, tag in zip(points, tags):
        if tag is None:
            continue
        r, k, d, w = tag
        if style == aw_build.TRACE and order == aw_build.SEGMENTS:
            seg = plan.segments[k]  # this segment's own front, from its start corner
            f = max(timing.trace_segment(r, k) * seg["length"] - sink, 0.0)
            u = d - plan.start_distance(k)
            if f <= 1e-6:  # not started: flat at its corner, not a sliver
                p.x, p.z = seg["a"][0] + seg["n"][0] * w, seg["a"][1] + seg["n"][1] * w
                p.y = 0.0
            elif u > f + 1e-6:
                fu = max(_packed(f, u, seg["length"]), 0.0)
                p.x = seg["a"][0] + seg["d"][0] * fu + seg["n"][0] * w
                p.z = seg["a"][1] + seg["d"][1] * fu + seg["n"][1] * w
                p.y = min(p.y, plan.top(k, fu, height))  # folded onto the front: no taller than the wall there
        elif style == aw_build.TRACE:
            run = plan.runs[r]
            f = max(timing.trace(r) * run.length - sink, 0.0)
            if f <= 1e-6:  # a run that hasn't started lies flat at its start, not as a sliver
                p.x, p.z = run.at(0.0, w)
                p.y = 0.0
            elif d > f + 1e-6:
                fd = max(_packed(f, d, run.length), 0.0)
                p.x, p.z = run.at(fd, w)
                fk, fu = plan.locate(r, fd)
                p.y = min(p.y, plan.top(fk, fu, height))  # a ridge further on mustn't show at the front
        else:
            top = plan.top(k, d - plan.start_distance(k), height)
            level = timing.rise(r, k) * top
            if level > 1e-6:
                level = max(level - sink, 1e-5)
            if level <= 1e-6:  # not started: folded onto the path's centre line, so nothing shows
                p.x, p.z = plan.runs[r].at(d, 0.0)
                p.y = 0.0
            elif p.y > level:
                p.y = max(_packed(level, p.y, top), 0.0)


def point_tag(plan, k, x, z):
    """The deform tag of a point (x, z) in the wall's space that belongs with global
    segment k (a window's points)."""
    seg = plan.segments[k]
    run = plan.runs[seg["run"]]
    u = (x - seg["a"][0]) * seg["d"][0] + (z - seg["a"][1]) * seg["d"][1]
    w = (x - seg["a"][0]) * seg["n"][0] + (z - seg["a"][1]) * seg["n"][1]
    return seg["run"], k, run.start_distance(seg["local"]) + u, w


def _add_run(mesh, path, height, w0, w1, seg_rects, r=0, k0=0, edge=False, seam=False, split=False,
             rises=None, overrides=None):
    """One run of a path wall into mesh. Each segment is a grid in its own (u, y)
    plane; its first and last columns land on the mitre points, so neighbouring
    segments share those vertices and the run is closed. UVs on both faces run
    along the run's length, continuous round corners.

    rises: per segment (ha, hb), how much taller than height the wall is at its
    start and end; the top runs straight between them (None: level). Window sills
    and heads are level bands shared by the whole run, so corners match; a column
    is added wherever a sloped top crosses a band, so every cell is either a full
    rectangle or has the slope for its top (a triangle where the slope meets the
    band at a column).

    r, k0: the run's index and its first global segment, for the points' build
    tags. edge: add columns just inside each segment's clear span (Segment by
    Segment Rise, so each segment rises on its own; only the mitred corner strip
    is shared). seam: don't weld the run's closing corner (Trace on a closed run:
    its last segment ends where its first starts, and the two must fold apart).
    split: no segment welds to its neighbours (Trace, Segment by Segment: each
    grows from its own corner and meets the next exactly when it is done)."""
    face0, face1 = ("Exterior", "Interior") if path.outside_is_w0() else ("Interior", "Exterior")
    nseg = len(path.segments)
    rises = rises or [(0.0, 0.0)] * nseg
    eps = 1e-4
    # One set of bands for the whole run: a window's sill and head split every
    # segment, so the vertices on a shared corner match on both sides (no T-junctions).
    ys = sorted({0.0, *[v for rs in seg_rects.values() for r in rs for v in r[2:]]})

    anchors = []  # where each segment's slope is measured from and to: its outside corners (Plan.anchor)
    for kk in range(nseg):
        u0_, u1_ = path.along(kk, path.corner(kk, False, w0)), path.along(kk, path.corner(kk, True, w0))
        anchors.append((u0_, u1_) if u1_ - u0_ > eps else (0.0, path.segments[kk]["length"]))

    def seg_T(kk, x):
        """Segment kk's top a distance x along it, carried on past its ends."""
        a_, b_ = rises[kk]
        u0_, u1_ = anchors[kk]
        return height + a_ + (b_ - a_) * ((x - u0_) / (u1_ - u0_) if u1_ - u0_ > eps else 0.0)

    def neighbour(kk, end):
        if nseg < 2:
            return None
        if end:
            return kk + 1 if kk + 1 < nseg else (0 if path.closed else None)
        return kk - 1 if kk > 0 else (nseg - 1 if path.closed else None)

    def corner_top(kk, end, w):
        """The top at a corner point of face w: where the slope really is at that
        point, the higher of the two walls meeting there. So a sloped wall's inner
        and outer corners each sit on its slope (no twist), and the shared vertex is
        the same for both walls."""
        pt = path.corner(kk, end, w)
        t = seg_T(kk, path.along(kk, pt))
        nb = neighbour(kk, end)
        if nb is not None:
            t = max(t, seg_T(nb, path.along(nb, pt)))
        return t

    for k, seg in enumerate(path.segments):
        L, (ax, az), (dx, dz), (nx, nz) = seg["length"], seg["a"], seg["d"], seg["n"]
        ha, hb = rises[k]

        def T(x):
            return seg_T(k, x)

        rects = seg_rects.get(k, [])
        c0, c1 = path.clear_span(k, w0, w1)
        extra = []
        if edge and c1 - c0 > 4 * aw_build.EDGE:  # just inside the clear span, so faces never fold
            extra += [c0 + aw_build.EDGE, c1 - aw_build.EDGE]
        for end, c in ((False, c0), (True, c1)):
            # a corner raised for its neighbour's slope: keep that to the corner strip
            raised = any(corner_top(k, end, w) > T(path.along(k, path.corner(k, end, w))) + eps for w in (w0, w1))
            c = c - aw_build.EDGE if end else c + aw_build.EDGE  # just inside: never on a corner point
            if raised and eps < c < L - eps:
                extra.append(c)
        crossings = ()
        if abs(hb - ha) > eps:  # where the sloped top passes a band (measured between the anchors)
            u0_, u1_ = anchors[k]
            crossings = tuple(u0_ + (u1_ - u0_) * (y - height - ha) / (hb - ha) for y in ys)
            crossings = tuple(x for x in crossings if eps < x < L - eps)
        xs = []
        for x in sorted({0.0, L, *extra, *crossings, *[v for r in rects for v in r[:2]]}):
            if not xs or x - xs[-1] > 1e-3:  # columns this close are one column
                xs.append(x)
            elif x == L:
                xs[-1] = L
        nx_ = len(xs) - 1

        def ftop(i, w):
            """The top at column i on face w (corner columns differ per face)."""
            if i == 0:
                return corner_top(k, False, w)
            if i == nx_:
                return corner_top(k, True, w)
            return T(xs[i])

        tops = [max(ftop(i, w0), ftop(i, w1)) for i in range(nx_ + 1)]
        joint_before = k > 0 or path.closed
        joint_after = k < nseg - 1 or path.closed
        start_u = path.start_distance(k)

        def cells(i):
            """[(bottom, next band)] up the interval between columns i and i+1."""
            top = max(tops[i], tops[i + 1])
            out = []
            for j, yb in enumerate(ys):
                if yb >= top - eps:
                    break
                out.append((yb, ys[j + 1] if j + 1 < len(ys) else float("inf")))
            return out

        grid = [cells(i) for i in range(nx_)]
        group0 = (overrides or {}).get((k0 + k, face0), face0)  # a Segment Override's group, else the face's
        group1 = (overrides or {}).get((k0 + k, face1), face1)

        def hole(i, j):
            yb, nxt = grid[i][j]
            cx, cy = (xs[i] + xs[i + 1]) / 2, (yb + min(nxt, (tops[i] + tops[i + 1]) / 2)) / 2
            return any(r[0] < cx < r[1] and r[2] < cy < r[3] for r in rects)

        solid = [[not hole(i, j) for j in range(len(grid[i]))] for i in range(nx_)]

        def side(i, j):
            """None where the neighbour is solid wall (or the next segment), else its group."""
            if 0 <= i < nx_:
                if j < len(grid[i]):
                    return None if solid[i][j] else "Reveals"
                return "Top"  # above the wall
            if i < 0 and joint_before or i >= nx_ and joint_after:
                return None
            return "Start" if i < 0 else "End"  # an open run's ends

        def P(i, y, w):
            if i == 0:
                x, z = path.corner(k, False, w)
            elif i == nx_:
                x, z = path.corner(k, True, w)
            else:
                x, z = ax + dx * xs[i] + nx * w, az + dz * xs[i] + nz * w
            closing = seam and k == nseg - 1 and i == nx_
            key = k if split else ("closing" if closing else None)
            return mesh.pt(x, y, z, tag=(r, k0 + k, start_u + xs[i], w), seam=key)

        def face(a, b, c, d, group, uv=None):
            """A quad; a triangle where two of its corners are the same point; two
            triangles, split along the shorter diagonal, where it isn't flat (a corner
            raised to meet a slope), so no renderer or exporter has to guess."""
            pts = [a, b, c, d]
            uniq = [p for n, p in enumerate(pts) if p != pts[n - 1]]
            if len(uniq) == 4:
                va, vb, vc, vd = (mesh.points[n] for n in pts)
                nrm = (vb - va).Cross(vc - va)
                if nrm.GetLength() > 1e-9 and abs((vd - va).Dot(nrm.GetNormalized())) > 1e-3:
                    uv = uv or [None] * 4
                    if (vb - vd).GetLength() < (va - vc).GetLength():
                        halves = ((0, 1, 3), (1, 2, 3))
                    else:
                        halves = ((0, 1, 2), (0, 2, 3))
                    for h in halves:
                        tri_uv = [uv[n] for n in h] + [uv[h[2]]] if uv[0] is not None else None
                        mesh.quad(pts[h[0]], pts[h[1]], pts[h[2]], pts[h[2]], group, tri_uv)
                    return
                mesh.quad(a, b, c, d, group, uv)
            elif len(uniq) == 3:
                keep = [n for n, p in enumerate(pts) if p != pts[n - 1]]
                mesh.quad(uniq[0], uniq[1], uniq[2], uniq[2], group,
                          [uv[n] for n in keep] + [uv[keep[2]]] if uv else None)

        for i in range(nx_):
            for j, (y0, nxt) in enumerate(grid[i]):
                if not solid[i][j]:
                    continue
                # tops at the left and right columns, per face; never below the cell's bottom
                l0, l1 = (max(y0, min(nxt, ftop(i, w))) for w in (w0, w1))
                r0, r1 = (max(y0, min(nxt, ftop(i + 1, w))) for w in (w0, w1))
                u0, u1 = start_u + xs[i], start_u + xs[i + 1]
                face(P(i, y0, w0), P(i, l0, w0), P(i + 1, r0, w0), P(i + 1, y0, w0), group0,
                     uv=[(u0, y0), (u0, l0), (u1, r0), (u1, y0)])
                face(P(i + 1, y0, w1), P(i + 1, r1, w1), P(i, l1, w1), P(i, y0, w1), group1,
                     uv=[(-u1, y0), (-u1, r1), (-u0, l1), (-u0, y0)])
                g = side(i - 1, j)
                if g and max(l0, l1) > y0 + eps:
                    face(P(i, y0, w1), P(i, l1, w1), P(i, l0, w0), P(i, y0, w0), g)
                g = side(i + 1, j)
                if g and max(r0, r1) > y0 + eps:
                    face(P(i + 1, y0, w0), P(i + 1, r0, w0), P(i + 1, r1, w1), P(i + 1, y0, w1), g)
                g = side(i, j - 1) if j > 0 else "Bottom"
                if g:
                    face(P(i, y0, w0), P(i + 1, y0, w0), P(i + 1, y0, w1), P(i, y0, w1), g)
                g = side(i, j + 1)
                if g:
                    face(P(i, l1, w1), P(i + 1, r1, w1), P(i + 1, r0, w0), P(i, l0, w0), g)


_paths = {}  # wall identity -> (path key, wall_path result): see wall_path


# The path: the wall's curves, read by the host as runs (aw_path.Plan).

ALIGN_NAMES = {aw_ids.AW_ALIGN_CENTER: "center", aw_ids.AW_ALIGN_INSIDE: "inside",
               aw_ids.AW_ALIGN_OUTSIDE: "outside"}


def build_key(op, path, w0, w1, height, segs, build):
    """Everything a wall's mesh is built from: equal keys mean the same mesh. Here,
    in lib, so adding to it never needs a restart (point heights were missed once)."""
    return (aw_host.name(op), tuple(path.points), path.closed, tuple(getattr(path, "heights", ())), w0, w1, height,
            tuple((k, tuple(v)) for k, v in sorted(segs.items())), build, tuple(sorted(overrides(op).items())))


def wall_path(op):
    """(plan, w0, w1, height, splines) for a wall with path splines, else None. The
    plan (aw_path.Plan) holds every run of every spline child, its point indices
    counting through the splines in order; splines is the host's handle on them
    (aw_host.wall_curves).

    Cached per wall until the wall or one of its splines changes: the wall and
    every window on it ask on every scene pass, and rebuilding the plan each
    time made an idle 200-wall scene five times slower."""
    ident = aw_host.ident(op)
    key = aw_host.path_key(op)
    hit = _paths.get(ident)
    if hit is not None and hit[0] == key:
        return hit[1]
    result = _wall_path(op)
    if len(_paths) > 20000:  # walls come and go; never let this grow without bound
        _paths.clear()
    _paths[ident] = (key, result)
    return result


def _wall_path(op):
    curves = aw_host.wall_curves(op)
    if curves is None:
        return None
    splines, runs, every, rises = curves
    path = aw_path.Plan(runs, every, rises)
    if not path.segments:
        return None
    spline = splines
    thick = max(aw_host.value(op, aw_ids.AW_WALL_THICKNESS), aw_ids.MIN_SIZE)
    height = max(aw_host.value(op, aw_ids.AW_WALL_HEIGHT), aw_ids.MIN_SIZE)
    align = ALIGN_NAMES.get(aw_host.value(op, aw_ids.AW_WALL_ALIGN) or 0, "center")
    w0, w1 = path.band(thick, align)
    path.anchor(w0)  # slopes run between the outside corners: no level strip at a gable's eave
    return path, w0, w1, height, spline


def path_opening(child, path, height):
    """(segment, u0, u1, y0, y1, centre u) a child cuts in a path wall, unclipped (a row
    of windows: its first, path_openings has them all). An AW Opening's span runs along
    its segment; on a wall whose Outside is the +n side the window is turned round, so
    its span runs the other way."""
    return path_openings(child, path, height)[0]


def path_openings(child, path, height):
    """[(segment, u0, u1, y0, y1, centre u)] of every hole a child cuts in a path wall:
    one, or a window row's (Count, Spacing apart), in the order it builds them."""
    pos = aw_host.local_matrix(child).off
    k, uc, _dist = path.project(pos.x, pos.z)
    if aw_ids.is_opening(child):
        v = lambda pid: aw_host.value(child, pid)  # noqa: E731
        s, w = v(aw_ids.AW_OPENING_START), max(v(aw_ids.AW_OPENING_WIDTH), aw_ids.MIN_SIZE)
        y0 = pos.y + v(aw_ids.AW_OPENING_SILL)
        y1 = y0 + max(v(aw_ids.AW_OPENING_HEIGHT), aw_ids.MIN_SIZE)
        n, step = 1, 0.0
        if aw_host.type_id(child) == aw_ids.ID_AW_OPENING:
            n = max(1, min(int(v(aw_ids.AW_OPENING_COUNT) or 1), 20))
            step = w + max(v(aw_ids.AW_OPENING_SPACING) or 0.0, 0.0)
        out = []
        for i in range(n):
            a = s + i * step
            u0, u1 = (uc + a, uc + a + w) if path.outside_is_w0() else (uc - a - w, uc - a)
            out.append((k, u0, u1, y0, y1, uc))
        return out
    size = aw_host.box_size(child)
    return [(k, uc - size.x / 2, uc + size.x / 2, pos.y - size.y / 2, pos.y + size.y / 2, uc)]


JOINT_GAP = 0.5  # cm an opening stays clear of a joint between segments, and below a sloped top


def _joint(path, k, end):
    """True when segment k meets another segment at its end (or start)."""
    runs = getattr(path, "runs", None)
    if runs is None:
        n, closed, local = len(path.segments), path.closed, k
    else:
        seg = path.segments[k]
        run = runs[seg["run"]]
        n, closed, local = len(run.segments), run.closed, seg["local"]
    return closed or (local < n - 1 if end else local > 0)


def path_rects(op, path, w0, w1, height, spline):
    """{segment: [(u0, u1, y0, y1), ...]} of every enabled opening, clipped to its
    segment's clear span and the wall height. Cutters are hidden; AW Openings and the
    path spline stay visible."""
    import aw_openings  # (it imports this module)
    out = {}
    for child, (k, u0, u1, y0, y1, _uc) in ((c, h) for c in aw_host.cutters(op, hide=True)  # its children but the
                                            for h in path_openings(c, path, height)):  # path splines; a row: each
        u0, u1, y0, y1 = aw_openings.hole_rect(child, u0, u1, y0, y1)  # opening with its window's own build
        c0, c1 = path.clear_span(k, w0, w1)
        seg = path.segments[k]
        if c0 < JOINT_GAP and _joint(path, k, False):  # keep clear of a joint: the reveal belongs here
            c0 = JOINT_GAP
        if c1 > seg["length"] - JOINT_GAP and _joint(path, k, True):
            c1 = seg["length"] - JOINT_GAP
        u0, u1 = max(u0, c0), min(u1, c1)
        t0, t1 = (path.top(k, u0, height), path.top(k, u1, height)) if hasattr(path, "top") else (height, height)
        top = min(t0, t1)
        if abs(t0 - t1) > 1e-4:  # under a slope: keep a sliver of wall above, or the wall pinches to a line
            top -= JOINT_GAP
        y0, y1 = max(y0, 0.0), min(y1, top)  # never through a sloped top
        if u1 - u0 > 1e-4 and y1 - y0 > 1e-4:
            out.setdefault(k, []).append((u0, u1, y0, y1))
    return out


def opening_frame(child, path, w0, w1):
    """The matrix that carries a window built along +X (Outside towards -Z) onto its
    segment, expressed in the opening's own space: it faces along the wall whichever
    way the opening object itself is turned."""
    ml = aw_host.local_matrix(child)
    pos = ml.off
    k, uc, _d = path.project(pos.x, pos.z)
    seg = path.segments[k]
    (ax, az), (dx, dz), (nx, nz) = seg["a"], seg["d"], seg["n"]
    wc = (w0 + w1) / 2
    origin = Vec(ax + dx * uc + nx * wc, pos.y, az + dz * uc + nz * wc)
    if path.outside_is_w0():
        v1, v3 = Vec(dx, 0, dz), Vec(nx, 0, nz)
    else:  # turned round, so its Outside still faces out
        v1, v3 = Vec(-dx, 0, -dz), Vec(-nx, 0, -nz)
    frame = Mat(origin, v1, Vec(0, 1, 0), v3)
    return ~ml * frame
