"""Archwerks door geometry: what a Door draws in its hole.

Laid out like Archipack's doors. Built in the door's own space, like a window:
the hole spans x0..x1 by y0..y1 (y0 is the floor, or the Sill Height), and the
wall runs z -thick/2 (Outside) .. +thick/2. Open picks the side the door swings
(or slides) to: Inside (+z, into the room) or Outside. Sizes in cm. Every part is
its own closed box.

Frame (Main tab):
- Shape: Single Rabbet (a stop behind the leaf), Double Rabbet (a stop at each
  face), or Cased Opening (a frame and no leaf at all).
- Layout: Encompass (jambs through the wall, casings on both faces), Fit (jambs
  through the wall, no casings), Inside (jambs Jamb Depth deep at the opening
  face, no casings), In Front (jambs through the wall, a casing on the opening
  face only).
- Jamb (the jambs' thickness), Stop and Stop Width (how far the stop stands off
  the jamb, and how deep it is), Rabbet (how far the leaf sits back from the
  opening face), Face and Backbend (casing width and thickness).

Leaves: 1 or 2 across the clear opening, Hinge (a single leaf's hinge side, seen
from outside). Types:
- Hinged: Open (0..1) swings the leaves through Max Angle about their hinges.
- Sliding: a barn door hung in front of the opening face, overlapping the
  opening, on a track; Open slides it towards its Hinge side (a pair parts).
- Pocket: the leaves slide into the wall on the Hinge side; Open slides them
  in (a pair parts, one into each side).

Leaf models (Parts tab): Flat, Panel (recessed panels), Bevel (raised panels),
Glass (lites), Half Lite (glass in the top row, recessed panels below). Panels are # h across by # v up, inside a Border (stiles and
rails; the bottom rail Bottom taller), Spacing between them; Distribution
Regular, 1/3 2/3 (with two rows up, the lower one twice the upper) or Colonial (the
top row short, the rest even: a 6 panel door). Bevel is
the recess (Panel) or chamfer (Bevel).

Also: Handle (any aw_handles type, a Custom one included, at Altitude above
the floor, Inside, Outside or Both; on the free edge, its lever towards the
hinge), Step (a threshold under the leaf) and Sill (outside, under the
threshold line).
"""
import math

import aw_handles as H
from aw_mesh import MeshBuilder

GROUPS = ("Leaf", "Panel", "Frame", "Casing", "Glass", "Handle", "Sill", "Step")

HINGED, SLIDING, POCKET, GARAGE = 0, 1, 2, 3  # Garage: a sectional overhead door
TYPE_KEYS = {HINGED: "Hinged", SLIDING: "Sliding", POCKET: "Pocket", GARAGE: "Garage"}
OPEN_INSIDE, OPEN_OUTSIDE = 0, 1
HINGE_LEFT, HINGE_RIGHT = 0, 1
SINGLE_RABBET, DOUBLE_RABBET, CASED = 0, 1, 2
ENCOMPASS, FIT, INSIDE, IN_FRONT = 0, 1, 2, 3
FLAT, PANEL, BEVEL, GLASS, HALF_LITE = 0, 1, 2, 3, 4  # Half Lite: glass in the top row, recessed panels below
REGULAR, ONE_THIRD, COLONIAL = 0, 1, 2  # Colonial: the top row short, as a 6 panel door's
COLONIAL_TOP = 0.2  # the share of a Colonial leaf's field its top row takes
LEVER, KNOB, PULL, FLUSH = H.LEVER, H.KNOB, H.PULL, H.FLUSH
HANDLE_NONE, HANDLE_INSIDE, HANDLE_OUTSIDE, HANDLE_BOTH = 0, 1, 2, 3

GAP = 0.3         # cm round a leaf, sides and top
UNDERCUT = 1.0    # cm under a leaf
GLASS_D = 0.6
SLIDE_LAP = 5.0   # cm a sliding (barn) door overlaps the opening each side
TRACK_H = 4.0     # its track's height above the opening
SECTION_JOINT = 0.4   # cm between a garage door's sections
PANEL_RAISE = 1.0     # cm a garage door's panels stand proud of its sections
HEAD_CLEAR = 2.0      # cm an open garage door's sections ride above the opening's head
PIN_CLEAR = 0.1   # cm a leaf swung right round stands off the casing


class Style:
    """Everything a door is built from, besides its hole (all defaults: a closed,
    single flat hinged door in an encompassing single-rabbet frame)."""

    FIELDS = (("kind", HINGED), ("open_side", OPEN_INSIDE), ("hinge", HINGE_LEFT), ("leaves", 1),
              ("opened", 0.0), ("max_angle", math.radians(90.0)),
              ("frame", True), ("shape", SINGLE_RABBET), ("layout", ENCOMPASS), ("jamb", 1.9),
              ("stop", 1.3), ("stop_w", 3.8), ("rabbet", 0.0), ("face", 5.715), ("backbend", 1.905),
              ("jamb_depth", 10.0),
              ("leaf_d", 3.5), ("model", FLAT), ("distrib", REGULAR), ("panels_h", 1), ("panels_v", 2),
              ("panel_bottom", 0.0), ("spacing", 10.0), ("border", 12.0), ("bevel", 0.5),
              ("handle_type", LEVER), ("handle_alt", 91.44), ("handle_side", HANDLE_BOTH),
              ("step", False), ("step_h", 1.0),
              ("sill_on", False), ("sill_w", 4.0), ("sill_d", 4.0), ("sill_h", 3.0))

    def __init__(self, **values):
        for name, default in self.FIELDS:
            setattr(self, name, values.pop(name, default))
        if values:
            raise TypeError("unknown door settings: %s" % ", ".join(values))

    def key(self):
        return tuple(getattr(self, name) for name, _d in self.FIELDS)


def _rotate(mesh, first, hx, hz, a):
    """Turn the points from index first on by a about a vertical axis at (hx, hz)."""
    c, s = math.cos(a), math.sin(a)
    for p in mesh.points[first:]:
        dx, dz = p.x - hx, p.z - hz
        p.x, p.z = hx + c * dx + s * dz, hz - s * dx + c * dz


def _shift(mesh, first, dx):
    for p in mesh.points[first:]:
        p.x += dx


# The frame ------------------------------------------------------------------------

def _frame(mesh, x0, x1, y0, y1, thick, s, sz, leaf_back):
    """Jambs, head, stops and casings. Returns the clear opening (cx0, cx1, cy1)."""
    if not s.frame:
        return x0, x1, y1
    j = max(s.jamb, 0.1)
    zs = sz * thick / 2   # the opening face
    if s.layout == INSIDE:
        za, zb = sorted((zs, zs - sz * min(max(s.jamb_depth, 0.1), thick)))
    else:
        za, zb = -thick / 2, thick / 2
    mesh.box(x0, x0 + j, y0, y1, za, zb, "Frame")
    mesh.box(x1 - j, x1, y0, y1, za, zb, "Frame")
    mesh.box(x0 + j, x1 - j, y1 - j, y1, za, zb, "Frame")
    cx0, cx1, cy1 = x0 + j, x1 - j, y1 - j
    if s.shape != CASED and s.kind == HINGED:  # stops on the jambs and head
        st, sw = max(s.stop, 0.05), max(s.stop_w, 0.1)
        faces = [leaf_back]                     # behind the leaf
        if s.shape == DOUBLE_RABBET:
            faces.append(-zs + sz * max(s.rabbet, 0.0) + sz * sw)  # and at the far face
        for zf in faces:
            a, b = sorted((zf, zf - sz * sw))
            a, b = max(a, za), min(b, zb)
            if b - a > 0.05:
                mesh.box(cx0, cx0 + st, y0, cy1 - st, a, b, "Frame")
                mesh.box(cx1 - st, cx1, y0, cy1 - st, a, b, "Frame")
                mesh.box(cx0, cx1, cy1 - st, cy1, a, b, "Frame")
    if s.layout in (ENCOMPASS, IN_FRONT):  # casings
        f, bb = max(s.face, 0.1), max(s.backbend, 0.05)
        sides = (sz,) if s.layout == IN_FRONT else (1, -1)
        for side in sides:
            zf = side * thick / 2
            a, b = sorted((zf, zf + side * bb))
            mesh.box(x0 - f, x0, y0, y1 + f, a, b, "Casing")
            mesh.box(x1, x1 + f, y0, y1 + f, a, b, "Casing")
            mesh.box(x0, x1, y1, y1 + f, a, b, "Casing")
    return cx0, cx1, cy1


# Leaves ---------------------------------------------------------------------------

def _rows(s, y0, y1):
    """[(y0, y1)] of the panel rows up the leaf's field."""
    n = max(1, int(s.panels_v))
    avail = y1 - y0 - s.spacing * (n - 1)
    if s.distrib == ONE_THIRD and n == 2:
        heights = [avail * 2 / 3, avail / 3]
    elif s.distrib == COLONIAL and n >= 2:
        top = avail * COLONIAL_TOP
        heights = [(avail - top) / (n - 1)] * (n - 1) + [top]
    else:
        heights = [avail / n] * n
    out, y = [], y0
    for h in heights:
        out.append((y, y + h))
        y += h + s.spacing
    return out


def _leaf(mesh, x0, x1, y0, y1, za, zb, s):
    """One leaf: a slab (Flat), or stiles and rails round # h x # v panels."""
    if s.model == FLAT:
        mesh.box(x0, x1, y0, y1, za, zb, "Leaf")
        return
    b = min(max(s.border, 1.0), (x1 - x0) / 3, (y1 - y0) / 4)
    fx0, fx1 = x0 + b, x1 - b
    fy0, fy1 = y0 + b + max(s.panel_bottom, 0.0), y1 - b
    cols = max(1, int(s.panels_h))
    sp = max(s.spacing, 0.5)
    if fx1 - fx0 < cols * 2 + sp * (cols - 1) or fy1 - fy0 < 4:
        mesh.box(x0, x1, y0, y1, za, zb, "Leaf")
        return
    mesh.box(x0, fx0, y0, y1, za, zb, "Leaf")        # stiles
    mesh.box(fx1, x1, y0, y1, za, zb, "Leaf")
    mesh.box(fx0, fx1, y0, fy0, za, zb, "Leaf")      # bottom rail
    mesh.box(fx0, fx1, fy1, y1, za, zb, "Leaf")      # top rail
    rows = _rows(s, fy0, fy1)
    pw = (fx1 - fx0 - sp * (cols - 1)) / cols
    zc, d = (za + zb) / 2, zb - za
    for r, (ry0, ry1) in enumerate(rows):
        if r > 0:  # a lock or mid rail
            mesh.box(fx0, fx1, ry0 - sp, ry0, za, zb, "Leaf")
        for c in range(cols):
            px0 = fx0 + c * (pw + sp)
            px1 = px0 + pw
            if c > 0:  # a muntin between panels
                mesh.box(px0 - sp, px0, ry0, ry1, za, zb, "Leaf")
            if s.model == GLASS or (s.model == HALF_LITE and r == len(rows) - 1):
                mesh.box(px0, px1, ry0, ry1, zc - GLASS_D / 2, zc + GLASS_D / 2, "Glass")
            elif s.model in (PANEL, HALF_LITE):  # recessed both faces
                r_ = min(max(s.bevel, 0.05), d / 3)
                mesh.box(px0, px1, ry0, ry1, za + r_, zb - r_, "Panel")
            else:  # raised: chamfered on both faces, from the mid plane
                r_ = min(max(s.bevel, 0.05), d / 4)
                inset = min(4 * r_ + 1.0, (px1 - px0) / 3, (ry1 - ry0) / 3)
                mesh.frustum(px0, px1, ry0, ry1, zc, zb - r_, 0.0, inset, "Panel")
                mesh.frustum(px0, px1, ry0, ry1, za + r_, zc, inset, 0.0, "Panel")


def _handle(mesh, s, x, y, za, zb, towards, custom):
    """The handle on a leaf's faces at (x, y), its lever pointing `towards` (+1 or -1
    along x: the hinge), on the inside face, the outside one or both."""
    faces = []
    if s.handle_side in (HANDLE_INSIDE, HANDLE_BOTH):
        faces.append((zb, 1))
    if s.handle_side in (HANDLE_OUTSIDE, HANDLE_BOTH):
        faces.append((za, -1))
    for z, d in faces:
        H.build(mesh, int(s.handle_type), H.place((x, y, z), (towards, 0, 0), (0, 0, d), (0, 1, 0)), "Handle",
                custom)


def build(name, x0, x1, y0, y1, thick, style=None, custom=None):
    """The door for a hole x0..x1 by y0..y1 in a wall thick deep, as `style`;
    custom: a Custom handle's (points, polys) (aw_host.custom_mesh)."""
    s = style or Style()
    mesh = MeshBuilder(GROUPS)
    sz = 1 if s.open_side == OPEN_INSIDE else -1
    zs = sz * thick / 2
    d = min(max(s.leaf_d, 0.5), thick if s.kind != SLIDING else 20.0)
    floor = y0 + (max(s.step_h, 0.05) if s.step else 0.0)

    # where a hinged leaf sits: its opening face Rabbet back from the opening face
    if s.kind == POCKET:
        lza, lzb = -d / 2, d / 2
    elif s.kind == SLIDING:
        stand = (max(s.backbend, 0.05) if s.frame and s.layout in (ENCOMPASS, IN_FRONT) else 0.0) + 1.0
        lza, lzb = sorted((zs + sz * stand, zs + sz * (stand + d)))
    else:
        front = zs - sz * min(max(s.rabbet, 0.0), max(thick - d, 0.0))
        lza, lzb = sorted((front, front - sz * d))
    leaf_back = (lza if sz > 0 else lzb)
    # a hinge pin half what stands in front of the leaf (its rabbet, the casing) out from
    # its face, so swung right round (180) it lies back against the casing, clear of it
    proud = max(s.backbend, 0.05) if s.frame and s.shape != CASED and s.layout in (ENCOMPASS, IN_FRONT) else 0.0
    pin = (abs(zs - (lzb if sz > 0 else lza)) + proud) / 2 + PIN_CLEAR

    cx0, cx1, cy1 = _frame(mesh, x0, x1, y0, y1, thick, s, sz, leaf_back)
    if s.step:  # between the jambs
        mesh.box(cx0, cx1, y0, floor, -thick / 2, thick / 2, "Step")
    if s.sill_on:
        mesh.box(x0 - s.sill_w, x1 + s.sill_w, y0 - max(s.sill_h, 0.1), y0,
                 -thick / 2 - max(s.sill_d, 0.1), -thick / 2, "Sill")

    if s.frame and s.shape == CASED:
        return mesh.build(name)  # a cased opening: no leaf

    n = 2 if int(s.leaves) >= 2 else 1
    if s.kind == SLIDING:
        lx0, lx1, ly1 = cx0 - SLIDE_LAP, cx1 + SLIDE_LAP, cy1 + SLIDE_LAP
        ly0 = floor + UNDERCUT
        w = (lx1 - lx0) / n
        left = n == 2 or s.hinge == HINGE_LEFT    # the track runs out over where it slides to
        right = n == 2 or s.hinge == HINGE_RIGHT
        mesh.box(lx0 - (w if left else 0.0), lx1 + (w if right else 0.0), ly1, ly1 + TRACK_H, lza, lzb, "Handle")
    else:
        lx0, lx1, ly1 = cx0 + GAP, cx1 - GAP, cy1 - GAP
        ly0 = floor + UNDERCUT
        w = (lx1 - lx0 - (GAP if n == 2 else 0.0)) / n
    if lx1 - lx0 < 2 or ly1 - ly0 < 2:
        return mesh.build(name)
    if s.kind == GARAGE:
        _garage(mesh, lx0, lx1, ly0, ly1, lza, lzb, sz, s)
        return mesh.build(name)

    for i in range(n):
        if n == 1:
            hinge_left = s.hinge == HINGE_LEFT
            a0, a1 = lx0, lx1
        else:
            hinge_left = i == 0
            a0 = lx0 + i * (w + (GAP if s.kind != SLIDING else 0.0))
            a1 = a0 + w
        first = len(mesh.points)
        _leaf(mesh, a0, a1, ly0, ly1, lza, lzb, s)
        hy = min(max(y0 + s.handle_alt, ly0 + 8.0), ly1 - 8.0)
        if s.handle_side != HANDLE_NONE:
            inset = 5.0 if s.handle_type in (H.PULL, H.FLUSH) else 6.5
            hx = a1 - inset if hinge_left else a0 + inset
            _handle(mesh, s, hx, hy, lza, lzb, -1 if hinge_left else 1, custom)
        t = min(max(s.opened, 0.0), 1.0)
        if t <= 0:
            continue
        if s.kind == HINGED:
            angle = t * min(max(s.max_angle, 0.0), math.pi)
            hx = a0 if hinge_left else a1
            hz = (lzb if sz > 0 else lza) + sz * pin  # the hinge pin, out from the opening face
            _rotate(mesh, first, hx, hz, angle * (-sz if hinge_left else sz))
        else:  # slide towards the Hinge side (into the wall there, for a pocket); a pair parts
            travel = (a1 - a0) * t * (0.98 if s.kind == POCKET else 1.0)
            _shift(mesh, first, -travel if hinge_left else travel)
    return mesh.build(name)


def _garage(mesh, x0, x1, y0, y1, za, zb, sz, s):
    """A sectional overhead door filling x0..x1 by y0..y1, its sections za..zb deep (on
    the room side): # v sections (panels_v) up it, each with # h panels across (panels_h)
    Border in from its sides and Spacing apart, raised (Panel), bevelled (Bevel), none
    (Flat), or the top section's glass (Glass). Open rolls them up and back over the
    room, the top one first, as a door on its tracks does; one under way stays upright
    till it's clear of the head."""
    n = max(1, int(s.panels_v))
    height = y1 - y0
    hs = height / n
    t = min(max(s.opened, 0.0), 1.0)
    travel = t * height
    face_out, out = (za, -1.0) if sz > 0 else (zb, 1.0)  # the face toward the outside, and which way that is
    face_in = zb if sz > 0 else za
    depth = zb - za
    for i in range(n):
        along = i * hs + travel  # its bottom, along the track from the floor
        if along + hs <= height + 1e-6:  # upright, in the opening
            b0, b1 = y0 + along + SECTION_JOINT / 2, y0 + along + hs - SECTION_JOINT / 2
            mesh.box(x0, x1, b0, b1, za, zb, "Leaf")
            _garage_panels(mesh, x0, x1, b0, b1, face_out, out, s, glass=s.model == GLASS and i == n - 1)
        else:  # over the room, under the head
            r0 = along - (height - hs)  # how far in past the head its near edge has gone
            ya = y1 + HEAD_CLEAR
            a, b = sorted((face_in + sz * (r0 - hs + SECTION_JOINT / 2), face_in + sz * (r0 - SECTION_JOINT / 2)))
            mesh.box(x0, x1, ya, ya + depth, a, b, "Leaf")


def _garage_panels(mesh, x0, x1, y0, y1, face, out, s, glass=False):
    """One section's panels on its outside face (out: which way that faces)."""
    if s.model == FLAT and not glass:
        return
    cols = max(1, int(s.panels_h))
    side = min(max(s.border, 0.5), (x1 - x0) / 4)
    rim = min(side, (y1 - y0) * 0.2)
    gap = max(s.spacing, 0.5)
    w = (x1 - x0 - 2 * side - gap * (cols - 1)) / cols
    if w < 1.0 or y1 - y0 - 2 * rim < 1.0:
        return
    for k in range(cols):
        a = x0 + side + k * (w + gap)
        if glass:  # a pane set in, a rim of section round it
            za, zb = sorted((face - out * 0.6, face + out * 0.2))
            mesh.box(a, a + w, y0 + rim, y1 - rim, za, zb, "Glass")
        elif s.model == BEVEL:  # raised and bevelled
            inset = min(s.bevel * 3.0, w / 4, (y1 - y0 - 2 * rim) / 4)
            za, zb = sorted((face, face + out * PANEL_RAISE))
            ins = (inset, 0.0) if out < 0 else (0.0, inset)  # narrower at its outer face
            mesh.frustum(a, a + w, y0 + rim, y1 - rim, za, zb, ins[0], ins[1], "Panel")
        else:  # raised, square
            za, zb = sorted((face, face + out * PANEL_RAISE))
            mesh.box(a, a + w, y0 + rim, y1 - rim, za, zb, "Panel")


def settings(op):
    """The Style of a Door; parameters it predates read as their defaults."""
    import aw_host
    import aw_ids as I
    defaults = dict(Style.FIELDS)
    values = {}
    for name, pid in I.AW_DOOR_STYLE_PARAMS:
        v = aw_host.value(op, pid)
        values[name] = defaults[name] if v is None else type(defaults[name])(v)
    return Style(**values)


def custom_handle(op):
    """(change key, (points, polys)) of a Custom handle's linked object, or (None, None)."""
    import aw_host
    import aw_ids as I
    if aw_host.value(op, I.AW_DOOR_HANDLE_TYPE) != H.CUSTOM:
        return None, None
    obj = aw_host.link(op, I.AW_DOOR_HANDLE_CUSTOM)
    return aw_host.custom_key(obj), aw_host.custom_mesh(obj)
