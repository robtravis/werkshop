"""Archwerks default materials, host-neutral: which default material goes in which
material slot of each object, and what each one looks like, so a new window has the
same frame, glass and sill in Cinema 4D and in Blender.

Cinema 4D copies them from its Redshift library (res/aw_materials.c4d, src/aw_materials.py);
Blender makes them from LOOKS (blender/materials.py): the library's own OpenPBR values,
read from it (base colour, specular roughness and IOR, metalness, transmission).
"""
import aw_ids as I

DEFAULTS = {
    I.ID_AW_WALL: {"Exterior": "AW Wall Exterior", "Interior": "AW Wall Interior", "Top": "AW Wall Exterior",
                   "Bottom": "AW Wall Exterior", "Start": "AW Wall Exterior", "End": "AW Wall Exterior",
                   "Reveals": "AW Wall Exterior"},
    I.ID_AW_MOLDING: {"Molding": "AW Window Frame"},
    I.ID_AW_ROOF: {"Covering": "AW Roof Asphalt", "Soffit": "AW Window Frame", "Edge": "AW Window Frame",
                   "Fascia": "AW Window Frame", "Bargeboard": "AW Window Frame", "Rafters": "AW Floor",
                   "Tiles": "AW Roof Asphalt"},  # asphalt granules, each tile its own shade (the Tint vertex colour)
    I.ID_AW_BEAM: {"Beam": "AW Floor"},
    I.ID_AW_COUNTERTOP: {"Top": "AW Countertop", "Bottom": "AW Countertop", "Edge": "AW Countertop",
                         "Backsplash": "AW Countertop", "Sink": "AW Stainless", "Cooktop": "AW Cooktop Glass"},
    I.ID_AW_CABINET: {"Fronts": "AW Window Frame", "Carcass": "AW Window Frame", "Shelves": "AW Window Frame",
                      "Toe Kick": "AW Window Frame", "Glass": "AW Window Glass", "Pulls": "AW Window Sill"},
    I.ID_AW_RAILING: {"Posts": "AW Window Frame", "Handrail": "AW Floor", "Rails": "AW Window Frame",
                      "Pickets": "AW Window Frame", "Panels": "AW Window Glass"},
    I.ID_AW_STAIR: {"Treads": "AW Floor", "Risers": "AW Window Frame", "Structure": "AW Wall Interior",
                    "Stringers": "AW Window Frame"},
    I.ID_AW_DOOR: {"Leaf": "AW Window Frame", "Panel": "AW Window Frame", "Frame": "AW Window Frame",
                   "Casing": "AW Window Frame", "Glass": "AW Window Glass", "Handle": "AW Window Sill",
                   "Sill": "AW Window Sill", "Step": "AW Window Sill"},
    I.ID_AW_WALL_PANELS: {"Frames": "AW Wall Interior", "Flourishes": "AW Wall Interior"},  # painted with the wall
    I.ID_AW_FIREPLACE: {"Surround": "AW Cast Stone", "Mantel": "AW Cast Stone", "Hearth": "AW Countertop",
                        "Firebox": "AW Firebox", "Back": "AW Wall Exterior", "Grate": "AW Black Iron",
                        "Logs": "AW Logs", "Log Ends": "AW Log Ends", "Insert Frame": "AW Black Iron",
                        "Glass": "AW Window Glass", "Screen": "AW Chain Screen", "Handle": "AW Brass"},
    I.ID_AW_OPENING: {"Frame": "AW Window Frame", "Sash": "AW Window Frame", "Glass": "AW Window Glass",
                      "Sill": "AW Window Sill", "Trim": "AW Window Frame",
                      "Casing": "AW Window Frame", "SillIn": "AW Window Sill", "Handle": "AW Window Frame",
                      "Shutters": "AW Window Frame", "Blinds": "AW Shade Fabric"},
}


FLOOR_DEFAULTS = {"Top": "AW Floor", "Bottom": "AW Ceiling", "Edge": "AW Wall Exterior"}
CEILING_DEFAULTS = {"Top": "AW Ceiling", "Bottom": "AW Ceiling", "Edge": "AW Ceiling"}


def defaults_for(kind, slab_type=0):
    """{slot name: default material name} for an object of kind (a Slab: of slab_type)."""
    if kind == I.ID_AW_FLOOR:
        return FLOOR_DEFAULTS
    if kind == I.ID_AW_CEILING:
        return CEILING_DEFAULTS
    if kind == I.ID_AW_SLAB:
        return CEILING_DEFAULTS if slab_type == 1 else FLOOR_DEFAULTS
    return DEFAULTS.get(kind)


# The library's materials (OpenPBR): base colour, specular roughness, metalness,
# transmission weight, specular IOR.
LOOKS = {
    "AW Wall Exterior": ((0.74, 0.72, 0.68), 0.85, 0.0, 0.0, 1.5),
    "AW Wall Interior": ((0.86, 0.86, 0.84), 0.9, 0.0, 0.0, 1.5),   # matte paint
    "AW Window Frame": ((0.86, 0.86, 0.84), 0.5, 0.0, 0.0, 1.5),    # the walls' white in satin: all the trim
    "AW Window Glass": ((0.16, 0.2, 0.23), 0.0, 0.0, 1.0, 1.5),
    "AW Window Sill": ((0.68, 0.67, 0.64), 0.6, 0.0, 0.0, 1.5),
    "AW Floor": ((0.62, 0.48, 0.33), 0.45, 0.0, 0.0, 1.5),
    "AW Ceiling": ((0.9, 0.9, 0.89), 0.9, 0.0, 0.0, 1.5),
    "AW Roof": ((0.16, 0.17, 0.19), 0.8, 0.0, 0.0, 1.5),
    "AW Roof Asphalt": ((0.045, 0.043, 0.043), 0.86, 0.0, 0.0, 1.5),  # charcoal: real asphalt is this dark
    "AW Roof Metal": ((0.3, 0.31, 0.32), 0.38, 1.0, 0.0, 1.5),
    "AW Stainless": ((0.78, 0.79, 0.8), 0.28, 1.0, 0.0, 1.5),
    "AW Countertop": ((0.86, 0.85, 0.82), 0.32, 0.0, 0.0, 1.5),
    "AW Cooktop Glass": ((0.015, 0.015, 0.018), 0.04, 0.0, 0.0, 1.5),
    "AW Cast Stone": ((0.8, 0.77, 0.7), 0.85, 0.0, 0.0, 1.5),
    "AW Firebox": ((0.05, 0.045, 0.04), 0.9, 0.0, 0.0, 1.5),
    "AW Black Iron": ((0.04, 0.04, 0.04), 0.5, 1.0, 0.0, 1.5),
    "AW Brass": ((0.85, 0.65, 0.33), 0.3, 1.0, 0.0, 1.5),
    "AW Logs": ((0.16, 0.11, 0.07), 0.9, 0.0, 0.0, 1.5),
    "AW Log Ends": ((0.55, 0.42, 0.28), 0.8, 0.0, 0.0, 1.5),
    "AW Chain Screen": ((0.04, 0.04, 0.04), 0.45, 1.0, 0.0, 1.5),
    "AW Shade Fabric": ((0.42, 0.41, 0.39), 0.92, 0.0, 0.0, 1.5),  # a woven linen, grey
}

# Their colour in a Solid view where it isn't their base colour (linear): the walls a light
# blue, as C4D's Wall display colour (aw_style.WALL_DISPLAY), so the white openings, trim and
# cabinets stand out against them. Renders never see it.
WALL_SOLID = (0.45, 0.6, 0.81)
SOLID = {"AW Wall Exterior": WALL_SOLID, "AW Wall Interior": WALL_SOLID,
         "AW Roof Asphalt": (0.12, 0.12, 0.125)}  # a roof dark grey, not black, so its shape reads

# Materials cut out by a texture's alpha (shipped beside them: blender/textures, plugin res):
# where it is clear the surface isn't there. A fireplace's chains are drawn this way.
CUTOUTS = {"AW Chain Screen": "aw_chain_screen.png"}

# Their specular weight where it isn't 1 (OpenPBR's full specular): the roofs are duller.
SPECULAR = {"AW Roof Asphalt": 0.25, "AW Roof": 0.3}
