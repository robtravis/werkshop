"""Archwerks plugin and parameter ids, shared by the plugin and the geometry code.

Plugin ids are registered to Rob Travis at Maxon (Plugin Cafe, 2026-10-23), one
per plugin, 1072135 to 1072155. Scenes store objects by these numbers, so never
change one: that orphans every object of that kind in existing files.
Parameter ids must match res/description/*.h.
"""

ID_AW_WALL = 1072136
ID_AW_OPENING = 1072137
ID_AW_EDIT_TOOL = 1072138
ID_AW_WALLS_FROM_SPLINE = 1072139
ID_AW_FLOOR_PLAN = 1072140
ID_AW_SCALE_PLAN_TOOL = 1072141
ID_AW_PANEL = 1072142
ID_AW_WATCHER = 1072143
ID_AW_PLACE_TOOL = 1072144
ID_AW_SLAB = 1072145

ID_ARCHWERKS = 1072135  # the suite's own id: a key for Archwerks data in other objects' containers
# Registered for what comes next (not used yet)
ID_AW_DOOR = 1072146
ID_AW_MOLDING = 1072147
ID_AW_FLOOR = 1072148
ID_AW_CEILING = 1072149
ID_AW_DUPLICATE_TOOL = 1072150
ID_AW_ROOF_CUTTER = 1072151  # registered as Profile: a hole in a Roof, or what is kept of it
ID_AW_PROFILE = ID_AW_ROOF_CUTTER
ID_AW_ROOF = 1072152
ID_AW_STAIR = 1072153
ID_AW_RAILING = 1072154
ID_AW_CUTTER = 1072155  # registered as ArchwerksSpare1: a shaped hole (aw_cutter)
ID_AW_BEAM = 1072219     # registered 2026-10-25
ID_AW_CABINET = 1072220  # not built yet
ID_AW_COUNTERTOP = 1072221  # registered as ArchwerksSpare2
ID_AW_SINK = 1072222        # registered as ArchwerksSpare3
ID_AW_FIREPLACE = 1072223   # registered as ArchwerksSpare4: a fireplace in a wall (aw_fireplace)
ID_AW_WALL_PANELS = 1072224  # registered as ArchwerksSpare5: picture-frame panels on a wall (aw_panels)
# every registered id is used now: register more at Maxon before the next new object

# Wall (Oawwall.h)
AW_WALL_HEIGHT = 1001
AW_WALL_THICKNESS = 1002
# 1000 (Length) and 1003 (Start Offset) belonged to the retired straight wall: don't reuse them
AW_WALL_DIMS = 1004
AW_WALL_ALIGN = 1005  # where the wall sits on its spline: values below
AW_ALIGN_CENTER, AW_ALIGN_INSIDE, AW_ALIGN_OUTSIDE = 0, 1, 2
# Build: the wall's build-on animation (aw_build). Build and Stagger are 0..1.
AW_WALL_BUILD = 1101
AW_WALL_BUILD_STYLE = 1102
AW_WALL_BUILD_ORDER = 1103
AW_WALL_BUILD_STAGGER = 1104
AW_BUILD_RISE, AW_BUILD_TRACE = 0, 1
AW_ORDER_TOGETHER, AW_ORDER_RUNS, AW_ORDER_SEGMENTS = 0, 1, 2
# Materials: one link per part of the wall; aw_materials keeps a material tag per filled slot.
AW_WALL_MATERIAL_SLOTS = (("Exterior", 1201), ("Interior", 1202), ("Top", 1203), ("Bottom", 1204),
                          ("Start", 1205), ("End", 1206), ("Reveals", 1207))
# Segment Overrides (Archipack's): up to MAX_OVERRIDES rows, each a segment (1-based, along every
# run in turn), which face, and a material; its faces go to their own group, "Override n".
AW_WALL_OVERRIDES = 1400
MAX_OVERRIDES = 8
OVERRIDE_INTERIOR, OVERRIDE_EXTERIOR, OVERRIDE_BOTH = 0, 1, 2


def wall_override(i, field):
    """Override row i's setting: field 0 segment, 1 face, 2 material."""
    return 1410 + 4 * i + field


AW_WALL_OVERRIDE_SLOTS = tuple(("Override %d" % (i + 1), wall_override(i, 2)) for i in range(MAX_OVERRIDES))

# AW Opening (Oawopening.h). The opening spans Start Offset .. Start Offset + Width
# along the wall from its own axis, and Sill Height .. Sill Height + Height up
# from it, so each edge can move on its own, like the wall's ends.
AW_OPENING_WIDTH = 1000
AW_OPENING_HEIGHT = 1001
AW_OPENING_SILL = 1002
AW_OPENING_START = 1003
AW_OPENING_TYPE = 1004    # Double-Hung 0, Casement 1, Fixed 2, Sliding 3 (aw_window)
AW_OPENING_HINGE = 1006   # a one-leaf casement row: Left 0, Right 1
AW_OPENING_OPEN = 1007    # casement swing, sliding or hung travel, 0..1
AW_OPENING_SWING = 1016   # which way casement leaves open: Outside 0, Inside 1
# Main tab, after the size: where the frame sits (Archipack's Align, Offset, Mount, Overflow)
AW_OPENING_POSITION = 1010  # Align: Outside 0, Center 1, Inside 2 (a frame in the hole)
AW_OPENING_OFFSET = 1011    # then moved this far towards the Inside
AW_OPENING_MOUNT = 1014     # In the Hole 0, Exterior 1, Interior 2 (surface-mounted on that face)
AW_OPENING_OVERFLOW = 1015  # a surface-mounted frame runs this far past the hole
# Leaves tab: rows from the bottom, each its own leaves; the last row takes what's left
AW_OPENING_ROWS = 1050
MAX_ROWS = 4
AW_OPENING_LEAVES = 1005  # row 1's leaves (kept from when there was one row)


# An opening's build-on animation (aw_build.opening): with its wall's Build, or its own.
AW_OPENING_BUILD_WITH = 1700      # Wall 0 (its wall's build front reaches it), Own 1
AW_OPENING_BUILD = 1701           # 0..1: how far its own build has got (keyframe it)
AW_OPENING_BUILD_STYLE = 1702     # Parts in Order 0, Drop In 1, Rise 2, Slide In 3, Scale Up 4
AW_OPENING_BUILD_STAGGER = 1703   # 0..1: how much its parts wait for each other
AW_OPENING_BUILD_SEQUENCE = 1704  # 0..1: how much linked windows wait for each other (one Build for them all)
AW_OPENING_PORTAL = 1710          # a light portal in the opening (Blender: a Cycles portal light, the window's child)
AW_BUILD_WITH_WALL, AW_BUILD_OWN = 0, 1
AW_BUILD_PARTS, AW_BUILD_DROP, AW_BUILD_RISE_IN, AW_BUILD_SLIDE, AW_BUILD_SCALE = 0, 1, 2, 3, 4


def row_param(row, field):
    """The id of row `row` (0-based) setting `field`: leaves, height, fixed, handle."""
    if row == 0 and field == "leaves":
        return AW_OPENING_LEAVES
    return 1500 + 10 * row + ("leaves", "height", "fixed", "handle").index(field)


AW_OPENING_HANDLE = 1017       # handles: None 0, Inside 1, Outside 2, Both 3 (rows may override)
AW_OPENING_HANDLE_ALT = 1018   # handle height above the leaf's bottom; 0: the middle
AW_OPENING_HANDLE_TYPE = 1019  # aw_handles: Lever 0, Modern Lever 1, Custom 6
AW_OPENING_HANDLE_CUSTOM = 1049
HANDLE_AUTO = 4                # a row's handle: as the window's
# Parts tab
AW_OPENING_FRAME_W = 1008
AW_OPENING_FRAME_D = 1009
AW_OPENING_SASH_W = 1012  # panel (sash) frame
AW_OPENING_SASH_D = 1013
AW_OPENING_FRAME_OUT = 1060    # exterior casing round the hole
AW_OPENING_FRAME_OUT_W = 1061
AW_OPENING_FRAME_OUT_D = 1062  # how far it stands proud of the Outside face
AW_OPENING_FRAME_OUT_OFFSET = 1063  # gap from the hole's edge
AW_OPENING_FRAME_OUT_CLOSE = 1064   # a bottom piece too
AW_OPENING_SILL_ON = 1020    # sill out
AW_OPENING_SILL_OUT = 1021   # projection past the Outside face
AW_OPENING_SILL_SIDE = 1022  # overhang past each side of the hole
AW_OPENING_SILL_H = 1023     # thickness
AW_OPENING_SILL_ALT = 1029   # moved up (down if negative)
AW_OPENING_SILL_IN = 1024    # sill in (interior stool)
AW_OPENING_SILL_IN_D = 1025  # projection into the room
AW_OPENING_SILL_IN_SIDE = 1026
AW_OPENING_SILL_IN_H = 1027
AW_OPENING_SILL_IN_ALT = 1028
AW_OPENING_TRIM = 1040       # frame in: interior casing
AW_OPENING_TRIM_W = 1041
AW_OPENING_TRIM_D = 1042
AW_OPENING_MUNTINS = 1030
AW_OPENING_MUNTIN_COLS = 1031
AW_OPENING_MUNTIN_ROWS = 1032
AW_OPENING_MUNTIN_W = 1033
AW_OPENING_MATERIAL_SLOTS = (("Frame", 1101), ("Sash", 1102), ("Glass", 1103), ("Sill", 1104), ("Trim", 1105),
                             ("Casing", 1106), ("SillIn", 1108), ("Handle", 1107), ("Shutters", 1109), ("Blinds", 1110))
# Plantation shutters on the window's room side (aw_shutters)
AW_OPENING_SHUTTERS = 1080
AW_OPENING_SHUTTER_OPEN = 1081     # 0..1: swung into the room
AW_OPENING_SHUTTER_LEAVES = 1082   # leaves each side: 1, or 2 folding
AW_OPENING_LOUVER_W = 1083
AW_OPENING_LOUVER_TILT = 1084      # 0 flat (open) .. 1 closed
AW_OPENING_SHUTTER_DIVIDER = 1085  # a rail across the middle
# A Roman shade or roller blind on the room side (aw_blinds)
AW_OPENING_BLINDS = 1086           # None 0, Roman 1, Roller 2
AW_OPENING_BLIND_OPEN = 1087       # 0 closed (down) .. 1 open (up)
AW_OPENING_BLIND_MOUNT = 1088      # Inside 0 (in the opening), Outside 1 (on the wall over it)
AW_OPENING_BLIND_FOLD = 1089       # a Roman shade's fabric to a fold
# Drapes: a curtain object of your own, fitted to the window (a linked copy in Blender, an
# instance in Cinema 4D), modelled facing the front (Blender -Y, Cinema 4D -Z), its back away from it,
# its bottom at its lowest point, centred left to right
AW_OPENING_DRAPES = 1090         # None 0, Default 1 (your default drapes), Custom 2 (Drape Object)
DRAPES_NONE, DRAPES_DEFAULT, DRAPES_CUSTOM = 0, 1, 2
AW_OPENING_DRAPE_OBJ = 1091
AW_OPENING_DRAPE_ROD = 1092      # the rod's top above the window's head
AW_OPENING_DRAPE_EXTEND = 1093   # past each side of the window
AW_OPENING_DRAPE_DROP = 1094     # the drape's bottom above the floor (- puddles)
AW_OPENING_DRAPE_OFFSET = 1095   # off the wall (or a Frame In)
AW_OPENING_DRAPE_OPEN = 1096     # 0..1: each side gathered toward its outer edge, its pleats bunched tighter
AW_OPENING_COUNT = 1097          # a row of this many windows along the wall, each Width wide
AW_OPENING_SPACING = 1098        # the wall between them

# aw_window.Style field: the parameter it is read from (and saved to presets as)
AW_OPENING_STYLE_PARAMS = (
    ("kind", AW_OPENING_TYPE), ("hinge", AW_OPENING_HINGE), ("opened", AW_OPENING_OPEN),
    ("count", AW_OPENING_COUNT), ("spacing", AW_OPENING_SPACING),
    ("swing", AW_OPENING_SWING), ("position", AW_OPENING_POSITION), ("offset", AW_OPENING_OFFSET),
    ("mount", AW_OPENING_MOUNT), ("overflow", AW_OPENING_OVERFLOW), ("rows", AW_OPENING_ROWS),
    ("handle", AW_OPENING_HANDLE), ("handle_alt", AW_OPENING_HANDLE_ALT), ("handle_type", AW_OPENING_HANDLE_TYPE),
    ("frame_w", AW_OPENING_FRAME_W), ("frame_d", AW_OPENING_FRAME_D),
    ("sash_w", AW_OPENING_SASH_W), ("sash_d", AW_OPENING_SASH_D),
    ("frame_out", AW_OPENING_FRAME_OUT), ("frame_out_w", AW_OPENING_FRAME_OUT_W),
    ("frame_out_d", AW_OPENING_FRAME_OUT_D), ("frame_out_offset", AW_OPENING_FRAME_OUT_OFFSET),
    ("frame_out_close", AW_OPENING_FRAME_OUT_CLOSE),
    ("sill_on", AW_OPENING_SILL_ON), ("sill_out", AW_OPENING_SILL_OUT), ("sill_side", AW_OPENING_SILL_SIDE),
    ("sill_h", AW_OPENING_SILL_H), ("sill_alt", AW_OPENING_SILL_ALT),
    ("sill_in", AW_OPENING_SILL_IN), ("sill_in_d", AW_OPENING_SILL_IN_D), ("sill_in_side", AW_OPENING_SILL_IN_SIDE),
    ("sill_in_h", AW_OPENING_SILL_IN_H), ("sill_in_alt", AW_OPENING_SILL_IN_ALT),
    ("trim", AW_OPENING_TRIM), ("trim_w", AW_OPENING_TRIM_W), ("trim_d", AW_OPENING_TRIM_D),
    ("muntins", AW_OPENING_MUNTINS), ("muntin_cols", AW_OPENING_MUNTIN_COLS), ("muntin_rows", AW_OPENING_MUNTIN_ROWS),
    ("muntin_w", AW_OPENING_MUNTIN_W), ("shutters", AW_OPENING_SHUTTERS), ("shutter_open", AW_OPENING_SHUTTER_OPEN),
    ("shutter_leaves", AW_OPENING_SHUTTER_LEAVES), ("louver_w", AW_OPENING_LOUVER_W),
    ("louver_tilt", AW_OPENING_LOUVER_TILT), ("shutter_divider", AW_OPENING_SHUTTER_DIVIDER),
    ("blinds", AW_OPENING_BLINDS), ("blind_open", AW_OPENING_BLIND_OPEN), ("blind_mount", AW_OPENING_BLIND_MOUNT),
    ("blind_fold", AW_OPENING_BLIND_FOLD)) + tuple(
    ("%s_%d" % (field, r + 1), row_param(r, field))
    for r in range(MAX_ROWS) for field in ("leaves", "height", "fixed", "handle"))

# Door (Oawdoor). Width, Height, Sill Height and Start Offset are the AW Opening's
# ids (1000-1003), so a wall cuts, guides and grips doors exactly as windows.
AW_DOOR_TYPE = 1004       # Hinged 0, Sliding 1, Pocket 2, Garage 3 (aw_door)
AW_DOOR_OPEN_SIDE = 1005  # Inside 0, Outside 1
AW_DOOR_HINGE = 1006      # Left 0, Right 1 (seen from outside); the side a sliding door goes to
AW_DOOR_LEAVES = 1007     # 1 or 2
AW_DOOR_OPEN = 1008       # 0..1
AW_DOOR_MAX_ANGLE = 1009  # a hinged door's swing at Open 100%
AW_DOOR_FRAME = 1020
AW_DOOR_SHAPE = 1021      # Single Rabbet 0, Double Rabbet 1, Cased Opening 2
AW_DOOR_LAYOUT = 1022     # Encompass 0, Fit 1, Inside 2, In Front 3
AW_DOOR_JAMB = 1023
AW_DOOR_STOP = 1024
AW_DOOR_STOP_W = 1025
AW_DOOR_RABBET = 1026
AW_DOOR_FACE = 1027
AW_DOOR_BACKBEND = 1028
AW_DOOR_JAMB_DEPTH = 1029
AW_DOOR_LEAF_D = 1040
AW_DOOR_MODEL = 1041      # Flat 0, Panel 1, Bevel 2, Glass 3, Half Lite 4
AW_DOOR_DISTRIB = 1042    # Regular 0, 1/3 2/3 1, Colonial 2
AW_DOOR_PANELS_H = 1043
AW_DOOR_PANELS_V = 1044
AW_DOOR_PANEL_BOTTOM = 1045
AW_DOOR_SPACING = 1046
AW_DOOR_BORDER = 1047
AW_DOOR_BEVEL = 1048
AW_DOOR_HANDLE_TYPE = 1050  # aw_handles: Lever 0, Modern Lever 1, Knob 2, Plate Lever 3, Pull Bar 4, Flush 5, Custom 6
AW_DOOR_HANDLE_CUSTOM = 1053  # the object a Custom handle copies
AW_DOOR_HANDLE_ALT = 1051
AW_DOOR_HANDLE_SIDE = 1052  # None 0, Inside 1, Outside 2, Both 3
AW_DOOR_STEP = 1060
AW_DOOR_STEP_H = 1061
AW_DOOR_SILL = 1065
AW_DOOR_SILL_W = 1066
AW_DOOR_SILL_D = 1067
AW_DOOR_SILL_H = 1068
AW_DOOR_MATERIAL_SLOTS = (("Leaf", 1101), ("Panel", 1102), ("Frame", 1103), ("Casing", 1104), ("Glass", 1105),
                          ("Handle", 1106), ("Sill", 1107), ("Step", 1108))
AW_DOOR_STYLE_PARAMS = (
    ("kind", AW_DOOR_TYPE), ("open_side", AW_DOOR_OPEN_SIDE), ("hinge", AW_DOOR_HINGE), ("leaves", AW_DOOR_LEAVES),
    ("opened", AW_DOOR_OPEN), ("max_angle", AW_DOOR_MAX_ANGLE), ("frame", AW_DOOR_FRAME), ("shape", AW_DOOR_SHAPE),
    ("layout", AW_DOOR_LAYOUT), ("jamb", AW_DOOR_JAMB), ("stop", AW_DOOR_STOP), ("stop_w", AW_DOOR_STOP_W),
    ("rabbet", AW_DOOR_RABBET), ("face", AW_DOOR_FACE), ("backbend", AW_DOOR_BACKBEND),
    ("jamb_depth", AW_DOOR_JAMB_DEPTH), ("leaf_d", AW_DOOR_LEAF_D), ("model", AW_DOOR_MODEL),
    ("distrib", AW_DOOR_DISTRIB), ("panels_h", AW_DOOR_PANELS_H), ("panels_v", AW_DOOR_PANELS_V),
    ("panel_bottom", AW_DOOR_PANEL_BOTTOM), ("spacing", AW_DOOR_SPACING), ("border", AW_DOOR_BORDER),
    ("bevel", AW_DOOR_BEVEL), ("handle_type", AW_DOOR_HANDLE_TYPE), ("handle_alt", AW_DOOR_HANDLE_ALT),
    ("handle_side", AW_DOOR_HANDLE_SIDE), ("step", AW_DOOR_STEP), ("step_h", AW_DOOR_STEP_H),
    ("sill_on", AW_DOOR_SILL), ("sill_w", AW_DOOR_SILL_W), ("sill_d", AW_DOOR_SILL_D), ("sill_h", AW_DOOR_SILL_H))

# Molding (Oawmolding): a baseboard or crown following a Wall's rooms (aw_molding)
AW_MOLDING_TYPE = 1000     # Base 0, Crown 1
AW_MOLDING_WALL = 1001
AW_MOLDING_SIDE = 1002     # Inside 0 (the rooms' faces), Outside 1
AW_MOLDING_PROFILE = 1003  # aw_molding.PROFILE_NAMES; Custom 6
AW_MOLDING_HEIGHT = 1004
AW_MOLDING_DEPTH = 1005
AW_MOLDING_OFFSET = 1006   # up from the floor (base), down from the wall top (crown)
AW_MOLDING_GAP = 1007      # out from the wall face
AW_MOLDING_BREAK = 1008    # break at openings
AW_MOLDING_CUSTOM = 1009   # a Custom profile's spline
AW_MOLDING_MATERIAL_SLOTS = (("Molding", 1101),)

# Roof (Oawroof): gable and hip roofs over a Wall's rooms (aw_roof)
AW_ROOF_WALL = 1000
AW_ROOF_PITCH = 1001             # radians
AW_ROOF_PITCH_FROM_WALLS = 1002  # use the sloped wall tops' pitch when there are any
AW_ROOF_EAVE = 1003              # eave overhang
AW_ROOF_RAKE = 1004              # rake (gable) overhang
AW_ROOF_THICKNESS = 1005
AW_ROOF_OFFSET = 1006
AW_ROOF_ELEVATION = 1007         # a standalone roof's eaves
AW_ROOF_SHAPE = 1008             # aw_roof.SHAPE_NAMES
AW_ROOF_MAIN_EDGE = 1009         # 1-based; 0: the longest
AW_ROOF_WIDTH_L = 1010           # an axis roof's width left of its axis
AW_ROOF_WIDTH_R = 1011           # and right of it
AW_ROOF_ENDS = 1012              # an axis roof's ends: Gable 0, Hip 1
AW_ROOF_DRAFT = 1013             # a polygon object whose faces are the roof planes
AW_ROOF_DIMS = 1014              # show its dimensions while it is selected (aw_roofdims)
AW_ROOF_FASCIA, AW_ROOF_FASCIA_H, AW_ROOF_FASCIA_W = 1020, 1021, 1022
AW_ROOF_BARGE, AW_ROOF_BARGE_H, AW_ROOF_BARGE_W = 1030, 1031, 1032
AW_ROOF_RAFTERS, AW_ROOF_RAFTER_W, AW_ROOF_RAFTER_H, AW_ROOF_RAFTER_S = 1040, 1041, 1042, 1043
AW_ROOF_TILES, AW_ROOF_TILE_MODEL, AW_ROOF_TILE_W, AW_ROOF_TILE_L, AW_ROOF_TILE_T = 1050, 1051, 1052, 1053, 1054
AW_ROOF_TILE_OVER = 1055         # how far the tiles reach past the fascia and bargeboard
AW_ROOF_MATERIAL_SLOTS = (("Covering", 1101), ("Soffit", 1102), ("Edge", 1103), ("Fascia", 1104),
                          ("Bargeboard", 1105), ("Rafters", 1106), ("Tiles", 1107))


def roof_edge(i):
    """The id of outline edge i's type: Auto 0, Eave 1, Gable 2."""
    return 1600 + i


# Roof Cutter (Oawprofile): under a Roof, a hole through it or the part of it kept (aw_roof)
AW_RCUT_SHAPE = 1000   # Rectangle 0, Circle 1, Custom 2 (its child spline)
AW_RCUT_WIDTH = 1001
AW_RCUT_LENGTH = 1002
AW_RCUT_MODE = 1003    # Hole 0, Keep Inside 1


# Floor and Ceiling (Oawfloor, Oawceiling): slabs shaped by their own child splines (aw_floor)
AW_FLOOR_ELEVATION = 1000  # a Floor's top, a Ceiling's underside
AW_FLOOR_THICKNESS = 1001
AW_FLOOR_MATERIAL_SLOTS = (("Top", 1101), ("Bottom", 1102), ("Edge", 1103))

# Stair (Oawstair): straight, L, U or along its own spline (aw_stair)
AW_STAIR_SHAPE = 1000          # aw_stair.SHAPE_NAMES
AW_STAIR_HEIGHT = 1001
AW_STAIR_STEPS = 1002          # risers; 0: as few as keep each under Max Riser
AW_STAIR_MAX_RISER = 1003
AW_STAIR_GOING = 1004          # tread depth, riser to riser (not on a Spline stair: its path sets it)
AW_STAIR_WIDTH = 1005
AW_STAIR_TURN = 1006           # L and U: Left 0, Right 1
AW_STAIR_LANDING_AT = 1007     # L and U: steps before the landing; 0: half way
AW_STAIR_GAP = 1008            # U: between the two flights
AW_STAIR_CONSTRUCTION = 1009   # Closed 0, Open 1
AW_STAIR_UNDERSIDE = 1010      # Closed: Sloped 0, Solid 1
AW_STAIR_WAIST = 1011          # Sloped: the slab's thickness under the steps
AW_STAIR_TREAD_T = 1012
AW_STAIR_NOSING = 1013
AW_STAIR_STRINGERS = 1020      # None 0, Sides 1, Centre 2
AW_STAIR_STRINGER_W = 1021
AW_STAIR_STRINGER_D = 1022
AW_STAIR_STRINGER_ABOVE = 1023  # housed stringers: above the nosings
AW_STAIR_STRINGER_SPACING = 1024  # Sides: centre to each stringer; 0: at the edges, housing the treads
# Beam (Oawbeam): a straight beam, cloned in rows and layers (aw_beam)
AW_BEAM_LENGTH = 1000
AW_BEAM_WIDTH = 1001
AW_BEAM_HEIGHT = 1002
AW_BEAM_ALIGN = 1003          # Bottom 0, Centre 1, Top 2: where the origin is
AW_BEAM_SECTION = 1004        # aw_beam.SECTION_NAMES
AW_BEAM_RADIUS = 1005         # Rounded
AW_BEAM_FLANGE = 1006         # I-Beam
AW_BEAM_WEB = 1007            # I-Beam
AW_BEAM_PROFILE = 1008        # Custom: a spline, in its XY plane
AW_BEAM_DIMS = 1009
AW_BEAM_COUNT = 1020          # beams side by side along +Z
AW_BEAM_SPACING_MODE = 1021   # Per Step 0, Span 1
AW_BEAM_SPACING = 1022
AW_BEAM_SPAN = 1023
AW_BEAM_LAYERS = 1024         # stacked up +Y
AW_BEAM_LAYER_SPACING = 1025
AW_BEAM_MATERIAL_SLOTS = (("Beam", 1101),)

# Cabinet (Oawcabinet): base, upper, tall and vanity cabinets (aw_cabinet, aw_pulls)
AW_CAB_TYPE = 1000             # Base 0, Upper 1, Tall 2, Vanity 3
AW_CAB_WIDTH = 1001
AW_CAB_HEIGHT = 1002
AW_CAB_DEPTH = 1003
AW_CAB_TOP = 1004              # an upper's top above the floor
AW_CAB_KICK_H = 1005
AW_CAB_KICK_SETBACK = 1006
AW_CAB_THICKNESS = 1007        # the box's boards
AW_CAB_OPEN = 1008             # 0..1: doors swing, drawers slide
AW_CAB_DIMS = 1009             # show its dimensions while it is selected
AW_CAB_PUSH = 1018             # a width change moves the cabinets it touches
AW_CAB_ANCHOR = 1019           # Left 0, Centre 1, Right 2: the end that stays put
AW_CAB_STYLE = 1010            # Slab 0, Shaker 1, Glass Shaker 2
AW_CAB_DRAWER_STYLE = 1011     # Same 0, Slab 1
AW_CAB_FRAME_W = 1012
AW_CAB_FRONT_T = 1013
AW_CAB_OVERLAY = 1014          # Full 0, Inset 1
AW_CAB_REVEAL = 1015
AW_CAB_FACE_FRAME = 1016
AW_CAB_PANEL_RECESS = 1017
AW_CAB_ZONES = 1020
AW_CAB_DOOR_PULL = 1030        # aw_pulls.NAMES
AW_CAB_DOOR_PULL_SIZE = 1031
AW_CAB_DOOR_PULL_ORIENT = 1032  # Vertical 0, Horizontal 1
AW_CAB_DOOR_PULL_POS = 1033    # Auto 0, Top 1, Middle 2, Bottom 3
AW_CAB_DOOR_PULL_EDGE = 1034
AW_CAB_DOOR_PULL_END = 1035
AW_CAB_DOOR_PULL_LIB = 1036
AW_CAB_DOOR_PULL_OBJ = 1037
AW_CAB_DRAWER_PULL = 1040
AW_CAB_DRAWER_PULL_SIZE = 1041
AW_CAB_DRAWER_PULL_ORIENT = 1042  # Vertical 0, Horizontal 1
AW_CAB_DRAWER_PULL_POS = 1043  # Centre 0, Near Top 1
AW_CAB_DRAWER_PULL_TOP = 1044
AW_CAB_DRAWER_TWO_OVER = 1045
AW_CAB_DRAWER_PULL_LIB = 1046
AW_CAB_DRAWER_PULL_OBJ = 1047
AW_CAB_END_L = 1050            # a finished end panel on its left end (seen from the front)
AW_CAB_END_R = 1051
AW_CAB_END_T = 1052
AW_CAB_END_PROUD = 1053        # how far an end panel stands past the fronts
AW_CAB_FILLER_L = 1054         # a filler strip's width at its left end
AW_CAB_FILLER_R = 1055
AW_CAB_BLIND = 1056            # None 0, Left 1, Right 2: the end a blind corner's panel is at
AW_CAB_BLIND_W = 1057
AW_CAB_CORNER = 1058           # None 0, Pie Cut 1, Diagonal 2
AW_CAB_RETURN = 1059           # a corner cabinet's length along the other wall
AW_CAB_CORNER_SIDE = 1060      # Left 0, Right 1: the end its corner is at
AW_CAB_MATERIAL_SLOTS = (("Fronts", 1101), ("Carcass", 1102), ("Shelves", 1103), ("Toe Kick", 1104), ("Glass", 1105),
                         ("Pulls", 1106))


def cab_zone(i, field):
    """Zone i's setting: field 0 kind, 1 height, 2 columns, 3 shelves, 4 glass."""
    return 1200 + 10 * i + field


# Countertop (Oawcountertop) and Sink (Oawsink): aw_counter
AW_CT_CABINETS = 1000      # the cabinets it covers (an In/Exclude list)
AW_CT_THICKNESS = 1001
AW_CT_FRONT = 1002         # overhang past the fronts
AW_CT_BACK = 1003          # past the backs: 0 against a wall, more for a bar
AW_CT_SIDE = 1004          # past an exposed end
AW_CT_ELEVATION = 1005     # an outline's (island's) top, when it has no cabinets
AW_CT_SPLASH = 1006
AW_CT_SPLASH_H = 1007
AW_CT_SPLASH_T = 1008
AW_CT_WATERFALL = 1009
AW_CT_WIPE = 1010          # 0..1: how much of it the wiping-on front has passed (keyframe it)
AW_CT_WIPE_DIR = 1011      # Along the Run 0, Along X 1, Along Z 2
AW_CT_WIPE_REVERSE = 1012
CT_SINK = 20               # a countertop's Sinks tab: each sink setting's id + this (AW_SINK_MOUNT 1000 -> 1020)
AW_CT_MATERIAL_SLOTS = (("Top", 1101), ("Bottom", 1102), ("Edge", 1103), ("Backsplash", 1104), ("Sink", 1105),
                        ("Cooktop", 1106))
AW_SINK_MOUNT = 1000       # aw_counter.MOUNT_NAMES
AW_SINK_SHAPE = 1001       # aw_counter.SHAPE_NAMES
AW_SINK_WIDTH = 1002
AW_SINK_LENGTH = 1003
AW_SINK_RADIUS = 1004
AW_SINK_DEPTH = 1005
AW_SINK_WALL = 1006
AW_SINK_RIM = 1007

# Railing (Oawrailing): railings on a Stair, fences along their own splines (aw_railing)
AW_RAIL_STAIR = 1000            # a linked Stair: the path; else the railing's own splines
AW_RAIL_SIDE = 1001             # Left 0, Right 1, Both 2
AW_RAIL_INSET = 1002            # in from the stair's edge
AW_RAIL_HEIGHT = 1003           # the handrail's top above the path
AW_RAIL_POSTS = 1010
AW_RAIL_POST_SPACING = 1011     # 0: ends and corners only
AW_RAIL_POST_W = 1012
AW_RAIL_POST_SHAPE = 1013       # Square 0, Round 1
AW_RAIL_POST_ABOVE = 1014       # its top above the handrail's
AW_RAIL_POST_CAP = 1015
AW_RAIL_HANDRAIL = 1020
AW_RAIL_HANDRAIL_SHAPE = 1021   # Square 0, Round 1, Custom 2
AW_RAIL_HANDRAIL_W = 1022
AW_RAIL_HANDRAIL_H = 1023
AW_RAIL_HANDRAIL_PROFILE = 1024  # Custom: a spline, drawn in its XY plane
AW_RAIL_INFILL = 1030           # None 0, Pickets 1, Rails 2, Panels 3
AW_RAIL_INFILL_BOTTOM = 1031
AW_RAIL_PICKET_SPACING = 1032
AW_RAIL_PICKET_W = 1033
AW_RAIL_PICKET_D = 1034       # Board: its thickness across the path
AW_RAIL_PICKET_SHAPE = 1035   # Square 0, Round 1, Board 2
AW_RAIL_PICKET_TOP = 1036      # Straight 0, Dog-eared 1
AW_RAIL_DOG_EAR = 1037          # how long the clipped corners are
AW_RAIL_STRINGERS = 1044        # rails the pickets are fixed to
AW_RAIL_STRINGER_W = 1045
AW_RAIL_STRINGER_H = 1046
AW_RAIL_STRINGER_INSET = 1047   # in from the pickets' bottom and top
AW_RAIL_STRINGER_SIDE = 1048    # Behind 0, In Front 1, Centred 2
AW_RAIL_RAILS = 1040            # how many horizontal rails or boards
AW_RAIL_RAIL_W = 1041
AW_RAIL_RAIL_H = 1042
AW_RAIL_RAIL_SHAPE = 1043       # Square 0, Round 1
AW_RAIL_PANEL_T = 1050
AW_RAIL_PANEL_GAP = 1051
AW_RAIL_BOTTOM = 1060           # a bottom rail
AW_RAIL_BOTTOM_W = 1061
AW_RAIL_BOTTOM_H = 1062
AW_RAIL_MATERIAL_SLOTS = (("Posts", 1101), ("Handrail", 1102), ("Rails", 1103), ("Pickets", 1104),
                          ("Panels", 1105))
AW_STAIR_MATERIAL_SLOTS = (("Treads", 1101), ("Risers", 1102), ("Structure", 1103), ("Stringers", 1104))

# Cutter (Oawcutter): Width, Height, Sill Height, Start Offset as an AW Opening's (1000-1003)
AW_CUTTER_SHAPE = 1004        # aw_cutter.SHAPE_NAMES
AW_CUTTER_RESOLUTION = 1005
AW_CUTTER_RADIUS = 1006       # Top Round, Pointed; 0: half the width
AW_CUTTER_RISE = 1007         # Top Elliptic, Top Oblique
AW_CUTTER_CUT_MOLDINGS = 1008
AW_CUTTER_STYLE_PARAMS = (("shape", AW_CUTTER_SHAPE), ("resolution", AW_CUTTER_RESOLUTION),
                          ("radius", AW_CUTTER_RADIUS), ("rise", AW_CUTTER_RISE),
                          ("cut_moldings", AW_CUTTER_CUT_MOLDINGS))

# Fireplace (Oawfireplace): Width, Height, Sill Height, Start Offset as an AW Opening's (1000-1003):
# its firebox opening, which the wall cuts. The rest is built on the room side (aw_fireplace).
AW_FP_SIDE = 1004          # which face it is on: Inside 0, Outside 1
AW_FP_SHAPE = 1005         # the opening's shape: aw_fireplace.SHAPE_NAMES
AW_FP_RADIUS = 1006        # Rounded Corners: the corners' radius; Top Round: the arch's (0: half the width)
AW_FP_RISE = 1007          # Top Elliptic
AW_FP_RESOLUTION = 1008
AW_FP_SURROUND = 1010
AW_FP_SURROUND_SIDE = 1011  # its width beside the opening
AW_FP_SURROUND_TOP = 1012   # its height over the opening
AW_FP_SURROUND_D = 1013     # how far it stands off the wall
AW_FP_BEAD_W = 1014         # the raised border round the opening
AW_FP_BEAD_D = 1015         # how far it stands off the surround (0: none)
AW_FP_FACING = 1016         # the surround's opening its own size, a facing filling it round the firebox's
AW_FP_FACING_W = 1017       # that opening's width
AW_FP_FACING_H = 1018       # and height, from the hearth
AW_FP_FACING_D = 1019       # how far the facing stands off the wall
AW_FP_MANTEL = 1020
AW_FP_SHELF_T = 1021
AW_FP_SHELF_D = 1022        # how far the shelf reaches past the surround's face
AW_FP_SHELF_SIDE = 1023     # and past each end
AW_FP_BED_H = 1024          # the step under the shelf (0: none)
AW_FP_HEARTH = 1030
AW_FP_HEARTH_D = 1031       # how far it reaches into the room
AW_FP_HEARTH_SIDE = 1032    # past each side of the surround
AW_FP_HEARTH_T = 1033
AW_FP_DEPTH = 1040          # the firebox, from the wall face back
AW_FP_LINER = 1041          # its lining's thickness (a brick)
AW_FP_SPLAY = 1042          # how much narrower its back is, each side
AW_FP_INSIDE_WALL = 1043    # no deeper than its wall
AW_FP_GRATE = 1050
AW_FP_LOGS = 1051           # how many logs on the grate
AW_FP_DOORS = 1052          # None 0, Pair 1, Bifold 2
AW_FP_DOORS_OPEN = 1053     # 0..1
AW_FP_SCREEN = 1054         # a chain curtain behind the doors
AW_FP_SCREEN_OPEN = 1055    # 0..1: drawn back to each side
AW_FP_MATERIAL_SLOTS = (("Surround", 1101), ("Mantel", 1102), ("Hearth", 1103), ("Firebox", 1104), ("Back", 1105),
                        ("Grate", 1106), ("Logs", 1107), ("Log Ends", 1108), ("Insert Frame", 1109),
                        ("Glass", 1110), ("Screen", 1111), ("Handle", 1112))
AW_FP_STYLE_PARAMS = (
    ("side", AW_FP_SIDE), ("shape", AW_FP_SHAPE), ("radius", AW_FP_RADIUS), ("rise", AW_FP_RISE),
    ("resolution", AW_FP_RESOLUTION), ("surround", AW_FP_SURROUND), ("surround_side", AW_FP_SURROUND_SIDE),
    ("surround_top", AW_FP_SURROUND_TOP), ("surround_d", AW_FP_SURROUND_D), ("bead_w", AW_FP_BEAD_W),
    ("bead_d", AW_FP_BEAD_D), ("facing", AW_FP_FACING), ("facing_w", AW_FP_FACING_W), ("facing_h", AW_FP_FACING_H),
    ("facing_d", AW_FP_FACING_D), ("mantel", AW_FP_MANTEL), ("shelf_t", AW_FP_SHELF_T), ("shelf_d", AW_FP_SHELF_D),
    ("shelf_side", AW_FP_SHELF_SIDE), ("bed_h", AW_FP_BED_H), ("hearth", AW_FP_HEARTH), ("hearth_d", AW_FP_HEARTH_D),
    ("hearth_side", AW_FP_HEARTH_SIDE), ("hearth_t", AW_FP_HEARTH_T), ("depth", AW_FP_DEPTH), ("liner", AW_FP_LINER),
    ("splay", AW_FP_SPLAY), ("inside_wall", AW_FP_INSIDE_WALL), ("grate", AW_FP_GRATE), ("logs", AW_FP_LOGS), ("doors", AW_FP_DOORS),
    ("doors_open", AW_FP_DOORS_OPEN), ("screen", AW_FP_SCREEN), ("screen_open", AW_FP_SCREEN_OPEN))

# Wall Panels (Oawpanels)
AW_PNL_WALL = 1000
AW_PNL_SIDE = 1001        # Faces: Inside 0, Outside 1
AW_PNL_BOTTOM = 1002      # the frames' bottom, up from the floor
AW_PNL_TOP = 1003         # their top, down from the wall's top
AW_PNL_MARGIN = 1004      # in from each end of a stretch of wall
AW_PNL_GAP = 1005         # between frames
AW_PNL_WIDTH = 1006       # about how wide each frame is
AW_PNL_MIN_W = 1007       # narrower than this: none
AW_PNL_BREAKS = 1008      # stop at openings
AW_PNL_AROUND = 1009      # and frame what is left over and under them
AW_PNL_PROFILE = 1010     # aw_molding.PROFILE_NAMES
AW_PNL_FRAME_W = 1011
AW_PNL_FRAME_D = 1012
AW_PNL_CUSTOM = 1013      # Custom profile: its spline
AW_PNL_FLOURISH = 1020    # None 0, Top Corners 1, All Corners 2
AW_PNL_FLOURISH_KIND = 1021  # Built-in 0, Custom 1
AW_PNL_FLOURISH_SIZE = 1022
AW_PNL_FLOURISH_D = 1023
AW_PNL_FLOURISH_INSET = 1024
AW_PNL_FLOURISH_OBJ = 1025
AW_PNL_HEIGHT = 1026      # with no Wall: the top Top is measured down from
AW_PNL_MATERIAL_SLOTS = (("Frames", 1101), ("Flourishes", 1102))

OPENING_TYPES = (ID_AW_OPENING, ID_AW_DOOR, ID_AW_CUTTER, ID_AW_FIREPLACE)  # what a Wall cuts a hole for and builds in it


def is_opening(op):
    import aw_host
    return op is not None and aw_host.type_id(op) in OPENING_TYPES


MIN_SIZE = 0.1

# Cinema 4D menu commands (core/aw_commands keys), one registered plugin id each, from
# developers.maxon.net (Plugin ID). A command not listed here stays out of the C4D menu.
# Walls from Spline, Floor Plan, Edit Dimensions and Scale Plan have their own ids above.
COMMAND_IDS = {"wall": 1072433, "floor": 1072434, "ceiling": 1072435, "slab": 1072436, "stair": 1072437,
               "railing": 1072438, "beam": 1072439, "window": 1072440, "door": 1072441, "archway": 1072442,
               "fireplace": 1072443, "baseboard": 1072444, "crown": 1072445, "wall_panels": 1072446,
               "cabinet": 1072447, "countertop": 1072448, "sink": 1072449, "add_pull": 1072450, "roof": 1072451,
               "roof_cutter": 1072452, "tidy": 1072453,  # registered 2026-10-28 as ArchwerksCmd<Name> (Wall: ArchwerksWall)
               "workspace": 1072454}  # was ArchwerksSpare6
ID_AW_DRAW_TOOL = 1072455  # registered as ArchwerksSpare7: AW Draw (src/aw_drawtool_c4d), in place of the Spline Pen
SPARE_IDS = (1072456, 1072457, 1072458, 1072459)  # ArchwerksSpare8..11: the next objects or commands

# Slab (Oawslab.h): a floor or ceiling filling a Wall's rooms (aw_slab)
AW_SLAB_TYPE = 1000       # Floor 0, Ceiling 1
AW_SLAB_WALL = 1001       # the Wall it fills
AW_SLAB_FIT = 1002        # Inside faces 0, Outside faces 1, Spline 2
AW_SLAB_THICKNESS = 1003
AW_SLAB_OFFSET = 1004
AW_SLAB_FOLLOW = 1005     # a Ceiling follows the wall tops (gables), not a flat plane
AW_SLAB_MATERIAL_SLOTS = (("Top", 1101), ("Bottom", 1102), ("Edge", 1103))
