"""Archwerks roofs: gable, hip, shed, axis and draft roofs, with cutters.

Where a Roof's shape comes from, the first that applies:
- Draft: a linked polygon object (Archipack's Draft Roof). Every face of it that
  isn't upright is a roof plane, sloping the way it slopes; the Roof adds the
  thickness, trim, rafters and covering.
- Wall: a linked Wall. Its rooms (closed runs) are roofed from their outside
  outline, the eaves on the walls.
- Its own child splines (a standalone roof). A closed spline is an outline,
  roofed like a wall's, its eaves at Elevation. An open spline is an axis
  (Archipack's roof sections with turns): the roof runs along it, Width Left and
  Width Right either side, the ridge on the axis, turning where it turns, its two
  ends gables or hips (Ends).

An outline's every edge is an Eave (the roof slopes up from it) or a Gable (the
roof ends over it in a vertical gable). Shape picks them: Hip (all eaves),
Gable (eaves along the Main Edge, gables across it), Shed (the Main Edge the only
eave: one slope up to the far side), or Auto (gables where a wall rises, else
hips); an edge's own setting (Edges tab) wins. Main Edge 0 is the longest. The
roof itself is a weighted straight skeleton (aw_skeleton): eaves at the Pitch,
gables standing still, hips, valleys and ridges where they meet.

Pitch From Walls takes a wall roof's pitch from its sloped wall tops, so the
underside lies on the gable rakes. Eave and Rake Overhang push the outline out
(the eaves drop as they reach out). Thickness is the roof's depth (vertical),
Offset lifts it.

Roof Cutters under the Roof cut a hole through it (Hole) or keep only what is
inside them (Keep Inside); tiles, panels and rafters stop at their edge.

Everything past the shape works on faces: each roof plane is pieces (convex
polygons in plan, every point with its underside's height) and a Frame (its
plane: which way is up the slope, how steep, how high where). So the deck, the
trim (Fascia along level edges, Bargeboard up sloped ones), Rafters, Tiles
(Plain Tile, Shingle, Slate, Standing Seam) and the caps over hips and ridges
are the same for every source. Plan points are (x, z); heights in cm.
"""
import math

import aw_host
from aw_mat import Mat
from aw_vec import Vec

import aw_skeleton as K

AUTO, EAVE, GABLE = 0, 1, 2
SHAPE_AUTO, SHAPE_HIP, SHAPE_GABLE, SHAPE_SHED = 0, 1, 2, 3
SHAPE_NAMES = ("Auto", "Hip", "Gable", "Shed")
ENDS_GABLE, ENDS_HIP = 0, 1
CUT_HOLE, CUT_KEEP = 0, 1
CUT_RECTANGLE, CUT_CIRCLE, CUT_CUSTOM = 0, 1, 2
GROUPS = ("Covering", "Soffit", "Edge", "Fascia", "Bargeboard", "Rafters", "Tiles")
MAX_EDGES = 32
PLAIN, SHINGLE, SLATE, SEAM, DIMENSIONAL = 0, 1, 2, 3, 4
MODEL_MATERIALS = {SEAM: "AW Roof Metal"}  # a model's own default covering (others: AW Roof Asphalt)
DEFAULT_COVERING = "AW Roof Asphalt"
MAX_TILES = 30000
# what each model's tiles are, by default: width, exposure (up the slope), thickness, cm
TILE_DEFAULTS = {PLAIN: (30.0, 20.0, 1.8), SHINGLE: (91.44, 12.7, 0.6), SLATE: (25.0, 21.0, 0.8),
                 SEAM: (45.72, 20.0, 3.81),  # standing seam: panel width, (unused), seam height
                 DIMENSIONAL: (100.0, 14.3, 0.45)}  # a laminated strip; its two layers each Thickness
SEAM_WIDTH = 2.5   # a standing seam's own width
PANEL_THICK = 0.3  # the metal sheet
SHINGLE_TABS = 3
SHINGLE_SLOT = 0.6   # the gap between a shingle strip's tabs
TILE_GAP = 0.3       # between plain tiles and slates
# a dimensional (laminated) shingle: a base strip and, laminated on it, tabs of uneven width,
# some cut shorter so the base shows below them; every tab a little lifted, tilted and turned
DIM_TAB = (26.0, 34.0)  # its tabs' widths, cm
DIM_SLOT = 0.8          # the gap between tabs, showing the base
DIM_CUTS = (0.0,) * 9 + (0.12,)  # how much shorter a tab is cut, of the exposure (one of these): now and then, a little
DIM_BASE_SHADE = 0.82   # the base strip, a little in the shadow of the tabs
DIM_SHADE = 0.1         # how far a strip's shade strays; its tabs stray a third as far from it
DIM_LIFT = 0.25         # cm a tab's bottom edge may stand proud
DIM_RISE = 3.2          # a strip's tilt, in Thicknesses: clear of the two layers below where they lap
DIM_TWIST = 0.006       # radians a tab may turn in the roof's plane
CAP_WIDTH = 15.0   # how far a cap reaches down each slope from the ridge or hip, in plan
CAP_THICK = 1.5
STARTER_T = 0.1    # the starter strip under a standing seam's overhang


# Plan helpers (pure) --------------------------------------------------------------

def _cross(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def area(pts):
    return sum(p[0] * q[1] - q[0] * p[1] for p, q in zip(pts, pts[1:] + pts[:1])) / 2


def merge_collinear(pts, flags):
    """pts (a closed outline) without the points where it runs straight on; flags
    (one per edge, edge i from pts[i]) or-ed across the edges merged."""
    pts, flags = list(pts), list(flags)
    changed = True
    while changed and len(pts) > 3:
        changed = False
        n = len(pts)
        for i in range(n):
            a, b, c = pts[i - 1], pts[i], pts[(i + 1) % n]
            if abs(_cross(a, b, c)) < 1e-6 * max(1.0, math.dist(a, b) * math.dist(b, c)):
                flags[i - 1] = flags[i - 1] or flags[i]
                del pts[i], flags[i]
                changed = True
                break
    return pts, flags


def _line(a, b):
    """(n, d, c): edge a->b of a counter-clockwise outline, n its inward normal, d its
    direction, the line n . x = c."""
    L = math.dist(a, b)
    d = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
    n = (-d[1], d[0])
    return n, d, n[0] * a[0] + n[1] * a[1]


def _meet(l1, l2, fallback):
    (n1, _d1, c1), (n2, _d2, c2) = l1, l2
    det = n1[0] * n2[1] - n1[1] * n2[0]
    if abs(det) < 1e-9:
        return fallback
    return ((c1 * n2[1] - c2 * n1[1]) / det, (n1[0] * c2 - n2[0] * c1) / det)


def offset(pts, out):
    """The outline with edge i pushed out by out[i] (mitred corners)."""
    n = len(pts)
    lines = []
    for i in range(n):
        nn, d, c = _line(pts[i], pts[(i + 1) % n])
        lines.append((nn, d, c - out[i]))
    res = []
    for i in range(n):
        cur = lines[i]
        fb = (pts[i][0] - cur[0][0] * out[i], pts[i][1] - cur[0][1] * out[i])
        res.append(_meet(lines[i - 1], cur, fb))
    return res


class Frame:
    """A roof plane: going `n` (a unit plan direction) it climbs `tan` per unit; `d`
    runs level along it, n to its left; at plan point `a` its underside is `ya`."""

    def __init__(self, a, d, n, tan, ya):
        self.a, self.d, self.n, self.tan, self.ya = a, d, n, tan, ya

    def tau(self, p):
        return (p[0] - self.a[0]) * self.n[0] + (p[1] - self.a[1]) * self.n[1]

    def u(self, p):
        return (p[0] - self.a[0]) * self.d[0] + (p[1] - self.a[1]) * self.d[1]

    def at(self, u, tau):
        return (self.a[0] + self.d[0] * u + self.n[0] * tau, self.a[1] + self.d[1] * u + self.n[1] * tau)

    def y(self, p):
        return self.ya + self.tan * self.tau(p)


def kinds_for(pts, sloped, shape, main_edge, overrides):
    """Each outline edge's kind (EAVE or GABLE) for Shape, the Main Edge (1-based; 0:
    the longest) and the edges' own settings (AUTO: as the Shape says). sloped: per
    edge, whether a wall rises along it (Auto makes those gables)."""
    n = len(pts)
    lengths = [math.dist(pts[i], pts[(i + 1) % n]) for i in range(n)]
    m = (main_edge - 1) if 1 <= main_edge <= n else max(range(n), key=lambda i: lengths[i])
    dm = _line(pts[m], pts[(m + 1) % n])[1]
    kinds = []
    for i in range(n):
        if shape == SHAPE_HIP:
            k = EAVE
        elif shape == SHAPE_SHED:
            k = EAVE if i == m else GABLE
        elif shape == SHAPE_GABLE:
            di = _line(pts[i], pts[(i + 1) % n])[1]
            k = EAVE if abs(dm[0] * di[1] - dm[1] * di[0]) < math.sin(math.radians(20)) else GABLE
        else:
            k = GABLE if sloped[i] else EAVE
        o = overrides[i] if i < len(overrides) else AUTO
        kinds.append(k if o == AUTO else o)
    return kinds


def skeleton_faces(pts, kinds, tans, outs, y_edge, fid0):
    """(pieces, frames, pushed-out outline) for one outline: kinds and tans (each
    eave's slope) per edge, outs the overhang per edge, y_edge the underside's height
    along the pushed-out eaves; face ids fid0 + edge index."""
    poly = offset(pts, outs)
    weights = [1.0 / max(t, 1e-6) if k == EAVE else 0.0 for k, t in zip(kinds, tans)]
    n = len(poly)
    pieces = [(fid0 + e, [(x, z, y_edge + h) for x, z, h in pc]) for e, pc in K.skeleton(poly, weights)
              if weights[e] > 0]
    frames = {}
    for i in range(n):
        if weights[i] > 0:
            nn, d, _c = _line(poly[i], poly[(i + 1) % n])
            frames[fid0 + i] = Frame(poly[i], d, nn, tans[i], y_edge)
    return pieces, frames, poly


def axis_outline(path, width_l, width_r, ends, pitch):
    """A roof running along an open axis, width_l to its left and width_r to its
    right, the ridge on the axis: (outline counter-clockwise, kinds, tans), or None.
    Both sides climb to the same ridge height (the wider at the pitch); the ends are
    gables or hips. The outline runs down the right side, across the far end, back
    up the left side and across the near end."""
    path = [p for i, p in enumerate(path) if i == 0 or math.dist(p, path[i - 1]) > 1e-4]
    if len(path) < 2:
        return None
    wl, wr = max(width_l, 1.0), max(width_r, 1.0)
    segs = [_line(path[i], path[i + 1]) for i in range(len(path) - 1)]

    def side(sign, w):
        out = []
        for i, p in enumerate(path):
            if 0 < i < len(path) - 1:  # a turn: the two sides' lines meet (mitred)
                l1, l2 = segs[i - 1], segs[i]
                o1 = (l1[0], l1[1], l1[2] + sign * w)
                o2 = (l2[0], l2[1], l2[2] + sign * w)
                nn = l1[0]
                out.append(_meet(o1, o2, (p[0] + nn[0] * sign * w, p[1] + nn[1] * sign * w)))
            else:
                nn = segs[0][0] if i == 0 else segs[-1][0]
                out.append((p[0] + nn[0] * sign * w, p[1] + nn[1] * sign * w))
        return out
    left, right = side(1.0, wl), side(-1.0, wr)
    pts = right + left[::-1]
    k = len(path) - 1
    H = max(wl, wr) * math.tan(math.radians(min(max(pitch, 1.0), 85.0)))
    cap = EAVE if ends == ENDS_HIP else GABLE
    kinds = [EAVE] * k + [cap] + [EAVE] * k + [cap]
    tans = [H / wr] * k + [H / max(wl, wr)] + [H / wl] * k + [H / max(wl, wr)]
    if area(pts) < 0:  # turned so far it crossed itself: at least wind it the right way
        pts = pts[::-1]
        kinds = kinds[-2::-1] + [kinds[-1]]
        tans = tans[-2::-1] + [tans[-1]]
    return pts, kinds, tans


def draft_faces(points, polys, fid0):
    """(pieces, frames) from a mesh: every face not standing upright is a roof plane
    (faces in one plane share it), its pieces counter-clockwise in plan, split into
    triangles where they aren't convex. points: [(x, y, z)]; polys: [(a, b, c, d)],
    d == c for a triangle."""
    import aw_slab
    pieces, frames, planes = [], {}, {}
    for a, b, c, d in polys:
        ids = [a, b, c] if c == d else [a, b, c, d]
        P = [points[i] for i in ids]
        nx = ny = nz = 0.0
        for i in range(len(P)):  # Newell's normal
            p, q = P[i], P[(i + 1) % len(P)]
            nx += (p[1] - q[1]) * (p[2] + q[2])
            ny += (p[2] - q[2]) * (p[0] + q[0])
            nz += (p[0] - q[0]) * (p[1] + q[1])
        L = math.sqrt(nx * nx + ny * ny + nz * nz)
        if L < 1e-9 or abs(ny) / L < 0.05:
            continue  # upright (or no area): not a roof plane
        gx, gz = -nx / ny, -nz / ny  # the plane: y = cst + gx x + gz z
        cst = P[0][1] - gx * P[0][0] - gz * P[0][2]
        key = (round(gx, 4), round(gz, 4), round(cst, 2))
        if key not in planes:
            fid = fid0 + len(planes)
            planes[key] = fid
            tan = math.hypot(gx, gz)
            n2 = (gx / tan, gz / tan) if tan > 1e-9 else (1.0, 0.0)
            frames[fid] = Frame((P[0][0], P[0][2]), (n2[1], -n2[0]), n2, tan, P[0][1])
        fid = planes[key]
        plan = [(p[0], p[2]) for p in P]
        pts3 = [(p[0], p[2], p[1]) for p in P]
        if area(plan) < 0:
            plan, pts3 = plan[::-1], pts3[::-1]
        if all(_cross(plan[j], plan[(j + 1) % len(plan)], plan[(j + 2) % len(plan)]) >= -1e-9
               for j in range(len(plan))):
            pieces.append((fid, pts3))
        else:
            for i, j, k in aw_slab.triangulate(plan):
                pieces.append((fid, [pts3[i], pts3[j], pts3[k]]))
    return pieces, frames


# Cutting (pure) ------------------------------------------------------------------

def _clip(poly, a, b, keep_left):
    """Sutherland-Hodgman: the part of convex poly [(x, z, y)] left (or right) of the
    line a->b, heights carried along; [] when nothing is left."""
    out = []
    n = len(poly)

    def side(p):
        s = _cross(a, b, (p[0], p[1]))
        return s if keep_left else -s
    for i in range(n):
        p, q = poly[i], poly[(i + 1) % n]
        sp, sq = side(p), side(q)
        if sp >= -1e-9:
            out.append(p)
        if (sp >= -1e-9) != (sq >= -1e-9):
            t = sp / (sp - sq)
            out.append(tuple(p[k] + (q[k] - p[k]) * t for k in range(3)))
    clean = []
    for p in out:
        if not clean or math.dist(p[:2], clean[-1][:2]) > 1e-7:
            clean.append(p)
    if len(clean) > 1 and math.dist(clean[0][:2], clean[-1][:2]) <= 1e-7:
        clean.pop()
    return clean if len(clean) >= 3 and abs(area(clean)) > 1e-6 else []


def _convex_parts(poly):
    """A cutter outline (counter-clockwise) as triangles."""
    import aw_slab
    return [[poly[i], poly[j], poly[k]] for i, j, k in aw_slab.triangulate(poly)]


def subtract(pieces, cutter):
    """The pieces less the cutter outline (counter-clockwise): each piece cut by every
    triangle of the cutter in turn, what is left still convex."""
    parts = _convex_parts(cutter)
    out = []
    for fid, poly in pieces:
        left = [poly]
        for c in parts:
            nxt = []
            for p in left:
                rem = p
                for j in range(len(c)):  # outside an edge of the triangle: kept; inside all three: gone
                    a, b = c[j], c[(j + 1) % len(c)]
                    outside = _clip(rem, a, b, False)
                    if outside:
                        nxt.append(outside)
                    rem = _clip(rem, a, b, True)
                    if not rem:
                        break
            left = nxt
        out += [(fid, p) for p in left]
    return out


def intersect(pieces, cutter):
    """Only the parts of the pieces inside the cutter outline (counter-clockwise)."""
    parts = _convex_parts(cutter)
    out = []
    for fid, poly in pieces:
        for c in parts:
            rem = poly
            for j in range(len(c)):
                rem = _clip(rem, c[j], c[(j + 1) % len(c)], True)
                if not rem:
                    break
            if rem:
                out.append((fid, rem))
    return out


def intervals(pieces, fid, origin, direction):
    """[(from, to)] along origin + direction t that face fid covers, merged, sorted."""
    ivs = []
    for e, poly in pieces:
        if e != fid:
            continue
        lo, hi, m, ok = -1e18, 1e18, len(poly), True
        for j in range(m):
            p, q = poly[j], poly[(j + 1) % m]
            ex, ez = q[0] - p[0], q[1] - p[1]
            ca = ex * (origin[1] - p[1]) - ez * (origin[0] - p[0])
            cb = ex * direction[1] - ez * direction[0]
            if abs(cb) < 1e-12:
                if ca < -1e-7:
                    ok = False
                    break
                continue
            t = -ca / cb
            if cb > 0:
                lo = max(lo, t)
            else:
                hi = min(hi, t)
        if ok and hi > lo + 1e-7:
            ivs.append((lo, hi))
    ivs.sort()
    merged = []
    for lo, hi in ivs:
        if merged and lo <= merged[-1][1] + 1e-4:
            merged[-1] = (merged[-1][0], max(merged[-1][1], hi))
        else:
            merged.append((lo, hi))
    return merged


def _overlap(ivs, lo, hi):
    """The stretch of [lo, hi] inside the interval of ivs it overlaps most, or None."""
    best = None
    for a, b in ivs:
        x0, x1 = max(lo, a), min(hi, b)
        if x1 > x0 and (best is None or x1 - x0 > best[1] - best[0]):
            best = (x0, x1)
    return best


def height_at(pieces, pt):
    """The underside's height at plan point pt, or None outside every piece."""
    for _e, poly in pieces:
        m = len(poly)
        if all(_cross(poly[j], poly[(j + 1) % m], pt) >= -1e-6 for j in range(m)):
            (x0, z0, h0), (x1, z1, h1), (x2, z2, h2) = poly[0], poly[1], poly[2]
            det = (x1 - x0) * (z2 - z0) - (x2 - x0) * (z1 - z0)
            if abs(det) < 1e-9:
                return h0
            aa = ((h1 - h0) * (z2 - z0) - (h2 - h0) * (z1 - z0)) / det
            bb = ((x1 - x0) * (h2 - h0) - (x2 - x0) * (h1 - h0)) / det
            return h0 + aa * (pt[0] - x0) + bb * (pt[1] - z0)
    return None


def _key(p):
    return (round(p[0], 3), round(p[1], 3), round(p[2], 3))


def split_pieces(pieces):
    """The pieces with every point of another piece that lies partway along one of
    their edges (where the skeleton split, or a cutter clipped) put into that edge, so
    neighbouring pieces meet edge to edge."""
    verts = {}
    for _e, poly in pieces:
        for p in poly:
            verts[_key(p)] = p
    cell = 50.0
    grid = {}
    for v in verts.values():
        grid.setdefault((int(math.floor(v[0] / cell)), int(math.floor(v[1] / cell))), []).append(v)

    def between(p, q):
        L2 = (q[0] - p[0]) ** 2 + (q[1] - p[1]) ** 2
        if L2 < 1e-12:
            return []
        x0, x1 = sorted((p[0], q[0]))
        z0, z1 = sorted((p[1], q[1]))
        on = []
        for gx in range(int(math.floor(x0 / cell)) - 1, int(math.floor(x1 / cell)) + 2):  # a cell spare: points on a cell's edge
            for gz in range(int(math.floor(z0 / cell)) - 1, int(math.floor(z1 / cell)) + 2):
                for v in grid.get((gx, gz), ()):
                    t = ((v[0] - p[0]) * (q[0] - p[0]) + (v[1] - p[1]) * (q[1] - p[1])) / L2
                    if t <= 1e-6 or t >= 1 - 1e-6:
                        continue
                    if abs(_cross(p, q, v)) / math.sqrt(L2) > 1e-3:
                        continue
                    if abs(p[2] + (q[2] - p[2]) * t - v[2]) > 1e-2:
                        continue
                    on.append((t, v))
        return [v for _t, v in sorted(on)]
    out = []
    for e, poly in pieces:
        ring = []
        m = len(poly)
        for j in range(m):
            ring.append(poly[j])
            ring += between(poly[j], poly[(j + 1) % m])
        out.append((e, ring))
    return out


def outside_edges(pieces):
    """The roof's outside edges [(p, q)] ((x, z, y) each), wound as the pieces are (the
    roof on their left): after split_pieces, an edge only one piece uses."""
    use = {}
    for _e, poly in split_pieces(pieces):
        m = len(poly)
        for j in range(m):
            p, q = poly[j], poly[(j + 1) % m]
            use.setdefault(tuple(sorted((_key(p), _key(q)))), []).append((p, q))
    return [v[0] for v in use.values() if len(v) == 1]


def boundary_loops(pieces):
    """outside_edges chained into runs, each edge followed by the one starting where it
    ends."""
    key = _key
    edges = outside_edges(pieces)
    starts = {}
    for i, (p, _q) in enumerate(edges):
        starts.setdefault(key(p), []).append(i)
    loops, seen = [], set()
    for i in range(len(edges)):
        if i in seen:
            continue
        loop, cur = [], i
        while cur is not None and cur not in seen:
            seen.add(cur)
            loop.append(edges[cur])
            nxt = [c for c in starts.get(key(edges[cur][1]), []) if c not in seen]
            cur = nxt[0] if nxt else None
        loops.append(loop)
    return loops


# Settings and sources (through the host, aw_host) ---------------------------------------------

def settings(op):
    import aw_ids as I
    v = lambda pid: aw_host.value(op, pid)  # noqa: E731
    return {"wall": aw_host.link(op, I.AW_ROOF_WALL), "draft": aw_host.link(op, I.AW_ROOF_DRAFT),
            "pitch": math.degrees(float(v(I.AW_ROOF_PITCH))),
            "from_walls": bool(v(I.AW_ROOF_PITCH_FROM_WALLS)), "eave": float(v(I.AW_ROOF_EAVE)),
            "rake": float(v(I.AW_ROOF_RAKE)), "thick": max(float(v(I.AW_ROOF_THICKNESS)), 0.5),
            "offset": float(v(I.AW_ROOF_OFFSET)), "elevation": float(v(I.AW_ROOF_ELEVATION)),
            "shape": int(v(I.AW_ROOF_SHAPE)), "main_edge": int(v(I.AW_ROOF_MAIN_EDGE)),
            "width_l": float(v(I.AW_ROOF_WIDTH_L)), "width_r": float(v(I.AW_ROOF_WIDTH_R)),
            "ends": int(v(I.AW_ROOF_ENDS)),
            "kinds": [int(v(I.roof_edge(i))) for i in range(MAX_EDGES)],
            "fascia": bool(v(I.AW_ROOF_FASCIA)), "fascia_h": float(v(I.AW_ROOF_FASCIA_H)),
            "fascia_w": float(v(I.AW_ROOF_FASCIA_W)), "barge": bool(v(I.AW_ROOF_BARGE)),
            "barge_h": float(v(I.AW_ROOF_BARGE_H)), "barge_w": float(v(I.AW_ROOF_BARGE_W)),
            "rafters": bool(v(I.AW_ROOF_RAFTERS)), "rafter_w": float(v(I.AW_ROOF_RAFTER_W)),
            "rafter_h": float(v(I.AW_ROOF_RAFTER_H)), "rafter_s": max(float(v(I.AW_ROOF_RAFTER_S)), 5.0),
            "tiles": bool(v(I.AW_ROOF_TILES)), "tile_model": int(v(I.AW_ROOF_TILE_MODEL)),
            "tile_w": max(float(v(I.AW_ROOF_TILE_W)), 5.0), "tile_l": max(float(v(I.AW_ROOF_TILE_L)), 5.0),
            "tile_t": max(float(v(I.AW_ROOF_TILE_T)), 0.2), "tile_over": max(float(v(I.AW_ROOF_TILE_OVER)), 0.0)}


def _alive(obj):
    return aw_host.alive(obj)


def outlines(wall):
    """([(outline, sloped per edge)] of the wall's rooms on their outside face,
    straight runs merged, wall_path) or (None, None) without a wall path."""
    import aw_slab
    import aw_wall
    wp = aw_wall.wall_path(wall) if _alive(wall) else None
    if wp is None:
        return None, None
    plan, w0, _w1, _height, _s = wp
    out = []
    for pts, rises in aw_slab.outlines_with_rise(plan, w0):
        n = len(pts)
        sloped = [abs(rises[i] - rises[(i + 1) % n]) > 1e-4 for i in range(n)]
        out.append(merge_collinear(pts, sloped))
    return out, wp


def wall_pitch(plan):
    """The pitch (degrees) of the wall's sloped tops, the middle one of them, or None."""
    slopes = []
    for seg in plan.segments:
        rise = abs(seg["hb"] - seg["ha"])
        run = seg.get("u1", seg["length"]) - seg.get("u0", 0.0)
        if rise > 1e-4 and run > 1e-4:
            slopes.append(math.degrees(math.atan2(rise, run)))
    if not slopes:
        return None
    slopes.sort()
    return slopes[len(slopes) // 2]


def own_splines(op):
    """([outlines], [axes]): the roof's own closed and open child splines (not its
    Roof Cutters), outlines counter-clockwise with straight runs merged."""
    import aw_ids as I
    closed, opened = aw_host.spline_paths(op, skip=(I.ID_AW_ROOF_CUTTER,))
    loops = []
    for pts in closed:
        if len(pts) >= 3 and abs(area(pts)) > 1e-3:
            pts = pts if area(pts) > 0 else pts[::-1]
            loops.append(merge_collinear(pts, [False] * len(pts))[0])
    return loops, [p for p in opened if len(p) >= 2]


_edge_counts = {}  # a wall's identity -> (its path key, how many outline edges its rooms have)


def edge_count(op):
    """How many outline edges the roof has (for showing its Edges tab): a wall's
    cached by its path key; a draft's or an axis's none (their edges aren't set one
    by one)."""
    import aw_ids as I
    try:
        if _alive(aw_host.link(op, I.AW_ROOF_DRAFT)):
            return 0
        wall = aw_host.link(op, I.AW_ROOF_WALL)
        if _alive(wall):
            key, ident = aw_host.path_key(wall), aw_host.ident(wall)
            hit = _edge_counts.get(ident)
            if hit and hit[0] == key:
                return hit[1]
            rooms, _wp = outlines(wall)
            count = sum(len(p) for p, _f in rooms or [])
            _edge_counts[ident] = (key, count)
            return count
        loops, _axes = own_splines(op)
        return sum(len(p) for p in loops)
    except Exception:
        return 0


def cutters(op):
    """[(outline counter-clockwise in op's space, mode)] of the Roof Cutters under op."""
    import aw_ids as I
    out = []
    for child in aw_host.children(op):
        if aw_host.type_id(child) != I.ID_AW_ROOF_CUTTER:
            continue
        outline = cutter_outline(child)
        if outline is None:
            continue
        ml = aw_host.local_matrix(child)
        pts = [(p.x, p.z) for p in (ml * Vec(x, 0, z) for x, z in outline)]
        if len(pts) >= 3 and abs(area(pts)) > 1e-3:
            out.append((pts if area(pts) > 0 else pts[::-1], int(aw_host.value(child, I.AW_RCUT_MODE))))
    return out


def faces(op, s, meta=None):
    """(pieces, frames, to_local): the roof's planes in their source's space (a wall's,
    or the roof's own), to_local carrying that space into the roof's. meta (a dict),
    if given, is filled with what the roof's dimensions need (aw_roofdims): its
    source, the pitch it used, each outline or axis it roofed, and each face's slope
    as a multiple of the pitch's."""
    pieces, frames = [], {}
    meta = {} if meta is None else meta
    meta.update(source="own", pitch=s["pitch"], outlines=[], scale={})

    def add(pc, fr):
        pieces.extend(pc)
        frames.update(fr)

    def tan_of(pitch):
        return math.tan(math.radians(min(max(pitch, 1.0), 85.0)))

    def roof_loops(rooms, y_eave_line, tan):
        base = 0
        for pts, sloped in rooms:
            n = len(pts)
            kinds = kinds_for(pts, sloped, s["shape"], s["main_edge"], s["kinds"][base:base + n])
            if any(k == EAVE for k in kinds):
                outs = [s["eave"] if k == EAVE else s["rake"] for k in kinds]
                y_edge = y_eave_line - s["eave"] * tan
                pc, fr, poly = skeleton_faces(pts, kinds, [tan] * n, outs, y_edge, base)
                add(pc, fr)
                meta["outlines"].append({"type": "loop", "pts": pts, "poly": poly, "kinds": kinds, "outs": outs,
                                         "y_edge": y_edge, "tans": [tan] * n})
                meta["scale"].update({f: 1.0 for f in fr})
            base += n
        return base
    draft, wall = s["draft"], s["wall"]
    if _alive(draft):
        mesh = aw_host.custom_mesh(draft)
        if mesh:
            m = aw_host.relative(op, draft)
            pts = [(q.x, q.y + s["offset"], q.z) for q in (m * p for p in mesh[0])]
            add(*draft_faces(pts, mesh[1], 0))
        meta["source"] = "draft"
        return pieces, frames, Mat()
    if _alive(wall):
        rooms, wp = outlines(wall)
        if not rooms:
            return [], {}, Mat()
        plan, _w0, _w1, height, _sp = wp
        pitch = (wall_pitch(plan) if s["from_walls"] else None) or s["pitch"]
        meta.update(source="wall", pitch=pitch)
        roof_loops(rooms, height + s["offset"], tan_of(pitch))
        return pieces, frames, aw_host.relative(op, wall)
    loops, axes = own_splines(op)
    fid = roof_loops([(p, [False] * len(p)) for p in loops], s["elevation"] + s["offset"], tan_of(s["pitch"]))
    for path in axes:  # roof sections along an axis: the eaves at Elevation along their outer edges
        ax = axis_outline(path, s["width_l"], s["width_r"], s["ends"], s["pitch"])
        if ax is None:
            continue
        pts, kinds, tans = ax
        outs = [0.0 if k == EAVE else s["rake"] for k in kinds]
        pc, fr, poly = skeleton_faces(pts, kinds, tans, outs, s["elevation"] + s["offset"], 1000 + fid)
        add(pc, fr)
        meta["outlines"].append({"type": "axis", "path": path, "pts": pts, "poly": poly, "kinds": kinds,
                                 "outs": outs, "y_edge": s["elevation"] + s["offset"], "tans": tans})
        tp = tan_of(s["pitch"])
        meta["scale"].update({f: frm.tan / tp for f, frm in fr.items()})
        fid += len(pts)
    return pieces, frames, Mat()


def build(op, meta=None, draft=False):
    """The roof's mesh in its own space, or None. meta (a dict), if given, is filled
    as faces() fills it, plus the pieces and frames as built (holes cut), to_local and
    the settings, for the roof's dimensions. draft: no tiles (they're slow to build),
    while it's being drawn or dragged."""
    from aw_mesh import MeshBuilder
    s = settings(op)
    meta = {} if meta is None else meta
    pieces, frames, to_local = faces(op, s, meta)
    meta.update(to=to_local, settings=s, pieces=[], frames=frames)
    if not pieces:
        return None
    inv = ~to_local
    cuts = []
    for pts, mode in cutters(op):  # each cutter's outline into the faces' space
        local = [(q.x, q.z) for q in (inv * Vec(x, 0, z) for x, z in pts)]
        cuts.append((local if area(local) > 0 else local[::-1], mode))
    for local, mode in cuts:
        if mode == CUT_KEEP:
            pieces = intersect(pieces, local)
    trim_pieces = pieces  # the trim follows the roof's edge, not its holes
    for local, mode in cuts:
        if mode == CUT_HOLE:
            pieces = subtract(pieces, local)
    if not pieces:
        return None
    meta["pieces"] = pieces
    mesh = MeshBuilder(GROUPS)
    _solid(mesh, pieces, s["thick"], to_local)
    if s["fascia"] or s["barge"]:
        _trim(mesh, trim_pieces, s, to_local)
    if s["rafters"]:
        _rafters(mesh, pieces, frames, s, to_local)
    if s["tiles"] and not draft:
        covered = tile_pieces(pieces, trim_pieces, s)
        _covering(mesh, covered, frames, s, to_local)
        _starter(mesh, pieces, covered, s, to_local)
    return mesh.build(aw_host.name(op))


# Building the parts --------------------------------------------------------------

def _xyz(v):
    return (v.x, v.y, v.z)


def _pt(mesh, to_local, x, y, z):
    p = to_local * Vec(x, y, z)
    return mesh.pt(p.x, p.y, p.z)


def _box(mesh, to_local, corner, group):
    """A closed six-sided solid from corner(i, j, k) -> (x, y, z) in the faces' space,
    turned so its normals point out."""
    c = {(i, j, k): _xyz(to_local * Vec(*corner(i, j, k))) for i in (0, 1) for j in (0, 1) for k in (0, 1)}
    first = len(mesh.polys)
    mesh.hexa(c, group)
    mesh._face_out(first)


def _solid(mesh, pieces, thick, to_local, groups=("Covering", "Soffit", "Edge")):
    """The roof deck: every piece's underside (Soffit) and top (Covering), and its
    outside edge all round, holes included (Edge); groups names them (a countertop
    uses this too)."""
    g_top, g_bottom, g_edge = groups
    mesh.new_part()
    first = len(mesh.polys)
    split = split_pieces(pieces)
    for (_e, poly), (_e2, ring) in zip(pieces, split):
        if len(ring) > len(poly):  # points along its edges: fan from its middle, so no sliver has no area
            mid = tuple(sum(p[k] for p in poly) / len(poly) for k in range(3))
            bot = [_pt(mesh, to_local, x, y, z) for x, z, y in ring]
            top = [_pt(mesh, to_local, x, y + thick, z) for x, z, y in ring]
            bm = _pt(mesh, to_local, mid[0], mid[2], mid[1])
            tm = _pt(mesh, to_local, mid[0], mid[2] + thick, mid[1])
            m = len(ring)
            for i in range(m):
                mesh.quad(tm, top[(i + 1) % m], top[i], top[i], g_top)
                mesh.quad(bm, bot[i], bot[(i + 1) % m], bot[(i + 1) % m], g_bottom)
            continue
        bot = [_pt(mesh, to_local, x, y, z) for x, z, y in poly]
        top = [_pt(mesh, to_local, x, y + thick, z) for x, z, y in poly]
        for i in range(1, len(poly) - 1):  # pieces are convex: a fan
            mesh.quad(top[0], top[i + 1], top[i], top[i], g_top)
            mesh.quad(bot[0], bot[i], bot[i + 1], bot[i + 1], g_bottom)
    for p, q in outside_edges(pieces):
        a, b = _pt(mesh, to_local, p[0], p[2], p[1]), _pt(mesh, to_local, q[0], q[2], q[1])
        ta, tb = _pt(mesh, to_local, p[0], p[2] + thick, p[1]), _pt(mesh, to_local, q[0], q[2] + thick, q[1])
        mesh.quad(ta, tb, b, a, g_edge)
    mesh._face_out(first)


def _trim(mesh, pieces, s, to_local):
    """Fascia along every level outside edge (the eaves, a shed's high side), Bargeboard
    up every sloped one (the rakes), each standing just outside the edge, its top
    flush with the covering; where two of a kind meet at a corner they are mitred, and
    where a fascia meets a bargeboard round a corner the fascia runs on over its end."""
    thick = s["thick"]
    planes = {}  # an outside edge -> the plane of the piece it bounds, to seat the boards under the tiles
    for _e, poly in split_pieces(pieces):
        h = _plane_height(poly)
        for j in range(len(poly)):
            planes[tuple(sorted((_key(poly[j]), _key(poly[(j + 1) % len(poly)]))))] = h
    for loop in boundary_loops(pieces):
        n = len(loop)
        info = []
        for p, q in loop:
            L = math.dist(p[:2], q[:2])
            level = L > 1e-6 and abs(q[2] - p[2]) <= 1e-4 * max(L, 1.0)
            kind = "Fascia" if level else "Bargeboard"
            w = s["fascia_w"] if level else s["barge_w"]
            dx, dz = ((q[0] - p[0]) / L, (q[1] - p[1]) / L) if L > 1e-9 else (1.0, 0.0)
            out = (dz, -dx)  # the roof is on the left: outside is to the right
            line = ((-out[0], -out[1]), (dx, dz), -(out[0] * p[0] + out[1] * p[1]) - w)
            info.append((kind, w, out, line, L, (dx, dz)))
        closed = n > 1 and math.dist(loop[-1][1][:2], loop[0][0][:2]) < 1e-3

        def on(kind):
            return s["fascia" if kind == "Fascia" else "barge"]
        for i, (p, q) in enumerate(loop):
            kind, w, out, line, L, d = info[i]
            if L < 1e-6 or not on(kind):
                continue

            def end(at, other, after, kind=kind, w=w, out=out, line=line, d=d):
                """(inside, outside) corners of this end in plan: mitred to one of its own
                kind; a fascia runs on round an outside corner to the bargeboard's face,
                covering its end (the bargeboard stops behind it), so they close flush."""
                fallback = ((at[0], at[1]), (at[0] + out[0] * w, at[1] + out[1] * w))
                if other is None:
                    return fallback
                ok = info[other]
                if abs(ok[2][0] * out[1] - ok[2][1] * out[0]) <= 1e-3:
                    return fallback  # straight on
                if ok[0] == kind:
                    return fallback[0], _meet(ok[3], line, fallback[1])
                turn = (d[0] * ok[5][1] - d[1] * ok[5][0]) if after else (ok[5][0] * d[1] - ok[5][1] * d[0])
                if kind != "Fascia" or not on(ok[0]) or turn <= 0:  # an inside corner: each stops at the edge
                    return fallback
                inner = ((-out[0], -out[1]), d, -(out[0] * at[0] + out[1] * at[1]))
                return _meet(ok[3], inner, fallback[0]), _meet(ok[3], line, fallback[1])
            prev = i - 1 if i > 0 else (n - 1 if closed else None)
            nxt = i + 1 if i < n - 1 else (0 if closed else None)
            ends = ((p, end(p, prev, False)), (q, end(q, nxt, True)))
            depth = max(s["fascia_h"] if kind == "Fascia" else s["barge_h"], 0.5)
            plane = planes.get(tuple(sorted((_key(p), _key(q)))))

            def corner(ii, jj, kk, ends=ends, depth=depth, plane=plane):
                """Its top on the roof's plane where that falls away from the edge (an eave's
                fascia, cut to the pitch, so the tiles run on over it), level where it would
                rise (a shed's high side) or runs level (a bargeboard)."""
                at, plan = ends[ii]
                x, z = plan[jj]
                if kk == 0:  # its bottom level, Height below the deck's top at the edge
                    return (x, at[2] + thick - depth, z)
                return (x, min(plane(x, z), at[2]) + thick if plane is not None else at[2] + thick, z)
            _box(mesh, to_local, corner, kind)


def _face_range(pieces, fid, frame):
    """(u min, u max, tau min, tau max) of face fid in its frame, or None."""
    pts = [(p[0], p[1]) for e, pc in pieces if e == fid for p in pc]
    if not pts:
        return None
    us, ts = [frame.u(p) for p in pts], [frame.tau(p) for p in pts]
    return min(us), max(us), min(ts), max(ts)


def _rafters(mesh, pieces, frames, s, to_local):
    """Rafters under the deck on every face, Spacing apart along it, each running up
    the slope from where the face starts (an eave, or a valley) to where it ends (a
    ridge, a hip, or a hole)."""
    rw, rh, sp = max(s["rafter_w"], 0.5), max(s["rafter_h"], 0.5), s["rafter_s"]
    for fid, fr in frames.items():
        rng = _face_range(pieces, fid, fr)
        if rng is None:
            continue
        u = rng[0] + sp / 2
        while u < rng[1] - rw / 2:
            r0 = intervals(pieces, fid, fr.at(u - rw / 2, 0.0), fr.n)
            r1 = intervals(pieces, fid, fr.at(u + rw / 2, 0.0), fr.n)
            for a, b in r0:
                m = _overlap(r1, a, b)
                if m is None or m[1] - m[0] <= rw:
                    continue
                spans = ((a, b), m)

                def corner(ii, jj, kk, spans=spans, u=u):
                    x, z = fr.at(u + (-rw / 2, rw / 2)[jj], spans[jj][ii])
                    return (x, fr.y((x, z)) - (rh if kk == 0 else 0.0), z)
                _box(mesh, to_local, corner, "Rafters")
            u += sp


def _jitter(i, j, k):
    """A steady pseudo-random number in -1..1 for row i, tile j (slates vary, but never
    from one rebuild to the next)."""
    x = math.sin(i * 12.9898 + j * 78.233 + k * 37.719) * 43758.5453
    return (x - math.floor(x)) * 2.0 - 1.0


def _tint(row, col, u, spread=0.24):
    """A tile's own shade (r, g, b around 1): asphalt shingles and tiles are never all
    alike. Mostly lighter or darker (by up to spread), a little warmer or cooler; the
    same on every rebuild."""
    k = 1.0 + spread * _jitter(row, col, 3) + 0.06 * _jitter(row, int(u), 4)
    warm = (0.03 + spread * 0.1) * _jitter(row, col, 5)
    return (max(0.0, k * (1 + warm)), max(0.0, k), max(0.0, k * (1 - warm)))


def _plane_height(poly):
    """fn(x, z) -> the height of the plane a piece lies on (its first three points)."""
    (x0, z0, h0), (x1, z1, h1), (x2, z2, h2) = poly[0], poly[1], poly[2]
    det = (x1 - x0) * (z2 - z0) - (x2 - x0) * (z1 - z0)
    if abs(det) < 1e-9:
        return lambda x, z: h0
    aa = ((h1 - h0) * (z2 - z0) - (h2 - h0) * (z1 - z0)) / det
    bb = ((x1 - x0) * (h2 - h0) - (x2 - x0) * (h1 - h0)) / det
    return lambda x, z: h0 + aa * (x - x0) + bb * (z - z0)


def tile_pieces(pieces, outline, s):
    """What the tiles cover: the pieces with every edge on the roof's outline (outline:
    the pieces before any hole) pushed out on its own plane past the fascia (a level
    edge) or the bargeboard (a sloped one), by its width when it's on, and Overhang
    beyond; a hole's edges stay where they are."""
    edges = []
    for p, q in outside_edges(outline):
        L = math.dist(p[:2], q[:2])
        if L > 1e-6:
            level = abs(q[2] - p[2]) <= 1e-4 * max(L, 1.0)
            trim = (s["fascia_w"] if s["fascia"] else 0.0) if level else (s["barge_w"] if s["barge"] else 0.0)
            edges.append((p, q, L, trim + s["tile_over"]))

    def push(a, b):
        """How far edge a..b goes out: by its outline edge's, when it lies along one."""
        m = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        for p, q, L, out in edges:
            dx, dz = (q[0] - p[0]) / L, (q[1] - p[1]) / L
            if abs((m[0] - p[0]) * dz - (m[1] - p[1]) * dx) < 1e-3 and abs((b[0] - a[0]) * dz - (b[1] - a[1]) * dx) < 1e-3:
                along = (m[0] - p[0]) * dx + (m[1] - p[1]) * dz
                if -1e-3 <= along <= L + 1e-3:
                    return out
        return 0.0
    out = []
    for e, poly in pieces:
        m = len(poly)
        outs = [push(poly[j], poly[(j + 1) % m]) for j in range(m)]
        if not any(outs):
            out.append((e, poly))
            continue
        h = _plane_height(poly)
        flat = offset([(x, z) for x, z, _h in poly], outs)
        out.append((e, [(x, z, h(x, z)) for x, z in flat]))
    return out


def _starter(mesh, pieces, covered, s, to_local):
    """A starter strip under the tiles where they overhang the trim, from the deck's edge
    out to theirs: what shows through under each row's raised edge is asphalt, not the
    fascia's or bargeboard's top. covered: the pieces as tile_pieces pushed them out,
    point for point."""
    thick = s["thick"]
    model = s["tile_model"]
    # as tall as the wedge under a row's raised edge (two layers of a dimensional strip, one
    # tile), filling it where the rows end at the rake: never over the rows themselves
    tall = {DIMENSIONAL: 2.0 * s["tile_t"], SEAM: STARTER_T}.get(model, s["tile_t"])
    for (_e, poly), (_e2, out) in zip(pieces, covered):
        if out is poly:
            continue
        h, m = _plane_height(poly), len(poly)
        for j in range(m):
            k = (j + 1) % m
            a, b = poly[j], poly[k]
            L = math.dist(a[:2], b[:2])
            if L < 1e-6:
                continue
            nx, nz = -(b[1] - a[1]) / L, (b[0] - a[0]) / L  # into the piece
            moved = max(abs((q[0] - a[0]) * nx + (q[1] - a[1]) * nz) for q in (out[j], out[k]))
            if moved < 1e-6:
                continue  # this edge stays where it is (a ridge, a hip, a valley, a hole)
            quad = ((a, out[j]), (b, out[k]))

            def corner(ii, jj, kk, quad=quad, h=h):
                x, z = quad[ii][jj][0], quad[ii][jj][1]
                return (x, h(x, z) + thick + (tall if kk else 0.0), z)
            _box(mesh, to_local, corner, "Tiles")


def _covering(mesh, pieces, frames, s, to_local):
    """Tiles (or a standing seam), then the caps."""
    model = s["tile_model"] if s["tile_model"] in TILE_DEFAULTS else PLAIN
    if model == SEAM:
        _standing_seam(mesh, pieces, frames, s, to_local)
        _caps(mesh, pieces, PANEL_THICK + s["tile_t"], s, to_local)
    else:
        _tiles(mesh, pieces, frames, model, s, to_local)
        lift = s["tile_t"] * (DIM_RISE + 3.0) + DIM_LIFT if model == DIMENSIONAL else s["tile_t"] * 2.0  # over its tabs
        _caps(mesh, pieces, lift, s, to_local)


def _tiles(mesh, pieces, frames, model, s, to_local):
    """Every face covered in rows Exposure apart up the slope (from where the face
    starts), every other row shifted half a tile, each tile lapping the row above and
    tilted so its bottom edge stands proud; every tile clipped to the face along both
    its edges, so the covering ends clean at a rake, a hip, a valley or a cutter.
    Plain Tile: thick flat tiles; Shingle: thin strips of three tabs; Slate: thin
    slates, each a little different; Dimensional Shingle: laminated strips of uneven
    tabs (_dimensional)."""
    W, Lx, T, thick = s["tile_w"], s["tile_l"], s["tile_t"], s["thick"]
    count = 0
    for fid, fr in frames.items():
        rng = _face_range(pieces, fid, fr)
        if rng is None:
            continue
        step = Lx / math.sqrt(1.0 + fr.tan * fr.tan)  # Exposure along the slope, in plan
        lap = step * 0.6
        row = 0
        while count < MAX_TILES:
            t0 = rng[2] + row * step
            if t0 >= rng[3] - 1e-3:
                break
            t1 = min(t0 + step + lap, rng[3])
            s0 = intervals(pieces, fid, fr.at(0.0, t0 + 1e-4), fr.d)
            s1 = intervals(pieces, fid, fr.at(0.0, t1 - 1e-4), fr.d)
            if not s0 and not s1:
                row += 1
                continue
            s0, s1 = s0 or s1, s1 or s0
            lo_all = min(a for a, _b in s0 + s1)
            hi_all = max(b for _a, b in s0 + s1)
            shift = (W / 2 if row % 2 else 0.0) + (_jitter(row, 0, 1) * W * 0.25 if model == SLATE else 0.0)
            if model == DIMENSIONAL:  # strips laid at random offsets, so no joint lines up
                shift = (_jitter(row, 0, 7) + 1.0) / 2.0 * W
                levels = {}
                for c in DIM_CUTS + (1.0 + 0.3,):
                    iv = intervals(pieces, fid, fr.at(0.0, min(t0 + c * step, t1) - 1e-4), fr.d)
                    levels[c] = iv or s1
            u = math.floor((lo_all - shift) / W) * W + shift  # the same joints on every face's row
            col = 0
            while u < hi_all - 1e-3 and count < MAX_TILES:
                if model == DIMENSIONAL:
                    count += _dimensional(mesh, fr, (row, col), u, W, (t0, t1, step), (s0, s1), levels,
                                          thick, T, to_local)
                    u += W
                    col += 1
                    continue
                parts = [(u, u + W)]
                if model == SHINGLE:  # the strip's tabs, slots between them
                    tw = W / SHINGLE_TABS
                    parts = [(u + k * tw + (SHINGLE_SLOT / 2 if k else 0), u + (k + 1) * tw -
                              (SHINGLE_SLOT / 2 if k < SHINGLE_TABS - 1 else 0)) for k in range(SHINGLE_TABS)]
                tint = _tint(row, col, u)
                gap = TILE_GAP / 2 if model != SHINGLE else 0.0
                for pu0, pu1 in parts:
                    e0 = _overlap(s0, pu0 + gap, pu1 - gap)
                    e1 = _overlap(s1, pu0 + gap, pu1 - gap)
                    if e0 is None or e1 is None or min(e0[1] - e0[0], e1[1] - e1[0]) < 0.2:
                        continue
                    slant = (1.0 + _jitter(row, col, 2) * 0.35) if model == SLATE else 1.0
                    ends = ((t0, e0), (t1, e1))

                    def corner(ii, jj, kk, ends=ends, slant=slant):
                        tau, span = ends[ii]
                        x, z = fr.at(span[jj], tau)
                        return (x, fr.y((x, z)) + thick + T * slant * (1.0 - ii) + (T if kk else 0.0), z)
                    p0 = len(mesh.points)
                    _box(mesh, to_local, corner, "Tiles")
                    for k in range(p0, len(mesh.points)):
                        mesh.tints[k] = tint
                    count += 1
                u += W
                col += 1
            row += 1


def _dimensional(mesh, fr, rc, u, W, rows, spans, levels, thick, T, to_local):
    """One dimensional shingle strip from u to u + W: its base strip, in shadow, then its
    tabs laminated on it, each of uneven width, some cut shorter, each a little lifted,
    tilted and turned, each its own shade. rows: (bottom, top, exposure) up the slope;
    spans: the face's run across the strip's bottom and top; levels: its run at each cut
    (DIM_CUTS, and the tabs' top, keyed 1.3). How many solids it made."""
    row, col = rc
    t0, t1, step = rows
    s0, s1 = spans
    made = 0
    rise = T * DIM_RISE  # the strip tilts up from its top to rest its bottom on the two layers below

    def tilt(tau):
        return rise * min(max((t1 - tau) / max(t1 - t0, 1e-6), 0.0), 1.0)
    strip = _tint(row, col, u, DIM_SHADE)  # a strip's tabs are from one batch: alike, not the same
    e0, e1 = _overlap(s0, u, u + W), _overlap(s1, u, u + W)
    if e0 is not None and e1 is not None and min(e0[1] - e0[0], e1[1] - e1[0]) >= 0.2:
        ends = ((t0, e0), (t1, e1))

        def base(ii, jj, kk, ends=ends):
            tau, span = ends[ii]
            x, z = fr.at(span[jj], tau)
            return (x, fr.y((x, z)) + thick + tilt(tau) + (T if kk else 0.0), z)
        p0 = len(mesh.points)
        _box(mesh, to_local, base, "Tiles")
        shade = tuple(c * DIM_BASE_SHADE for c in strip)
        for k in range(p0, len(mesh.points)):
            mesh.tints[k] = shade
        made += 1
    top = min(t0 + step * 1.3, t1)  # under the next row's strip; at most to the face's top (a ridge)
    a, k = u, 0
    while a < u + W - 1.0:
        r = (_jitter(row, col * 31 + k, 6) + 1.0) / 2.0
        b = min(a + DIM_TAB[0] + r * (DIM_TAB[1] - DIM_TAB[0]), u + W)
        if u + W - b < DIM_TAB[0] / 2:
            b = u + W  # no sliver at the end
        cut = DIM_CUTS[min(int((_jitter(row, col * 31 + k, 8) + 1.0) / 2.0 * len(DIM_CUTS)), len(DIM_CUTS) - 1)]
        lo, hi = a + DIM_SLOT / 2, b - DIM_SLOT / 2
        f0, f1 = _overlap(levels[cut], lo, hi), _overlap(levels[1.3], lo, hi)
        if f0 is not None and f1 is not None and min(f0[1] - f0[0], f1[1] - f1[0]) >= 0.2:
            whole = f0 == (lo, hi) and f1 == (lo, hi)  # turned only where nothing clips it
            twist = DIM_TWIST * _jitter(row, col * 31 + k, 9) if whole else 0.0
            lift = DIM_LIFT * (_jitter(row, col * 31 + k, 10) + 1.0) / 2.0
            bottom = t0 + cut * step
            if top - bottom < 0.5:  # cut away to nothing under a ridge
                a, k = b, k + 1
                continue
            ends = ((bottom, f0), (top, f1))
            mid = (bottom + top) / 2

            def tab(ii, jj, kk, ends=ends, twist=twist, lift=lift, mid=mid):
                tau, span = ends[ii]
                x, z = fr.at(span[jj] + twist * (tau - mid), tau)
                return (x, fr.y((x, z)) + thick + T + tilt(tau) + lift * (1.0 - ii) + (T if kk else 0.0), z)
            p0 = len(mesh.points)
            _box(mesh, to_local, tab, "Tiles")
            v = 1.0 + DIM_SHADE / 3 * _jitter(row, col * 31 + k, 3)
            shade = tuple(c * v for c in strip)
            for kk in range(p0, len(mesh.points)):
                mesh.tints[kk] = shade
            made += 1
        a, k = b, k + 1
    return made


def _standing_seam(mesh, pieces, frames, s, to_local):
    """A standing seam metal roof: on every face, panels Width wide running up the slope
    from where the face starts (an eave or a valley) to where it ends, around any
    cutter, a seam Thickness tall standing at every joint between them."""
    W, H, thick = max(s["tile_w"], 5.0), max(s["tile_t"], 0.5), s["thick"]
    for fid, fr in frames.items():
        rng = _face_range(pieces, fid, fr)
        if rng is None:
            continue

        def runs(u, fid=fid, fr=fr):
            return intervals(pieces, fid, fr.at(u, 0.0), fr.n)
        u, joints = rng[0], []
        while u < rng[1] - 1e-3:
            u0, u1 = u, min(u + W, rng[1])
            r0, r1 = runs(u0 + 1e-3), runs(u1 - 1e-3)
            for a, b in r0:  # a sheet for each stretch the strip's two edges share
                m = _overlap(r1, a, b)
                if m is None:
                    continue
                spans = ((a, b), m)

                def corner(ii, jj, kk, spans=spans, u0=u0, u1=u1, fr=fr):
                    x, z = fr.at((u0, u1)[jj], spans[jj][ii])
                    return (x, fr.y((x, z)) + thick + (PANEL_THICK if kk else 0.0), z)
                _box(mesh, to_local, corner, "Tiles")
            if u1 < rng[1] - 1e-3:
                joints.append(u1)
            u = u1
        for uj in joints:  # a seam standing at each joint, along the panels' run there
            ra, rb = runs(uj - SEAM_WIDTH / 2), runs(uj + SEAM_WIDTH / 2)
            for a, b in ra:
                m = _overlap(rb, a, b)
                if m is None or m[1] - m[0] < 1.0:
                    continue

                def corner(ii, jj, kk, m=m, uj=uj, fr=fr):
                    x, z = fr.at(uj + (-SEAM_WIDTH / 2, SEAM_WIDTH / 2)[jj], m[ii])
                    return (x, fr.y((x, z)) + thick + (PANEL_THICK, PANEL_THICK + H)[kk], z)
                _box(mesh, to_local, corner, "Tiles")


def _on_face(pieces, a, b, probe):
    """((t0, t1), plane): the stretch of plan segment a..b (t from 0 at a to 1 at b) that
    lies on the face holding plan point probe, round the part of it nearest probe, and
    that face's plane (fn(x, z) -> height); None when probe is on no face. Pieces are
    convex and counter-clockwise."""
    held = next(((e, poly) for e, poly in pieces if all(_cross(poly[j], poly[(j + 1) % len(poly)], probe) >= -1e-6
                                                         for j in range(len(poly)))), None)
    if held is None:
        return None
    fid, plane = held[0], _plane_height(held[1])
    spans = []
    for e, poly in pieces:
        if e != fid:
            continue
        t0, t1, m = 0.0, 1.0, len(poly)
        for j in range(m):  # inside every edge (Cyrus-Beck)
            fa, fb = _cross(poly[j], poly[(j + 1) % m], a), _cross(poly[j], poly[(j + 1) % m], b)
            if fa < -1e-6 and fb < -1e-6:
                t0, t1 = 1.0, 0.0
                break
            if (fa < 0) != (fb < 0) and abs(fa - fb) > 1e-12:
                t = fa / (fa - fb)
                t0, t1 = (max(t0, t), t1) if fa < 0 else (t0, min(t1, t))
        if t1 > t0 + 1e-9:
            spans.append([t0, t1])
    spans.sort()
    merged = []
    for t0, t1 in spans:
        if merged and t0 <= merged[-1][1] + 1e-6:
            merged[-1][1] = max(merged[-1][1], t1)
        else:
            merged.append([t0, t1])
    if not merged:
        return None
    best = min(merged, key=lambda m: 0.0 if m[0] <= 0.5 <= m[1] else min(abs(m[0] - 0.5), abs(m[1] - 0.5)))
    return tuple(best), plane


def _caps(mesh, pieces, lift, s, to_local):
    """Caps along every hip and ridge, the edges two roof faces share where both fall
    away from it, and a cover along every valley, where both rise from it, hiding
    where the tiles of the two faces meet (not a fold between pieces of one face). A
    cap folds over its edge, a valley cover into it: one thin strip up or down each
    slope, lying on its face just above the covering, the two meeting in the crease;
    it ends where the edge does (flush at a rake)."""
    def key(p):
        return (round(p[0], 3), round(p[1], 3), round(p[2], 3))
    shared = {}
    for e, poly in pieces:
        m = len(poly)
        for j in range(m):
            p, q = poly[j], poly[(j + 1) % m]
            shared.setdefault(tuple(sorted((key(p), key(q)))), set()).add(e)
    thick = s["thick"]
    for (p, q), fids in shared.items():
        if len(fids) < 2 or math.dist(p[:2], q[:2]) < 1e-3:
            continue
        dx, dz = q[0] - p[0], q[1] - p[1]
        L = math.hypot(dx, dz)
        side = (-dz / L, dx / L)
        mid = ((p[0] + q[0]) / 2, (p[1] + q[1]) / 2, (p[2] + q[2]) / 2)
        drops = []
        for sgn in (1, -1):  # how far each slope falls away over the cap's width
            h = height_at(pieces, (mid[0] + side[0] * sgn * CAP_WIDTH, mid[1] + side[1] * sgn * CAP_WIDTH))
            drops.append(None if h is None else mid[2] - h)
        if any(dr is None for dr in drops):
            continue
        if not (all(dr > 1e-6 for dr in drops) or all(dr < -1e-6 for dr in drops)):
            continue  # a fold between pieces of one face (or a slope and a flat): no edge to cover
        for sgn, drop in zip((1, -1), drops):
            # its outer edge ends where its face does: not past a ridge (a valley's top) or an eave
            oa = (p[0] + side[0] * sgn * CAP_WIDTH, p[1] + side[1] * sgn * CAP_WIDTH)
            ob = (q[0] + side[0] * sgn * CAP_WIDTH, q[1] + side[1] * sgn * CAP_WIDTH)
            probe = (mid[0] + side[0] * sgn * CAP_WIDTH / 2, mid[1] + side[1] * sgn * CAP_WIDTH / 2)
            held = _on_face(pieces, oa, ob, probe)
            span, plane = held if held is not None else ((0.0, 1.0), None)
            outer = [(oa[0] + (ob[0] - oa[0]) * t, oa[1] + (ob[1] - oa[1]) * t) for t in span]

            def corner(ii, jj, kk, sgn=sgn, drop=drop, outer=outer, plane=plane):
                if jj == 0:  # in the crease
                    v = (p, q)[ii]
                    x, z, y = v[0], v[1], v[2] + thick + lift
                else:  # out on its own face's plane (not whatever face is below, past a step)
                    x, z = outer[ii]
                    y = (plane(x, z) if plane is not None else (p, q)[ii][2] - drop) + thick + lift
                return (x, y + (CAP_THICK if kk else 0.0), z)
            _box(mesh, to_local, corner, "Tiles")


# Roof Cutter ---------------------------------------------------------------------

def cutter_outline(op):
    """A Roof Cutter's outline, [(x, z)] closed and flat in its own XZ plane:
    Rectangle (Width by Length), Circle (Width across) or Custom (its first child
    curve, laid flat); None without one."""
    import aw_ids as I
    shape = int(aw_host.value(op, I.AW_RCUT_SHAPE))
    w = max(float(aw_host.value(op, I.AW_RCUT_WIDTH)), 0.1)
    l = max(float(aw_host.value(op, I.AW_RCUT_LENGTH)), 0.1)  # noqa: E741
    if shape == CUT_CIRCLE:
        return [(w / 2 * math.cos(2 * math.pi * i / 48), w / 2 * math.sin(2 * math.pi * i / 48)) for i in range(48)]
    if shape == CUT_CUSTOM:
        raw = aw_host.curve_points(op)
        if not raw:
            return None
        flat_xz = max(abs(p[1]) for p in raw) <= max(abs(p[2]) for p in raw)
        return [(p[0], p[2] if flat_xz else p[1]) for p in raw]
    return [(-w / 2, -l / 2), (w / 2, -l / 2), (w / 2, l / 2), (-w / 2, l / 2)]
