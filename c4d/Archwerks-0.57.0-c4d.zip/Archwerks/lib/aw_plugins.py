"""Archwerks plugin behaviour, reloadable while Cinema 4D runs.

archwerks.pyp registers thin shells (one per plugin id) that hand every call
Cinema 4D makes to the class of the same job here: Wall, Opening, Slab, the
tools, the commands and the watcher. Each method takes the shell as `self`, so
state kept on `self` lives on the registered instance and survives a reload,
while the code itself is replaced by `install_c4d.py --lib`. A shell also finds
this class's `_helpers` and CONSTANTS through `self`. Because `self` is the
shell, never call super() here: call the base class directly, as in
c4d.plugins.ObjectData.Draw(self, ...).

`setup(self)` runs when a shell is made (in place of __init__). Placeholder
covers the ids registered for objects not built yet (door, molding, roof, ...).
"""
import math
import os

import c4d

import aw_groups_c4d
import aw_link_c4d
import aw_drawtool_c4d
import aw_c4d  # noqa: F401  (registers Cinema 4D as the core's host)
import aw_cutter
import aw_cutter_c4d
import aw_desc
import aw_dims
import aw_door
import aw_draw
import aw_fireplace
import aw_floor
import aw_floor_c4d
import aw_edit
import aw_grab
import aw_ids
import aw_materials
import aw_mesh
import aw_molding_c4d
import aw_openings
import aw_openings_c4d
import aw_panels_c4d
import aw_panel
import aw_place
import aw_plan
import aw_roof_c4d
import aw_roofdims_c4d
import aw_stair
import aw_stair_c4d
import aw_railing
import aw_railing_c4d
import aw_beam
import aw_beam_c4d
import aw_cabinet_c4d
import aw_counter_c4d
import aw_slab
import aw_slab_c4d
import aw_style
import aw_wall_c4d
import aw_window
from aw_ids import (AW_OPENING_HEIGHT, AW_OPENING_SILL, AW_OPENING_START, AW_OPENING_WIDTH,
                    AW_WALL_DIMS, AW_WALL_THICKNESS, ID_AW_EDIT_TOOL, ID_AW_FLOOR_PLAN, ID_AW_PANEL, ID_AW_SCALE_PLAN_TOOL,
                    ID_AW_WALL, ID_AW_WALLS_FROM_SPLINE, MIN_SIZE)

GENERATION = 0  # bumped by archwerks.pyp on every reload; in every rebuild key, so a reload rebuilds


def _enabling(self, node, pid, t_data, flags, itemdesc):
    """Greys out parameters whose aw_desc `when` test fails; C4D decides the rest."""
    ok = aw_desc.enabled(node, pid[0].id)
    if ok is not None:
        return ok
    try:
        return c4d.plugins.ObjectData.GetDEnabling(self, node, pid, t_data, flags, itemdesc)
    except (AttributeError, TypeError):
        return True


H_LEFT, H_RIGHT, H_SILL, H_OPENING_HEIGHT, H_MOVE = range(5)  # AW Opening grips


def _draw_grips(plugin, op, bd, bh, role, kinds=None):
    """Draw an object's grips in the Archwerks style; False if that failed."""
    try:
        info = c4d.HandleInfo()
        grips = []
        for i in range(plugin.GetHandleCount(op)):
            plugin.GetHandle(op, i, info)
            grips.append((c4d.Vector(info.position), c4d.Vector(info.direction)))
        hot = op.GetHighlightHandle(bd) if hasattr(op, "GetHighlightHandle") else -1
        aw_draw.draw_grips(bd, bh.GetMg(), grips, hot, role, kinds)
        return True
    except Exception as e:  # fall back to C4D's own dots rather than no grips at all
        print("Archwerks: grip drawing failed, using default handles:", e)
        return False


class Wall:
    """A wall that follows the splines among its children: every run of every
    spline is its own piece of mitred segments, open or closed, set Center /
    Inside / Outside of it by Align. Made from the Create menu it starts with a
    400 cm straight run (Run.001) to edit; with no spline at all it shows
    nothing. Every other child is an opening."""

    GetDEnabling = _enabling

    START_RUN = 400.0  # cm: the straight run a Wall made from the Create menu starts with

    def setup(self):
        # What the current mesh was built from, so unchanged walls reuse it.
        self._last_key = None
        self._quick = None  # aw_wall_c4d.change_key when the mesh was last checked
        self._path = None  # (plan, w0, w1, height, openings by segment)

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)  # every parameter's default (aw_desc.SPECS)
            aw_style.set_display(node, aw_style.WALL_DISPLAY)  # light pink in the viewport, like Archipack
        return True

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                if data["descid"][0].id in aw_materials.SLOT_IDS:
                    aw_materials.mark(node)  # its tags are synced on the next scene change, not mid-set
            except (TypeError, KeyError, IndexError):
                pass
        if mtype == c4d.MSG_MENUPREPARE and aw_wall_c4d.path_spline(node) is None:
            run = c4d.SplineObject(2, c4d.SPLINETYPE_LINEAR)  # from the Create menu: a run to start from
            run.SetName("Run.001")
            run.SetAllPoints([c4d.Vector(0, 0, 0), c4d.Vector(self.START_RUN, 0, 0)])
            run.Message(c4d.MSG_UPDATE)
            run.InsertUnder(node)
        if mtype == c4d.MSG_MENUPREPARE and isinstance(data, c4d.documents.BaseDocument):
            aw_materials.apply_defaults(data, node)  # default materials in its empty slots
        return True

    def GetVirtualObjects(self, op, hh):
        quick = (aw_wall_c4d.change_key(op), GENERATION)
        cache = op.GetCache(hh)
        if quick == self._quick and self._last_key is not None and cache is not None and not op.CheckCache(hh):
            aw_wall_c4d.hide_cutters(op)  # cutters stay consumed on every pass
            return cache
        self._quick = quick
        wp = aw_wall_c4d.wall_path(op)
        if wp is None:  # no spline, or one still being drawn (under two points)
            self._path = self._last_key = None
            aw_wall_c4d.hide_cutters(op)
            return c4d.BaseObject(c4d.Onull)
        path, w0, w1, height, spline = wp
        segs = aw_wall_c4d.path_rects(op, path, w0, w1, height, spline)  # also hides cutters
        self._path = (path, w0, w1, height, segs)
        build = aw_wall_c4d.build_settings(op)
        key = (aw_wall_c4d.build_key(op, path, w0, w1, height, segs, build), GENERATION)
        cache = op.GetCache(hh)
        if key == self._last_key and cache is not None and not op.CheckCache(hh):
            return cache
        self._last_key = key
        return aw_wall_c4d.build_path_wall(op.GetName(), path, height, w0, w1, segs, build, aw_wall_c4d.overrides(op))

    # Dimensions: drawn while the wall or one of its children is selected. Built
    # from the openings the last build used, so they follow every drag live.

    @staticmethod
    def _label(dim):
        return aw_draw.label_text(dim)

    def _layout(self, op):
        """The dimension layout to draw now, or None: a selected window in focus, or
        the wall's own lengths, angles and heights (aw_openings_c4d.wall_layout)."""
        if not op[AW_WALL_DIMS] or self._path is None:
            return None
        return aw_openings_c4d.wall_layout(op, self._path)

    def Draw(self, op, drawpass, bd, bh):
        if drawpass == c4d.DRAWPASS_OBJECT:
            layout = self._layout(op)
            if layout:
                aw_draw.draw_layout(bd, bh.GetMg(), layout, owner=op)  # owner: its labels become clickable
            else:
                aw_draw.clear_hits(bd, op)  # not showing labels, so none of them can be clicked
        elif drawpass == c4d.DRAWPASS_HANDLES and op.GetBit(c4d.BIT_ACTIVE):
            if not aw_wall_c4d.grips_allowed(op):
                return c4d.DRAWRESULT_OK  # no grips outside AW Edit Dimensions
            _wp, grips = self._path_grips(op)
            down = aw_wall_c4d.looking_down(bd)
            kinds = [("hidden" if down and g[2] in aw_wall_c4d.UPRIGHT else "move" if g[2] == "side" else g[2])
                     for g in grips or []]
            if grips and _draw_grips(self, op, bd, bh, "wall", kinds):
                return c4d.DRAWRESULT_OK
        return c4d.plugins.ObjectData.Draw(self, op, drawpass, bd, bh)

    # Grips, from aw_dims.path_grips: a corner grip on every spline point (moves
    # on the floor) and a rise grip above it (that point's height), both for
    # editable splines only, then Height and Thickness.

    @staticmethod
    def _path_grips(op):
        wp = aw_wall_c4d.wall_path(op)
        if wp is None:
            return None, None
        path, w0, w1, height, spline = wp
        return wp, aw_wall_c4d.wall_grips(path, w0, w1, height, spline)

    @staticmethod
    def _grips(op):
        """op's grips; for a childless copy (C4D's own tools' drag start), the real wall's
        as last worked out (aw_grab.remembered_grips)."""
        _wp, grips = Wall._path_grips(op)
        return aw_grab.remembered_grips(op, grips)

    def GetHandleCount(self, op):
        if not aw_wall_c4d.grips_allowed(op):
            return 0
        grips = self._grips(op)
        return len(grips) if grips else 0

    def GetHandle(self, op, i, info):
        pos, direction, kind = self._grips(op)[i][:3]
        info.position = c4d.Vector(*pos)
        info.direction = c4d.Vector(*direction)
        info.type = c4d.HANDLECONSTRAINTTYPE_PLANAR if kind == "corner" else c4d.HANDLECONSTRAINTTYPE_LINEAR
        doc = op.GetDocument()
        if kind in aw_wall_c4d.UPRIGHT and doc is not None and aw_wall_c4d.looking_down(doc.GetActiveBaseDraw()):
            info.type = c4d.HANDLECONSTRAINTTYPE_INVALID  # in Top view it sits on its corner: not grabbable

    def SetHandle(self, op, i, p, info):
        aw_grab.record_drag(op, i)  # in C4D's own tools: its path splines into the tool's undo step
        if info.type == c4d.HANDLECONSTRAINTTYPE_PLANAR:  # a corner: snapped and Shift-locked as AW Draw's
            p = aw_grab.native_corner(op, i, p)
        elif self._grips(op)[i][2] == "rise":  # flat, level with a neighbour, or a square peak
            p = aw_grab.snap_rise(op, i, p)
        aw_wall_c4d.set_path_grip(op, i, p)  # in lib, so grip behaviour reloads without a restart


ID_RS_LIGHT = 1036751   # Redshift's Light object
RS_LIGHT_TYPE, RS_PORTAL = 10000, 6
RS_PORTAL_SIZE_X, RS_PORTAL_SIZE_Y = 14000, 14001
PORTAL_OUT = 1.0  # cm a portal stands outside the opening's Exterior face, clear of the glass


def _portal(op, frame, x0, x1, y0, y1, thick):
    """A Redshift Portal light filling the opening just outside its Exterior face, shining
    in (its +Z), for the window's cache: Redshift renders lights in a generator's cache, so
    the portal goes with the window and nothing is added to the scene. Blender's add-on
    keeps a Cycles portal the same way (objects._portal)."""
    lt = c4d.BaseObject(ID_RS_LIGHT)
    lt.SetName(op.GetName() + " Portal")
    lt[RS_LIGHT_TYPE] = RS_PORTAL
    lt[RS_PORTAL_SIZE_X], lt[RS_PORTAL_SIZE_Y] = max(x1 - x0, 0.1), max(y1 - y0, 0.1)
    ax = frame.MulV(c4d.Vector(1, 0, 0)).GetNormalized()
    ay = frame.MulV(c4d.Vector(0, 1, 0)).GetNormalized()
    az = frame.MulV(c4d.Vector(0, 0, 1)).GetNormalized()  # inward: the Inside is +Z
    lt.SetMl(c4d.Matrix(frame * c4d.Vector((x0 + x1) / 2, (y0 + y1) / 2, -thick / 2 - PORTAL_OUT), ax, ay, az))
    return lt


def _drapes_key(op):
    """What a window's drapes are built from (its settings, the linked object as it is), or None."""
    I = aw_ids
    if op.GetType() != I.ID_AW_OPENING or op[I.AW_OPENING_DRAPES] != I.DRAPES_CUSTOM:
        return None  # (Default drapes: Blender's library for now; here, Custom)
    src = op[I.AW_OPENING_DRAPE_OBJ]
    if src is None or not src.IsAlive():
        return None
    rad, mp = src.GetRad(), src.GetMp()
    return (op[I.AW_OPENING_DRAPE_ROD], op[I.AW_OPENING_DRAPE_EXTEND], op[I.AW_OPENING_DRAPE_DROP],
            op[I.AW_OPENING_DRAPE_OFFSET], op[I.AW_OPENING_TRIM], op[I.AW_OPENING_TRIM_D], src.GetGUID(),
            src.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_CACHE), tuple(round(v, 4) for v in (rad.x, rad.y, rad.z, mp.x, mp.y, mp.z)))


def _drapes(op, frame, x0, x1, y1, thick):
    """An Instance of the window's Drape Object for its cache, fitted as aw_openings.drape_fit
    says (the object modelled facing -Z, its back on its Z max, its bottom on Y min, centred
    on X). Blender's add-on keeps a linked copy the same way (objects._drapes)."""
    I = aw_ids
    src = op[I.AW_OPENING_DRAPE_OBJ]
    rad, mp = src.GetRad(), src.GetMp()
    lo, hi = mp - rad, mp + rad
    face_in = thick / 2 + (max(op[I.AW_OPENING_TRIM_D], 0.1) if op[I.AW_OPENING_TRIM] else 0.0)
    fit = aw_openings.drape_fit(x0, x1, y1, face_in, {
        "rod": op[I.AW_OPENING_DRAPE_ROD], "extend": op[I.AW_OPENING_DRAPE_EXTEND],
        "drop": op[I.AW_OPENING_DRAPE_DROP], "offset": op[I.AW_OPENING_DRAPE_OFFSET]}, (2 * rad.x, 2 * rad.y))
    if fit is None:
        return None
    cx, by, bz, width, height = fit
    ax = frame.MulV(c4d.Vector(1, 0, 0)).GetNormalized()
    up = frame.MulV(c4d.Vector(0, 1, 0)).GetNormalized()
    back = -frame.MulV(c4d.Vector(0, 0, 1)).GetNormalized()  # its -Z into the room
    if ax.Cross(up).Dot(back) < 0:
        ax = -ax  # turned, not mirrored
    m = c4d.Matrix(c4d.Vector(0), ax * (width / (2 * rad.x)), up * (height / (2 * rad.y)), back)
    anchor = c4d.Vector((lo.x + hi.x) / 2, lo.y, hi.z)  # its back, bottom, middle
    m.off = frame * c4d.Vector(cx, by, bz) - m.MulV(anchor)
    inst = c4d.BaseObject(c4d.Oinstance)
    inst.SetName(op.GetName() + " Drapes")
    inst[c4d.INSTANCEOBJECT_LINK] = src
    inst.SetMl(m)
    return inst


class Opening:
    """A window (AW Opening) or a Door, placed under a Wall: the wall cuts the hole
    and the object draws a window (aw_window) or a door (aw_door) in it. It spans Start
    Offset .. Start Offset + Width along the wall from its own axis, and Sill
    Height .. Sill Height + Height up from it. Its grips match the wall's, in the
    focus colour: Left and Right (each moves only its own edge), Sill (raises the
    whole opening), Height, and Move (slides it along the wall)."""

    GetDEnabling = _enabling

    def setup(self):
        self._last_key = None  # what the current window was built from
        self._quick = None  # its own and its wall's change keys when last checked

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
            colour = aw_style.WALL_DISPLAY if node.GetType() == aw_ids.ID_AW_CUTTER else aw_style.WINDOW_DISPLAY
            aw_style.set_display(node, colour)  # walls light blue, windows and doors white
        return True

    @staticmethod
    def _wall(op):
        parent = op.GetUp()
        return parent if parent is not None and parent.GetType() == ID_AW_WALL else None

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                descid = data["descid"]
                if descid[0].id in {pid for _n, pid in aw_materials.slots(node)}:
                    aw_materials.mark(node)  # its material tags sync on the next scene change
                    for other in aw_link_c4d.linked(node):
                        aw_materials.mark(other)
            except (TypeError, KeyError, IndexError):
                descid = None
            aw_link_c4d.sync(node, descid)  # the windows placed with it change with it
        if mtype == c4d.MSG_MENUPREPARE and isinstance(data, c4d.documents.BaseDocument):
            aw_materials.apply_defaults(data, node)
        return True

    def GetVirtualObjects(self, op, hh):
        wall = self._wall(op)
        maker = {aw_ids.ID_AW_DOOR: aw_door, aw_ids.ID_AW_CUTTER: aw_cutter_c4d,
                 aw_ids.ID_AW_FIREPLACE: aw_fireplace}.get(op.GetType(), aw_window)
        custom_key, custom = maker.custom_handle(op)  # a linked handle object changing rebuilds it too
        quick = (op.GetName(), op.GetDirty(c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX),
                 aw_wall_c4d.change_key(wall) if wall is not None else None, custom_key, GENERATION)
        cache = op.GetCache(hh)
        if quick == self._quick and cache is not None and not op.CheckCache(hh):
            return cache  # nothing it or its wall depends on has changed
        self._quick = quick
        s, w = op[AW_OPENING_START], max(op[AW_OPENING_WIDTH], MIN_SIZE)
        y0, h = op[AW_OPENING_SILL], max(op[AW_OPENING_HEIGHT], MIN_SIZE)
        wp = aw_wall_c4d.wall_path(wall) if wall is not None else None
        build = None
        if wp is not None:  # on a spline wall: built facing along its segment
            path, w0, w1, wall_h, _spline = wp
            frame = aw_wall_c4d.opening_frame(op, path, w0, w1)
            thick = w1 - w0
            fkey = tuple(round(v, 4) for vec in (frame.off, frame.v1, frame.v3) for v in (vec.x, vec.y, vec.z))
            build = aw_wall_c4d.build_settings(wall)
        else:
            frame, fkey = None, None
            thick = max(wall[AW_WALL_THICKNESS], MIN_SIZE) if wall is not None else 20.0
        style = maker.settings(op)  # its type and every part's settings
        own = aw_openings.own_key(op)  # its own build-on (Build With: Own), shared with Blender
        portal = op.GetType() in (aw_ids.ID_AW_OPENING, aw_ids.ID_AW_DOOR) and bool(op[aw_ids.AW_OPENING_PORTAL])
        drapes = _drapes_key(op)
        key = (op.GetName(), s, w, y0, h, thick, fkey, build, own, style.key(), custom_key, portal, drapes, GENERATION)
        cache = op.GetCache(hh)
        if key == self._last_key and cache is not None and not op.CheckCache(hh):
            return cache
        self._last_key = key
        with aw_mesh.deforming(aw_openings.own_deform(op)):  # its points where its own Build has them
            window = maker.build(op.GetName(), s, s + w, y0, y0 + h, thick, style, custom)
        if frame is not None and window.GetPointCount():  # (a plain hole has nothing of its own)
            window.SetAllPoints([frame * p for p in window.GetAllPoints()])
            window.Message(c4d.MSG_UPDATE)
            aw_wall_c4d.deform_opening(op, path, wall_h, build, window)  # the wall's build-on
        if hasattr(maker, "finish"):
            maker.finish(op, wall, window)  # a cutter wears its wall's materials
        if portal and frame is not None:
            _portal(op, frame, s, s + w, y0, y0 + h, thick).InsertUnder(window)
        if drapes is not None and frame is not None:
            inst = _drapes(op, frame, s, s + w, y0 + h, thick)
            if inst is not None:
                inst.InsertUnder(window)
        return window

    def GetHandleCount(self, op):
        # On a wall its grips sit on the wall's focus guides (aw_openings_c4d, edit tool
        # only); on its own it keeps simple edge grips.
        if self._wall(op) is not None:
            return len(aw_openings_c4d.grips(op))
        return 5

    def GetHandle(self, op, i, info):
        if self._wall(op) is not None:
            pos, direction = aw_openings_c4d.grips(op)[i]
            info.position, info.direction = pos, direction
            info.type = c4d.HANDLECONSTRAINTTYPE_LINEAR
            return
        s, w = op[AW_OPENING_START], max(op[AW_OPENING_WIDTH], MIN_SIZE)
        y0, h = op[AW_OPENING_SILL], max(op[AW_OPENING_HEIGHT], MIN_SIZE)
        info.position, info.direction = [
            (c4d.Vector(s, y0 + h / 2, 0), c4d.Vector(-1, 0, 0)),
            (c4d.Vector(s + w, y0 + h / 2, 0), c4d.Vector(1, 0, 0)),
            (c4d.Vector(s + w / 2, y0, 0), c4d.Vector(0, -1, 0)),
            (c4d.Vector(s + w / 2, y0 + h, 0), c4d.Vector(0, 1, 0)),
            (c4d.Vector(s + w / 2, 0, 0), c4d.Vector(1, 0, 0))][i]
        info.type = c4d.HANDLECONSTRAINTTYPE_LINEAR

    def SetHandle(self, op, i, p, info):
        if self._wall(op) is not None:
            aw_openings_c4d.set_grip(op, i, p)
            return
        s, w = op[AW_OPENING_START], max(op[AW_OPENING_WIDTH], MIN_SIZE)
        sill = op[AW_OPENING_SILL]
        if i == H_LEFT:
            new_s = min(p.x, s + w - MIN_SIZE)
            op[AW_OPENING_START] = new_s
            op[AW_OPENING_WIDTH] = s + w - new_s
        elif i == H_RIGHT:
            op[AW_OPENING_WIDTH] = max(p.x - s, MIN_SIZE)
        elif i == H_SILL:
            op[AW_OPENING_SILL] = max(p.y, -op.GetMl().off.y)  # never below the floor
        elif i == H_OPENING_HEIGHT:
            op[AW_OPENING_HEIGHT] = max(p.y - sill, MIN_SIZE)
        else:  # Move: slide along the wall by shifting the span, so the object never moves mid-drag
            op[AW_OPENING_START] = p.x - w / 2

    def Draw(self, op, drawpass, bd, bh):
        if drawpass == c4d.DRAWPASS_HANDLES and op.GetBit(c4d.BIT_ACTIVE):
            if _draw_grips(self, op, bd, bh, "focus", aw_dims.OPENING_GRIP_KINDS):
                return c4d.DRAWRESULT_OK
        return c4d.plugins.ObjectData.Draw(self, op, drawpass, bd, bh)


ID_VALUE = 1000


class _ValueDialog(c4d.gui.GeDialog):
    """A one-field pop-up for a dimension's new value, in the document's units.
    Return accepts, Escape cancels."""

    def __init__(self, title, value):
        super().__init__()
        self.title, self.value, self.result = title, value, None

    def CreateLayout(self):
        self.SetTitle(self.title)
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorderSpace(8, 8, 8, 4)
        self.AddEditNumberArrows(ID_VALUE, c4d.BFH_SCALEFIT, 140, 0)
        self.GroupEnd()
        self.AddDlgGroup(c4d.DLG_OK | c4d.DLG_CANCEL)
        return True

    def InitValues(self):
        self.SetFloat(ID_VALUE, self.value, min=0.0, max=1.0e7, step=1.0, format=c4d.FORMAT_METER)
        self.Activate(ID_VALUE)
        return True

    def Command(self, cid, msg):
        if cid == c4d.DLG_OK:
            self.result = self.GetFloat(ID_VALUE)
            self.Close()
        elif cid == c4d.DLG_CANCEL:
            self.Close()
        return True


def _ask_value(title, value, win, x, y):
    """The typed value, or None if cancelled. Opens at the clicked label."""
    dlg = _ValueDialog(title, value)
    gx, gy = -2, -2  # fallback: C4D places it at the mouse
    try:
        g = win.Local2Global()
        gx, gy = int(g["x"] + x), int(g["y"] + y)
    except Exception:
        pass
    dlg.Open(c4d.DLG_TYPE_MODAL, xpos=gx, ypos=gy, defaultw=200, defaulth=0)
    return dlg.result


TITLES = {"segment": "Segment length", "length": "Wall length", "height": "Wall height", "thickness": "Wall thickness",
          "chain": "Distance", "gap": "Distance to wall end", "width": "Opening width",
          "sill": "Sill height", "opening_height": "Opening height", "slope": "Slope",
          "eave": "Eave overhang", "rake": "Rake overhang", "axis_width": "Roof width", "side": "Side length",
          "cut_width": "Cutter width", "cut_length": "Cutter length", "cab_width": "Cabinet width",
          "cab_height": "Cabinet height", "cab_depth": "Cabinet depth", "cab_kick": "Kick height", "cab_top": "Top",
          "cab_zone": "Zone height"}


class EditTool:
    """AW Edit Dimensions: drag a grip, or click a dimension label and type its new
    value in place (Return applies, Escape or a click elsewhere cancels; Option-click
    opens the pop-up field instead). Cmd-click a selected wall's top edge to add a
    spline point there (then drag its height grip to make a gable). Clicking anything else selects it, so the tool
    can stay active while moving between walls and windows. Each drag or edit is
    one undo step.

    Keystrokes are only taken while a label is being edited; otherwise every key
    goes to Cinema 4D as usual."""

    def setup(self):
        self._edit = None  # {"bd", "owner", "entry", "field"} while a label is being typed into
        self._hover = None  # (object, grip index) under the mouse, drawn highlighted

    def GetState(self, doc):
        return c4d.CMD_ENABLED

    def FreeTool(self, doc, data):
        self._edit = None  # switching tools cancels an edit in progress

    @staticmethod
    def _redraw():
        c4d.DrawViews(c4d.DRAWFLAGS_ONLY_ACTIVE_VIEW | c4d.DRAWFLAGS_NO_THREAD)

    def _apply(self, doc, owner, entry, value):
        doc.StartUndo()
        try:
            aw_edit.apply(doc, owner, entry["edit"], value)
            return True
        except ValueError as e:
            c4d.StatusSetText("Archwerks: %s %s" % (TITLES.get(entry["kind"], "value"), e))
            return False
        finally:
            doc.EndUndo()
            c4d.EventAdd()

    def MouseInput(self, doc, data, bd, win, msg):
        x, y = msg[c4d.BFM_INPUT_X], msg[c4d.BFM_INPUT_Y]
        self._edit = None  # any click ends the edit in progress
        if msg[c4d.BFM_INPUT_QUALIFIER] & c4d.QCTRL:  # Cmd-click a wall's top edge: add a point there
            doc.StartUndo()
            try:
                done = aw_edit.insert_point(doc, bd, x, y)
            except ValueError as e:
                done = None
                c4d.StatusSetText("Archwerks: %s" % e)
            doc.EndUndo()
            if done:
                c4d.StatusSetText("Archwerks: %s" % done)
                c4d.EventAdd()
                return True
        grab = aw_grab.pick(bd, doc, x, y)
        if grab is not None:
            self._drag(doc, bd, win, grab, x, y)
            return True
        hit = aw_draw.hit_test(bd, x, y)
        if hit is None:
            picked = aw_openings_c4d.pick(bd, doc, x, y)  # a window on a wall, else what C4D picks
            doc.SetActiveObject(picked, c4d.SELECTION_NEW)
            c4d.EventAdd()
            if picked is not None:
                self._move(doc, bd, win, picked, x, y)  # dragged on: moved, as the Move tool would
            return True
        owner, entry = hit
        if msg[c4d.BFM_INPUT_QUALIFIER] & c4d.QALT:  # Option-click: the pop-up field
            value = _ask_value(TITLES.get(entry["kind"], "Value"), entry["value"], win, x, y)
            if value is not None and abs(value - entry["value"]) > 1e-6:
                self._apply(doc, owner, entry, value)
            return True
        self._edit = {"bd": bd, "owner": owner, "entry": entry, "field": aw_edit.InlineEdit(entry["text"])}
        c4d.StatusSetText("Type a value, Return to apply, Escape to cancel")
        self._redraw()
        return True

    MOVE_PX = 4  # px the mouse goes before a click on an object becomes a move

    def _move(self, doc, bd, win, obj, x, y):
        """Click-and-drag on obj: it moves on the floor plane under the mouse (Shift: along
        X or Z only), one undo step. A window or door slides in its wall (the wall fits it to
        its path where it lands). A click that doesn't move leaves it selected only."""
        start = _floor_hit(bd, x, y, obj.GetMg().off.y)
        if start is None:
            return
        mg0 = obj.GetMg()
        win.MouseDragStart(c4d.KEY_MLEFT, x, y, c4d.MOUSEDRAGFLAGS_DONTHIDEMOUSE | c4d.MOUSEDRAGFLAGS_NOMOVE)
        mx, my, moving = x, y, False
        try:
            while True:
                result, dx, dy, channels = win.MouseDrag()
                if result != c4d.MOUSEDRAGRESULT_CONTINUE:
                    break
                if dx == 0 and dy == 0:
                    continue
                mx, my = mx + dx, my + dy
                if not moving:
                    if math.hypot(mx - x, my - y) < self.MOVE_PX:
                        continue
                    moving = True
                    doc.StartUndo()
                    doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                here = _floor_hit(bd, mx, my, mg0.off.y)
                if here is None:
                    continue
                d = here - start
                if channels.GetInt32(c4d.BFM_INPUT_QUALIFIER) & c4d.QSHIFT:  # along one axis
                    d = c4d.Vector(d.x, 0, 0) if abs(d.x) >= abs(d.z) else c4d.Vector(0, 0, d.z)
                mg = c4d.Matrix(mg0)
                mg.off = mg0.off + c4d.Vector(d.x, 0, d.z)
                obj.SetMg(mg)
                obj.Message(c4d.MSG_UPDATE)
                c4d.DrawViews(c4d.DRAWFLAGS_ONLY_ACTIVE_VIEW | c4d.DRAWFLAGS_NO_THREAD | c4d.DRAWFLAGS_NO_ANIMATION)
        finally:
            win.MouseDragEnd()
            if moving:
                doc.EndUndo()
            c4d.EventAdd()

    def _drag(self, doc, bd, win, grab, x, y):
        """Drag a grip along its line, as the Move tool would; one undo step."""
        obj, index = grab
        info = c4d.HandleInfo()
        obj.GetNodeData().GetHandle(obj, index, info)
        mg = obj.GetMg()
        origin, direction = mg * info.position, mg.MulV(info.direction)
        plane = info.type == c4d.HANDLECONSTRAINTTYPE_PLANAR  # a corner: moves on the floor
        doc.StartUndo()
        doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
        for spline in aw_grab.moved_by(obj):
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, spline)  # corner drags move their points
        win.MouseDragStart(c4d.KEY_MLEFT, x, y, c4d.MOUSEDRAGFLAGS_DONTHIDEMOUSE | c4d.MOUSEDRAGFLAGS_NOMOVE)
        mx, my = x, y
        try:
            while True:
                result, dx, dy, _channels = win.MouseDrag()
                if result != c4d.MOUSEDRAGRESULT_CONTINUE:
                    break
                if dx == 0 and dy == 0:
                    continue
                mx, my = mx + dx, my + dy
                aw_grab.drag_to(bd, obj, index, origin, direction, mx, my, plane)
                c4d.DrawViews(c4d.DRAWFLAGS_ONLY_ACTIVE_VIEW | c4d.DRAWFLAGS_NO_THREAD | c4d.DRAWFLAGS_NO_ANIMATION)
        finally:
            win.MouseDragEnd()
            doc.EndUndo()
            c4d.EventAdd()

    def KeyboardInput(self, doc, data, bd, win, msg):
        if self._edit is None:
            return False  # not editing: the key is Cinema 4D's
        channel = msg[c4d.BFM_INPUT_CHANNEL]
        name = {c4d.KEY_ENTER: "enter", c4d.KEY_ESC: "escape",
                c4d.KEY_BACKSPACE: "backspace", c4d.KEY_DELETE: "backspace"}.get(channel, "char")
        field = self._edit["field"]
        action = field.key(name, msg[c4d.BFM_INPUT_ASC] or "")
        if action == "cancel":
            self._edit = None
            c4d.StatusClear()
        elif action == "commit":
            try:
                value = field.value()
            except ValueError as e:
                c4d.StatusSetText("Archwerks: %s" % e)  # keep editing, so it can be fixed
                self._redraw()
                return True
            e = self._edit
            self._edit = None
            c4d.StatusClear()
            if abs(value - e["entry"]["value"]) > 1e-6:
                self._apply(doc, e["owner"], e["entry"], value)
        self._redraw()
        return True  # every key belongs to the field while it is open

    def Draw(self, doc, data, bd, bh, bt, flags):
        try:  # the grips, which C4D only draws for its own transform tools
            for obj in aw_grab.grip_objects(doc):
                grips, role, kinds = aw_grab.grips(obj)
                hot = self._hover[1] if self._hover and self._hover[0] == obj else -1
                aw_draw.draw_grips(bd, obj.GetMg(), grips, hot, role, kinds)
        except Exception as err:
            print("Archwerks: grip drawing in the edit tool failed:", err)
        e = self._edit
        if e is not None:
            try:
                if not aw_draw._alive(e["bd"], e["owner"]):
                    self._edit = None  # its view or wall is gone (document closed, object deleted)
                elif bd == e["bd"]:  # only in the view where the label was clicked
                    now = aw_draw.find_entry(bd, e["owner"], e["entry"]["edit"], e["entry"]["kind"])
                    aw_draw.draw_edit_label(bd, (now or e["entry"])["rect"], e["field"].shown())
            except Exception as err:  # never let the field break the viewport
                print("Archwerks: inline edit drawing failed:", err)
                self._edit = None
        return c4d.TOOLDRAW_NONE

    def GetCursorInfo(self, doc, data, bd, x, y, bc):
        if bc.GetId() == c4d.BFM_CURSORINFO_REMOVE:
            return True
        grab = aw_grab.pick(bd, doc, x, y)
        if grab != self._hover:  # highlight the grip under the mouse
            self._hover = grab
            c4d.DrawViews(c4d.DRAWFLAGS_ONLY_ACTIVE_VIEW | c4d.DRAWFLAGS_NO_THREAD)
        if grab is not None:
            bc.SetString(c4d.RESULT_BUBBLEHELP, "Drag to resize or move")
            bc.SetInt32(c4d.RESULT_CURSOR, c4d.MOUSE_MOVE_HAND)
            return True
        hit = aw_draw.hit_test(bd, x, y)
        if hit:
            bc.SetString(c4d.RESULT_BUBBLEHELP, "Click to type a new %s (Option-click: pop-up)"
                         % TITLES.get(hit[1]["kind"], "value").lower())
            bc.SetInt32(c4d.RESULT_CURSOR, c4d.MOUSE_POINT_HAND)
        else:
            bc.SetString(c4d.RESULT_BUBBLEHELP, "AW Edit Dimensions: click a dimension label to type a value")
        return True


class WallsFromSpline:
    """AW Walls from Spline: turns each selected spline into an AW Wall that follows
    it. The spline moves under the wall, where it stays live: edit its points and
    the wall follows. One undo step. With no spline selected it starts a new wall
    and the Spline Pen instead (aw_panel.start_wall), so it is never greyed out."""

    def GetState(self, doc):
        return c4d.CMD_ENABLED

    def Execute(self, doc):
        splines = aw_panel.selected_splines(doc)
        if not splines:
            aw_panel.start_wall(doc)
            return True
        doc.StartUndo()
        walls = []
        for spline in splines:
            mg = spline.GetMg()
            if spline.GetType() != c4d.Ospline and spline.GetDescription(c4d.DESCFLAGS_DESC_NONE) is not None:
                try:  # a spline primitive drawn upright: lay it on the floor
                    if spline[c4d.PRIM_PLANE] != c4d.PRIM_PLANE_XZ:
                        doc.AddUndo(c4d.UNDOTYPE_CHANGE, spline)
                        spline[c4d.PRIM_PLANE] = c4d.PRIM_PLANE_XZ
                except (AttributeError, TypeError):
                    pass
            wall = c4d.BaseObject(ID_AW_WALL)
            wall.SetName(aw_panel.next_wall_name(doc))  # Wall.001, Wall.002, ...
            wall.InsertBefore(spline)
            wall.SetMg(c4d.Matrix(mg.off))  # at the spline, upright
            doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, wall)
            aw_materials.apply_defaults(doc, wall)
            aw_groups_c4d.file(doc, wall)  # into its group: null and layer (aw_groups_c4d)
            doc.AddUndo(c4d.UNDOTYPE_DELETEOBJ, spline)
            spline.Remove()
            spline.InsertUnder(wall)
            spline.SetMg(mg)
            doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, spline)
            walls.append(wall)
        doc.SetActiveObject(walls[0], c4d.SELECTION_NEW)
        for wall in walls[1:]:
            doc.SetActiveObject(wall, c4d.SELECTION_ADD)
        doc.EndUndo()
        c4d.EventAdd()
        return True


class Slab:
    """A floor or ceiling that fills the rooms (closed runs) of the Wall it links to,
    out to the walls' Interior or Exterior faces or the spline, and follows it live.
    The work is in aw_slab."""

    GetDEnabling = _enabling

    def setup(self):
        self._quick = None

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)  # a floor over the walls' outer perimeter
        return True

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                if data["descid"][0].id in aw_materials.SLAB_SLOT_IDS:
                    aw_materials.mark(node)
            except (TypeError, KeyError, IndexError):
                pass
        return True

    def GetVirtualObjects(self, op, hh):
        quick = (aw_slab_c4d.change_key(op), GENERATION)
        cache = op.GetCache(hh)
        if quick == self._quick and cache is not None and not op.CheckCache(hh):
            return cache
        self._quick = quick
        return aw_slab_c4d.build(op) or c4d.BaseObject(c4d.Onull)


class Floor:
    """A Floor (or, registered separately, a Ceiling) shaped by the closed loops of
    its own child splines, holes and all, edited with C4D's point tools. The work
    is in aw_floor."""

    GetDEnabling = _enabling

    def setup(self):
        self._quick = None

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
        return True

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                if data["descid"][0].id in {pid for _n, pid in aw_materials.slots(node)}:
                    aw_materials.mark(node)
            except (TypeError, KeyError, IndexError):
                pass
        if mtype == c4d.MSG_MENUPREPARE and isinstance(data, c4d.documents.BaseDocument):
            aw_materials.apply_defaults(data, node)
        return True

    def GetVirtualObjects(self, op, hh):
        quick = (aw_floor_c4d.change_key(op), GENERATION)
        cache = op.GetCache(hh)
        if quick == self._quick and cache is not None and not op.CheckCache(hh):
            for child in op.GetChildren():
                child.Touch()  # its splines stay consumed (hidden) on every pass
            return cache
        self._quick = quick
        for child in op.GetChildren():
            if child.GetInfo() & c4d.OBJECT_ISSPLINE:
                child.Touch()
        return aw_floor.build(op) or c4d.BaseObject(c4d.Onull)


class Roof:
    """A gable or hip roof over the rooms of the Wall it links to, following it live.
    The work is in aw_roof_c4d (and aw_skeleton)."""

    GetDEnabling = _enabling

    def setup(self):
        self._quick = None
        self._meta = None  # what the last build made, for the dimensions and grips (aw_roofdims_c4d)

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
        return True

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                pid = data["descid"][0].id
            except (TypeError, KeyError, IndexError):
                pid = None
            if pid in {p for _n, p in aw_materials.slots(node)}:
                aw_materials.mark(node)
            if pid == aw_ids.AW_ROOF_TILE_MODEL:  # a new model brings its own sizes, and covering
                w, l, t = aw_roof_c4d.TILE_DEFAULTS.get(node[pid], aw_roof_c4d.TILE_DEFAULTS[aw_roof_c4d.PLAIN])
                node[aw_ids.AW_ROOF_TILE_W], node[aw_ids.AW_ROOF_TILE_L], node[aw_ids.AW_ROOF_TILE_T] = w, l, t
                aw_roof_c4d.swap_covering(node)
        if mtype == c4d.MSG_MENUPREPARE and isinstance(data, c4d.documents.BaseDocument):
            aw_materials.apply_defaults(data, node)
        return True

    def GetVirtualObjects(self, op, hh):
        quick = (aw_roof_c4d.change_key(op), GENERATION)  # (see Message for a tile model's sizes)
        cache = op.GetCache(hh)
        if quick == self._quick and cache is not None and not op.CheckCache(hh):
            for child in op.GetChildren():
                if child.GetType() != aw_ids.ID_AW_ROOF_CUTTER:
                    child.Touch()
            return cache
        self._quick = quick
        for child in op.GetChildren():
            if child.GetInfo() & c4d.OBJECT_ISSPLINE and child.GetType() != aw_ids.ID_AW_ROOF_CUTTER:
                child.Touch()  # its outline and axis splines are used up; its cutters stay in view
        meta = {}
        obj = aw_roof_c4d.build(op, meta)
        self._meta = meta
        return obj or c4d.BaseObject(c4d.Onull)

    # Dimensions and grips (aw_roofdims_c4d): drawn while the roof or one of its splines is
    # selected; grips in AW Edit Dimensions only, like a Wall's.

    def _layout(self, op):
        if not aw_desc.value(op, aw_ids.AW_ROOF_DIMS):  # (a roof made before Dimensions existed: its default, on)
            return None, []
        if not (op.GetBit(c4d.BIT_ACTIVE) or any(k.GetBit(c4d.BIT_ACTIVE) and k.GetType() == c4d.Ospline
                                                for k in op.GetChildren())):
            return None, []
        return aw_roofdims_c4d.roof_layout(op, getattr(self, "_meta", None))

    def Draw(self, op, drawpass, bd, bh):
        if drawpass == c4d.DRAWPASS_OBJECT:
            layout, _grips = self._layout(op)
            if layout:
                aw_draw.draw_layout(bd, bh.GetMg(), layout, owner=op)
            else:
                aw_draw.clear_hits(bd, op)
        elif drawpass == c4d.DRAWPASS_HANDLES and op.GetBit(c4d.BIT_ACTIVE) and aw_wall_c4d.grips_allowed(op):
            _layout, grips = aw_roofdims_c4d.roof_layout(op, getattr(self, "_meta", None))
            if grips and _draw_grips(self, op, bd, bh, "wall", [g[2] for g in grips]):
                return c4d.DRAWRESULT_OK
        return c4d.plugins.ObjectData.Draw(self, op, drawpass, bd, bh)

    def GetHandleCount(self, op):
        if not aw_wall_c4d.grips_allowed(op):
            return 0
        return len(self._roof_grips(op))

    def _roof_grips(self, op):
        """op's grips; for a childless copy, the real roof's (aw_grab.remembered_grips)."""
        return aw_grab.remembered_grips(op, aw_roofdims_c4d.roof_layout(op, getattr(self, "_meta", None))[1]) or []

    def GetHandle(self, op, i, info):
        pos, direction, kind, _act = self._roof_grips(op)[i]
        info.position = c4d.Vector(*pos)
        info.direction = c4d.Vector(*direction)
        info.type = c4d.HANDLECONSTRAINTTYPE_PLANAR if kind == "corner" else c4d.HANDLECONSTRAINTTYPE_LINEAR

    def SetHandle(self, op, i, p, info):
        aw_grab.record_drag(op)  # in C4D's own tools: its splines into the tool's undo step
        aw_roofdims_c4d.set_grip(op, getattr(self, "_meta", None), i, p)


class Stair:
    """A straight, L or U stair, or one along its own spline (aw_stair); registered
    again as Railing, a railing or fence along a Stair or its own splines
    (aw_railing). Either uses its child splines up."""

    GetDEnabling = _enabling

    def setup(self):
        self._quick = None

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
        return True

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                if data["descid"][0].id in {pid for _n, pid in aw_materials.slots(node)}:
                    aw_materials.mark(node)
            except (TypeError, KeyError, IndexError):
                pass
        if mtype == c4d.MSG_MENUPREPARE and isinstance(data, c4d.documents.BaseDocument):
            aw_materials.apply_defaults(data, node)
        return True

    def GetVirtualObjects(self, op, hh):
        maker = aw_railing_c4d if op.GetType() == aw_ids.ID_AW_RAILING else aw_stair_c4d
        quick = (maker.change_key(op), GENERATION)
        cache = op.GetCache(hh)
        if quick == self._quick and cache is not None and not op.CheckCache(hh):
            for child in op.GetChildren():
                child.Touch()  # its path spline stays consumed (hidden)
            return cache
        self._quick = quick
        for child in op.GetChildren():
            if child.GetInfo() & c4d.OBJECT_ISSPLINE:
                child.Touch()
        return maker.build(op) or c4d.BaseObject(c4d.Onull)


class Cabinet:
    """A base, upper, tall or vanity cabinet: a box of boards and its fronts, with
    pulls. The work is in aw_cabinet_c4d and aw_pulls."""

    GetDEnabling = _enabling

    def setup(self):
        self._quick = None

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
        return True

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                pid = data["descid"][0].id
            except (TypeError, KeyError, IndexError):
                pid = None
            if pid in {p for _n, p in aw_materials.slots(node)}:
                aw_materials.mark(node)
            if pid == aw_ids.AW_CAB_TYPE:  # a new type brings its own sizes
                aw_cabinet_c4d.apply_type_defaults(node)
            if pid in (aw_ids.AW_CAB_DOOR_PULL, aw_ids.AW_CAB_DRAWER_PULL):  # a knob made a pull: a pull's size
                aw_cabinet_c4d.apply_pull_defaults(node, pid)
            if pid in SINK_ZONE_PIDS and node.GetDocument() is not None:  # a Sink zone: its countertop's sink
                aw_counter_c4d.sync_sinks(node.GetDocument(), node)
        if mtype == c4d.MSG_MENUPREPARE and isinstance(data, c4d.documents.BaseDocument):
            aw_materials.apply_defaults(data, node)
        return True

    def GetVirtualObjects(self, op, hh):
        quick = (aw_cabinet_c4d.change_key(op), GENERATION)
        cache = op.GetCache(hh)
        if quick == self._quick and cache is not None and not op.CheckCache(hh):
            return cache
        self._quick = quick
        return aw_cabinet_c4d.build(op) or c4d.BaseObject(c4d.Onull)

    def Draw(self, op, drawpass, bd, bh):
        if drawpass == c4d.DRAWPASS_OBJECT:
            if op.GetBit(c4d.BIT_ACTIVE) and aw_desc.value(op, aw_ids.AW_CAB_DIMS):
                aw_draw.draw_layout(bd, bh.GetMg(), aw_cabinet_c4d.dims_layout(aw_cabinet_c4d.settings(op))[0], owner=op)
            else:
                aw_draw.clear_hits(bd, op)
        elif drawpass == c4d.DRAWPASS_HANDLES and op.GetBit(c4d.BIT_ACTIVE) and aw_wall_c4d.grips_allowed(op):
            if _draw_grips(self, op, bd, bh, "wall"):
                return c4d.DRAWRESULT_OK
        return c4d.plugins.ObjectData.Draw(self, op, drawpass, bd, bh)

    def GetHandleCount(self, op):
        return len(aw_cabinet_c4d.dims_layout(aw_cabinet_c4d.settings(op))[1]) if aw_wall_c4d.grips_allowed(op) else 0

    def GetHandle(self, op, i, info):
        pos, direction, _kind, _act = aw_cabinet_c4d.dims_layout(aw_cabinet_c4d.settings(op))[1][i]
        info.position = c4d.Vector(*pos)
        info.direction = c4d.Vector(*direction)
        info.type = c4d.HANDLECONSTRAINTTYPE_LINEAR

    def SetHandle(self, op, i, p, info):
        aw_cabinet_c4d.set_grip(op, i, p)


SINK_ZONE_PIDS = {aw_ids.AW_CAB_ZONES} | {aw_ids.cab_zone(i, 0) for i in range(6)}  # what makes a top zone a Sink


class Countertop:
    """A countertop over a run of cabinets (or its own outline), with its sinks. The work
    is in aw_counter_c4d."""

    GetDEnabling = _enabling

    def setup(self):
        self._quick = None

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
        return True

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                pid = data["descid"][0].id
            except (TypeError, KeyError, IndexError):
                pid = None
            if pid in {p for _n, p in aw_materials.slots(node)}:
                aw_materials.mark(node)
            if pid in aw_counter_c4d.ct_sink_pids():  # its Sinks tab: every sink under it
                aw_counter_c4d.sinks_from_tab(node, pid)
        if mtype == c4d.MSG_MENUPREPARE and isinstance(data, c4d.documents.BaseDocument):
            aw_materials.apply_defaults(data, node)
        return True

    def GetVirtualObjects(self, op, hh):
        quick = (aw_counter_c4d.change_key(op), GENERATION)
        cache = op.GetCache(hh)
        if quick == self._quick and cache is not None and not op.CheckCache(hh):
            for child in op.GetChildren():
                if child.GetType() != aw_ids.ID_AW_SINK:
                    child.Touch()
            return cache
        self._quick = quick
        for child in op.GetChildren():
            if child.GetInfo() & c4d.OBJECT_ISSPLINE and child.GetType() != aw_ids.ID_AW_SINK:
                child.Touch()  # an island's outline is used up; its sinks stay in view, to move
        return aw_counter_c4d.build(op) or c4d.BaseObject(c4d.Onull)


class Sink:
    """A sink (or cooktop) under a countertop: its outline, to place it; the countertop
    builds it and cuts its hole. The work is in aw_counter_c4d."""

    GetDEnabling = _enabling

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
        return True

    def GetContour(self, op, doc, lod, bt):
        return aw_counter_c4d.sink_contour(op)

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                pid = data["descid"][0].id
            except (TypeError, KeyError, IndexError):
                pid = None
            if pid in (aw_ids.AW_SINK_MOUNT, aw_ids.AW_SINK_DEPTH):  # the sink base under it follows
                aw_counter_c4d.match_base(node)
            if pid is not None:
                aw_counter_c4d.sink_to_tab(node)  # its countertop's Sinks tab shows what it is now
        return True


class Beam:
    """A straight beam, cloned in rows and layers, sized in AW Edit Dimensions. The
    work is in aw_beam."""

    GetDEnabling = _enabling

    def setup(self):
        self._quick = None

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
        return True

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                if data["descid"][0].id in {pid for _n, pid in aw_materials.slots(node)}:
                    aw_materials.mark(node)
            except (TypeError, KeyError, IndexError):
                pass
        if mtype == c4d.MSG_MENUPREPARE and isinstance(data, c4d.documents.BaseDocument):
            aw_materials.apply_defaults(data, node)
        return True

    def GetVirtualObjects(self, op, hh):
        quick = (aw_beam_c4d.change_key(op), GENERATION)
        cache = op.GetCache(hh)
        if quick == self._quick and cache is not None and not op.CheckCache(hh):
            return cache
        self._quick = quick
        return aw_beam.build(op) or c4d.BaseObject(c4d.Onull)

    def Draw(self, op, drawpass, bd, bh):
        if drawpass == c4d.DRAWPASS_OBJECT:
            if op.GetBit(c4d.BIT_ACTIVE) and aw_desc.value(op, aw_ids.AW_BEAM_DIMS):
                aw_draw.draw_layout(bd, bh.GetMg(), aw_beam.layout(aw_beam.settings(op))[0], owner=op)
            else:
                aw_draw.clear_hits(bd, op)
        elif drawpass == c4d.DRAWPASS_HANDLES and op.GetBit(c4d.BIT_ACTIVE) and aw_wall_c4d.grips_allowed(op):
            if _draw_grips(self, op, bd, bh, "wall"):
                return c4d.DRAWRESULT_OK
        return c4d.plugins.ObjectData.Draw(self, op, drawpass, bd, bh)

    def GetHandleCount(self, op):
        return len(aw_beam.layout(aw_beam.settings(op))[1]) if aw_wall_c4d.grips_allowed(op) else 0

    def GetHandle(self, op, i, info):
        pos, direction, _kind, _act = aw_beam.layout(aw_beam.settings(op))[1][i]
        info.position = c4d.Vector(*pos)
        info.direction = c4d.Vector(*direction)
        info.type = c4d.HANDLECONSTRAINTTYPE_LINEAR

    def SetHandle(self, op, i, p, info):
        aw_beam.set_grip(op, i, p)



class RoofCutter:
    """Under a Roof: a hole through it, or the part of it kept (Mode). A spline, so it
    draws its outline and snaps like one; the Roof reads it. The work is in aw_roof_c4d."""

    GetDEnabling = _enabling

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
        return True

    def GetContour(self, op, doc, lod, bt):
        return aw_roof_c4d.cutter_contour(op)

    def Draw(self, op, drawpass, bd, bh):
        if drawpass == c4d.DRAWPASS_OBJECT:
            if op.GetBit(c4d.BIT_ACTIVE):
                aw_draw.draw_layout(bd, bh.GetMg(), aw_roofdims_c4d.cutter_grips(op)[0], owner=op)
            else:
                aw_draw.clear_hits(bd, op)
        elif drawpass == c4d.DRAWPASS_HANDLES and op.GetBit(c4d.BIT_ACTIVE) and aw_wall_c4d.grips_allowed(op):
            if _draw_grips(self, op, bd, bh, "wall"):
                return c4d.DRAWRESULT_OK
        return c4d.plugins.ObjectData.Draw(self, op, drawpass, bd, bh)

    def GetHandleCount(self, op):
        return len(aw_roofdims_c4d.cutter_grips(op)[1]) if aw_wall_c4d.grips_allowed(op) else 0

    def GetHandle(self, op, i, info):
        pos, direction, _kind, _act = aw_roofdims_c4d.cutter_grips(op)[1][i]
        info.position = c4d.Vector(*pos)
        info.direction = c4d.Vector(*direction)
        info.type = c4d.HANDLECONSTRAINTTYPE_LINEAR

    def SetHandle(self, op, i, p, info):
        aw_roofdims_c4d.set_cutter_grip(op, i, p)


class Molding:
    """A baseboard or crown along the rooms of the Wall it links to, mitred at the
    corners and broken at openings, following it live. The work is in aw_molding_c4d."""

    GetDEnabling = _enabling

    def setup(self):
        self._quick = None

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
            aw_style.set_display(node, aw_style.WINDOW_DISPLAY)  # white, like trim
        return True

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                if data["descid"][0].id in {pid for _n, pid in aw_materials.slots(node)}:
                    aw_materials.mark(node)
            except (TypeError, KeyError, IndexError):
                pass
        if mtype == c4d.MSG_MENUPREPARE and isinstance(data, c4d.documents.BaseDocument):
            aw_materials.apply_defaults(data, node)
        return True

    def GetVirtualObjects(self, op, hh):
        quick = (aw_molding_c4d.change_key(op), GENERATION)
        cache = op.GetCache(hh)
        if quick == self._quick and cache is not None and not op.CheckCache(hh):
            return cache
        self._quick = quick
        return aw_molding_c4d.build(op) or c4d.BaseObject(c4d.Onull)


class WallPanels:
    """Picture-frame panels along the rooms of the Wall they link to, between its corners
    and openings, with flourishes in their corners, following it live. The work is in
    aw_panels (shared with Blender)."""

    GetDEnabling = _enabling

    def setup(self):
        self._quick = None

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
            aw_style.set_display(node, aw_style.WINDOW_DISPLAY)  # white, like trim
        return True

    def Message(self, node, mtype, data):
        if mtype == c4d.MSG_DESCRIPTION_POSTSETPARAMETER:
            try:
                if data["descid"][0].id in {pid for _n, pid in aw_materials.slots(node)}:
                    aw_materials.mark(node)
            except (TypeError, KeyError, IndexError):
                pass
        if mtype == c4d.MSG_MENUPREPARE and isinstance(data, c4d.documents.BaseDocument):
            aw_materials.apply_defaults(data, node)
        return True

    def GetVirtualObjects(self, op, hh):
        quick = (aw_panels_c4d.change_key(op), GENERATION)
        cache = op.GetCache(hh)
        if quick == self._quick and cache is not None and not op.CheckCache(hh):
            return cache
        self._quick = quick
        return aw_panels_c4d.build(op) or c4d.BaseObject(c4d.Onull)


class PlaceTool:
    """AW Place Window: hover a wall to see the panel's chosen window preset on it,
    with distances either side; click to place it (Shift centres it on the wall);
    Escape goes back to AW Edit Dimensions. The work is in aw_place."""

    def GetState(self, doc):
        return c4d.CMD_ENABLED

    def FreeTool(self, doc, data):
        aw_place._hover = None

    @staticmethod
    def _redraw():
        c4d.DrawViews(c4d.DRAWFLAGS_ONLY_ACTIVE_VIEW | c4d.DRAWFLAGS_NO_THREAD)

    def MouseInput(self, doc, data, bd, win, msg):
        x, y = msg[c4d.BFM_INPUT_X], msg[c4d.BFM_INPUT_Y]
        aw_place.hover(doc, bd, x, y, bool(msg[c4d.BFM_INPUT_QUALIFIER] & c4d.QSHIFT))
        if aw_place.can_place():  # a spot to place in wins: the next cabinet beside the last one lands on it
            aw_place.place(doc)  # its EventAdd redraws: forcing a frame here (DrawViews NO_THREAD)
            return True          # held the click until C4D had drawn the new window, a second or more
        mine = aw_place.clicked_object(bd, doc, x, y)
        if mine is not None:  # no spot here, but a cabinet or window already there: select it, placing stops
            aw_place._hover = None
            doc.SetActiveObject(mine, c4d.SELECTION_NEW)
            doc.SetAction(ID_AW_EDIT_TOOL)
            c4d.StatusSetText("Selected %s" % mine.GetName())
            c4d.EventAdd()
            return True
        aw_place.place(doc)  # nothing to place or select: says why ("doesn't fit")
        self._redraw()
        return True

    def KeyboardInput(self, doc, data, bd, win, msg):
        key = msg[c4d.BFM_INPUT_CHANNEL]
        if key == c4d.KEY_ESC:
            aw_place._hover = None
            doc.SetAction(ID_AW_EDIT_TOOL)
            c4d.EventAdd()
            return True
        if key == c4d.KEY_BACKSPACE:
            took = aw_place.size_key(back=True)
        elif key == c4d.KEY_ENTER:
            took = aw_place.size_key(commit=True)
        elif msg.GetString(c4d.BFM_INPUT_ASC) in ("r", "R") and aw_place.preset.get("object") == aw_place.CABINET:
            import aw_cabinet
            aw_cabinet.turns += 1  # a free cabinet turns a quarter
            took = True
        else:  # a size, typed: 36x60
            took = aw_place.size_key(msg.GetString(c4d.BFM_INPUT_ASC))
        if took:
            aw_place._hover = None  # the next move fits the new size
            self._redraw()
        return took

    def Draw(self, doc, data, bd, bh, bt, flags):
        try:
            aw_place.draw(bd)
        except Exception as err:  # never let the preview break the viewport
            print("Archwerks: window preview failed:", err)
        return c4d.TOOLDRAW_NONE

    def GetCursorInfo(self, doc, data, bd, x, y, bc):
        if bc.GetId() == c4d.BFM_CURSORINFO_REMOVE:
            aw_place._hover = None
            self._redraw()
            return True
        before = aw_place.preview_key()
        aw_place.hover(doc, bd, x, y, aw_grab.shift_held())
        if aw_place.preview_key() != before:  # most moves leave the snapped preview where it was
            c4d.DrawViews(c4d.DRAWFLAGS_ONLY_ACTIVE_VIEW)  # threaded: the mouse never waits on a frame
        free = aw_place.preset.get("object") == aw_place.CABINET
        bc.SetString(c4d.RESULT_BUBBLEHELP, "Place %s: click a wall%s (Shift: centre it); Escape to stop"
                     % (aw_place.preset["label"].lower(), " or the floor, R turns it" if free else ""))
        bc.SetInt32(c4d.RESULT_CURSOR, c4d.MOUSE_CROSS)
        return True


class DrawTool:
    """AW Draw: a path drawn point by point with Blender's Archwerks Draw guides,
    snapping and typed lengths (core/aw_pen); the work is in aw_drawtool_c4d."""

    def GetState(self, doc):
        return c4d.CMD_ENABLED

    def FreeTool(self, doc, data):
        aw_drawtool_c4d.leave(doc)

    @staticmethod
    def _redraw():
        c4d.DrawViews(c4d.DRAWFLAGS_ONLY_ACTIVE_VIEW | c4d.DRAWFLAGS_NO_THREAD)

    @staticmethod
    def _mods(msg):
        q = msg[c4d.BFM_INPUT_QUALIFIER]
        return bool(q & c4d.QSHIFT), bool(q & c4d.QCTRL)

    def MouseInput(self, doc, data, bd, win, msg):
        if not aw_drawtool_c4d.active():
            return False
        if msg[c4d.BFM_INPUT_CHANNEL] == c4d.BFM_INPUT_MOUSERIGHT:  # right-click: the run is done
            aw_drawtool_c4d.key(doc, bd, c4d.KEY_ENTER, "")
            self._redraw()
            return True
        shift, ctrl = self._mods(msg)
        aw_drawtool_c4d.click(doc, bd, msg[c4d.BFM_INPUT_X], msg[c4d.BFM_INPUT_Y], shift, ctrl)
        c4d.StatusSetText(aw_drawtool_c4d.status())
        self._redraw()
        return True

    def KeyboardInput(self, doc, data, bd, win, msg):
        if not aw_drawtool_c4d.active():
            return False
        shift, ctrl = self._mods(msg)
        took = aw_drawtool_c4d.key(doc, bd, msg[c4d.BFM_INPUT_CHANNEL], msg.GetString(c4d.BFM_INPUT_ASC), shift, ctrl)
        if took:
            c4d.StatusSetText(aw_drawtool_c4d.status())
            self._redraw()
        return took

    def Draw(self, doc, data, bd, bh, bt, flags):
        try:
            aw_drawtool_c4d.draw(doc, bd)
        except Exception as err:  # never let the guides break the viewport
            print("Archwerks: draw guides failed:", err)
        return c4d.TOOLDRAW_NONE

    def GetCursorInfo(self, doc, data, bd, x, y, bc):
        if not aw_drawtool_c4d.active() or bc.GetId() == c4d.BFM_CURSORINFO_REMOVE:
            return True
        aw_drawtool_c4d.update(doc, bd, x, y, aw_grab.shift_held(), _ctrl_held())
        self._redraw()
        bc.SetString(c4d.RESULT_BUBBLEHELP, aw_drawtool_c4d.status())
        bc.SetInt32(c4d.RESULT_CURSOR, c4d.MOUSE_CROSS)
        return True


def _floor_hit(bd, x, y, height):
    """Where view pixel (x, y) meets the level plane at height, or None."""
    a, v = aw_place._ray(bd, x, y)
    if abs(v.y) < 1e-9:
        return None
    t = (height - a.y) / v.y
    return a + v * t if t > 0 else None


def _ctrl_held():
    """True while Ctrl is down (aw_grab.shift_held's way)."""
    bc = c4d.BaseContainer()
    if not c4d.gui.GetInputState(c4d.BFM_INPUT_KEYBOARD, c4d.KEY_CONTROL, bc):
        return False
    return bool(bc.GetInt32(c4d.BFM_INPUT_QUALIFIER) & c4d.QCTRL)


class FloorPlan:
    """AW Floor Plan: pick an image of a plan; it is laid flat on the floor, 1 pixel
    = 1 cm, under the walls and hidden from renders, and AW Scale Plan starts so
    it can be brought to size. One undo step."""

    def Execute(self, doc):
        path = c4d.storage.LoadDialog(type=c4d.FILESELECTTYPE_IMAGES, title="Floor plan image")
        if not path:
            return True
        try:
            plane, mat = aw_plan.make_plan(doc, path)
        except ValueError as e:
            c4d.gui.MessageDialog("AW Floor Plan: %s.\n%s" % (e, path))
            return True
        plane.SetName(os.path.splitext(os.path.basename(path))[0])
        doc.StartUndo()
        doc.InsertMaterial(mat)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, mat)
        doc.InsertObject(plane)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, plane)
        doc.SetActiveObject(plane, c4d.SELECTION_NEW)
        doc.EndUndo()
        doc.SetAction(ID_AW_SCALE_PLAN_TOOL)
        c4d.EventAdd()
        return True


class ScalePlanTool:
    """AW Scale Plan: drag across a dimension you know on the selected plan (Shift
    keeps the line straight along X or Z); a pop-up asks for its real length and the
    plan scales about where the drag started so that line is that long. Works on any
    selected object, so an imported DWG can be scaled the same way. One undo step.
    The line stays on screen afterwards as a check, until the next drag or Escape."""

    def setup(self):
        self._reset()

    def _reset(self):
        self._a = self._b = None  # the measuring line, world points
        self._bd = None

    def GetState(self, doc):
        return c4d.CMD_ENABLED

    def FreeTool(self, doc, data):
        self._reset()

    @staticmethod
    def _redraw():
        c4d.DrawViews(c4d.DRAWFLAGS_ONLY_ACTIVE_VIEW | c4d.DRAWFLAGS_NO_THREAD)

    def MouseInput(self, doc, data, bd, win, msg):
        target = doc.GetActiveObject()
        if target is None:
            c4d.StatusSetText("AW Scale Plan: select the floor plan first")
            return True
        x, y = msg[c4d.BFM_INPUT_X], msg[c4d.BFM_INPUT_Y]
        height = target.GetMg().off.y
        self._reset()
        self._bd = bd
        self._a = self._b = aw_plan.floor_point(bd, x, y, height)
        win.MouseDragStart(c4d.KEY_MLEFT, x, y, c4d.MOUSEDRAGFLAGS_DONTHIDEMOUSE | c4d.MOUSEDRAGFLAGS_NOMOVE)
        mx, my = x, y
        try:
            while True:
                result, dx, dy, channels = win.MouseDrag()
                if result != c4d.MOUSEDRAGRESULT_CONTINUE:
                    break
                mx, my = mx + dx, my + dy
                b = aw_plan.floor_point(bd, mx, my, height)
                if channels.GetInt32(c4d.BFM_INPUT_QUALIFIER) & c4d.QSHIFT:
                    b = aw_plan.axis_lock(self._a, b)
                self._b = b
                c4d.DrawViews(c4d.DRAWFLAGS_ONLY_ACTIVE_VIEW | c4d.DRAWFLAGS_NO_THREAD | c4d.DRAWFLAGS_NO_ANIMATION)
        finally:
            win.MouseDragEnd()
        measured = (self._b - self._a).GetLength()
        if measured < 1e-3:
            self._reset()
            c4d.StatusSetText("AW Scale Plan: drag across a dimension you know")
            return True
        self._redraw()
        real = aw_plan.ask_real_length(measured, target.GetName(), win, mx, my)
        if real is None:
            self._reset()
        else:
            self._b, k = aw_plan.scale_plan(doc, target, self._a, self._b, real)
            c4d.StatusSetText("AW Scale Plan: scaled %s by %.4f" % (target.GetName(), k))
        self._redraw()
        return True

    def KeyboardInput(self, doc, data, bd, win, msg):
        if self._a is None or msg[c4d.BFM_INPUT_CHANNEL] != c4d.KEY_ESC:
            return False
        self._reset()  # Escape clears the measuring line
        c4d.StatusClear()
        self._redraw()
        return True

    def Draw(self, doc, data, bd, bh, bt, flags):
        if self._a is None:
            return c4d.TOOLDRAW_NONE
        if not aw_draw._alive(self._bd):  # its document closed: comparing a dead view raises
            self._reset()
            return c4d.TOOLDRAW_NONE
        if bd != self._bd:  # only in the view it was measured in
            return c4d.TOOLDRAW_NONE
        try:
            text = aw_draw.fmt_length((self._b - self._a).GetLength())
            aw_draw.draw_measure(bd, self._a, self._b, text)
        except Exception as err:
            print("Archwerks: scale plan drawing failed:", err)
            self._reset()
        return c4d.TOOLDRAW_NONE

    def GetCursorInfo(self, doc, data, bd, x, y, bc):
        if bc.GetId() == c4d.BFM_CURSORINFO_REMOVE:
            return True
        bc.SetString(c4d.RESULT_BUBBLEHELP, "AW Scale Plan: drag across a dimension you know (Shift keeps it "
                     "straight); you'll be asked for its real length")
        bc.SetInt32(c4d.RESULT_CURSOR, c4d.MOUSE_CROSS)
        return True


class Panel:
    """Opens the dockable Archwerks panel (aw_panel.Panel); C4D restores it with the
    layout through RestoreLayout."""

    def setup(self):
        self.dialog = None

    def _dialog(self):
        if self.dialog is None:
            self.dialog = aw_panel.Panel()
        elif type(self.dialog) is not aw_panel.Panel:  # reloaded since it was made
            self.dialog.__class__ = aw_panel.Panel
        return self.dialog

    def Execute(self, doc):
        return self._dialog().Open(c4d.DLG_TYPE_ASYNC, pluginid=ID_AW_PANEL, defaultw=240, defaulth=0)

    def RestoreLayout(self, sec_ref):
        return self._dialog().Restore(pluginid=ID_AW_PANEL, secret=sec_ref)


class Watcher:
    """On every scene change, two cheap checks: while a wall started from the panel
    or Walls from Spline is being drawn, it pulls each new spline the Spline Pen
    makes into it (aw_panel.adopt); after a wall's material slot changes, it syncs
    that wall's material tags (aw_materials.flush). A message plugin, so it works
    whether or not the panel is open or visible."""

    def CoreMessage(self, mid, bc):
        if mid == c4d.EVMSG_CHANGE:
            if aw_panel._armed is not None:
                aw_panel.adopt(c4d.documents.GetActiveDocument())
            if aw_materials.pending():  # a wall's material slots changed
                aw_materials.flush()
            try:  # a cabinet's width changed: its run moves with it
                aw_cabinet_c4d.watch(c4d.documents.GetActiveDocument())
            except Exception as e:  # never let it break the scene
                print("Archwerks: cabinet neighbours:", e)
            try:  # something new from Cinema 4D's own menus: into its group
                aw_groups_c4d.watch(c4d.documents.GetActiveDocument())
            except Exception as e:
                print("Archwerks: groups:", e)
        return True


def _build_menu():
    """An Archwerks menu in the main menu bar, after Extensions: the shared command list
    (core/aw_commands), a submenu per group (aw_commands_c4d.menu)."""
    import aw_commands_c4d
    main = c4d.gui.GetMenuResource("M_EDITOR")
    menu = aw_commands_c4d.menu()
    extensions = c4d.gui.SearchPluginMenuResource()
    if extensions:
        main.InsDataAfter(c4d.MENURESOURCE_STRING, menu, extensions)
    else:
        main.InsData(c4d.MENURESOURCE_SUBMENU, menu)


class Command:
    """One command of the shared list (core/aw_commands), registered under its own id
    (aw_ids.COMMAND_IDS): archwerks.pyp sets aw_key on each, and Execute runs it
    (aw_commands_c4d.run), so every menu entry, palette icon and shortcut does what the
    Archwerks panel's button does."""

    def GetState(self, doc):
        return c4d.CMD_ENABLED

    def Execute(self, doc):
        import aw_commands_c4d
        aw_commands_c4d.run(getattr(self, "aw_key", ""), doc)
        return True


class Placeholder:
    """A registered id whose object isn't built yet: shows nothing."""

    GetDEnabling = _enabling

    def Init(self, node, isCloneInit=False):
        if not isCloneInit:
            aw_desc.init(self, node)
        return True

    def GetVirtualObjects(self, op, hh):
        return c4d.BaseObject(c4d.Onull)


class PlaceholderTool:
    """A registered tool id not built yet."""

    def GetState(self, doc):
        return 0  # greyed out


# Ids registered for what comes next: each is a Placeholder until its class is written here
Ceiling = Floor  # the same object, registered as Ceiling: it stands up from its Elevation
Railing = Stair  # see Stair
Door = Opening  # a door is built and placed exactly as a window is, by aw_door
Cutter = Opening  # and so is a shaped hole, by aw_cutter
Fireplace = Opening  # and a fireplace, by aw_fireplace
DuplicateTool = PlaceholderTool


Cutout = Cutter  # a plugin file installed 2026-10-28 named the class Cutout: it still finds it
