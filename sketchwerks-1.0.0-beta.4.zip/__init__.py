bl_info = {
    "name": "Sketchwerks",
    "author": "Vivinel",
    "version": (1, 0, 0),
    "warning": "Beta 4",
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Sketchwerks",
    "description": "Realtime hand-drawn line art via Geometry Nodes. Feature edges from a "
                   "collection become world-locked wobbly strokes (real mesh ribbons, no "
                   "Grease Pencil) with pencil/charcoal/ink texture, overshoot and AO smudge "
                   "shading. Crease, boundary, freestyle and view-silhouette edges, with "
                   "camera-raycast occlusion, styled hidden lines and a screen-space detail "
                   "cap that stops it drawing finer than the render can show. Build-on "
                   "animation: a keyframeable draw-on with spatially-coherent stroke order, "
                   "and a colour-fill matte that dissolves in on its own as each object "
                   "finishes drawing, so a build-on only starts occluding once it exists. "
                   "20 media style presets. Renders natively in EEVEE, no baking.",
    "doc_url": "https://www.vivinel.com/",
    "category": "Werks",
}

# =============================================================================
# Sketchwerks (module stays `sketchy_lines` - see the rename note by PANEL_CATEGORY)
# -----------------------------------------------------------------------------
# A realtime, non-destructive line-art system for archviz and stylised
# rendering, built to solve the temporal jitter, popping and aliasing that
# Grease Pencil Line Art and Freestyle suffer from under camera motion.
#
# Core idea: feature edges are turned into strokes by a Geometry Nodes group
# and the wobble/texture is keyed to WORLD-SPACE geometry, never to the camera
# or screen. A stroke's shape therefore cannot swim or crawl when the camera
# moves - it is baked into real 3D mesh ribbons that render (and anti-alias)
# natively in EEVEE and Cycles, identical in viewport and final frame.
#
# Each "line set" is one object + one modifier + one material, targeting one
# collection, so a scene can carry several independent styles at once. The
# N-panel (View3D > Sketchy) and the modifier UI share the same hierarchy.
#
# Feature groups (see the README for full docs):
#   Line       - collection, width (mm, world-space), colour
#   Wobble     - amount/size/complexity, overlapping strokes, seed, boiling
#   Overshoot  - lines running past (or short of) corners, with randomisation
#   Breakup    - opacity skips, thickness (pressure) and per-pixel paper grain
#   Dashes     - world arc-length dashes
#   Shading    - form-tone shading: smooth smudge, or Hatch / Cross-hatch /
#                Dots / Stipple screentone whose density tracks the tone, with
#                hard cel levels and an optional faked light direction
#   Hidden Lines - raycast occlusion with independently styled ghost lines
#   Edges      - which edges to draw (angle / sharp / boundary / freestyle)
#   Draw-On    - keyframeable build-on animation with easing and stagger
#   Style Presets - 20 media looks + save/load your own
# =============================================================================

import bpy
import bmesh
import json
import os
import re
from math import radians

NODE_GROUP_NAME = "Sketchwerks Line Art"
LINESET_COLLECTION = "Sketchwerks Lines"   # objects created by the add-on live here
# ⚠ COSMETIC ONLY, and safe BECAUSE nothing looks the modifier up by name -- every
# lookup is `m.type == 'NODES'` plus the node group name. The node group and the
# collections above are DATA names that live in the user's .blend and cannot be
# renamed without orphaning existing line sets.
MODIFIER_NAME = "Sketchwerks"

# ⚠ THESE ARE DATA NAMES INSIDE THE USER'S .BLEND. The add-on finds its own work by
# them, so renaming without migrating orphans every existing line set. Renamed at
# 1.0.0-beta.1, while the only files in the wild are Rob's own -- after testers have
# files it is permanent. `_migrate_legacy_names` runs on load_post AND at the top of
# rebuild, so old files fix themselves on open without anyone knowing to press
# anything.
# ⚠ NOT renamed, deliberately: MARKER_PROP / FROZEN_PROP (custom-property keys that
# IDENTIFY line sets - changing them orphans everything, and nobody sees them), the
# preset directory (holds the user's saved presets), and the `sketchy.*` operator ids
# (in keymaps, invisible).
_LEGACY = {
    "node_group": "Sketchy Line Art",
    "lineset":    "Sketchy Lines",
    "source":     "Sketchy Source",
    "obj":        "Sketchy Lines — ",
    "mesh":       "SketchyLines_",
    "light":      "Sketchy Light",
    "proxy":      "Sketchy Occluder Proxy",
}


def _migrate_legacy_names():
    """Rename pre-1.0 'Sketchy *' datablocks to 'Sketchwerks *'. Idempotent."""
    n = 0
    ng = bpy.data.node_groups.get(_LEGACY["node_group"])
    if ng is not None and bpy.data.node_groups.get(NODE_GROUP_NAME) is None:
        ng.name = NODE_GROUP_NAME
        n += 1
    pc = bpy.data.collections.get(_LEGACY["proxy"])
    if pc is not None and bpy.data.collections.get("Sketchwerks Occluder Proxy") is None:
        pc.name = "Sketchwerks Occluder Proxy"
        n += 1
    c = bpy.data.collections.get(_LEGACY["lineset"])
    if c is not None and bpy.data.collections.get(LINESET_COLLECTION) is None:
        c.name = LINESET_COLLECTION
        n += 1
    for col in bpy.data.collections:
        if col.name.startswith(_LEGACY["source"]):
            col.name = SOURCE_COLLECTION + col.name[len(_LEGACY["source"]):]
            n += 1
    for mat in bpy.data.materials:
        for pre in ("SketchyLine", "SketchySmudge", "SketchyFill"):
            if mat.name.startswith(pre):
                mat.name = "Sketchwerks" + mat.name[len("Sketchy"):]
                n += 1
                break
    for ob in bpy.data.objects:
        old = ob.name
        if old.startswith(_LEGACY["obj"]):
            ob.name = "%s — %s" % (LINESET_COLLECTION, old[len(_LEGACY["obj"]):])
        elif old == _LEGACY["light"]:
            ob.name = "Sketchwerks Light"
        if ob.name != old:
            n += 1
            # ⚠ frozen snapshots remember their source BY NAME - repoint them or
            # unfreezing silently fails to restore the live set
            for f in bpy.data.objects:
                if f.get(FROZEN_SRC) == old:
                    f[FROZEN_SRC] = ob.name
        if ob.data is not None and getattr(ob.data, "name", "").startswith(_LEGACY["mesh"]):
            ob.data.name = "SketchwerksLines_" + ob.data.name[len(_LEGACY["mesh"]):]
        for m in ob.modifiers:
            if m.type == 'NODES' and m.name.startswith("Sketchy"):
                m.name = MODIFIER_NAME
                n += 1
    return n


@bpy.app.handlers.persistent
def _migrate_load_post(*_a):
    try:
        n = _migrate_legacy_names()
        if n:
            print("[sketchy] migrated %d legacy 'Sketchy *' name(s) to 'Sketchwerks *'" % n)
    except Exception as exc:
        print("[sketchy] name migration error:", exc)
ATTR_SIL_FRONT = "sk_sil_front"        # per-face "faces the camera", read back on edges
# ⚠ DATA NAME, NOT BRANDING — do NOT rename with the rebrand. This names a collection
# inside the user's .blend and the generated objects are named from it, so changing it
# would orphan every line set in every existing file. Same call as keeping the module
# `sketchy_lines` and the `sketchy.*` operator ids.
PROXY_COLLECTION = "Sketchwerks Occluder Proxy"  # low-poly raycast stand-ins live here
PROXY_MARKER = "sketchy_proxy"         # id-prop flag on generated proxy objects
ATTR_INCLUDE = "sketchy_include"   # bool, edge domain: force edge into line art
ATTR_EXCLUDE = "sketchy_exclude"   # bool, edge domain: force edge out of line art
ATTR_VIS = "sk_vis"                # float, point domain: 1 visible .. hidden opacity .. 0
ATTR_OPOS = "sk_opos"              # vector, point domain: pre-ghost world position
ATTR_ANCHOR = "sk_anchor"          # vector, point domain: on-edge position for occlusion tests
ATTR_GRAIN = "sk_grain"            # float, uniform: grain amount, read by the material
ATTR_GSCALE = "sk_gscale"          # float, uniform: grain noise frequency, read by the material
ATTR_TAN = "sk_tan"                # vector, point domain: stroke tangent, read by the material
ATTR_GW = "sk_gw"                  # float, uniform: grain boil clock, read by the material
ATTR_OCC = "sk_occ"                # float, point domain: 1 = occluded, drives hidden-line styling
ATTR_SMUDGE = "sk_smudge"          # float, uniform: smudge amount, read by the smudge material
ATTR_SMDIST = "sk_smdist"          # float, uniform: AO distance in meters
ATTR_SMSIZE = "sk_smsize"          # float, uniform: smudge noise frequency
ATTR_SMAO = "sk_smao"              # float, uniform: 1 = add true AO cavity term
ATTR_TSTYLE = "sk_tstyle"          # float, uniform: shading style 0=Smudge 1=Hatch 2=Cross 3=Dots 4=Stipple
ATTR_TLEVELS = "sk_tlev"           # float, uniform: posterize levels (hard tone bands)
ATTR_TDIR = "sk_tdir"              # vector, uniform: fake light direction (zero = form only)
ATTR_TPANGLE = "sk_tpang"          # float, uniform: hatch/dot pattern angle (radians)
ATTR_TWEIGHT = "sk_tweight"        # float, uniform: pattern mark weight (line width / dot size)
ATTR_TEDGE = "sk_tedge"            # float, uniform: sharp-edge darkening strength
ATTR_TSKETCH = "sk_tsketch"        # float, uniform: hatch sketchiness (hand-drawn wobble)
ATTR_SMVIS = "sk_smvis"            # float, point: 1 = smudge surface camera-visible, 0 = occluded
ATTR_FRONT = "sk_front"            # float, face: 1 = face toward camera, 0 = away
ATTR_SIL = "sk_sil"                # float, edge/point: ~0.5 on the view silhouette, 0/1 interior
ATTR_FCHOKE = "sk_fchoke"          # float, uniform: colour-fill choke (pull back from edges)
ATTR_FTEX = "sk_ftex"              # float, uniform: colour-fill texture/erosion amount
ATTR_FTSIZE = "sk_ftsize"          # float, uniform: colour-fill texture size (meters)
# ⚠ Matte Fade is a FRACTION of the draw, so no single default suits both a 15-frame and
# a 60-frame build. These are the DURATIONS Make Build-On aims for, converted to a
# fraction from the keyed draw length. Six frames is where the DITHERED dissolve stops
# reading as one stochastic flash frame; three frames early lets occlusion settle before
# the last strokes land.
MATTE_FADE_FRAMES = 6.0
MATTE_LEAD_FRAMES = 3.0

ATTR_FOPAC = "sk_fopac"            # float, uniform: colour-fill / matte opacity (0-1)
ATTR_FMATTE = "sk_fmatte"          # float, uniform: 1 = fill renders as a transparent holdout
ATTR_FSPREAD = "sk_fspread"        # float, uniform: matte reveal grain, metres
ATTR_FREVEAL = "sk_freveal"        # float, uniform: 1 = threshold the matte spatially
MARKER_PROP = "sketchy_line_set"


# ---------------------------------------------------------------------------
# Node-building helpers
# ---------------------------------------------------------------------------

def _in(node, name):
    """Input socket by name, honoring data_type switches (Compare, Store
    Named Attribute etc. keep one socket per type; only one is enabled)."""
    for s in node.inputs:
        if s.name == name and s.enabled:
            return s
    return node.inputs[name]


def _out(node, name):
    for s in node.outputs:
        if s.name == name and s.enabled:
            return s
    return node.outputs[name]


class _Builder:
    def __init__(self, tree):
        self.tree = tree
        self.x = 0

    def node(self, type_name, x, y, **settings):
        n = self.tree.nodes.new(type_name)
        n.location = (x, y)
        for k, v in settings.items():
            setattr(n, k, v)
        return n

    def link(self, from_sock, to_sock):
        self.tree.links.new(from_sock, to_sock)

    def math(self, op, x, y, a=None, b=None, av=None, bv=None):
        n = self.node("ShaderNodeMath", x, y, operation=op)
        if a is not None:
            self.link(a, n.inputs[0])
        elif av is not None:
            n.inputs[0].default_value = av
        if b is not None:
            self.link(b, n.inputs[1])
        elif bv is not None:
            n.inputs[1].default_value = bv
        return n.outputs[0]

    def vmath(self, op, x, y, a=None, b=None, scale=None):
        n = self.node("ShaderNodeVectorMath", x, y, operation=op)
        if a is not None:
            self.link(a, n.inputs[0])
        if b is not None:
            if isinstance(b, tuple):
                n.inputs[1].default_value = b
            else:
                self.link(b, n.inputs[1])
        if scale is not None:
            if isinstance(scale, (int, float)):
                n.inputs["Scale"].default_value = scale
            else:
                self.link(scale, n.inputs["Scale"])
        return n.outputs[0]

    def bool_op(self, op, x, y, a, b=None):
        n = self.node("FunctionNodeBooleanMath", x, y, operation=op)
        self.link(a, n.inputs[0])
        if b is not None:
            self.link(b, n.inputs[1])
        return n.outputs[0]


def _new_interface_socket(tree, name, socket_type, in_out='INPUT', parent=None, **props):
    kwargs = dict(name=name, in_out=in_out, socket_type=socket_type)
    if parent is not None:
        kwargs["parent"] = parent
    sock = tree.interface.new_socket(**kwargs)
    for k, v in props.items():
        if hasattr(sock, k):
            setattr(sock, k, v)
    return sock


def build_node_group():
    """Create the shared Sketchy Line Art node group (only if missing, so
    existing modifiers keep their socket values)."""
    tree = bpy.data.node_groups.get(NODE_GROUP_NAME)
    if tree is not None:
        return tree

    tree = bpy.data.node_groups.new(NODE_GROUP_NAME, "GeometryNodeTree")
    tree.is_modifier = True

    # Interface is grouped into panels so the modifier UI mirrors the N-panel
    # section hierarchy (Line settings at the root, then collapsible sections).
    def panel(name):
        return tree.interface.new_panel(name, default_closed=True)

    _new_interface_socket(tree, "Geometry", "NodeSocketGeometry", in_out='OUTPUT')

    # --- root: the settings you touch most ---
    _new_interface_socket(tree, "Line Collection", "NodeSocketCollection")
    _new_interface_socket(tree, "Line Width", "NodeSocketFloat",
                          default_value=8.0, min_value=0.05, max_value=60.0,
                          description="Stroke width in millimeters (world-space, like a "
                                      "real pen on the building)")
    _new_interface_socket(tree, "Material", "NodeSocketMaterial")

    p_wob = panel("Wobble")
    _new_interface_socket(tree, "Wobble Amount", "NodeSocketFloat", parent=p_wob,
                          default_value=10.0, min_value=0.0, max_value=200.0,
                          description="How far lines wander off the true edge, in "
                                      "millimeters")
    _new_interface_socket(tree, "Wobble Size", "NodeSocketFloat", parent=p_wob,
                          default_value=12.0, min_value=0.5, max_value=500.0,
                          description="Length of the wander waves along the line, in "
                                      "centimeters. Smaller = tighter scribble")
    _new_interface_socket(tree, "Wobble Complexity", "NodeSocketFloat", parent=p_wob,
                          default_value=2.0, min_value=0.0, max_value=8.0,
                          description="Octaves of finer wiggle layered on the base waves, "
                                      "like Roughen's Complexity")
    _new_interface_socket(tree, "Strokes", "NodeSocketInt", parent=p_wob,
                          default_value=1, min_value=1, max_value=5,
                          description="How many times each line is drawn over, offset "
                                      "slightly each time like hand overdraw")
    _new_interface_socket(tree, "Seed", "NodeSocketInt", default_value=0, parent=p_wob)
    _new_interface_socket(tree, "Boil Rate", "NodeSocketFloat", parent=p_wob,
                          default_value=0.0, min_value=0.0, max_value=24.0,
                          description="Wobble re-draws per second (0 = static). "
                                      "Classic boiling line: 8-12")

    p_over = panel("Overshoot")
    _new_interface_socket(tree, "Overshoot", "NodeSocketFloat", parent=p_over,
                          default_value=0.0, min_value=-200.0, max_value=200.0,
                          description="Run each line past its corners by this many "
                                      "millimeters, like a hand sketch. Negative values "
                                      "undershoot (stop short of the join). 0 = exact")
    _new_interface_socket(tree, "Overshoot Random", "NodeSocketFloat", parent=p_over,
                          default_value=0.0, min_value=0.0, max_value=200.0,
                          description="Randomize each line end by up to this many "
                                      "millimeters, so some run long and some fall short "
                                      "(mixing over- and undershoot). Reshuffled by Seed")

    p_brk = panel("Breakup")
    _new_interface_socket(tree, "Opacity Breakup", "NodeSocketFloat", parent=p_brk,
                          default_value=0.35, min_value=0.0, max_value=1.0, subtype='FACTOR',
                          description="Fades and gaps along the stroke, like the medium "
                                      "skipping. Like After Effects' Roughen on opacity")
    _new_interface_socket(tree, "Opacity Size", "NodeSocketFloat", parent=p_brk,
                          default_value=1.5, min_value=0.05, max_value=100.0,
                          description="Feature size of the opacity breakup, in centimeters")
    _new_interface_socket(tree, "Thickness Breakup", "NodeSocketFloat", parent=p_brk,
                          default_value=0.5, min_value=0.0, max_value=1.0, subtype='FACTOR',
                          description="Thickness variation along the stroke, like pencil "
                                      "pressure. High values pinch strokes down to nothing")
    _new_interface_socket(tree, "Thickness Size", "NodeSocketFloat", parent=p_brk,
                          default_value=2.5, min_value=0.05, max_value=100.0,
                          description="Feature size of the pressure variation, in "
                                      "centimeters. Larger = long calligraphic swells")
    _new_interface_socket(tree, "Grain", "NodeSocketFloat", parent=p_brk,
                          default_value=0.4, min_value=0.0, max_value=3.0, subtype='FACTOR',
                          description="Per-pixel paper tooth chewing in from the stroke "
                                      "edges (rendered in the material, so it can be far "
                                      "finer than the stroke geometry). Above 1 the bite "
                                      "reaches past the stroke core")
    _new_interface_socket(tree, "Grain Size", "NodeSocketFloat", parent=p_brk,
                          default_value=0.25, min_value=0.02, max_value=10.0,
                          description="Feature size of the paper tooth, in centimeters")

    p_dash = panel("Dashes")
    _new_interface_socket(tree, "Dash Length", "NodeSocketFloat", parent=p_dash,
                          default_value=2.0, min_value=0.0, max_value=100.0,
                          description="Dash length in centimeters along the stroke "
                                      "(0 = solid line even with Dashes on)")
    _new_interface_socket(tree, "Dash Gap", "NodeSocketFloat", parent=p_dash,
                          default_value=1.0, min_value=0.05, max_value=100.0,
                          description="Gap between dashes, in centimeters")

    p_smu = panel("Smudge")
    _new_interface_socket(tree, "Smudge Enable", "NodeSocketBool", parent=p_smu,
                          default_value=False,
                          description="Turn on soft grainy smudge shading rubbed toward "
                                      "the forms and corners of the drawn objects")
    _new_interface_socket(tree, "Smudge", "NodeSocketFloat", parent=p_smu,
                          default_value=0.6, min_value=0.0, max_value=2.0, subtype='FACTOR',
                          description="Smudge strength / darkness. Above 1 the tone "
                                      "saturates toward solid")
    _new_interface_socket(tree, "Smudge Distance", "NodeSocketFloat", parent=p_smu,
                          default_value=20.0, min_value=1.0, max_value=500.0,
                          description="How far the tone bleeds in from form edges, in "
                                      "centimeters (also the cavity radius)")
    _new_interface_socket(tree, "Smudge Size", "NodeSocketFloat", parent=p_smu,
                          default_value=4.0, min_value=0.05, max_value=100.0,
                          description="Grain size of the smudge tooth, in centimeters. "
                                      "Small = fine powder, large = rough chunky charcoal")
    _new_interface_socket(tree, "Smudge Cavity", "NodeSocketBool", parent=p_smu,
                          default_value=False,
                          description="Add true ambient-occlusion darkening in real "
                                      "corners and contacts (EEVEE needs Raytracing on). "
                                      "The base facing tone works without it")
    _new_interface_socket(tree, "Smudge Material", "NodeSocketMaterial", parent=p_smu)

    p_hid = panel("Hidden Lines")
    _new_interface_socket(tree, "Show Hidden Lines", "NodeSocketBool", parent=p_hid,
                          default_value=False,
                          description="Draw occluded lines in their own style instead of "
                                      "hiding them")
    _new_interface_socket(tree, "Hidden Line Opacity", "NodeSocketFloat", parent=p_hid,
                          default_value=0.35, min_value=0.0, max_value=1.0, subtype='FACTOR',
                          description="Opacity of hidden lines when they are shown")
    _new_interface_socket(tree, "Hidden Width Scale", "NodeSocketFloat", parent=p_hid,
                          default_value=0.5, min_value=0.05, max_value=1.0, subtype='FACTOR',
                          description="Width of hidden lines relative to visible ones")
    _new_interface_socket(tree, "Hidden Dash Length", "NodeSocketFloat", parent=p_hid,
                          default_value=1.5, min_value=0.0, max_value=100.0,
                          description="Dash length for hidden lines, in centimeters "
                                      "(0 = solid)")
    _new_interface_socket(tree, "Hidden Dash Gap", "NodeSocketFloat", parent=p_hid,
                          default_value=0.8, min_value=0.05, max_value=100.0,
                          description="Gap between hidden-line dashes, in centimeters")
    _new_interface_socket(tree, "Occlusion Bias", "NodeSocketFloat", parent=p_hid,
                          default_value=10.0, min_value=0.1, max_value=1000.0,
                          description="Stop the visibility ray this many millimeters short "
                                      "of the surface so strokes lying on it don't occlude "
                                      "themselves. Raise it above Wobble Amount if lines "
                                      "flicker")
    _new_interface_socket(tree, "Occlude Against", "NodeSocketCollection", parent=p_hid,
                          description="Also hide lines behind the meshes in this "
                                      "collection, on top of this line set's own geometry. "
                                      "Point every line set at one collection holding all "
                                      "your objects so separate sets occlude each other")

    p_edge = panel("Edges")
    _new_interface_socket(tree, "Angle Threshold", "NodeSocketFloat", parent=p_edge,
                          default_value=radians(40.0), min_value=0.0,
                          max_value=radians(180.0), subtype='ANGLE')
    _new_interface_socket(tree, "Include Sharp Edges", "NodeSocketBool",
                          default_value=True, parent=p_edge)
    _new_interface_socket(tree, "Include Boundaries", "NodeSocketBool",
                          default_value=True, parent=p_edge)
    _new_interface_socket(tree, "Use Freestyle Marks", "NodeSocketBool",
                          default_value=True, parent=p_edge)

    p_draw = panel("Draw-On")
    _new_interface_socket(tree, "Draw On", "NodeSocketBool", parent=p_draw,
                          default_value=False,
                          description="Reveal the lines by a keyframeable amount, like a "
                                      "hand sketching the scene on")
    _new_interface_socket(tree, "Draw Amount", "NodeSocketFloat", parent=p_draw,
                          default_value=1.0, min_value=0.0, max_value=1.0, subtype='FACTOR',
                          description="How much of the drawing is done, 0 = blank, 1 = "
                                      "complete. Keyframe this in the timeline to animate "
                                      "the draw-on")
    _new_interface_socket(tree, "Draw Stagger", "NodeSocketFloat", parent=p_draw,
                          default_value=0.5, min_value=0.0, max_value=1.0, subtype='FACTOR',
                          description="0 = every line draws at once; 1 = lines draw one "
                                      "after another (build-on). Order is shuffled by Seed")
    _new_interface_socket(tree, "Draw Easing", "NodeSocketMenu", parent=p_draw,
                          description="Shape of the reveal over Draw Amount: Linear, or "
                                      "ease the start/end so it accelerates and settles "
                                      "like a hand")

    # NOTE: created LAST on purpose. Socket identifiers ("Socket_N") are assigned
    # by creation order, so appending here keeps every existing socket's id (and
    # therefore every existing keyframe/driver) stable across an Update Node Group.
    # It still lives in the Overshoot panel via parent=p_over.
    _new_interface_socket(tree, "Overshoot Enable", "NodeSocketBool", parent=p_over,
                          default_value=False,
                          description="Master switch for overshoot. Off skips the per-edge "
                                      "split branch entirely (faster on dense meshes) while "
                                      "keeping your Overshoot values dialed in")

    # Toon/textured shading (rendered by the smudge material). Created LAST so
    # every existing socket id — and every keyframe — stays put. They live in
    # the Smudge (a.k.a. Shading) panel via parent=p_smu.
    _new_interface_socket(tree, "Shading Style", "NodeSocketMenu", parent=p_smu,
                          description="How the shading tone is drawn: Smudge (smooth "
                                      "grain), or a screentone pattern — Hatch, Cross-"
                                      "hatch, Dots or Stipple — whose density tracks the "
                                      "tone")
    _new_interface_socket(tree, "Tone Steps", "NodeSocketFloat", parent=p_smu,
                          default_value=3.0, min_value=2.0, max_value=8.0,
                          description="How many flat tone steps the shading is quantized "
                                      "into. 2 = hard two-tone cel (just lit / shadow); "
                                      "higher = more gradations, so subtler angle changes "
                                      "get their own step (smoother, more detail)")
    _new_interface_socket(tree, "Pattern Angle", "NodeSocketFloat", parent=p_smu,
                          default_value=radians(45.0), min_value=radians(-180.0),
                          max_value=radians(180.0), subtype='ANGLE',
                          description="Direction of the hatch lines / dot grid")
    _new_interface_socket(tree, "Use Light Angle", "NodeSocketBool", parent=p_smu,
                          default_value=False,
                          description="Add a faked directional shadow (a hard cel "
                                      "terminator you aim), on top of the form tone. "
                                      "Cycles-native — it doesn't cast between objects")
    _new_interface_socket(tree, "Light Empty", "NodeSocketObject", parent=p_smu,
                          description="Aim the fake light by pointing this Empty like a "
                                      "sun — its arrow is the light ray, so point the arrow "
                                      "AT the surfaces you want lit. Rotate it in the "
                                      "viewport; keyframeable. Use the button to create one")
    _new_interface_socket(tree, "Shade Outer Only", "NodeSocketBool", parent=p_smu,
                          default_value=False,
                          description="Treat the object as solid: don't shade inner "
                                      "cavity walls (a face whose outward normal points "
                                      "back into the object's own geometry). Turn on for "
                                      "hollow/open props; leave off for room interiors you "
                                      "view from inside")
    _new_interface_socket(tree, "Pattern Weight", "NodeSocketFloat", parent=p_smu,
                          default_value=0.6, min_value=0.1, max_value=1.0, subtype='FACTOR',
                          description="Thickness of the pattern marks: hatch/cross line "
                                      "width, dot size, stipple density. Lower = finer, "
                                      "thinner lines and smaller dots (more paper showing)")
    _new_interface_socket(tree, "Sketchiness", "NodeSocketFloat", parent=p_smu,
                          default_value=0.0, min_value=0.0, max_value=1.0, subtype='FACTOR',
                          description="Wobble the hatch / dot pattern so it looks hand-drawn "
                                      "instead of mechanical. World-locked, so the wobble "
                                      "stays put on the surface (no swimming)")
    _new_interface_socket(tree, "Edge", "NodeSocketFloat", parent=p_smu,
                          default_value=0.0, min_value=0.0, max_value=2.0, subtype='FACTOR',
                          description="Darken a soft accent along the model's SHARP edges "
                                      "and creases (via bevel-normal edge detection), adding "
                                      "definition the broad-face shading misses. 0 = off")
    _new_interface_socket(tree, "Screen-Space Width", "NodeSocketBool", parent=p_edge,
                          default_value=False,
                          description="Keep on-screen line thickness CONSTANT as the camera "
                                      "dollies in and out, instead of world-locked width that "
                                      "goes thin on distant shots. Perspective cameras only "
                                      "(orthographic is already distance-independent)")
    _new_interface_socket(tree, "Reference Distance", "NodeSocketFloat", parent=p_edge,
                          default_value=3.0, min_value=0.1, max_value=100.0, subtype='DISTANCE',
                          description="The distance at which Line Width equals its literal mm "
                                      "value. Lines nearer the camera than this get thinner, "
                                      "farther get thicker, so the on-screen weight holds")
    _new_interface_socket(tree, "Viewport Coarsen", "NodeSocketFloat", parent=p_edge,
                          default_value=1.0, min_value=1.0, max_value=32.0,
                          description="Resample strokes this many times coarser IN THE "
                                      "VIEWPORT only - renders are untouched. Cost tracks "
                                      "vertex count, so 4 is roughly 4x cheaper to work "
                                      "with. The wobble reads the same, just with fewer "
                                      "points describing it")
    _new_interface_socket(tree, "Line Taper", "NodeSocketFloat", parent=p_over,
                          default_value=0.0, min_value=0.0, max_value=1.0, subtype='FACTOR',
                          description="Taper the stroke toward its ends, like lifting a pen. "
                                      "0 = uniform width; 1 = strokes thin to a point at both "
                                      "ends. Softens the mechanical feel of even-weight lines")
    _new_interface_socket(tree, "Colour Fill", "NodeSocketBool", parent=p_edge,
                          default_value=False,
                          description="Flood the shapes with a flat colour under the ink lines, "
                                      "turning the line art into a coloured illustration. A copy "
                                      "of the surface, nudged toward the camera so it covers the "
                                      "grey model; unlit, so the colour stays flat")
    _new_interface_socket(tree, "Fill Material", "NodeSocketMaterial", parent=p_edge)
    _new_interface_socket(tree, "Fill Choke", "NodeSocketFloat", parent=p_edge,
                          default_value=0.0, min_value=0.0, max_value=1.0, subtype='FACTOR',
                          description="Pull the fill back from the edges toward the Paper colour, "
                                      "so the colour doesn't quite reach the ink lines — the "
                                      "loose hand-coloured look. 0 = fills fully to the outline")
    _new_interface_socket(tree, "Fill Texture", "NodeSocketFloat", parent=p_edge,
                          default_value=0.0, min_value=0.0, max_value=1.0, subtype='FACTOR',
                          description="Break the fill up with a world-locked mottle, revealing the "
                                      "Paper colour in patches like a dry brush or watercolour "
                                      "wash. 0 = smooth, flat colour")
    _new_interface_socket(tree, "Fill Texture Size", "NodeSocketFloat", parent=p_edge,
                          default_value=6.0, min_value=0.2, max_value=50.0,
                          description="Size of the fill texture mottle, in centimeters")

    # Per-section enable toggles, appended LAST so every existing Socket_N (and
    # so every keyframe, e.g. Draw Amount = Socket_46) keeps its identifier.
    # Default ON so rebuilt/older files keep their current look. Parented to
    # their panels so they read as that section's master switch in the modifier.
    _new_interface_socket(tree, "Wobble Enable", "NodeSocketBool", parent=p_wob,
                          default_value=True,
                          description="Master switch for the whole Wobble section. Off "
                                      "skips the wobble noise entirely (straight lines, "
                                      "cheaper)")
    _new_interface_socket(tree, "Breakup Enable", "NodeSocketBool", parent=p_brk,
                          default_value=True,
                          description="Master switch for the Breakup section (opacity, "
                                      "thickness and grain variation). Off = clean, even "
                                      "strokes")
    _new_interface_socket(tree, "Dashes Enable", "NodeSocketBool", parent=p_dash,
                          default_value=False,
                          description="Master switch for dashed strokes. Off = solid lines. "
                                      "Opt-in: enabling shows the Dash/Gap pattern below")
    # Appended after the enable toggles, still LAST, so Draw Amount stays Socket_46.
    _new_interface_socket(tree, "Include Silhouettes", "NodeSocketBool", parent=p_edge,
                          default_value=True,
                          description="Draw the outline where the surface turns away from "
                                      "the camera. Sharp-edge and angle selection find "
                                      "nothing on smooth objects - a subdivided bottle "
                                      "measured 512,000 edges and 0 lines - because a "
                                      "smooth surface has no creases. This finds them by "
                                      "camera projection instead. View-dependent, so it "
                                      "re-evaluates as the camera moves")
    _new_interface_socket(tree, "Simplify (mm)", "NodeSocketFloat", parent=p_edge,
                          default_value=0.0, min_value=0.0, max_value=200.0,
                          description="Weld source vertices closer than this before finding "
                                      "edges. Cost tracks source element count, so it is the "
                                      "one setting that meaningfully speeds line art up: 5 mm "
                                      "measured half the evaluation time for a 0.18% change "
                                      "in the rendered image. Thin geometry welds first - "
                                      "railing bars went at 20 mm - so the safe value is set "
                                      "by the finest detail you need")

    _new_interface_socket(tree, "Render Width (px)", "NodeSocketFloat", parent=p_edge,
                          default_value=1920.0, min_value=16.0, max_value=16384.0,
                          description="Output width in pixels. Only used to work out how "
                                      "fine a stroke can usefully be - Geometry Nodes cannot "
                                      "read the render size itself")
    _new_interface_socket(tree, "Detail Limit (px)", "NodeSocketFloat", parent=p_edge,
                          default_value=3.0, min_value=0.0, max_value=16.0,
                          description="Never resample strokes finer than this many pixels. "
                                      "Point spacing is otherwise set in WORLD units by the "
                                      "smallest noise size, which on an exterior meant 2 mm "
                                      "spacing where one pixel was 12.6 mm - 6x more points "
                                      "than the render could show. Self-tuning: fine up "
                                      "close, coarse far away. 0 disables it")

    _new_interface_socket(tree, "Depth Occlusion", "NodeSocketBool", parent=p_hid,
                          default_value=False,
                          description="Let the renderer's depth buffer hide the lines "
                                      "instead of raycasting them. Much faster - the "
                                      "occluder geometry is not traced at all. REQUIRES "
                                      "your objects to be present and drawn in the view "
                                      "layer: if they are excluded or hidden there is no "
                                      "depth to test against and EVERY line shows, so this "
                                      "cannot be used for a lines-only render. Holdout is "
                                      "not a workaround - it removes the lines too. Hidden "
                                      "Lines cannot be drawn in this mode, only hidden")
    _new_interface_socket(tree, "Depth Bias (mm)", "NodeSocketFloat", parent=p_hid,
                          default_value=1.0, min_value=0.0, max_value=100.0,
                          description="With Depth Occlusion on, pull strokes this far "
                                      "toward the camera so they sit in front of the "
                                      "surface they lie on instead of z-fighting it. "
                                      "Raise it if lines break up in patches")

    _new_interface_socket(tree, "Viewport Detail (px)", "NodeSocketFloat", parent=p_edge,
                          default_value=0.0, min_value=0.0, max_value=64.0,
                          description="Extra Detail Limit applied in the VIEWPORT ONLY, "
                                      "never to renders. This is what Fast Viewport drives, "
                                      "so leaving it switched on can never coarsen your "
                                      "output. 0 = off")

    _new_interface_socket(tree, "Fill Opacity", "NodeSocketFloat", parent=p_edge,
                          default_value=1.0, min_value=0.0, max_value=1.0, subtype='FACTOR',
                          description="Opacity of the Colour Fill matte. Keyframe it 0 to 1 "
                                      "over a frame or two once a Draw On build finishes, so "
                                      "the shape starts occluding the background only after "
                                      "it has been drawn. The lines themselves are not "
                                      "affected")

    _new_interface_socket(tree, "Fill Follows Draw", "NodeSocketBool", parent=p_edge,
                          default_value=True,
                          description="Bring the Colour Fill matte in automatically as the "
                                      "Draw On build finishes, instead of keyframing Fill "
                                      "Opacity by hand. Off = Fill Opacity is manual")
    _new_interface_socket(tree, "Matte Fade", "NodeSocketFloat", parent=p_edge,
                          default_value=0.25, min_value=0.001, max_value=1.0, subtype='FACTOR',
                          description="Fraction of the draw over which the matte fades in. "
                                      "0.25 = the last quarter of Draw Amount. Too short "
                                      "and the dissolve lands on a single frame, which the "
                                      "DITHERED fill shows as a flash. Make Build-On sizes "
                                      "this from the keyed draw length")

    _new_interface_socket(tree, "Transparent Matte", "NodeSocketBool", parent=p_edge,
                          default_value=False,
                          description="Render the Colour Fill as a HOLDOUT instead of flat "
                                      "colour: it still hides whatever is behind it, but "
                                      "punches alpha to zero so it comps as an empty matte "
                                      "rather than a white shape. Needs Film > Transparent")

    _new_interface_socket(tree, "Draw Spread", "NodeSocketFloat", parent=p_draw,
                          default_value=0.0, min_value=0.0, max_value=20.0,
                          description="Size in metres of the spatial pattern that decides "
                                      "draw order. 0 = the classic per-stroke random, which "
                                      "STROBES if Include Silhouettes is on and the camera "
                                      "moves. Above 0, nearby strokes draw together and the "
                                      "order is stable under camera motion. Try 1-3 m")

    _new_interface_socket(tree, "Matte Lead", "NodeSocketFloat", parent=p_edge,
                          default_value=0.0, min_value=0.0, max_value=0.9, subtype='FACTOR',
                          description="Finish the matte this far BEFORE the drawing does, as "
                                      "a fraction of the draw. 0 = the matte completes exactly "
                                      "as the last stroke lands. 0.2 = fully occluding while "
                                      "the final fifth is still being drawn")

    b = _Builder(tree)
    gi = b.node("NodeGroupInput", -1600, 0)
    go = b.node("NodeGroupOutput", 2400, 0)

    def gin(name):
        return gi.outputs[name]

    # --- source geometry -------------------------------------------------
    # Host object sits locked at the world origin, so RELATIVE space == world
    # space for every position in this tree (wobble, raycast, camera).
    ci = b.node("GeometryNodeCollectionInfo", -1350, 300, transform_space='RELATIVE')
    b.link(gin("Line Collection"), ci.inputs["Collection"])
    ri = b.node("GeometryNodeRealizeInstances", -1150, 300)
    b.link(ci.outputs[0], ri.inputs[0])
    # ⚠ Simplify goes here, before EVERYTHING: edge finding, the raycast target and
    # the curve build all scale with source element count, and an empty Line
    # Collection costs 8 ms against 1080 ms for the real one - the graph is free,
    # the source is the whole cost. Merge distance is a single value; a FIELD linked
    # into it is silently ignored by Blender and costs ~280 ms more than nothing.
    simp = b.node("GeometryNodeMergeByDistance", -1050, 300)
    b.link(ri.outputs[0], simp.inputs["Geometry"])
    b.link(b.math('DIVIDE', -1150, 180, a=gin("Simplify (mm)"), bv=1000.0),
           simp.inputs["Distance"])
    realized = simp.outputs["Geometry"]

    # Occlusion raycast target: this set's own geometry PLUS an optional shared
    # "Occlude Against" collection, so separate line sets (e.g. one per object
    # for independent draw-on timing) hide each other. Empty collection info
    # yields nothing, so the join is just `realized` by default.
    occ_ci = b.node("GeometryNodeCollectionInfo", -1350, 500, transform_space='RELATIVE')
    b.link(gin("Occlude Against"), occ_ci.inputs["Collection"])
    occ_ri = b.node("GeometryNodeRealizeInstances", -1150, 500)
    b.link(occ_ci.outputs[0], occ_ri.inputs[0])
    occ_target = b.node("GeometryNodeJoinGeometry", -1000, 400)
    b.link(realized, occ_target.inputs[0])
    b.link(occ_ri.outputs[0], occ_target.inputs[0])
    # ⚠ Gate the occlude TARGET, not the raycast result. Feeding the raycasts an empty
    # geometry is what actually skips the work (no BVH over the occluder collection);
    # merely ignoring "Is Hit" downstream would still pay for every trace. Both the
    # hidden-line ray and the silhouette occlusion ray read `occluders`, so one Switch
    # short-circuits both, and Is Hit falls out as 0 = everything visible, which is
    # exactly right when the depth buffer is doing the hiding.
    occ_sw = b.node("GeometryNodeSwitch", -900, 400, input_type='GEOMETRY')
    b.link(gin("Depth Occlusion"), occ_sw.inputs["Switch"])
    b.link(occ_target.outputs[0], _in(occ_sw, "False"))   # True: left empty on purpose
    occluders = occ_sw.outputs[0]

    # --- edge selection ---------------------------------------------------
    ea = b.node("GeometryNodeInputMeshEdgeAngle", -1350, -100)
    cmp_angle = b.node("FunctionNodeCompare", -1150, -100,
                       data_type='FLOAT', operation='GREATER_THAN')
    b.link(_out(ea, "Unsigned Angle"), _in(cmp_angle, "A"))
    b.link(gin("Angle Threshold"), _in(cmp_angle, "B"))

    smooth = b.node("GeometryNodeInputEdgeSmooth", -1350, -250)
    not_smooth = b.bool_op('NOT', -1150, -250, smooth.outputs[0])
    sharp_sel = b.bool_op('AND', -1000, -250, not_smooth, gin("Include Sharp Edges"))

    nb = b.node("GeometryNodeInputMeshEdgeNeighbors", -1350, -400)
    cmp_bound = b.node("FunctionNodeCompare", -1150, -400,
                       data_type='FLOAT', operation='LESS_THAN')
    b.link(_out(nb, "Face Count"), _in(cmp_bound, "A"))
    _in(cmp_bound, "B").default_value = 1.5
    bound_sel = b.bool_op('AND', -1000, -400, cmp_bound.outputs[0], gin("Include Boundaries"))

    fs = b.node("GeometryNodeInputNamedAttribute", -1350, -550, data_type='BOOLEAN')
    fs.inputs["Name"].default_value = "freestyle_edge"
    fs_sel = b.bool_op('AND', -1150, -550, _out(fs, "Attribute"), gin("Use Freestyle Marks"))

    inc = b.node("GeometryNodeInputNamedAttribute", -1350, -700, data_type='BOOLEAN')
    inc.inputs["Name"].default_value = ATTR_INCLUDE
    exc = b.node("GeometryNodeInputNamedAttribute", -1350, -850, data_type='BOOLEAN')
    exc.inputs["Name"].default_value = ATTR_EXCLUDE

    # Silhouette: an edge whose two faces disagree about facing the camera. Stored on
    # FACE then read back on EDGE, where averaging two faces gives exactly 0.5 on the
    # boundary and 0 or 1 everywhere else.
    # ⚠ This does NOT replace the crease tests. An edge whose two faces BOTH face the
    # camera is not a silhouette, so wall-to-ceiling junctions and face-on box edges
    # only come from the angle test. They are complementary, hence the OR.
    sil_cam = b.node("GeometryNodeInputActiveCamera", -1600, -1000)
    sil_oi = b.node("GeometryNodeObjectInfo", -1450, -1000)
    b.link(sil_cam.outputs[0], sil_oi.inputs["Object"])
    sil_pos = b.node("GeometryNodeInputPosition", -1600, -1120)
    sil_nrm = b.node("GeometryNodeInputNormal", -1600, -880)
    sil_view = b.node("ShaderNodeVectorMath", -1300, -1080, operation='SUBTRACT')
    b.link(sil_pos.outputs[0], sil_view.inputs[0])
    b.link(sil_oi.outputs["Location"], sil_view.inputs[1])
    sil_dot = b.node("ShaderNodeVectorMath", -1150, -1000, operation='DOT_PRODUCT')
    b.link(sil_nrm.outputs[0], sil_dot.inputs[0])
    b.link(sil_view.outputs[0], sil_dot.inputs[1])
    sil_front = b.node("ShaderNodeMath", -1000, -1000, operation='LESS_THAN')
    sil_front.inputs[1].default_value = 0.0
    b.link(sil_dot.outputs["Value"], sil_front.inputs[0])
    sil_store = b.node("GeometryNodeStoreNamedAttribute", -950, 300,
                       domain='FACE', data_type='FLOAT')
    sil_store.inputs["Name"].default_value = ATTR_SIL_FRONT
    b.link(realized, sil_store.inputs["Geometry"])
    b.link(sil_front.outputs[0], sil_store.inputs["Value"])
    realized = sil_store.outputs["Geometry"]

    sil_read = b.node("GeometryNodeInputNamedAttribute", -1600, -1250, data_type='FLOAT')
    sil_read.inputs["Name"].default_value = ATTR_SIL_FRONT
    sil_edge = b.node("GeometryNodeFieldOnDomain", -1450, -1250,
                      domain='EDGE', data_type='FLOAT')
    b.link(sil_read.outputs[0], sil_edge.inputs[0])
    sil_lo = b.node("ShaderNodeMath", -1300, -1200, operation='GREATER_THAN')
    sil_lo.inputs[1].default_value = 0.25
    sil_hi = b.node("ShaderNodeMath", -1300, -1330, operation='LESS_THAN')
    sil_hi.inputs[1].default_value = 0.75
    b.link(sil_edge.outputs[0], sil_lo.inputs[0])
    b.link(sil_edge.outputs[0], sil_hi.inputs[0])
    sil_band = b.node("ShaderNodeMath", -1150, -1250, operation='MULTIPLY')
    b.link(sil_lo.outputs[0], sil_band.inputs[0])
    b.link(sil_hi.outputs[0], sil_band.inputs[1])
    sil_is = b.node("FunctionNodeCompare", -1000, -1250,
                    data_type='FLOAT', operation='GREATER_THAN')
    b.link(sil_band.outputs[0], _in(sil_is, "A"))
    _in(sil_is, "B").default_value = 0.5
    sil_sel = b.bool_op('AND', -850, -1250, sil_is.outputs[0], gin("Include Silhouettes"))

    sel = b.bool_op('OR', -850, -150, cmp_angle.outputs[0], sharp_sel)
    sel = b.bool_op('OR', -750, -250, sel, bound_sel)
    sel = b.bool_op('OR', -650, -350, sel, fs_sel)
    sel = b.bool_op('OR', -550, -450, sel, _out(inc, "Attribute"))
    sel = b.bool_op('OR', -500, -1250, sel, sil_sel)
    not_exc = b.bool_op('NOT', -550, -650, _out(exc, "Attribute"))
    sel = b.bool_op('AND', -450, -500, sel, not_exc)

    m2c = b.node("GeometryNodeMeshToCurve", -300, 300)
    b.link(realized, m2c.inputs["Mesh"])
    b.link(sel, m2c.inputs["Selection"])
    # occlusion anchor = on-edge position (no overshoot here, so anchor is
    # just the point itself); interpolates cleanly through resample
    p_apos = b.node("GeometryNodeInputPosition", -300, 160)
    p_anchor = b.node("GeometryNodeStoreNamedAttribute", -150, 300,
                      data_type='FLOAT_VECTOR', domain='POINT')
    p_anchor.inputs["Name"].default_value = ATTR_ANCHOR
    b.link(m2c.outputs[0], p_anchor.inputs["Geometry"])
    b.link(p_apos.outputs[0], _in(p_anchor, "Value"))

    # --- overshoot: extend every drawn edge past its corners, like a sketch
    # where the pen runs past the join. This needs one 2-point spline PER
    # edge — otherwise a closed loop or merged polyline gets its interior
    # points dragged along their tangent and the whole shape distorts (Split
    # Edges is not enough: a face's edges still share corner vertices).
    # Duplicate Elements on the edge domain gives each drawn edge its own
    # unshared vertices, so every edge is an independent straight segment.
    # Only on this branch; a Switch keeps the plain polylines when off.
    dup_e = b.node("GeometryNodeDuplicateElements", -160, 60, domain='EDGE')
    b.link(realized, dup_e.inputs["Geometry"])
    b.link(sel, _in(dup_e, "Selection"))
    _in(dup_e, "Amount").default_value = 1
    m2c_o = b.node("GeometryNodeMeshToCurve", 40, 60)
    b.link(dup_e.outputs[0], m2c_o.inputs["Mesh"])

    # push each endpoint along the edge: -tangent at the start (factor 0),
    # +tangent at the end (factor 1). Positive length runs past the corner
    # (overshoot), negative falls short (undershoot).
    otan = b.node("GeometryNodeInputTangent", 40, -120)
    osp = b.node("GeometryNodeSplineParameter", 40, -260)
    osign = b.node("ShaderNodeMath", 200, -260, operation='MULTIPLY_ADD')
    b.link(_out(osp, "Factor"), osign.inputs[0])
    osign.inputs[1].default_value = 2.0
    osign.inputs[2].default_value = -1.0

    over_m = b.math('MULTIPLY', 160, -120, a=gin("Overshoot"), bv=0.001)
    rand_m = b.math('MULTIPLY', 160, -420, a=gin("Overshoot Random"), bv=0.001)
    # per-endpoint random in [-1,1], keyed to point index + Seed so it is
    # stable and world-locked (no jitter); some ends run long, some short
    oidx = b.node("GeometryNodeInputIndex", 160, -560)
    ornd = b.node("FunctionNodeRandomValue", 320, -520, data_type='FLOAT')
    _in(ornd, "Min").default_value = -1.0
    _in(ornd, "Max").default_value = 1.0
    b.link(_out(oidx, "Index"), _in(ornd, "ID"))
    b.link(gin("Seed"), _in(ornd, "Seed"))
    rand_off = b.math('MULTIPLY', 470, -480, a=rand_m, b=_out(ornd, "Value"))
    signed = b.math('ADD', 300, -120, a=over_m, b=rand_off)

    # cap the magnitude to a fraction of the edge's own length (both ways), so
    # short edges (knob facets) don't tangle and the two ends can't cross
    slen = b.node("GeometryNodeSplineLength", 160, -320)
    slen_cap = b.math('MULTIPLY', 300, -320, a=_out(slen, "Length"), bv=0.35)
    neg_cap = b.math('MULTIPLY', 440, -360, a=slen_cap, bv=-1.0)
    oclamp = b.node("ShaderNodeClamp", 470, -120)
    b.link(signed, oclamp.inputs["Value"])
    b.link(neg_cap, oclamp.inputs["Min"])
    b.link(slen_cap, oclamp.inputs["Max"])
    over_signed = b.math('MULTIPLY', 620, -190, a=oclamp.outputs[0], b=osign.outputs[0])
    ooff = b.vmath('SCALE', 620, -120, otan.outputs[0], scale=over_signed)
    # store the corner position BEFORE extending, so an overshoot tick is
    # occlusion-tested at its corner (inherits the edge's visibility) rather
    # than at its own tip out past the silhouette
    o_apos = b.node("GeometryNodeInputPosition", 320, 0)
    o_anchor = b.node("GeometryNodeStoreNamedAttribute", 470, 60,
                      data_type='FLOAT_VECTOR', domain='POINT')
    o_anchor.inputs["Name"].default_value = ATTR_ANCHOR
    b.link(m2c_o.outputs[0], o_anchor.inputs["Geometry"])
    b.link(o_apos.outputs[0], _in(o_anchor, "Value"))
    oext = b.node("GeometryNodeSetPosition", 620, 60)
    b.link(o_anchor.outputs[0], oext.inputs["Geometry"])
    b.link(ooff, _in(oext, "Offset"))

    # active when the base overshoot (either sign) or the random is non-zero
    over_abs = b.math('ABSOLUTE', 360, 300, a=gin("Overshoot"))
    o_act = b.math('MAXIMUM', 500, 300, a=over_abs, b=gin("Overshoot Random"))
    o_cmp = b.node("FunctionNodeCompare", 640, 300,
                   data_type='FLOAT', operation='GREATER_THAN')
    b.link(o_act, _in(o_cmp, "A"))
    _in(o_cmp, "B").default_value = 0.0001
    # take the extended branch only when Enable is on AND some amount is set; a
    # geometry Switch lazily evaluates only the chosen branch, so with overshoot
    # off the per-edge Duplicate Elements split never runs (the perf win).
    o_on = b.node("FunctionNodeBooleanMath", 720, 360, operation='AND')
    b.link(gin("Overshoot Enable"), o_on.inputs[0])
    b.link(o_cmp.outputs[0], o_on.inputs[1])
    o_sw = b.node("GeometryNodeSwitch", 780, 200, input_type='GEOMETRY')
    b.link(o_on.outputs[0], o_sw.inputs["Switch"])
    b.link(p_anchor.outputs[0], _in(o_sw, "False"))
    b.link(oext.outputs[0], _in(o_sw, "True"))

    res = b.node("GeometryNodeResampleCurve", 680, 200)
    if hasattr(res, "mode"):
        res.mode = 'LENGTH'
    else:
        # 5.x: mode is a menu socket
        res.inputs["Mode"].default_value = 'Length'
    b.link(o_sw.outputs[0], res.inputs[0])

    # A polyline can't show noise features smaller than its point spacing, so
    # sample ~4 points per smallest feature (base scale x 2^detail octaves).
    # Segment Length is only the coarsest bound; 2 mm floor bounds the cost.
    # Sizes are user-facing centimeters; noise nodes want frequency (per meter)
    wob_freq = b.math('DIVIDE', -500, 350, av=100.0, b=gin("Wobble Size"))
    th_freq = b.math('DIVIDE', -500, 550, av=100.0, b=gin("Thickness Size"))
    op_freq = b.math('DIVIDE', -500, 650, av=100.0, b=gin("Opacity Size"))
    oct_pow = b.math('POWER', -350, 450, av=2.0, b=gin("Wobble Complexity"))
    # ⚠⚠ GATE EACH FREQUENCY ON ITS SECTION'S ENABLE. Measured 2026-07-29: with Wobble,
    # Overshoot, Breakup, Dashes and Smudge ALL off the vertex count did not move — 15.4 M
    # on a house — because this formula reads only the SIZES and never the Enable flags, so
    # every curve was resampled at 7.5 mm for effects that were switched off. A Boolean
    # socket converts to 1.0/0.0 when linked to a float, so a MULTIPLY is the whole gate.
    wob_on = b.math('MULTIPLY', -420, 350, a=wob_freq, b=gin("Wobble Enable"))
    th_on = b.math('MULTIPLY', -420, 550, a=th_freq, b=gin("Breakup Enable"))
    op_on = b.math('MULTIPLY', -420, 650, a=op_freq, b=gin("Breakup Enable"))
    freq_max = b.math('MULTIPLY', -350, 550, a=wob_on, b=oct_pow)
    freq_max = b.math('MAXIMUM', -275, 600, a=freq_max, b=th_on)
    freq_max = b.math('MAXIMUM', -275, 700, a=freq_max, b=op_on)
    # ⚠ FLOOR IT AT 5.0. With everything gated off freq_max would be 0, and GN's DIVIDE by
    # zero returns 0 — which would drive seg_len to the 2 mm FLOOR, the exact opposite of
    # what is wanted. 0.25 / 5.0 = 0.05 m, i.e. the same 5 cm coarse bound applied below.
    freq_max = b.math('MAXIMUM', -240, 750, a=freq_max, bv=5.0)
    auto_len = b.math('DIVIDE', -200, 500, av=0.25, b=freq_max)
    seg_len = b.math('MINIMUM', -200, 400, a=auto_len, bv=0.05)
    # ⚠ SCREEN-SPACE FLOOR. The 2 mm floor is a WORLD measure, so on an exterior it
    # produced 6.3x more points than the render could resolve (one pixel at 12 m with an
    # 18 mm lens on a 1920 render is 12.6 mm). Sub-pixel noise is invisible anyway, so
    # taking the COARSER of the two costs nothing visually and is self-tuning.
    # ⚠ Resample's Length is NOT a field -- verified: a varying input gives uniform
    # spacing -- so this is one representative distance (camera to the strokes' bounding
    # box centre), not per point.
    bb = b.node("GeometryNodeBoundBox", -300, 120)
    b.link(o_sw.outputs[0], bb.inputs["Geometry"])
    bb_sum = b.vmath('ADD', -180, 120, a=bb.outputs["Min"], b=bb.outputs["Max"])
    bb_mid = b.vmath('SCALE', -100, 120, a=bb_sum, scale=0.5)
    px_cam = b.node("GeometryNodeInputActiveCamera", -420, 60)
    px_oi = b.node("GeometryNodeObjectInfo", -340, 60)
    b.link(px_cam.outputs[0], px_oi.inputs["Object"])
    # ⚠ Built directly, not via b.vmath(): that helper returns outputs[0], which on a
    # Vector Math node is "Vector". DISTANCE puts its scalar in "Value" and leaves
    # "Vector" at zero, so the helper silently handed back 0 and killed the whole term.
    dnode = b.node("ShaderNodeVectorMath", -20, 120, operation='DISTANCE')
    b.link(bb_mid, dnode.inputs[0])
    b.link(px_oi.outputs["Location"], dnode.inputs[1])
    subj_d = dnode.outputs["Value"]
    px_ci = b.node("GeometryNodeCameraInfo", -420, -40)
    # ⚠ Camera Info has a REQUIRED Camera input. Left unlinked it does not fall back to
    # the active camera -- every output reads 0, so Focal Length 0 made the DIVIDE below
    # return 0 and the whole pixel term silently vanished. Measured: no change at any
    # Detail Limit until this link existed.
    b.link(px_cam.outputs[0], px_ci.inputs["Camera"])
    sensor_x = b.node("ShaderNodeSeparateXYZ", -340, -40)
    b.link(px_ci.outputs["Sensor"], sensor_x.inputs[0])
    focal = b.math('MAXIMUM', -280, -110, a=px_ci.outputs["Focal Length"], bv=1.0)
    fov = b.math('DIVIDE', -240, -40, a=sensor_x.outputs[0], b=focal)
    world_per_px = b.math('DIVIDE', -140, -40, a=fov, b=gin("Render Width (px)"))
    px_size = b.math('MULTIPLY', -60, -40, a=subj_d, b=world_per_px)
    # ⚠ Detail Limit applies to RENDERS as well as the viewport - that is the point of it,
    # it is camera-derived. Fast Viewport must NOT work that way: it is a temporary
    # navigation toggle, and leaving it on must never quietly coarsen the delivered frame.
    # So the fast value lives in its own viewport-only socket and is MAXed in, which also
    # means pressing Fast can never make a high Detail Limit finer.
    vpd_is = b.node("GeometryNodeIsViewport", -160, -140)
    vpd_max = b.math('MAXIMUM', -100, -180, a=gin("Detail Limit (px)"),
                     b=gin("Viewport Detail (px)"))
    vpd_sw = b.node("GeometryNodeSwitch", -30, -140, input_type='FLOAT')
    b.link(vpd_is.outputs[0], vpd_sw.inputs["Switch"])
    b.link(gin("Detail Limit (px)"), _in(vpd_sw, "False"))   # renders: never the fast value
    b.link(vpd_max, _in(vpd_sw, "True"))
    px_floor = b.math('MULTIPLY', 20, -40, a=px_size, b=vpd_sw.outputs[0])
    # ⚠ The formula is perspective-only. An ortho camera has no distance falloff, so feed
    # 0 and let the 2 mm floor take over rather than inventing a wrong spacing.
    px_ortho = b.node("GeometryNodeSwitch", 55, -40, input_type='FLOAT')
    b.link(px_ci.outputs["Is Orthographic"], px_ortho.inputs["Switch"])
    b.link(px_floor, _in(px_ortho, "False"))
    _in(px_ortho, "True").default_value = 0.0
    px_floor = px_ortho.outputs[0]
    floor = b.math('MAXIMUM', 90, -40, a=px_floor, bv=0.002)
    seg_len = b.math('MAXIMUM', -50, 450, a=seg_len, b=floor)
    # ⚠ AFTER the clamps, so the viewport is free to go coarser than the 5 cm ceiling.
    # `Is Viewport` is the only thing here that distinguishes working from rendering, and
    # vertex count is the ONLY lever that moved the needle: occlusion was measured twice and
    # is irrelevant (990 ms with it, 1004 ms without, at the same 15.4 M verts).
    vp_is = b.node("GeometryNodeIsViewport", -170, 300)
    vp_amt = b.math('MAXIMUM', -120, 300, a=gin("Viewport Coarsen"), bv=1.0)
    vp_sw = b.node("GeometryNodeSwitch", -60, 300, input_type='FLOAT')
    b.link(vp_is.outputs[0], vp_sw.inputs["Switch"])
    _in(vp_sw, "False").default_value = 1.0        # renders: never coarsened
    b.link(vp_amt, _in(vp_sw, "True"))
    seg_len = b.math('MULTIPLY', 10, 450, a=seg_len, b=vp_sw.outputs[0])
    b.link(seg_len, _in(res, "Length"))

    # Original point positions, kept as an attribute so the wobble noise can
    # stay keyed to world-locked coordinates even for points the ghost-line
    # step slides toward the camera.
    store_opos = b.node("GeometryNodeStoreNamedAttribute", 100, 200,
                        data_type='FLOAT_VECTOR', domain='POINT')
    store_opos.inputs["Name"].default_value = ATTR_OPOS
    b.link(res.outputs[0], store_opos.inputs["Geometry"])
    pos = b.node("GeometryNodeInputPosition", -100, 50)
    b.link(pos.outputs[0], _in(store_opos, "Value"))

    # --- occlusion --------------------------------------------------------
    # Ray from the active camera toward each clean (un-wobbled) point. A hit
    # short of the point means it's occluded. Occluded points then slide
    # along their own view ray to just in front of the first occluder: the
    # screen position is invariant along a view ray, so ghost lines land on
    # the same pixels but render on top of the surfaces hiding them.
    cam = b.node("GeometryNodeInputActiveCamera", -100, -300)
    oi = b.node("GeometryNodeObjectInfo", 50, -300, transform_space='ORIGINAL')
    b.link(cam.outputs[0], oi.inputs["Object"])
    cam_loc = _out(oi, "Location")

    # test occlusion at the on-edge anchor, not the raw (possibly overshot)
    # point, so ticks poking past the silhouette inherit their edge's hidden
    # state instead of reading as visible open-space geometry
    anchor = b.node("GeometryNodeInputNamedAttribute", -100, -420,
                    data_type='FLOAT_VECTOR')
    anchor.inputs["Name"].default_value = ATTR_ANCHOR
    delta = b.vmath('SUBTRACT', 100, -500, _out(anchor, "Attribute"), cam_loc)
    dist_n = b.node("ShaderNodeVectorMath", 250, -600, operation='LENGTH')
    b.link(delta, dist_n.inputs[0])
    dist = dist_n.outputs["Value"]
    ray_dir = b.vmath('NORMALIZE', 250, -450, delta)

    # stop the ray just short of the surface the point itself lies on
    bias_m = b.math('MULTIPLY', 250, -700, a=gin("Occlusion Bias"), bv=0.001)
    wob_amt_m = b.math('MULTIPLY', 250, -800, a=gin("Wobble Amount"), bv=0.001)
    ray_len = b.math('SUBTRACT', 400, -650, a=dist, b=bias_m)
    ray_len = b.math('MAXIMUM', 550, -650, a=ray_len, bv=0.0)

    ray = b.node("GeometryNodeRaycast", 850, -400)
    b.link(occluders, ray.inputs["Target Geometry"])
    b.link(cam_loc, _in(ray, "Source Position"))
    b.link(ray_dir, _in(ray, "Ray Direction"))
    b.link(ray_len, _in(ray, "Ray Length"))
    is_hit = _out(ray, "Is Hit")

    # vis = 1 - is_hit * (1 - hidden_opacity); hidden lines only exist at all
    # when Show Hidden Lines is on
    eff_hidden = b.math('MULTIPLY', 850, -550, a=gin("Hidden Line Opacity"),
                        b=gin("Show Hidden Lines"))
    inv_hidden = b.math('SUBTRACT', 1000, -550, av=1.0, b=eff_hidden)
    hit_amount = b.math('MULTIPLY', 1150, -500, a=is_hit, b=inv_hidden)
    vis = b.math('SUBTRACT', 1300, -450, av=1.0, b=hit_amount)

    store_occ = b.node("GeometryNodeStoreNamedAttribute", 300, 200,
                       data_type='FLOAT', domain='POINT')
    store_occ.inputs["Name"].default_value = ATTR_VIS
    b.link(store_opos.outputs[0], store_occ.inputs["Geometry"])
    b.link(vis, _in(store_occ, "Value"))

    store_occf = b.node("GeometryNodeStoreNamedAttribute", 400, 200,
                        data_type='FLOAT', domain='POINT')
    store_occf.inputs["Name"].default_value = ATTR_OCC
    b.link(store_occ.outputs[0], store_occf.inputs["Geometry"])
    b.link(is_hit, _in(store_occf, "Value"))

    # ghost position: in front of the occluder by enough that the wobble
    # can't push the stroke back inside it
    ghost_eps = b.math('ADD', 1000, -750, a=bias_m, b=wob_amt_m)
    ghost_dist = b.math('SUBTRACT', 1150, -750, a=_out(ray, "Hit Distance"), b=ghost_eps)
    ghost_off = b.vmath('SCALE', 1300, -700, ray_dir, scale=ghost_dist)
    ghost_pos = b.vmath('ADD', 1450, -650, cam_loc, ghost_off)

    # Only slide occluded points to their ghost positions when hidden lines
    # are actually being shown. When they're hidden, those points collapse to
    # zero radius, and sliding them across space would leave a tapering
    # sliver stretching from each visible point to a ghost point parked in
    # front of the occluder — the streaks. Leaving them put makes the stroke
    # simply taper to nothing at the real occluded location.
    ghost_sel = b.bool_op('AND', 350, 100, is_hit, gin("Show Hidden Lines"))
    ghost_move = b.node("GeometryNodeSetPosition", 500, 100)
    b.link(store_occf.outputs[0], ghost_move.inputs["Geometry"])
    b.link(ghost_sel, _in(ghost_move, "Selection"))
    b.link(ghost_pos, _in(ghost_move, "Position"))

    # Depth bias: strokes lie exactly ON the surface, so the depth test would z-fight
    # them into speckle. Sliding along the view ray moves them in front without moving
    # them on screen (the same invariance the ghost offset above relies on). The gate is
    # a MULTIPLY by the Bool, so this is a no-op in raycast mode.
    dbias = b.math('MULTIPLY', 500, -900, a=gin("Depth Bias (mm)"), bv=-0.001)
    dbias = b.math('MULTIPLY', 620, -900, a=dbias, b=gin("Depth Occlusion"))
    dpos = b.node("GeometryNodeSetPosition", 620, 100)
    b.link(ghost_move.outputs[0], dpos.inputs["Geometry"])
    b.link(b.vmath('SCALE', 500, -1000, ray_dir, scale=dbias), _in(dpos, "Offset"))

    # --- overlapping passes ------------------------------------------------
    dup = b.node("GeometryNodeDuplicateElements", 750, 300, domain='SPLINE')
    b.link(dpos.outputs[0], dup.inputs["Geometry"])
    b.link(gin("Strokes"), _in(dup, "Amount"))

    # --- wobble displacement (world-locked: keyed to geometry position, so
    # camera motion can never make it swim) ---------------------------------
    stime = b.node("GeometryNodeInputSceneTime", 750, 700)
    boil = b.math('MULTIPLY', 900, 700, a=_out(stime, "Seconds"), b=gin("Boil Rate"))
    boil = b.math('FLOOR', 1050, 700, a=boil)
    boil_w = b.math('MULTIPLY', 1200, 700, a=boil, bv=11.717)
    pass_w = b.math('MULTIPLY', 1050, 550, a=_out(dup, "Duplicate Index"), bv=97.13)
    w = b.math('ADD', 1200, 550, a=gin("Seed"), b=pass_w)
    w = b.math('ADD', 1350, 600, a=w, b=boil_w)

    noise = b.node("ShaderNodeTexNoise", 1500, 500, noise_dimensions='4D')
    opos = b.node("GeometryNodeInputNamedAttribute", 1300, 450, data_type='FLOAT_VECTOR')
    opos.inputs["Name"].default_value = ATTR_OPOS
    b.link(_out(opos, "Attribute"), noise.inputs["Vector"])
    b.link(w, noise.inputs["W"])
    b.link(wob_freq, noise.inputs["Scale"])
    b.link(gin("Wobble Complexity"), noise.inputs["Detail"])

    centered = b.vmath('SUBTRACT', 1700, 500, noise.outputs["Color"], (0.5, 0.5, 0.5))

    sp = b.node("GeometryNodeSplineParameter", 1350, 250)
    inv_f = b.math('SUBTRACT', 1500, 250, av=1.0, b=_out(sp, "Factor"))
    tmin = b.math('MINIMUM', 1650, 250, a=_out(sp, "Factor"), b=inv_f)
    tmin = b.math('MINIMUM', 1800, 250, a=tmin, bv=0.15)
    taper = b.math('DIVIDE', 1950, 250, a=tmin, bv=0.15)

    amp2 = b.math('MULTIPLY', 1700, 350, a=wob_amt_m, bv=2.0)
    amp = b.math('MULTIPLY', 1850, 350, a=amp2, b=taper)
    offset = b.vmath('SCALE', 1900, 500, centered, scale=amp)

    setpos = b.node("GeometryNodeSetPosition", 1150, 300)
    b.link(dup.outputs[0], setpos.inputs["Geometry"])
    b.link(offset, _in(setpos, "Offset"))

    # Pull strokes toward the camera by 2x radius so tubes lying on a face
    # aren't half-buried in it. Along the view ray the screen position is
    # unchanged, so this cannot introduce jitter.
    pull_dir = b.vmath('SUBTRACT', 1300, 850, cam_loc, pos.outputs[0])
    pull_dir = b.vmath('NORMALIZE', 1450, 850, pull_dir)
    pull_amt = b.math('MULTIPLY', 1450, 950, a=gin("Line Width"), bv=0.001)
    pull = b.vmath('SCALE', 1600, 850, pull_dir, scale=pull_amt)
    # Wobble master switch: when off, feed the un-displaced curve straight
    # through so the wobble noise is never evaluated (Switch is lazy — it only
    # computes the branch it selects), saving that work on plain straight lines.
    wob_sw = b.node("GeometryNodeSwitch", 1400, 300, input_type='GEOMETRY')
    b.link(gin("Wobble Enable"), _in(wob_sw, "Switch"))
    b.link(dup.outputs[0], _in(wob_sw, "False"))
    b.link(setpos.outputs[0], _in(wob_sw, "True"))

    setpos2 = b.node("GeometryNodeSetPosition", 1600, 300)
    b.link(_out(wob_sw, "Output"), setpos2.inputs["Geometry"])
    b.link(pull, _in(setpos2, "Offset"))

    # --- opacity noise (Roughen-style breakup along the stroke) ------------
    # Separate world-locked noise multiplied into sk_vis; differs per pass
    # and boils with Boil Rate via the shared W.
    onoise = b.node("ShaderNodeTexNoise", 1500, 900, noise_dimensions='4D')
    b.link(_out(opos, "Attribute"), onoise.inputs["Vector"])
    w_op = b.math('ADD', 1350, 900, a=w, bv=53.7)
    b.link(w_op, onoise.inputs["W"])
    b.link(op_freq, onoise.inputs["Scale"])
    onoise.inputs["Detail"].default_value = 5.0
    onoise.inputs["Roughness"].default_value = 0.55
    # Noise Fac clusters around 0.5; boost contrast x3 (clamped) so breakup
    # actually reaches "fully there" and "fully gone" instead of mild dimming
    ocon = b.math('SUBTRACT', 1650, 800, a=_out(onoise, "Fac"), bv=0.5)
    ocon = b.math('MULTIPLY', 1800, 800, a=ocon, bv=3.0)
    ocon_n = b.node("ShaderNodeMath", 1950, 800, operation='ADD', use_clamp=True)
    b.link(ocon, ocon_n.inputs[0])
    ocon_n.inputs[1].default_value = 0.5
    op_amt = b.math('MULTIPLY', 1600, 960, a=gin("Opacity Breakup"), b=gin("Breakup Enable"))
    eaten = b.math('MULTIPLY', 1700, 900, a=op_amt, b=ocon_n.outputs[0])
    op_mul = b.math('SUBTRACT', 1850, 900, av=1.0, b=eaten)
    vis_prev = b.node("GeometryNodeInputNamedAttribute", 1700, 1050, data_type='FLOAT')
    vis_prev.inputs["Name"].default_value = ATTR_VIS
    vis_new = b.math('MULTIPLY', 2000, 950, a=_out(vis_prev, "Attribute"), b=op_mul)

    store_vis2 = b.node("GeometryNodeStoreNamedAttribute", 1800, 300,
                        data_type='FLOAT', domain='POINT')
    store_vis2.inputs["Name"].default_value = ATTR_VIS
    b.link(setpos2.outputs[0], store_vis2.inputs["Geometry"])
    b.link(vis_new, _in(store_vis2, "Value"))

    # Post-wobble stroke direction, so the material can measure edge distance
    # in the stroke's own cross-section instead of raw view facing (which
    # collapses on foreshortened strokes and chews them inconsistently)
    tan = b.node("GeometryNodeInputTangent", 1850, 450)
    store_tan = b.node("GeometryNodeStoreNamedAttribute", 2000, 300,
                       data_type='FLOAT_VECTOR', domain='POINT')
    store_tan.inputs["Name"].default_value = ATTR_TAN
    b.link(store_vis2.outputs[0], store_tan.inputs["Geometry"])
    b.link(tan.outputs[0], _in(store_tan, "Value"))

    # --- radius (fully hidden points collapse to zero width) ---------------
    visattr = b.node("GeometryNodeInputNamedAttribute", 1150, 100, data_type='FLOAT')
    visattr.inputs["Name"].default_value = ATTR_VIS
    vis_gt = b.node("FunctionNodeCompare", 1350, 100,
                    data_type='FLOAT', operation='GREATER_THAN')
    b.link(_out(visattr, "Attribute"), _in(vis_gt, "A"))
    _in(vis_gt, "B").default_value = 0.0005
    # Line Width is millimeters of stroke diameter; curve radius is meters
    width_m = b.math('MULTIPLY', 1400, 100, a=gin("Line Width"), bv=0.0005)
    radius = b.math('MULTIPLY', 1550, 100, a=width_m, b=vis_gt.outputs[0])

    # --- screen-space width: hold on-screen thickness constant as the camera
    # dollies. A world length L at camera distance d projects to ~L/d on screen,
    # so scaling the radius by d cancels the shrink (focal/sensor drop out). We
    # anchor to a fixed Reference Distance so Line Width is "true" mm there.
    # Orthographic cameras are already distance-independent → no-op.
    ssw_pos = b.node("GeometryNodeInputPosition", 1250, 440)
    ssw_dist = b.node("ShaderNodeVectorMath", 1400, 420, operation='DISTANCE')
    b.link(ssw_pos.outputs[0], ssw_dist.inputs[0])
    b.link(cam_loc, ssw_dist.inputs[1])
    ssw_ref = b.math('MAXIMUM', 1400, 260, a=gin("Reference Distance"), bv=0.001)
    ssw_ratio = b.math('DIVIDE', 1560, 380, a=_out(ssw_dist, "Value"), b=ssw_ref)
    # orthographic cameras project distance-independently, so scaling by distance
    # would be wrong — detect and skip via CameraInfo (Blender 5.2+). On older
    # builds the node doesn't exist; assume perspective (the common case).
    ssw_factor = ssw_ratio
    if hasattr(bpy.types, "GeometryNodeCameraInfo"):
        ssw_ci = b.node("GeometryNodeCameraInfo", 1250, 340)
        b.link(cam.outputs[0], ssw_ci.inputs["Camera"])
        ssw_persp = b.node("GeometryNodeSwitch", 1720, 380, input_type='FLOAT')
        b.link(_out(ssw_ci, "Is Orthographic"), ssw_persp.inputs["Switch"])
        b.link(ssw_ratio, _in(ssw_persp, "False"))
        _in(ssw_persp, "True").default_value = 1.0
        ssw_factor = ssw_persp.outputs[0]
    ssw_on = b.node("GeometryNodeSwitch", 1870, 380, input_type='FLOAT')
    b.link(gin("Screen-Space Width"), ssw_on.inputs["Switch"])
    _in(ssw_on, "False").default_value = 1.0
    b.link(ssw_factor, _in(ssw_on, "True"))
    radius = b.math('MULTIPLY', 2020, 100, a=radius, b=ssw_on.outputs[0])

    # --- line taper: thin the stroke toward its ends via the spline parameter,
    # like lifting a pen. Factor is 0 at a spline's start, 1 at its end, so the
    # distance to the nearest end is min(Factor, 1-Factor) in [0, 0.5].
    # taper_mul = 1 - Taper*(1 - 2*end): Taper 0 = uniform, Taper 1 = a point at
    # each end. Applied to curve points before Curve to Mesh, so it follows the
    # (possibly draw-on-trimmed) stroke ends.
    tap_sp = b.node("GeometryNodeSplineParameter", 1560, 360)
    tap_inv = b.math('SUBTRACT', 1710, 430, av=1.0, b=_out(tap_sp, "Factor"))
    tap_end = b.math('MINIMUM', 1840, 380, a=_out(tap_sp, "Factor"), b=tap_inv)
    tap_2 = b.math('MULTIPLY', 1970, 380, a=tap_end, bv=2.0)
    tap_ramp = b.math('SUBTRACT', 2100, 380, av=1.0, b=tap_2)
    tap_amt = b.math('MULTIPLY', 2230, 380, a=gin("Line Taper"), b=tap_ramp)
    tap_mul = b.math('SUBTRACT', 2360, 380, av=1.0, b=tap_amt)
    tap_mul = b.math('MAXIMUM', 2490, 380, a=tap_mul, bv=0.0)
    radius = b.math('MULTIPLY', 2620, 100, a=radius, b=tap_mul)

    # --- thickness noise (pencil-pressure variation along the stroke) ------
    # Same world-locked breakup grain as the opacity noise but a different W
    # offset, so thin spots and faint spots don't coincide.
    tnoise = b.node("ShaderNodeTexNoise", 1500, 1250, noise_dimensions='4D')
    b.link(_out(opos, "Attribute"), tnoise.inputs["Vector"])
    w_t = b.math('ADD', 1350, 1250, a=w, bv=117.3)
    b.link(w_t, tnoise.inputs["W"])
    b.link(th_freq, tnoise.inputs["Scale"])
    tnoise.inputs["Detail"].default_value = 5.0
    tnoise.inputs["Roughness"].default_value = 0.55
    tcon = b.math('SUBTRACT', 1650, 1150, a=_out(tnoise, "Fac"), bv=0.5)
    tcon = b.math('MULTIPLY', 1800, 1150, a=tcon, bv=3.0)
    tcon_n = b.node("ShaderNodeMath", 1950, 1150, operation='ADD', use_clamp=True)
    b.link(tcon, tcon_n.inputs[0])
    tcon_n.inputs[1].default_value = 0.5
    th_amt = b.math('MULTIPLY', 1600, 1310, a=gin("Thickness Breakup"), b=gin("Breakup Enable"))
    thin = b.math('MULTIPLY', 1700, 1250, a=th_amt, b=tcon_n.outputs[0])
    thick_mul = b.math('SUBTRACT', 1850, 1250, av=1.0, b=thin)
    radius = b.math('MULTIPLY', 2000, 1200, a=radius, b=thick_mul)

    # hidden lines draw thinner by Hidden Width Scale
    occa = b.node("GeometryNodeInputNamedAttribute", 1150, 1450, data_type='FLOAT')
    occa.inputs["Name"].default_value = ATTR_OCC
    occ_f = _out(occa, "Attribute")
    hw = b.math('SUBTRACT', 1300, 1450, av=1.0, b=gin("Hidden Width Scale"))
    hw = b.math('MULTIPLY', 1450, 1450, a=occ_f, b=hw)
    hw = b.math('SUBTRACT', 1600, 1450, av=1.0, b=hw)
    radius = b.math('MULTIPLY', 1750, 1400, a=radius, b=hw)

    # dashes, cut in world arc-length so they stay put on the stroke; hidden
    # lines get their own pattern
    len_cm = b.math('MULTIPLY', 1150, 1600, a=_out(sp, "Length"), bv=100.0)

    def dash_mask(dash_sock, gap_sock, y):
        period = b.math('ADD', 1300, y, a=dash_sock, b=gap_sock)
        m = b.math('MODULO', 1450, y, a=len_cm, b=period)
        on = b.math('LESS_THAN', 1600, y, a=m, b=dash_sock)
        solid = b.math('LESS_THAN', 1450, y - 80, a=dash_sock, bv=0.0001)
        return b.math('MAXIMUM', 1750, y, a=on, b=solid)

    on_vis = dash_mask(gin("Dash Length"), gin("Dash Gap"), 1600)
    # Dashes master switch: force the visible-stroke mask solid when off.
    dash_off = b.math('SUBTRACT', 1850, 1620, av=1.0, b=gin("Dashes Enable"))
    on_vis = b.math('MAXIMUM', 1950, 1600, a=on_vis, b=dash_off)
    on_hid = dash_mask(gin("Hidden Dash Length"), gin("Hidden Dash Gap"), 1800)
    d_diff = b.math('SUBTRACT', 1900, 1700, a=on_hid, b=on_vis)
    d_mix = b.math('MULTIPLY', 2000, 1700, a=occ_f, b=d_diff)
    dash_on = b.math('ADD', 2100, 1700, a=on_vis, b=d_mix)
    radius = b.math('MULTIPLY', 2200, 1400, a=radius, b=dash_on)

    # --- draw-on: progressively reveal each stroke by trimming the curve to
    # [0, progress]. Progress runs from Draw Start to Draw End over the
    # timeline. Stagger spreads the per-line start times (shuffled by Seed) so
    # lines can build on one after another instead of all at once. The End
    # field is evaluated per spline by Trim Curve, so Index below resolves to
    # the spline index (each line gets its own draw time).
    # Draw Amount (0..1) is keyframed by the user in the timeline; the Draw
    # Easing dropdown reshapes it so they can keyframe linearly and still get
    # an accelerate/settle feel.
    prog_c = b.node("ShaderNodeClamp", 1500, 620)
    b.link(gin("Draw Amount"), prog_c.inputs["Value"])
    prog_c.inputs["Min"].default_value = 0.0
    prog_c.inputs["Max"].default_value = 1.0
    t = prog_c.outputs[0]
    e_in = b.math('MULTIPLY', 1680, 700, a=t, b=t)                 # t^2
    omt = b.math('SUBTRACT', 1680, 560, av=1.0, b=t)
    omt2 = b.math('MULTIPLY', 1820, 560, a=omt, b=omt)
    e_out = b.math('SUBTRACT', 1960, 560, av=1.0, b=omt2)          # 1-(1-t)^2
    t2 = b.math('MULTIPLY', 1680, 420, a=t, b=t)                   # smoothstep
    t3 = b.math('MULTIPLY', 1820, 420, a=t2, b=t)
    io3 = b.math('MULTIPLY', 1960, 460, a=t2, bv=3.0)
    io2 = b.math('MULTIPLY', 1960, 380, a=t3, bv=2.0)
    e_io = b.math('SUBTRACT', 2100, 420, a=io3, b=io2)             # 3t^2-2t^3
    ease = b.node("GeometryNodeMenuSwitch", 2260, 560)
    ease.data_type = 'FLOAT'
    ease.enum_items.clear()
    for _nm in ("Linear", "Ease In", "Ease Out", "Ease In-Out"):
        ease.enum_items.new(_nm)
    b.link(gin("Draw Easing"), ease.inputs["Menu"])
    b.link(t, ease.inputs["Linear"])
    b.link(e_in, ease.inputs["Ease In"])
    b.link(e_out, ease.inputs["Ease Out"])
    b.link(e_io, ease.inputs["Ease In-Out"])
    eased = ease.outputs["Output"]

    # per-spline draw order: random 0..1 keyed to the spline index (Trim Curve
    # evaluates End per spline, so Index here is the spline index)
    didx = b.node("GeometryNodeInputIndex", 1600, 340)
    drnd = b.node("FunctionNodeRandomValue", 1760, 360, data_type='FLOAT')
    _in(drnd, "Min").default_value = 0.0
    _in(drnd, "Max").default_value = 1.0
    b.link(_out(didx, "Index"), _in(drnd, "ID"))
    b.link(gin("Seed"), _in(drnd, "Seed"))

    # ⚠ SPATIAL draw order, the fix for the build-on strobe. The per-spline random above
    # is keyed to spline INDEX, and `Include Silhouettes` is view-dependent: a moving
    # camera makes splines appear, split and merge, every index shifts, and every reveal
    # time is reshuffled. Measured jitter 0.47% vs 0.08% baseline.
    # ⚠ Hashing a per-spline value instead does NOT work - tried, and it was WORSE
    # (1.58%), because a hash amplifies drift and splines are not stable entities.
    # A CONTINUOUS field is the answer: when a spline splits, its averaged value barely
    # moves, so the reveal time barely moves. Nearby strokes also draw together, which
    # reads more like someone actually drawing than a scatter across the object.
    dan = b.node("GeometryNodeInputNamedAttribute", 1450, 200, data_type='FLOAT_VECTOR')
    dan.inputs["Name"].default_value = ATTR_ANCHOR
    dsz = b.math('MAXIMUM', 1450, 120, a=gin("Draw Spread"), bv=0.01)
    dsc = b.math('DIVIDE', 1530, 120, av=1.0, b=dsz)
    dnoise = b.node("ShaderNodeTexNoise", 1620, 200)
    dnoise.noise_dimensions = '4D'
    b.link(_out(dan, "Attribute"), dnoise.inputs["Vector"])
    b.link(dsc, dnoise.inputs["Scale"])
    b.link(gin("Seed"), dnoise.inputs["W"])
    # Draw Spread 0 keeps the original random, so existing files are untouched
    dmode = b.node("FunctionNodeCompare", 1700, 120, data_type='FLOAT',
                   operation='GREATER_THAN')
    b.link(gin("Draw Spread"), _in(dmode, "A"))
    _in(dmode, "B").default_value = 0.0001
    # ⚠ NORMALISE THE NOISE. Noise Fac is NOT uniform 0-1 like Random Value is - measured
    # here it spans about 0.35 to 0.72, clustered around the middle. Fed straight in, the
    # build did NOTHING until Draw Amount 0.35 and was finished by 0.75, cramming the whole
    # reveal into a third of the duration: Rob saw a 45-frame build idle until frame ~16
    # and finish by ~34. Stretching the working range back to 0-1 restores even pacing.
    dnorm = b.node("ShaderNodeMapRange", 1740, 120)
    dnorm.clamp = True
    b.link(_out(dnoise, "Fac"), _in(dnorm, "Value"))
    _in(dnorm, "From Min").default_value = 0.35
    _in(dnorm, "From Max").default_value = 0.72
    _in(dnorm, "To Min").default_value = 0.0
    _in(dnorm, "To Max").default_value = 1.0
    dpick = b.node("GeometryNodeSwitch", 1830, 200, input_type='FLOAT')
    b.link(dmode.outputs[0], dpick.inputs["Switch"])
    b.link(_out(drnd, "Value"), _in(dpick, "False"))
    b.link(_out(dnorm, "Result"), _in(dpick, "True"))
    win = b.math('SUBTRACT', 1760, 220, av=1.0, b=gin("Draw Stagger"))
    win = b.math('MAXIMUM', 1900, 220, a=win, bv=0.03)
    # ⚠ START TIMES MUST FIT IN [0, 1 - window], NOT [0, 1]. A stroke reveals over `win`,
    # so one starting at 0.99 with win = 0.03 is only a third drawn when Draw Amount hits
    # its maximum of 1.0 -- it stays permanently truncated. At Draw Stagger 1.0 (win floors
    # to 0.03) that stranded every stroke above 0.97, which reads as scattered DASHES in a
    # supposedly finished drawing. Measured against Draw On OFF at Draw Amount 1.0: the
    # classic random was 1.45% short of the full linework. Scaling by (1 - win) makes the
    # last stroke finish exactly at 1.0.
    st_room = b.math('SUBTRACT', 1830, 300, av=1.0, b=win)
    starti = b.math('MULTIPLY', 1900, 360, a=dpick.outputs[0], b=gin("Draw Stagger"))
    starti = b.math('MULTIPLY', 1960, 300, a=starti, b=st_room)
    endi = b.math('SUBTRACT', 2420, 360, a=eased, b=starti)
    endi = b.math('DIVIDE', 2260, 360, a=endi, b=win)
    endi_c = b.node("ShaderNodeClamp", 2390, 360)
    b.link(endi, endi_c.inputs["Value"])
    endi_c.inputs["Min"].default_value = 0.0
    endi_c.inputs["Max"].default_value = 1.0

    trim = b.node("GeometryNodeTrimCurve", 2260, 300, mode='FACTOR')
    b.link(store_tan.outputs[0], trim.inputs["Curve"])
    _in(trim, "Start").default_value = 0.0
    b.link(endi_c.outputs[0], _in(trim, "End"))
    # Trim to [0,0] leaves a degenerate stub that still renders as a faint dot
    # (very visible on the knobs' many tiny edges), so drop every spline that
    # isn't drawn on yet. As Draw Amount rises they reappear and grow.
    undrawn = b.node("FunctionNodeCompare", 2420, 420,
                     data_type='FLOAT', operation='LESS_THAN')
    b.link(endi_c.outputs[0], _in(undrawn, "A"))
    _in(undrawn, "B").default_value = 0.0005
    ddel = b.node("GeometryNodeDeleteGeometry", 2560, 300, domain='CURVE')
    b.link(trim.outputs[0], ddel.inputs["Geometry"])
    b.link(undrawn.outputs[0], _in(ddel, "Selection"))
    draw_sw = b.node("GeometryNodeSwitch", 2720, 250, input_type='GEOMETRY')
    b.link(gin("Draw On"), draw_sw.inputs["Switch"])
    b.link(store_tan.outputs[0], _in(draw_sw, "False"))
    b.link(ddel.outputs[0], _in(draw_sw, "True"))
    draw_curve = draw_sw.outputs[0]

    # --- strokes as real mesh: anti-aliased by render sampling, identical in
    # viewport and final frame, in EEVEE and Cycles -------------------------
    circle = b.node("GeometryNodeCurvePrimitiveCircle", 1750, 0, mode='RADIUS')
    circle.inputs["Resolution"].default_value = 6
    circle.inputs["Radius"].default_value = 1.0

    c2m = b.node("GeometryNodeCurveToMesh", 1950, 200)
    b.link(circle.outputs[0], _in(c2m, "Profile Curve"))
    if any(s.name == "Scale" for s in c2m.inputs):
        # 5.x: profile size is an explicit per-point field input
        b.link(draw_curve, c2m.inputs["Curve"])
        b.link(radius, _in(c2m, "Scale"))
    else:
        # older builds scale the profile by the curve radius attribute
        setrad = b.node("GeometryNodeSetCurveRadius", 1750, 200)
        b.link(draw_curve, setrad.inputs["Curve"])
        b.link(radius, _in(setrad, "Radius"))
        b.link(setrad.outputs[0], c2m.inputs["Curve"])

    shade = b.node("GeometryNodeSetShadeSmooth", 2100, 200)
    b.link(c2m.outputs[0], shade.inputs[0])
    if "Shade Smooth" in shade.inputs:
        shade.inputs["Shade Smooth"].default_value = True

    rm = b.node("GeometryNodeRemoveAttribute", 2175, 200)
    rm.inputs["Name"].default_value = ATTR_OPOS
    b.link(shade.outputs[0], rm.inputs["Geometry"])

    # Grain settings ride along as uniform attributes so the material (which
    # renders the per-pixel grain) is driven from the same modifier UI
    store_g = b.node("GeometryNodeStoreNamedAttribute", 2200, 400,
                     data_type='FLOAT', domain='POINT')
    store_g.inputs["Name"].default_value = ATTR_GRAIN
    grain_amt = b.math('MULTIPLY', 2050, 460, a=gin("Grain"), b=gin("Breakup Enable"))
    b.link(rm.outputs[0], store_g.inputs["Geometry"])
    b.link(grain_amt, _in(store_g, "Value"))
    g_freq = b.math('DIVIDE', 2100, 550, av=100.0, b=gin("Grain Size"))
    store_gs = b.node("GeometryNodeStoreNamedAttribute", 2225, 550,
                      data_type='FLOAT', domain='POINT')
    store_gs.inputs["Name"].default_value = ATTR_GSCALE
    b.link(store_g.outputs[0], store_gs.inputs["Geometry"])
    b.link(g_freq, _in(store_gs, "Value"))

    # grain boils on the same stepped clock as the wobble
    g_w = b.math('MULTIPLY', 2150, 700, a=boil, bv=9.73)
    store_gw = b.node("GeometryNodeStoreNamedAttribute", 2250, 700,
                      data_type='FLOAT', domain='POINT')
    store_gw.inputs["Name"].default_value = ATTR_GW
    b.link(store_gs.outputs[0], store_gw.inputs["Geometry"])
    b.link(g_w, _in(store_gw, "Value"))

    setmat = b.node("GeometryNodeSetMaterial", 2250, 200)
    b.link(store_gw.outputs[0], setmat.inputs["Geometry"])
    b.link(gin("Material"), setmat.inputs["Material"])

    # --- smudge shading: one copy of the source surfaces, nudged off the
    # geometry, wearing a facing/cavity shading material. No extra per-stroke
    # ribbons (those clipped), so this is just the object surface re-shaded.
    # The whole branch is skipped unless Smudge Enable is on and strong.
    normal = b.node("GeometryNodeInputNormal", 1900, 900)
    push_vec = b.vmath('SCALE', 2050, 900, normal.outputs[0], scale=0.0015)
    sm_push = b.node("GeometryNodeSetPosition", 2200, 900)
    b.link(realized, sm_push.inputs["Geometry"])
    b.link(push_vec, _in(sm_push, "Offset"))

    # Optional outer-shell cull (Shade Outer Only): cast a ray from each FACE
    # along its OUTWARD normal against the object's OWN geometry. A hit means an
    # opposite wall sits in front of the normal -> an inner cavity face -> drop
    # it, so hollow/open props read solid. (This alone misses interior walls
    # that face an opening — the camera-occlusion cull below handles those.)
    # CAVEAT: like the line occlusion, the cull below uses the SCENE camera, so
    # orbiting the viewport away from it can hide/show faces until you look
    # through the camera again — the strokes behave the same way.
    sm_pos = b.node("GeometryNodeInputPosition", 2050, 700)
    sm_nrm = b.node("GeometryNodeInputNormal", 2050, 560)
    sm_bb = b.node("GeometryNodeBoundBox", 2050, 420)
    b.link(realized, sm_bb.inputs["Geometry"])
    diagn = b.node("ShaderNodeVectorMath", 2200, 420, operation='DISTANCE')
    b.link(_out(sm_bb, "Max"), diagn.inputs[0])
    b.link(_out(sm_bb, "Min"), diagn.inputs[1])
    sm_off = b.vmath('SCALE', 2200, 600, sm_nrm.outputs[0], scale=0.001)
    sm_src = b.vmath('ADD', 2340, 600, sm_pos.outputs[0], sm_off)
    sm_cray = b.node("GeometryNodeRaycast", 2500, 560)
    b.link(realized, sm_cray.inputs["Target Geometry"])
    b.link(sm_src, _in(sm_cray, "Source Position"))
    b.link(sm_nrm.outputs[0], _in(sm_cray, "Ray Direction"))
    b.link(diagn.outputs["Value"], _in(sm_cray, "Ray Length"))
    cull_inner = b.bool_op('AND', 2680, 560, _out(sm_cray, "Is Hit"),
                           gin("Shade Outer Only"))
    inner_vis = b.math('SUBTRACT', 2820, 620, av=1.0, b=cull_inner)

    # Camera occlusion (always on): the outer-shell cull above can't catch a
    # visible interior wall whose outward normal faces an OPENING (no opposite
    # wall to hit) — e.g. an open cabinet's back panel — so it read as a solid
    # dark slab. Fix: the SAME active-camera raycast the lines use. Cast from
    # the camera toward each FACE centre against the occluders; a hit short of
    # the face means the front of the object (or another occluder) hides it, so
    # drop its shading. Now the smudge disappears exactly where the strokes do.
    sm_cam = b.node("GeometryNodeInputActiveCamera", 2050, 340)
    sm_coi = b.node("GeometryNodeObjectInfo", 2200, 340, transform_space='ORIGINAL')
    b.link(sm_cam.outputs[0], sm_coi.inputs["Object"])
    sm_camloc = _out(sm_coi, "Location")
    sm_cdelta = b.vmath('SUBTRACT', 2340, 340, sm_pos.outputs[0], sm_camloc)
    sm_cdist = b.node("ShaderNodeVectorMath", 2480, 340, operation='LENGTH')
    b.link(sm_cdelta, sm_cdist.inputs[0])
    sm_cdir = b.vmath('NORMALIZE', 2480, 260, sm_cdelta)
    sm_cbias = b.math('MULTIPLY', 2340, 180, a=gin("Occlusion Bias"), bv=0.001)
    sm_clen = b.math('SUBTRACT', 2620, 300, a=sm_cdist.outputs["Value"], b=sm_cbias)
    sm_clen = b.math('MAXIMUM', 2760, 300, a=sm_clen, bv=0.0)
    sm_oray = b.node("GeometryNodeRaycast", 2900, 340)
    b.link(occluders, sm_oray.inputs["Target Geometry"])
    b.link(sm_camloc, _in(sm_oray, "Source Position"))
    b.link(sm_cdir, _in(sm_oray, "Ray Direction"))
    b.link(sm_clen, _in(sm_oray, "Ray Length"))
    # guard: no active camera -> ObjectInfo Location (0,0,0) -> skip the cull so
    # the shading doesn't self-erase from rays fired out of the world origin.
    sm_camlen = b.node("ShaderNodeVectorMath", 2620, 180, operation='LENGTH')
    b.link(sm_camloc, sm_camlen.inputs[0])
    sm_hascam = b.math('GREATER_THAN', 2760, 100, a=sm_camlen.outputs["Value"], bv=0.0001)
    sm_camocc = b.math('MULTIPLY', 3040, 340, a=_out(sm_oray, "Is Hit"), b=sm_hascam)
    cam_vis = b.math('SUBTRACT', 3040, 480, av=1.0, b=sm_camocc)
    sm_vis = b.math('MULTIPLY', 3200, 560, a=inner_vis, b=cam_vis)

    # store on the FACE domain: evaluated per-face, InputPosition/InputNormal
    # resolve to the face centre and face normal, so inner vs outer faces are
    # cleanly separated (per-vertex is ambiguous — rim verts are shared).
    sm_vstore = b.node("GeometryNodeStoreNamedAttribute", 2300, 950,
                       data_type='FLOAT', domain='FACE')
    sm_vstore.inputs["Name"].default_value = ATTR_SMVIS
    b.link(sm_push.outputs[0], sm_vstore.inputs["Geometry"])
    b.link(sm_vis, _in(sm_vstore, "Value"))

    # fade the smudge in with the draw-on so shading builds up with the lines
    # instead of popping in fully at Draw Amount 0. draw_fac = Draw On ? eased
    # : 1, so it has no effect unless the draw-on is active.
    sm_inv = b.math('SUBTRACT', 2050, 1050, av=1.0, b=eased)
    sm_gate = b.math('MULTIPLY', 2200, 1050, a=gin("Draw On"), b=sm_inv)
    sm_dfac = b.math('SUBTRACT', 2050, 1150, av=1.0, b=sm_gate)
    sm_amt = b.math('MULTIPLY', 2200, 1200, a=gin("Smudge"), b=sm_dfac)
    sm_s1 = b.node("GeometryNodeStoreNamedAttribute", 2350, 900,
                   data_type='FLOAT', domain='POINT')
    sm_s1.inputs["Name"].default_value = ATTR_SMUDGE
    b.link(sm_vstore.outputs[0], sm_s1.inputs["Geometry"])
    b.link(sm_amt, _in(sm_s1, "Value"))

    smd = b.math('MULTIPLY', 2300, 1050, a=gin("Smudge Distance"), bv=0.01)
    sm_s2 = b.node("GeometryNodeStoreNamedAttribute", 2450, 1000,
                   data_type='FLOAT', domain='POINT')
    sm_s2.inputs["Name"].default_value = ATTR_SMDIST
    b.link(sm_s1.outputs[0], sm_s2.inputs["Geometry"])
    b.link(smd, _in(sm_s2, "Value"))

    smf = b.math('DIVIDE', 2400, 1150, av=100.0, b=gin("Smudge Size"))
    sm_s3 = b.node("GeometryNodeStoreNamedAttribute", 2550, 1100,
                   data_type='FLOAT', domain='POINT')
    sm_s3.inputs["Name"].default_value = ATTR_SMSIZE
    b.link(sm_s2.outputs[0], sm_s3.inputs["Geometry"])
    b.link(smf, _in(sm_s3, "Value"))

    sm_s4 = b.node("GeometryNodeStoreNamedAttribute", 2650, 1000,
                   data_type='FLOAT', domain='POINT')
    sm_s4.inputs["Name"].default_value = ATTR_SMAO
    b.link(sm_s3.outputs[0], sm_s4.inputs["Geometry"])
    b.link(gin("Smudge Cavity"), _in(sm_s4, "Value"))

    # --- toon/textured shading uniforms (read by the smudge material) -------
    # style index 0..4 from the menu, carried as a float uniform
    sm_style = b.node("GeometryNodeMenuSwitch", 2500, 1250)
    sm_style.data_type = 'FLOAT'
    sm_style.enum_items.clear()
    for _i, _nm in enumerate(("Smudge", "Hatch", "Cross-hatch", "Dots", "Stipple", "Flat")):
        sm_style.enum_items.new(_nm)
        sm_style.inputs[_nm].default_value = float(_i)
    b.link(gin("Shading Style"), sm_style.inputs["Menu"])
    sm_t1 = b.node("GeometryNodeStoreNamedAttribute", 2650, 1150,
                   data_type='FLOAT', domain='POINT')
    sm_t1.inputs["Name"].default_value = ATTR_TSTYLE
    b.link(sm_s4.outputs[0], sm_t1.inputs["Geometry"])
    b.link(sm_style.outputs["Output"], _in(sm_t1, "Value"))

    sm_t2 = b.node("GeometryNodeStoreNamedAttribute", 2650, 1300,
                   data_type='FLOAT', domain='POINT')
    sm_t2.inputs["Name"].default_value = ATTR_TLEVELS
    b.link(sm_t1.outputs[0], sm_t2.inputs["Geometry"])
    b.link(gin("Tone Steps"), _in(sm_t2, "Value"))

    sm_t3 = b.node("GeometryNodeStoreNamedAttribute", 2650, 1450,
                   data_type='FLOAT', domain='POINT')
    sm_t3.inputs["Name"].default_value = ATTR_TPANGLE
    b.link(sm_t2.outputs[0], sm_t3.inputs["Geometry"])
    b.link(gin("Pattern Angle"), _in(sm_t3, "Value"))

    # fake light direction = TOWARD the light = the Light Empty's local -Z (its
    # arrow, +Z, points the way the light travels, like a sun's rays — aim the
    # arrow at the faces you want lit). Zeroed when unused.
    le_oi = b.node("GeometryNodeObjectInfo", 2350, 1600, transform_space='ORIGINAL')
    b.link(gin("Light Empty"), le_oi.inputs["Object"])
    lvr = b.node("ShaderNodeVectorRotate", 2600, 1600, rotation_type='EULER_XYZ')
    _in(lvr, "Vector").default_value = (0.0, 0.0, -1.0)
    b.link(_out(le_oi, "Rotation"), _in(lvr, "Rotation"))
    ldir_g = b.vmath('SCALE', 2800, 1600, lvr.outputs[0], scale=gin("Use Light Angle"))
    sm_t4 = b.node("GeometryNodeStoreNamedAttribute", 2650, 1550,
                   data_type='FLOAT_VECTOR', domain='POINT')
    sm_t4.inputs["Name"].default_value = ATTR_TDIR
    b.link(sm_t3.outputs[0], sm_t4.inputs["Geometry"])
    b.link(ldir_g, _in(sm_t4, "Value"))

    sm_t5 = b.node("GeometryNodeStoreNamedAttribute", 2650, 1700,
                   data_type='FLOAT', domain='POINT')
    sm_t5.inputs["Name"].default_value = ATTR_TWEIGHT
    b.link(sm_t4.outputs[0], sm_t5.inputs["Geometry"])
    b.link(gin("Pattern Weight"), _in(sm_t5, "Value"))

    sm_t6 = b.node("GeometryNodeStoreNamedAttribute", 2650, 1800,
                   data_type='FLOAT', domain='POINT')
    sm_t6.inputs["Name"].default_value = ATTR_TSKETCH
    b.link(sm_t5.outputs[0], sm_t6.inputs["Geometry"])
    b.link(gin("Sketchiness"), _in(sm_t6, "Value"))

    sm_t7 = b.node("GeometryNodeStoreNamedAttribute", 2650, 1900,
                   data_type='FLOAT', domain='POINT')
    sm_t7.inputs["Name"].default_value = ATTR_TEDGE
    b.link(sm_t6.outputs[0], sm_t7.inputs["Geometry"])
    b.link(gin("Edge"), _in(sm_t7, "Value"))

    sm_setmat = b.node("GeometryNodeSetMaterial", 3000, 1000)
    b.link(sm_t7.outputs[0], sm_setmat.inputs["Geometry"])
    b.link(gin("Smudge Material"), sm_setmat.inputs["Material"])

    # gate on Enable AND non-zero strength
    sm_cmp = b.node("FunctionNodeCompare", 2450, 800,
                    data_type='FLOAT', operation='GREATER_THAN')
    b.link(gin("Smudge"), _in(sm_cmp, "A"))
    _in(sm_cmp, "B").default_value = 0.0005
    sm_on = b.bool_op('AND', 2650, 800, gin("Smudge Enable"), sm_cmp.outputs[0])
    sm_sw = b.node("GeometryNodeSwitch", 2950, 850, input_type='GEOMETRY')
    b.link(sm_on, sm_sw.inputs["Switch"])
    b.link(sm_setmat.outputs[0], _in(sm_sw, "True"))

    # --- colour fill: a flat-coloured copy of the surface, nudged toward the
    # camera so it covers the grey source, sitting under the ink lines (which are
    # pulled further forward). World-locked (no swim). Toward-camera keeps the
    # silhouette in place — no colour bleeding past the outline like a normal push.
    fill_pos = b.node("GeometryNodeInputPosition", 2600, 620)
    fill_dir = b.vmath('SUBTRACT', 2750, 620, a=cam_loc, b=fill_pos.outputs[0])
    fill_dir = b.vmath('NORMALIZE', 2880, 620, a=fill_dir)
    fill_off = b.vmath('SCALE', 3010, 620, a=fill_dir, scale=0.0005)
    fill_sp = b.node("GeometryNodeSetPosition", 3150, 560)
    b.link(ri.outputs[0], fill_sp.inputs["Geometry"])
    b.link(fill_off, _in(fill_sp, "Offset"))
    # carry the choke / texture controls to the fill material as uniform attrs
    fc1 = b.node("GeometryNodeStoreNamedAttribute", 3260, 560, data_type='FLOAT', domain='POINT')
    fc1.inputs["Name"].default_value = ATTR_FCHOKE
    b.link(fill_sp.outputs[0], fc1.inputs["Geometry"])
    b.link(gin("Fill Choke"), _in(fc1, "Value"))
    fc2 = b.node("GeometryNodeStoreNamedAttribute", 3360, 560, data_type='FLOAT', domain='POINT')
    fc2.inputs["Name"].default_value = ATTR_FTEX
    b.link(fc1.outputs[0], fc2.inputs["Geometry"])
    b.link(gin("Fill Texture"), _in(fc2, "Value"))
    ftsz = b.math('MULTIPLY', 3260, 460, a=gin("Fill Texture Size"), bv=0.01)
    fc3 = b.node("GeometryNodeStoreNamedAttribute", 3460, 560, data_type='FLOAT', domain='POINT')
    fc3.inputs["Name"].default_value = ATTR_FTSIZE
    b.link(fc2.outputs[0], fc3.inputs["Geometry"])
    b.link(ftsz, _in(fc3, "Value"))
    fc4 = b.node("GeometryNodeStoreNamedAttribute", 3510, 560, data_type='FLOAT', domain='POINT')
    fc4.inputs["Name"].default_value = ATTR_FOPAC
    b.link(fc3.outputs[0], fc4.inputs["Geometry"])
    # ⚠ Occlusion is geometric and time-independent, so a build-on object hides the
    # background before it has been drawn. Deriving the matte from this line set's own
    # Draw Amount makes it start occluding exactly as it finishes drawing, with no
    # keyframing. Draw Amount is 1 when Draw On is off, so static sets stay fully opaque.
    fade = b.math('MAXIMUM', 3300, 380, a=gin("Matte Fade"), bv=0.001)
    # ⚠ The fade is anchored to the END of the draw. `Matte Lead` slides that anchor back
    # so the matte can be fully in while the last strokes are still landing - occlusion
    # settling before the drawing finishes, rather than snapping in with the final stroke.
    # Clamped so the window can never invert or run off the start of the build.
    lead = b.math('MINIMUM', 3300, 440, a=gin("Matte Lead"), bv=0.9)
    lead = b.math('MAXIMUM', 3360, 440, a=lead, bv=0.0)
    fade_hi = b.math('SUBTRACT', 3420, 440, av=1.0, b=lead)
    fade_hi = b.math('MAXIMUM', 3480, 440, a=fade_hi, bv=0.05)
    fade_lo = b.math('SUBTRACT', 3380, 380, a=fade_hi, b=fade)
    fade_lo = b.math('MAXIMUM', 3440, 380, a=fade_lo, bv=0.0)
    auto_op = b.node("ShaderNodeMapRange", 3300, 300)
    auto_op.interpolation_type = 'SMOOTHSTEP'
    auto_op.clamp = True
    b.link(gin("Draw Amount"), _in(auto_op, "Value"))
    b.link(fade_lo, _in(auto_op, "From Min"))
    b.link(fade_hi, _in(auto_op, "From Max"))
    _in(auto_op, "To Min").default_value = 0.0
    _in(auto_op, "To Max").default_value = 1.0
    op_sw = b.node("GeometryNodeSwitch", 3440, 300, input_type='FLOAT')
    b.link(gin("Fill Follows Draw"), op_sw.inputs["Switch"])
    b.link(gin("Fill Opacity"), _in(op_sw, "False"))
    b.link(_out(auto_op, "Result"), _in(op_sw, "True"))
    b.link(op_sw.outputs[0], _in(fc4, "Value"))
    fc5 = b.node("GeometryNodeStoreNamedAttribute", 3530, 620, data_type='FLOAT', domain='POINT')
    fc5.inputs["Name"].default_value = ATTR_FMATTE
    b.link(fc4.outputs[0], fc5.inputs["Geometry"])
    b.link(gin("Transparent Matte"), _in(fc5, "Value"))
    # ⚠ The matte is revealed SPATIALLY, not by fading. See build_fill_material: the
    # shader needs the reveal grain and whether to threshold at all, so both ride along
    # as uniform attributes. Grain is Draw Spread, floored so the scale cannot blow up on
    # a static set where Draw Spread is 0 and the reveal is a no-op anyway.
    fsp = b.math('MAXIMUM', 3300, 680, a=gin("Draw Spread"), bv=0.25)
    fc6 = b.node("GeometryNodeStoreNamedAttribute", 3560, 680, data_type='FLOAT', domain='POINT')
    fc6.inputs["Name"].default_value = ATTR_FSPREAD
    b.link(fc5.outputs[0], fc6.inputs["Geometry"])
    b.link(fsp, _in(fc6, "Value"))
    fc7 = b.node("GeometryNodeStoreNamedAttribute", 3590, 740, data_type='FLOAT', domain='POINT')
    fc7.inputs["Name"].default_value = ATTR_FREVEAL
    b.link(fc6.outputs[0], fc7.inputs["Geometry"])
    b.link(gin("Fill Follows Draw"), _in(fc7, "Value"))
    fill_setmat = b.node("GeometryNodeSetMaterial", 3560, 560)
    b.link(fc7.outputs[0], fill_setmat.inputs["Geometry"])
    b.link(gin("Fill Material"), fill_setmat.inputs["Material"])
    fill_sw = b.node("GeometryNodeSwitch", 3450, 560, input_type='GEOMETRY')
    b.link(gin("Colour Fill"), fill_sw.inputs["Switch"])
    b.link(fill_setmat.outputs[0], _in(fill_sw, "True"))

    join = b.node("GeometryNodeJoinGeometry", 3620, 300)
    b.link(setmat.outputs[0], join.inputs[0])
    b.link(sm_sw.outputs[0], join.inputs[0])
    b.link(fill_sw.outputs[0], join.inputs[0])

    b.link(join.outputs[0], go.inputs[0])
    return tree


# ---------------------------------------------------------------------------
# Line material
# ---------------------------------------------------------------------------

def build_line_material(name):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()

    out = nt.nodes.new("ShaderNodeOutputMaterial")
    out.location = (400, 0)
    mix = nt.nodes.new("ShaderNodeMixShader")
    mix.location = (200, 0)
    transp = nt.nodes.new("ShaderNodeBsdfTransparent")
    transp.location = (0, 100)
    emit = nt.nodes.new("ShaderNodeEmission")
    emit.location = (0, -100)

    # visible vs hidden line color, chosen by the occlusion flag
    rgb_line = nt.nodes.new("ShaderNodeRGB")
    rgb_line.name = rgb_line.label = "Line Color"
    rgb_line.location = (-450, -100)
    rgb_line.outputs[0].default_value = (0.0, 0.0, 0.0, 1.0)
    rgb_hidden = nt.nodes.new("ShaderNodeRGB")
    rgb_hidden.name = rgb_hidden.label = "Hidden Color"
    rgb_hidden.location = (-450, -300)
    rgb_hidden.outputs[0].default_value = (0.0, 0.0, 0.0, 1.0)
    attr_occ = nt.nodes.new("ShaderNodeAttribute")
    attr_occ.location = (-450, -500)
    attr_occ.attribute_type = 'GEOMETRY'
    attr_occ.attribute_name = ATTR_OCC

    mixc = nt.nodes.new("ShaderNodeMix")
    mixc.data_type = 'RGBA'
    mixc.location = (-200, -200)

    def _msock(node, name, out=False):
        seq = node.outputs if out else node.inputs
        return next(s for s in seq if s.name == name and s.enabled)

    nt.links.new(attr_occ.outputs["Fac"], _msock(mixc, "Factor"))
    nt.links.new(rgb_line.outputs[0], _msock(mixc, "A"))
    nt.links.new(rgb_hidden.outputs[0], _msock(mixc, "B"))
    nt.links.new(_msock(mixc, "Result", out=True), emit.inputs["Color"])
    attr = nt.nodes.new("ShaderNodeAttribute")
    attr.location = (-600, 300)
    attr.attribute_type = 'GEOMETRY'
    attr.attribute_name = ATTR_VIS

    # Per-pixel paper-tooth grain: shader-space noise multiplied into stroke
    # alpha. Being per-pixel it has no geometric sampling limit, which is
    # what lets it get charcoal-fine. World-position keyed, so strokes drag
    # through a fixed tooth field the way media drags across paper.
    geo = nt.nodes.new("ShaderNodeNewGeometry")
    geo.location = (-1000, 100)
    attr_gscale = nt.nodes.new("ShaderNodeAttribute")
    attr_gscale.location = (-1000, -150)
    attr_gscale.attribute_type = 'GEOMETRY'
    attr_gscale.attribute_name = ATTR_GSCALE
    attr_gw = nt.nodes.new("ShaderNodeAttribute")
    attr_gw.location = (-1000, -400)
    attr_gw.attribute_type = 'GEOMETRY'
    attr_gw.attribute_name = ATTR_GW
    grain_noise = nt.nodes.new("ShaderNodeTexNoise")
    grain_noise.name = grain_noise.label = "Grain Noise"
    grain_noise.location = (-800, 100)
    grain_noise.noise_dimensions = '4D'
    grain_noise.inputs["Detail"].default_value = 6.0
    grain_noise.inputs["Roughness"].default_value = 0.6
    nt.links.new(geo.outputs["Position"], grain_noise.inputs["Vector"])
    nt.links.new(attr_gscale.outputs["Fac"], grain_noise.inputs["Scale"])
    nt.links.new(attr_gw.outputs["Fac"], grain_noise.inputs["W"])

    gc = nt.nodes.new("ShaderNodeMath")
    gc.operation = 'SUBTRACT'
    gc.location = (-600, 100)
    nt.links.new(grain_noise.outputs["Fac"], gc.inputs[0])
    gc.inputs[1].default_value = 0.5
    gc2 = nt.nodes.new("ShaderNodeMath")
    gc2.operation = 'MULTIPLY'
    gc2.location = (-450, 100)
    nt.links.new(gc.outputs[0], gc2.inputs[0])
    gc2.inputs[1].default_value = 3.0
    gc3 = nt.nodes.new("ShaderNodeMath")
    gc3.operation = 'ADD'
    gc3.use_clamp = True
    gc3.location = (-300, 100)
    nt.links.new(gc2.outputs[0], gc3.inputs[0])
    gc3.inputs[1].default_value = 0.5

    attr_grain = nt.nodes.new("ShaderNodeAttribute")
    attr_grain.location = (-300, -100)
    attr_grain.attribute_type = 'GEOMETRY'
    attr_grain.attribute_name = ATTR_GRAIN
    gamt = nt.nodes.new("ShaderNodeMath")
    gamt.operation = 'MULTIPLY'
    gamt.name = gamt.label = "Grain Amount"
    gamt.location = (-150, 100)
    nt.links.new(gc3.outputs[0], gamt.inputs[0])
    nt.links.new(attr_grain.outputs["Fac"], gamt.inputs[1])

    # Choke-from-edge, like AE Roughen: measure distance from the stroke edge
    # in the stroke's own cross-section. The view vector is projected into
    # the plane perpendicular to the stroke tangent before dotting with the
    # normal — raw view facing would collapse on foreshortened strokes and
    # chew them harder than side-on ones. 1 at the centerline, 0 at the
    # silhouette, for any stroke orientation.
    attr_tan = nt.nodes.new("ShaderNodeAttribute")
    attr_tan.location = (-900, 600)
    attr_tan.attribute_type = 'GEOMETRY'
    attr_tan.attribute_name = ATTR_TAN
    tnorm = nt.nodes.new("ShaderNodeVectorMath")
    tnorm.operation = 'NORMALIZE'
    tnorm.location = (-750, 600)
    nt.links.new(attr_tan.outputs["Vector"], tnorm.inputs[0])

    vdott = nt.nodes.new("ShaderNodeVectorMath")
    vdott.operation = 'DOT_PRODUCT'
    vdott.location = (-600, 600)
    nt.links.new(geo.outputs["Incoming"], vdott.inputs[0])
    nt.links.new(tnorm.outputs[0], vdott.inputs[1])
    proj = nt.nodes.new("ShaderNodeVectorMath")
    proj.operation = 'SCALE'
    proj.location = (-600, 450)
    nt.links.new(tnorm.outputs[0], proj.inputs[0])
    nt.links.new(vdott.outputs["Value"], proj.inputs["Scale"])
    vperp = nt.nodes.new("ShaderNodeVectorMath")
    vperp.operation = 'SUBTRACT'
    vperp.location = (-450, 550)
    nt.links.new(geo.outputs["Incoming"], vperp.inputs[0])
    nt.links.new(proj.outputs[0], vperp.inputs[1])
    vperpn = nt.nodes.new("ShaderNodeVectorMath")
    vperpn.operation = 'NORMALIZE'
    vperpn.location = (-300, 550)
    nt.links.new(vperp.outputs[0], vperpn.inputs[0])

    fdot = nt.nodes.new("ShaderNodeVectorMath")
    fdot.operation = 'DOT_PRODUCT'
    fdot.location = (-300, 400)
    nt.links.new(geo.outputs["Normal"], fdot.inputs[0])
    nt.links.new(vperpn.outputs[0], fdot.inputs[1])
    center = nt.nodes.new("ShaderNodeMath")
    center.operation = 'ABSOLUTE'
    center.location = (-150, 450)
    nt.links.new(fdot.outputs["Value"], center.inputs[0])

    chew = nt.nodes.new("ShaderNodeMath")
    chew.operation = 'SUBTRACT'
    chew.location = (-150, 300)
    nt.links.new(gamt.outputs[0], chew.inputs[0])
    nt.links.new(center.outputs[0], chew.inputs[1])
    chew_soft = nt.nodes.new("ShaderNodeMath")
    chew_soft.operation = 'DIVIDE'
    chew_soft.use_clamp = True
    chew_soft.location = (0, 300)
    nt.links.new(chew.outputs[0], chew_soft.inputs[0])
    chew_soft.inputs[1].default_value = 0.3

    ginv = nt.nodes.new("ShaderNodeMath")
    ginv.operation = 'SUBTRACT'
    ginv.location = (150, 300)
    ginv.inputs[0].default_value = 1.0
    nt.links.new(chew_soft.outputs[0], ginv.inputs[1])

    alpha = nt.nodes.new("ShaderNodeMath")
    alpha.operation = 'MULTIPLY'
    alpha.location = (300, 400)
    nt.links.new(attr.outputs["Fac"], alpha.inputs[0])
    nt.links.new(ginv.outputs[0], alpha.inputs[1])

    nt.links.new(alpha.outputs[0], mix.inputs["Fac"])
    nt.links.new(transp.outputs[0], mix.inputs[1])
    nt.links.new(emit.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs["Surface"])

    if hasattr(mat, "surface_render_method"):
        mat.surface_render_method = 'BLENDED'
    return mat


def build_fill_material(name):
    """Flat unlit colour wash for the interior fill. Stays OPAQUE (covers the
    grey model) but fades toward a Paper colour where it's CHOKED back from the
    silhouette (facing) or broken up by a world-locked TEXTURE mottle — so the
    colour reads like loose hand-colouring that doesn't quite reach the ink, and
    never reveals grey. Choke / Texture / Texture-Size come in as uniform attrs."""
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    L = nt.links.new
    fill_c = nt.nodes.new("ShaderNodeRGB")
    fill_c.name = fill_c.label = "Fill Color"
    fill_c.location = (-700, 250)
    fill_c.outputs[0].default_value = (0.85, 0.84, 0.80, 1.0)
    paper_c = nt.nodes.new("ShaderNodeRGB")
    paper_c.name = paper_c.label = "Paper Color"
    paper_c.location = (-700, 60)
    paper_c.outputs[0].default_value = (0.96, 0.95, 0.93, 1.0)

    def ATTR(nm, y):
        a = nt.nodes.new("ShaderNodeAttribute")
        a.attribute_name = nm
        a.location = (-700, y)
        return a
    a_choke = ATTR(ATTR_FCHOKE, -150)
    a_tex = ATTR(ATTR_FTEX, -320)
    a_tsz = ATTR(ATTR_FTSIZE, -490)

    # choke: fade from full fill (facing the camera) to Paper near the silhouette
    lw = nt.nodes.new("ShaderNodeLayerWeight"); lw.location = (-700, -680)
    choke_max = nt.nodes.new("ShaderNodeMath"); choke_max.operation = 'MAXIMUM'
    choke_max.inputs[1].default_value = 0.001; choke_max.location = (-500, -180)
    L(a_choke.outputs["Fac"], choke_max.inputs[0])
    choke_mr = nt.nodes.new("ShaderNodeMapRange"); choke_mr.interpolation_type = 'SMOOTHSTEP'
    choke_mr.location = (-320, -400)
    L(lw.outputs["Facing"], _in(choke_mr, "Value"))
    _in(choke_mr, "From Min").default_value = 0.0
    L(choke_max.outputs[0], _in(choke_mr, "From Max"))

    # texture: world-locked mottle erodes the fill toward Paper as amount rises
    pos = nt.nodes.new("ShaderNodeNewGeometry"); pos.location = (-950, -900)
    tsz_max = nt.nodes.new("ShaderNodeMath"); tsz_max.operation = 'MAXIMUM'
    tsz_max.inputs[1].default_value = 0.002; tsz_max.location = (-500, -520)
    L(a_tsz.outputs["Fac"], tsz_max.inputs[0])
    tscale = nt.nodes.new("ShaderNodeMath"); tscale.operation = 'DIVIDE'
    tscale.inputs[0].default_value = 1.0; tscale.location = (-330, -520)
    L(tsz_max.outputs[0], tscale.inputs[1])
    noise = nt.nodes.new("ShaderNodeTexNoise"); noise.location = (-150, -760)
    noise.inputs["Detail"].default_value = 2.0
    L(pos.outputs["Position"], noise.inputs["Vector"])
    L(tscale.outputs[0], noise.inputs["Scale"])
    tex_lo = nt.nodes.new("ShaderNodeMath"); tex_lo.operation = 'MULTIPLY'
    tex_lo.inputs[1].default_value = 0.9; tex_lo.location = (-150, -520)
    L(a_tex.outputs["Fac"], tex_lo.inputs[0])
    tex_hi = nt.nodes.new("ShaderNodeMath"); tex_hi.operation = 'ADD'
    tex_hi.inputs[1].default_value = 0.15; tex_hi.location = (20, -520)
    L(tex_lo.outputs[0], tex_hi.inputs[0])
    tex_mr = nt.nodes.new("ShaderNodeMapRange"); tex_mr.interpolation_type = 'SMOOTHSTEP'
    tex_mr.location = (200, -680)
    L(noise.outputs["Fac"], _in(tex_mr, "Value"))
    L(tex_lo.outputs[0], _in(tex_mr, "From Min"))
    L(tex_hi.outputs[0], _in(tex_mr, "From Max"))

    cov = nt.nodes.new("ShaderNodeMath"); cov.operation = 'MULTIPLY'; cov.location = (420, -450)
    L(_out(choke_mr, "Result"), cov.inputs[0])
    L(_out(tex_mr, "Result"), cov.inputs[1])

    mix = nt.nodes.new("ShaderNodeMix"); mix.data_type = 'RGBA'; mix.location = (640, 60)
    L(cov.outputs[0], _in(mix, "Factor"))
    L(paper_c.outputs[0], _in(mix, "A"))
    L(fill_c.outputs[0], _in(mix, "B"))
    emit = nt.nodes.new("ShaderNodeEmission"); emit.location = (860, 60)
    L(_out(mix, "Result"), emit.inputs["Color"])
    # ⚠ The matte has to be able to DISSOLVE. Build-on work needs the shape to start
    # hiding the background only once its lines have drawn; a solid Emission occludes
    # from frame one. Opacity arrives as a uniform attribute so it stays a modifier
    # control and survives Update Node Group, which regenerates these materials.
    a_op = ATTR(ATTR_FOPAC, -820)
    a_matte = ATTR(ATTR_FMATTE, -980)
    # ⚠ HOLDOUT still occludes but writes alpha 0, so the matte comps as a hole rather
    # than a white shape. Selected per line set, so one scene can mix visible fills and
    # invisible mattes. Needs Film > Transparent to read as transparent.
    hold = nt.nodes.new("ShaderNodeHoldout"); hold.location = (860, -320)
    pick = nt.nodes.new("ShaderNodeMixShader"); pick.location = (1040, -120)
    L(a_matte.outputs["Fac"], pick.inputs["Fac"])
    L(emit.outputs[0], pick.inputs[1])
    L(hold.outputs[0], pick.inputs[2])
    transp = nt.nodes.new("ShaderNodeBsdfTransparent"); transp.location = (860, -160)

    # ⚠ The matte is revealed SPATIALLY, never by partial opacity. The fill renders
    # DITHERED, and DITHERED resolves a partial alpha by randomly keeping or discarding
    # each pixel, so a half-faded matte came out as an opaque noise plate over the
    # artwork. Measured on FTF-810: 270 K dark partial-alpha pixels for the whole
    # dissolve, against a 7.6 K baseline.
    #
    # BLENDED is the obvious escape and is a trap: it writes no depth, so occlusion falls
    # back on draw-order sorting. Same measurement, one build-on lost its occlusion
    # entirely (3115 px -> 0).
    #
    # So the ramp is spent on a THRESHOLD instead. Every fragment is fully matte or fully
    # transparent, there is no partial alpha for DITHERED to randomise, depth is still
    # written, and the matte fills in region by region following the drawing. World-space
    # position keeps the pattern from swimming under camera motion, as the wobble does.
    a_spread = ATTR(ATTR_FSPREAD, -520)
    a_reveal = ATTR(ATTR_FREVEAL, -620)
    rgeo = nt.nodes.new("ShaderNodeNewGeometry"); rgeo.location = (-640, -420)
    rscale = nt.nodes.new("ShaderNodeMath"); rscale.operation = 'DIVIDE'
    rscale.location = (-640, -540)
    rscale.inputs[0].default_value = 1.0
    L(a_spread.outputs["Fac"], rscale.inputs[1])
    rnoise = nt.nodes.new("ShaderNodeTexNoise"); rnoise.location = (-460, -460)
    L(rgeo.outputs["Position"], rnoise.inputs["Vector"])
    L(rscale.outputs[0], rnoise.inputs["Scale"])
    # ⚠ Noise Fac is NOT uniformly distributed, it bunches around the middle, so a raw
    # comparison idles then rushes. Spread it, and stop SHORT of 0 and 1 at both ends:
    # GREATER_THAN is strict, so a fragment sitting at exactly 1.0 would never reveal
    # even at full opacity, leaving permanent holes in the matte.
    rmap = nt.nodes.new("ShaderNodeMapRange"); rmap.location = (-280, -460)
    rmap.clamp = True
    rmap.inputs["From Min"].default_value = 0.35
    rmap.inputs["From Max"].default_value = 0.72
    rmap.inputs["To Min"].default_value = 0.02
    rmap.inputs["To Max"].default_value = 0.98
    L(rnoise.outputs["Fac"], rmap.inputs["Value"])
    rstep = nt.nodes.new("ShaderNodeMath"); rstep.operation = 'GREATER_THAN'
    rstep.location = (-100, -460)
    L(a_op.outputs["Fac"], rstep.inputs[0])
    L(rmap.outputs["Result"], rstep.inputs[1])
    # ⚠ Only a build-on thresholds. With Follow Draw On off, Fill Opacity is a manual
    # control and a user asking for 0.5 wants a half-transparent fill, not a 50% dissolve.
    rpick = nt.nodes.new("ShaderNodeMix"); rpick.location = (80, -460)
    rpick.data_type = 'FLOAT'
    L(a_reveal.outputs["Fac"], rpick.inputs["Factor"])
    L(a_op.outputs["Fac"], rpick.inputs[2])
    L(rstep.outputs[0], rpick.inputs[3])

    mixsh = nt.nodes.new("ShaderNodeMixShader"); mixsh.location = (1240, 60)
    L(rpick.outputs[0], mixsh.inputs["Fac"])
    L(transp.outputs[0], mixsh.inputs[1])
    L(pick.outputs[0], mixsh.inputs[2])
    out = nt.nodes.new("ShaderNodeOutputMaterial"); out.location = (1440, 60)
    L(mixsh.outputs[0], out.inputs["Surface"])
    # ⚠ DITHERED, not BLENDED. BLENDED stops the fill writing depth, so it no longer
    # sorts per pixel against the stroke tubes and covers the object's OWN lines --
    # measured: line ink fell 284,545 -> 164,940 with the house's own linework gone.
    # DITHERED keeps per-pixel depth, so the strokes (tubes of Line Width radius, well
    # in front of the fill's 0.5 mm offset) stay on top. The cost is that a partial
    # dissolve is stochastic rather than a smooth fade.
    if hasattr(mat, "surface_render_method"):
        mat.surface_render_method = 'DITHERED'
    return mat


def build_smudge_material(name):
    """Form-driven shading tone, rendered as smooth smudge OR a screentone
    pattern. The tone pools where the surface turns toward its silhouette
    (Layer Weight Facing) plus an optional true-AO cavity term, with an
    optional faked directional shadow (Cycles-native cel terminator). That
    tone is posterized into hard bands and either drawn smooth (grainy
    graphite) or used to threshold a world-locked pattern — Hatch, Cross-
    hatch, Dots or Stipple — so the pattern density tracks the shading.
    Output is a tinted Transparent BSDF: a colored transparent surface
    multiplies what is behind it, so tone darkens at any scene brightness
    (emission would glow in dark scenes)."""
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()

    def N(t, x, y, **kw):
        nd = nt.nodes.new(t)
        nd.location = (x, y)
        for k, v in kw.items():
            setattr(nd, k, v)
        return nd

    def L(a, b):
        nt.links.new(a, b)

    def M(op, x, y, a=None, b=None, av=None, bv=None, clamp=False):
        nd = N("ShaderNodeMath", x, y, operation=op)
        nd.use_clamp = clamp
        if a is not None:
            L(a, nd.inputs[0])
        elif av is not None:
            nd.inputs[0].default_value = av
        if b is not None:
            L(b, nd.inputs[1])
        elif bv is not None:
            nd.inputs[1].default_value = bv
        return nd.outputs[0]

    def ATN(attr, x, y):
        nd = N("ShaderNodeAttribute", x, y, attribute_type='GEOMETRY')
        nd.attribute_name = attr
        return nd

    out = N("ShaderNodeOutputMaterial", 1600, 0)
    transp = N("ShaderNodeBsdfTransparent", 1400, 0)
    rgb = N("ShaderNodeRGB", 1000, -340)
    rgb.name = rgb.label = "Smudge Color"
    rgb.outputs[0].default_value = (0.07, 0.07, 0.075, 1.0)

    geo = N("ShaderNodeNewGeometry", -1550, -250)
    attr_dist = ATN(ATTR_SMDIST, -1550, 300)

    # --- form tone: pools toward the silhouette (Layer Weight Facing) plus an
    # optional true-AO cavity term. Light-independent, so it works in Cycles.
    blend = M('MAXIMUM', -1300, 300, a=attr_dist.outputs["Fac"], bv=0.05)
    lw = N("ShaderNodeLayerWeight", -1150, 300)
    L(blend, lw.inputs["Blend"])
    face = M('POWER', -950, 300, a=lw.outputs["Facing"], bv=2.0)

    attr_ao = ATN(ATTR_SMAO, -1550, 100)
    ao = N("ShaderNodeAmbientOcclusion", -1300, 80, samples=8)
    L(attr_dist.outputs["Fac"], ao.inputs["Distance"])
    cav = M('SUBTRACT', -1120, 80, av=1.0, b=ao.outputs["AO"])
    cav2 = M('MULTIPLY', -980, 80, a=cav, bv=5.0, clamp=True)
    cav_g = M('MULTIPLY', -840, 80, a=cav2, b=attr_ao.outputs["Fac"])
    form = M('ADD', -680, 200, a=face, b=cav_g, clamp=True)

    # broader shape tone for the pattern styles: normal·view gives a smooth
    # 0 (facing camera) -> 1 (silhouette) gradient across the whole face, so
    # form-hatching reads even without a light (the plain facing term above
    # hugs the rim too tightly for a nice screentone).
    nv = N("ShaderNodeVectorMath", -840, -420, operation='DOT_PRODUCT')
    L(geo.outputs["Normal"], nv.inputs[0])
    L(geo.outputs["Incoming"], nv.inputs[1])
    shape = M('SUBTRACT', -680, -420, av=1.0, b=nv.outputs["Value"])
    form_p = M('MULTIPLY', -540, -420, a=shape, bv=1.3, clamp=True)
    form_p = M('MAXIMUM', -400, -420, a=form_p, b=cav_g)

    # --- optional faked directional shadow (Cycles-native cel terminator):
    # dark where the normal turns from a stored light direction. A zero
    # direction (Use Light Angle off) contributes nothing.
    attr_dir = ATN(ATTR_TDIR, -1550, -100)
    dlen = N("ShaderNodeVectorMath", -1330, -100, operation='LENGTH')
    L(attr_dir.outputs["Vector"], dlen.inputs[0])
    use_light = M('GREATER_THAN', -1160, -140, a=dlen.outputs["Value"], bv=0.5)
    dirn = N("ShaderNodeVectorMath", -1330, -240, operation='NORMALIZE')
    L(attr_dir.outputs["Vector"], dirn.inputs[0])
    ndl = N("ShaderNodeVectorMath", -1160, -260, operation='DOT_PRODUCT')
    L(geo.outputs["Normal"], ndl.inputs[0])
    L(dirn.outputs[0], ndl.inputs[1])
    lamb = M('MAXIMUM', -1000, -260, a=ndl.outputs["Value"], bv=0.0)
    shadow = M('SUBTRACT', -860, -260, av=1.0, b=lamb)
    # pattern tone = mix(form, directional-shadow+cavity, use_light). With Fake
    # Light on the directional shadow IS the tone (a clean cel gradient, no
    # silhouette rim); off, it's the form tone (hatch follows the shape).
    tone_lit = M('ADD', -720, -300, a=shadow, b=cav_g, clamp=True)
    inv_ul = M('SUBTRACT', -720, -180, av=1.0, b=use_light)
    tf = M('MULTIPLY', -560, -180, a=form_p, b=inv_ul)
    tld = M('MULTIPLY', -560, -300, a=tone_lit, b=use_light)
    tone = M('ADD', -420, -240, a=tf, b=tld)

    # --- posterize the tone into hard cel bands
    attr_lev = ATN(ATTR_TLEVELS, -1550, 520)
    lm1 = M('SUBTRACT', -320, 560, a=attr_lev.outputs["Fac"], bv=1.0)
    lm1 = M('MAXIMUM', -180, 560, a=lm1, bv=1.0)
    tl = M('MULTIPLY', -320, 460, a=tone, b=attr_lev.outputs["Fac"])
    tlf = M('FLOOR', -180, 460, a=tl)
    t_q = M('DIVIDE', -40, 500, a=tlf, b=lm1)
    t_q = M('MINIMUM', 100, 500, a=t_q, bv=1.0)

    # pattern mark weight: scales line width / dot size / stipple density
    attr_tw = ATN(ATTR_TWEIGHT, -1550, 720)
    pw = attr_tw.outputs["Fac"]
    tw = M('MULTIPLY', 260, 480, a=t_q, b=pw)

    # --- world-locked pattern coordinates. Build an in-surface tangent frame
    # (T, B) from the world normal, then rotate it by Pattern Angle, so the
    # hatch lies IN the surface and the angle really turns the lines on any
    # facing (a plain world-planar projection stays vertical on walls and the
    # angle does nothing). Keyed to world position, so it still never swims.
    attr_size = ATN(ATTR_SMSIZE, -1550, 920)
    attr_pang = ATN(ATTR_TPANGLE, -1550, 1140)
    ca = M('COSINE', -1330, 1140, a=attr_pang.outputs["Fac"])
    sa = M('SINE', -1330, 1240, a=attr_pang.outputs["Fac"])
    nsa = M('MULTIPLY', -1330, 1340, a=sa, bv=-1.0)

    def vscl(x, y, vec, fac):
        nd = N("ShaderNodeVectorMath", x, y, operation='SCALE')
        L(vec, nd.inputs[0]); L(fac, nd.inputs["Scale"])
        return nd.outputs[0]

    def vadd(x, y, a, b):
        nd = N("ShaderNodeVectorMath", x, y, operation='ADD')
        L(a, nd.inputs[0]); L(b, nd.inputs[1])
        return nd.outputs[0]

    def vdot(x, y, a, b):
        nd = N("ShaderNodeVectorMath", x, y, operation='DOT_PRODUCT')
        L(a, nd.inputs[0]); L(b, nd.inputs[1])
        return nd.outputs["Value"]

    Nv = geo.outputs["Normal"]
    upz = N("ShaderNodeCombineXYZ", -1500, 1000); upz.inputs["Z"].default_value = 1.0
    sepn = N("ShaderNodeSeparateXYZ", -1500, 1120); L(Nv, sepn.inputs[0])
    flat = M('GREATER_THAN', -1330, 1040,
             a=M('ABSOLUTE', -1460, 1040, a=sepn.outputs["Z"]), bv=0.985)
    tcr = N("ShaderNodeVectorMath", -1330, 940, operation='CROSS_PRODUCT')
    L(Nv, tcr.inputs[0]); L(upz.outputs[0], tcr.inputs[1])
    tnr = N("ShaderNodeVectorMath", -1200, 940, operation='NORMALIZE'); L(tcr.outputs[0], tnr.inputs[0])
    tflr = N("ShaderNodeCombineXYZ", -1330, 860); tflr.inputs["X"].default_value = 1.0
    Tmix = N("ShaderNodeMix", -1040, 940, data_type='VECTOR')
    L(flat, next(s for s in Tmix.inputs if s.name == "Factor" and s.enabled))
    L(tnr.outputs[0], next(s for s in Tmix.inputs if s.name == "A" and s.enabled))
    L(tflr.outputs[0], next(s for s in Tmix.inputs if s.name == "B" and s.enabled))
    Tv = next(s for s in Tmix.outputs if s.name == "Result" and s.enabled)
    Bcr = N("ShaderNodeVectorMath", -880, 860, operation='CROSS_PRODUCT')
    L(Nv, Bcr.inputs[0]); L(Tv, Bcr.inputs[1]); Bv = Bcr.outputs[0]

    dir1 = vadd(-680, 960, vscl(-820, 1000, Tv, ca), vscl(-820, 900, Bv, sa))
    dir2 = vadd(-680, 1160, vscl(-820, 1200, Tv, nsa), vscl(-820, 1100, Bv, ca))
    c1 = M('MULTIPLY', -520, 960, a=vdot(-540, 960, geo.outputs["Position"], dir1),
           b=attr_size.outputs["Fac"])
    c2 = M('MULTIPLY', -520, 1160, a=vdot(-540, 1160, geo.outputs["Position"], dir2),
           b=attr_size.outputs["Fac"])

    # Sketchiness: wobble the pattern coordinates with a world-locked noise so
    # the lines wander like hand-drawn hatching instead of ruler-straight ones.
    attr_sk = ATN(ATTR_TSKETCH, -1550, 520)
    skamt = M('MULTIPLY', -1400, 520, a=attr_sk.outputs["Fac"], bv=1.6)
    skfreq = M('MULTIPLY', -1400, 620, a=attr_size.outputs["Fac"], bv=0.35)
    wnz = N("ShaderNodeTexNoise", -1250, 560, noise_dimensions='3D')
    wnz.inputs["Detail"].default_value = 2.0
    L(geo.outputs["Position"], wnz.inputs["Vector"])
    L(skfreq, wnz.inputs["Scale"])
    wsep = N("ShaderNodeSeparateXYZ", -1080, 560)
    L(wnz.outputs["Color"], wsep.inputs[0])
    wx = M('MULTIPLY', -380, 700, a=M('SUBTRACT', -520, 700, a=wsep.outputs["X"], bv=0.5), b=skamt)
    wy = M('MULTIPLY', -380, 780, a=M('SUBTRACT', -520, 780, a=wsep.outputs["Y"], bv=0.5), b=skamt)
    c1 = M('ADD', -240, 960, a=c1, b=wx)
    c2 = M('ADD', -240, 1160, a=c2, b=wy)

    def line_dist(c, x, y):
        fr = M('FRACT', x, y, a=c)
        dd = M('SUBTRACT', x + 140, y, a=fr, bv=0.5)
        dd = M('ABSOLUTE', x + 280, y, a=dd)
        return M('MULTIPLY', x + 420, y, a=dd, bv=2.0)

    dcn1 = line_dist(c1, -500, 1100)
    dcn2 = line_dist(c2, -500, 1320)

    # Hatch widens lines with the (weighted) tone; Cross-hatch adds a second
    # set in the dark half. Pattern Weight scales the line width.
    hatch = M('LESS_THAN', 220, 1100, a=dcn1, b=tw)
    t2 = M('SUBTRACT', 220, 1340, a=t_q, bv=0.5)
    t2 = M('MULTIPLY', 360, 1340, a=t2, bv=2.0, clamp=True)
    t2 = M('MULTIPLY', 460, 1340, a=t2, b=pw)
    cross2 = M('LESS_THAN', 580, 1340, a=dcn2, b=t2)
    cross = M('MAXIMUM', 700, 1200, a=hatch, b=cross2)

    # Dots: halftone circles that grow with tone (radius = √tone, area ∝ tone)
    fr1 = M('FRACT', 220, 900, a=c1)
    fr2 = M('FRACT', 360, 900, a=c2)
    cxv = M('SUBTRACT', 500, 940, a=fr1, bv=0.5)
    cyv = M('SUBTRACT', 500, 860, a=fr2, bv=0.5)
    cell = N("ShaderNodeCombineXYZ", 640, 900)
    L(cxv, cell.inputs["X"])
    L(cyv, cell.inputs["Y"])
    rlen = N("ShaderNodeVectorMath", 780, 900, operation='LENGTH')
    L(cell.outputs[0], rlen.inputs[0])
    r2 = M('MULTIPLY', 920, 900, a=rlen.outputs["Value"], bv=2.0)
    rad = M('SQRT', 920, 800, a=t_q)
    rad = M('MULTIPLY', 1060, 800, a=rad, bv=1.4)
    rad = M('MULTIPLY', 1180, 800, a=rad, b=pw)
    dots = M('LESS_THAN', 1320, 880, a=r2, b=rad)

    # Stipple: dark ink dots on light — ink at the noise PEAKS (isolated specks),
    # density rising with tone (× weight), so it reads as pointillist dots rather
    # than a solid field with light holes.
    stn = N("ShaderNodeTexNoise", 220, 700, noise_dimensions='3D')
    stn.inputs["Detail"].default_value = 3.0
    L(geo.outputs["Position"], stn.inputs["Vector"])
    L(attr_size.outputs["Fac"], stn.inputs["Scale"])
    stip_th = M('SUBTRACT', 360, 620, av=1.0, b=tw)
    stip = M('GREATER_THAN', 520, 700, a=stn.outputs["Fac"], b=stip_th)

    # --- style select: 0 Smudge · 1 Hatch · 2 Cross-hatch · 3 Dots · 4 Stipple
    attr_style = ATN(ATTR_TSTYLE, -700, -560)
    st = attr_style.outputs["Fac"]

    def is_style(k, x, y):
        dd = M('SUBTRACT', x, y, a=st, bv=float(k))
        dd = M('ABSOLUTE', x + 140, y, a=dd)
        return M('LESS_THAN', x + 280, y, a=dd, bv=0.5)

    p1 = M('MULTIPLY', 940, 1200, a=hatch, b=is_style(1, 300, 1500))
    p2 = M('MULTIPLY', 940, 1340, a=cross, b=is_style(2, 300, 1570))
    p3 = M('MULTIPLY', 1360, 880, a=dots, b=is_style(3, 300, 1640))
    p4 = M('MULTIPLY', 780, 700, a=stip, b=is_style(4, 300, 1710))
    pat = M('ADD', 1120, 1120, a=p1, b=p2)
    pat = M('ADD', 1260, 1120, a=pat, b=p3)
    pat = M('ADD', 1400, 1120, a=pat, b=p4)

    # Flat: the posterized tone drawn as a SOLID tint (no pattern) — clean
    # cel / SketchUp-style flat face shading with Fake Light + Levels + AO.
    flat_cov = M('MULTIPLY', 1120, 980, a=t_q, b=is_style(5, 300, 1780))

    # --- smooth Smudge path (world-locked graphite grain), the default style
    snoise = N("ShaderNodeTexNoise", -980, -420, noise_dimensions='3D')
    snoise.inputs["Detail"].default_value = 8.0
    snoise.inputs["Roughness"].default_value = 0.65
    L(geo.outputs["Position"], snoise.inputs["Vector"])
    L(attr_size.outputs["Fac"], snoise.inputs["Scale"])
    streak = M('SUBTRACT', -800, -420, a=snoise.outputs["Fac"], bv=0.5)
    streakc = M('MULTIPLY', -660, -420, a=streak, bv=2.5)
    streak2 = M('ADD', -520, -420, a=streakc, bv=0.72, clamp=True)
    smooth = M('MULTIPLY', -320, -320, a=form, b=streak2)

    # coverage = (style is Smudge) ? smooth : pattern
    is_sm = M('LESS_THAN', 760, -180, a=st, bv=0.5)
    inv_sm = M('SUBTRACT', 900, -180, av=1.0, b=is_sm)
    cov_a = M('MULTIPLY', 1040, -120, a=smooth, b=is_sm)
    cov_b = M('MULTIPLY', 1040, -260, a=pat, b=inv_sm)
    coverage = M('ADD', 1180, -180, a=cov_a, b=cov_b)
    coverage = M('ADD', 1320, -220, a=coverage, b=flat_cov)

    # --- strength, backface kill, tint into a transparent BSDF (multiplies the
    # scene behind it, so tone darkens at any brightness instead of glowing)
    attr_amt = ATN(ATTR_SMUDGE, 1040, -420)
    a2 = M('MULTIPLY', 1260, -300, a=coverage, b=attr_amt.outputs["Fac"], clamp=True)
    bf_inv = M('SUBTRACT', 1260, -460, av=1.0, b=geo.outputs["Backfacing"])
    a3 = M('MULTIPLY', 1400, -360, a=a2, b=bf_inv)
    # occlusion: fade tone where the surface is hidden from the camera (set by
    # the raycast in the node group), so the shading matches the line occlusion
    attr_vis = ATN(ATTR_SMVIS, 1040, -560)
    a4 = M('MULTIPLY', 1500, -400, a=a3, b=attr_vis.outputs["Fac"])

    # --- sharp-edge darkening: compare the true normal to a bevel-smoothed one;
    # where they diverge is a hard edge/crease, so add a soft dark accent there.
    # (Bevel is a Cycles feature — in EEVEE it's a no-op, so no edge accent.)
    attr_edge = ATN(ATTR_TEDGE, 1040, -700)
    bev = N("ShaderNodeBevel", 1200, -680)
    bev.samples = 8
    bev.inputs["Radius"].default_value = 0.04
    ednt = N("ShaderNodeVectorMath", 1360, -680, operation='DOT_PRODUCT')
    L(geo.outputs["Normal"], ednt.inputs[0])
    L(bev.outputs["Normal"], ednt.inputs[1])
    edge = M('SUBTRACT', 1500, -680, av=1.0, b=ednt.outputs["Value"])
    edge = M('MULTIPLY', 1620, -680, a=edge, bv=8.0, clamp=True)
    edge_t = M('MULTIPLY', 1740, -680, a=edge, b=attr_edge.outputs["Fac"])
    edge_t = M('MULTIPLY', 1620, -560, a=edge_t, b=bf_inv)
    edge_t = M('MULTIPLY', 1740, -560, a=edge_t, b=attr_vis.outputs["Fac"])
    a5 = M('ADD', 1620, -400, a=a4, b=edge_t, clamp=True)

    tint = N("ShaderNodeMix", 1900, 0, data_type='RGBA')
    fac_in = next(s for s in tint.inputs if s.name == "Factor" and s.enabled)
    a_in = next(s for s in tint.inputs if s.name == "A" and s.enabled)
    b_in = next(s for s in tint.inputs if s.name == "B" and s.enabled)
    a_in.default_value = (1.0, 1.0, 1.0, 1.0)
    L(a5, fac_in)
    L(rgb.outputs[0], b_in)
    res_out = next(s for s in tint.outputs if s.name == "Result" and s.enabled)
    L(res_out, transp.inputs["Color"])
    L(transp.outputs[0], out.inputs["Surface"])

    if hasattr(mat, "surface_render_method"):
        mat.surface_render_method = 'BLENDED'
    return mat


# ---------------------------------------------------------------------------
# Media presets — look parameters only (width, wobble, breakup, grain,
# strokes, color). Edge selection and occlusion are scene decisions and are
# deliberately never touched by a preset.
# ---------------------------------------------------------------------------

def _preset(width, wob, wsize, wcomp, strokes, op, osize, th, tsize,
            grain, gsize, color, boil=0.0, smudge=0.0, taper=0.5):
    return {"sockets": {
        "Line Width": width,
        "Wobble Amount": wob, "Wobble Size": wsize, "Wobble Complexity": wcomp,
        "Strokes": strokes, "Boil Rate": boil,
        "Opacity Breakup": op, "Opacity Size": osize,
        "Thickness Breakup": th, "Thickness Size": tsize,
        "Grain": grain, "Grain Size": gsize,
        "Smudge": smudge, "Line Taper": taper,
    }, "color": color}


PRESETS = {
    # pencils
    "2H Pencil":       _preset(6.0,  4, 10, 2, 1, 0.30, 1.2, 0.45, 2.0, 0.5, 0.20, (0.25, 0.25, 0.27, 1.0), taper=0.45),
    "HB Pencil":       _preset(9.0,  5, 12, 2, 1, 0.30, 1.5, 0.50, 2.5, 0.7, 0.25, (0.11, 0.11, 0.12, 1.0), taper=0.5),
    "6B Pencil":       _preset(14.0,  6, 12, 3, 1, 0.35, 2.0, 0.60, 3.0, 1.0, 0.35, (0.045, 0.045, 0.05, 1.0), smudge=0.35, taper=0.6),
    "Colored Pencil":  _preset(10.0,  6, 11, 2, 1, 0.40, 1.5, 0.55, 2.0, 0.9, 0.30, (0.02, 0.12, 0.40, 1.0), taper=0.45),
    # charcoal & chalk  (widths trimmed — the set read too heavy; taper feathers the ends)
    "Charcoal":        _preset(18.0, 12, 15, 3, 1, 0.40, 3.0, 0.70, 4.0, 1.8, 0.60, (0.03, 0.03, 0.03, 1.0), smudge=0.45, taper=0.7),
    "Willow Charcoal": _preset(26.0, 15, 18, 3, 1, 0.50, 4.0, 0.75, 5.0, 2.5, 0.90, (0.06, 0.06, 0.06, 1.0), smudge=0.6, taper=0.8),
    "Conte Sanguine":  _preset(14.0,  8, 14, 2, 1, 0.35, 2.5, 0.60, 3.5, 1.4, 0.45, (0.35, 0.10, 0.04, 1.0), smudge=0.4, taper=0.6),
    "Chalk":           _preset(16.0, 10, 14, 2, 1, 0.40, 2.5, 0.60, 3.0, 1.6, 0.50, (0.92, 0.93, 0.90, 1.0), smudge=0.35, taper=0.65),
    # pens
    "Technical Pen":   _preset(6.0,  1, 20, 0, 1, 0.00, 2.0, 0.00, 3.0, 0.0, 0.20, (0.0, 0.0, 0.0, 1.0), taper=0.0),
    "Fineliner":       _preset(9.0,  4, 15, 1, 1, 0.10, 2.0, 0.25, 3.0, 0.15, 0.15, (0.02, 0.02, 0.02, 1.0), taper=0.1),
    "Ballpoint":       _preset(7.0,  5,  8, 2, 2, 0.45, 1.0, 0.30, 2.0, 0.30, 0.15, (0.02, 0.03, 0.10, 1.0), taper=0.3),
    "Fountain Pen":    _preset(10.0,  4, 18, 1, 1, 0.15, 3.0, 0.55, 6.0, 0.10, 0.20, (0.03, 0.05, 0.14, 1.0), taper=0.55),
    # ink & brush
    "Ink Brush":       _preset(24.0,  9, 20, 2, 1, 0.25, 4.0, 0.85, 8.0, 0.8, 0.70, (0.01, 0.01, 0.015, 1.0), taper=0.85),
    "Dry Brush":       _preset(28.0, 10, 16, 2, 1, 0.50, 3.0, 0.70, 5.0, 2.8, 1.10, (0.02, 0.02, 0.02, 1.0), smudge=0.3, taper=0.7),
    "Woodcut":         _preset(45.0,  8, 25, 1, 1, 0.15, 5.0, 0.80, 7.0, 0.6, 0.50, (0.02, 0.015, 0.015, 1.0), taper=0.15),
    # wax & pastel
    "Wax Crayon":      _preset(16.0, 18, 10, 1, 1, 0.45, 1.5, 0.50, 2.0, 1.1, 0.30, (0.13, 0.05, 0.03, 1.0), taper=0.4),
    "Soft Pastel":     _preset(28.0, 12, 16, 2, 1, 0.45, 3.0, 0.60, 4.0, 2.0, 0.80, (0.22, 0.13, 0.08, 1.0), smudge=0.55, taper=0.7),
    # stylized
    "Architect Sepia": _preset(8.0,  8, 25, 2, 2, 0.30, 2.5, 0.45, 4.0, 0.4, 0.30, (0.16, 0.09, 0.04, 1.0), taper=0.4),
    "Blueprint":       _preset(6.0,  2, 20, 1, 1, 0.15, 2.0, 0.10, 3.0, 0.2, 0.20, (0.85, 0.90, 0.98, 1.0), taper=0.0),
    "Boiling Sketch":  _preset(12.0, 18, 14, 3, 3, 0.35, 2.0, 0.50, 3.0, 0.6, 0.30, (0.03, 0.03, 0.03, 1.0), boil=8.0, taper=0.55),
}

PRESET_GROUPS = [
    ("Pencil", ["2H Pencil", "HB Pencil", "6B Pencil", "Colored Pencil"]),
    ("Charcoal & Chalk", ["Charcoal", "Willow Charcoal", "Conte Sanguine", "Chalk"]),
    ("Pen", ["Technical Pen", "Fineliner", "Ballpoint", "Fountain Pen"]),
    ("Ink & Brush", ["Ink Brush", "Dry Brush", "Woodcut"]),
    ("Wax & Pastel", ["Wax Crayon", "Soft Pastel"]),
    ("Stylized", ["Architect Sepia", "Blueprint", "Boiling Sketch"]),
]

# the look parameters a preset owns (built-in and user alike; user presets
# additionally capture the dash pattern and smudge shaping)
PRESET_SOCKET_NAMES = list(next(iter(PRESETS.values()))["sockets"].keys()) + [
    "Dash Length", "Dash Gap", "Smudge Distance", "Smudge Size", "Overshoot",
    "Overshoot Random"]


def user_preset_dir(create=False):
    return bpy.utils.user_resource(
        'SCRIPTS', path=os.path.join("presets", "sketchy_lineart"), create=create)


def _safe_preset_name(name):
    return re.sub(r'[^\w\- ()]', '', name).strip()


def load_user_presets():
    out = {}
    d = user_preset_dir()
    if not d or not os.path.isdir(d):
        return out
    for fn in sorted(os.listdir(d)):
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(d, fn)) as f:
                data = json.load(f)
            if "sockets" in data and "color" in data:
                out[os.path.splitext(fn)[0]] = data
        except Exception:
            continue
    return out


# --- preset thumbnails: a previews collection maps preset name -> icon id, ----
# loading a rendered <name>.png from the preset folder on demand.
_preset_previews = None


def _preset_thumb_path(name, create=False):
    d = user_preset_dir(create=create)
    return os.path.join(d, _safe_preset_name(name) + ".png") if d else None


def _preset_icon(name):
    """Icon id for a preset's thumbnail, or 0 if none rendered yet."""
    if _preset_previews is None:
        return 0
    if name in _preset_previews:
        return _preset_previews[name].icon_id
    p = _preset_thumb_path(name)
    if not p or not os.path.exists(p):
        return 0
    try:
        return _preset_previews.load(name, p, 'IMAGE').icon_id
    except Exception:
        return 0


# Thumbnails render on a FIXED standard subject — a Suzanne framed tight — in a
# throwaway scene, so previews are consistent, legible, and independent of the
# user's scene/camera. Keeping this deterministic means future thumbnails match.
def _build_preset_preview(engine):
    """Build the standard preset-preview scene: a smooth Suzanne with a Sketchy
    line set, framed close, neutral world. Returns (scene, host, made) where
    `made` is the list of datablocks to free in _teardown_preview."""
    import math
    import mathutils
    made = []
    # a single sweeping stroke: a polyline whose edges are forced into the line art
    # via the sketchy_include attribute. Shown flat and large, it reads like a brush
    # swatch — you can see the line's weight, texture, colour and end taper clearly.
    N = 48
    verts = [((i / (N - 1) - 0.5) * 0.26, 0.0, 0.035 * math.sin(i / (N - 1) * math.tau))
             for i in range(N)]
    edges = [(i, i + 1) for i in range(N - 1)]
    me = bpy.data.meshes.new("Sk_Preview_Swatch")
    me.from_pydata(verts, edges, [])
    me.update()
    inc = me.attributes.new(ATTR_INCLUDE, 'BOOLEAN', 'EDGE')
    for d in inc.data:
        d.value = True
    stroke = bpy.data.objects.new("Sk_Preview_Swatch", me)
    src = bpy.data.collections.new("Sk_Preview_src")
    src.objects.link(stroke)
    made += [("obj", stroke), ("mesh", me), ("coll", src)]

    scene = bpy.data.scenes.new("Sk_Preview")
    scene.render.engine = engine
    scene.render.resolution_x = scene.render.resolution_y = 256
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = 'PNG'
    scene.collection.children.link(src)
    made.append(("scene", scene))
    try:
        scene.cycles.samples = 12
    except Exception:
        pass
    try:
        scene.eevee.taa_render_samples = 12
    except Exception:
        pass

    wd = bpy.data.worlds.new("Sk_Preview_W")
    wd.use_nodes = True
    wd.node_tree.nodes["Background"].inputs[0].default_value = (0.94, 0.94, 0.95, 1.0)
    scene.world = wd
    made.append(("world", wd))

    cam_data = bpy.data.cameras.new("Sk_Preview_Cam")
    cam_data.type = 'ORTHO'
    cam_data.ortho_scale = 0.31
    cam = bpy.data.objects.new("Sk_Preview_Cam", cam_data)
    cam.location = (0.0, -2.0, 0.0)
    look = (mathutils.Vector((0.0, 0.0, 0.0)) - cam.location).normalized()
    cam.rotation_euler = look.to_track_quat('-Z', 'Y').to_euler()
    scene.collection.objects.link(cam)
    scene.camera = cam
    made += [("obj", cam), ("cam", cam_data)]

    tree = build_node_group()   # shared group; socket values are per-modifier
    hmesh = bpy.data.meshes.new("Sk_Preview_HostMesh")
    host = bpy.data.objects.new("Sk_Preview_Host", hmesh)
    scene.collection.objects.link(host)
    md = host.modifiers.new(MODIFIER_NAME, 'NODES')
    md.node_group = tree
    lm = build_line_material("Sk_Preview_Line")
    sm = build_smudge_material("Sk_Preview_Smudge")
    fm = build_fill_material("Sk_Preview_Fill")
    mi_set(md, socket_identifier(tree, "Line Collection"), src)
    mi_set(md, socket_identifier(tree, "Material"), lm)
    mi_set(md, socket_identifier(tree, "Smudge Material"), sm)
    mi_set(md, socket_identifier(tree, "Fill Material"), fm)
    made += [("obj", host), ("mesh", hmesh), ("mat", lm), ("mat", sm), ("mat", fm)]
    return scene, host, made


def _teardown_preview(made):
    removers = {
        "obj": bpy.data.objects, "mesh": bpy.data.meshes, "coll": bpy.data.collections,
        "scene": bpy.data.scenes, "world": bpy.data.worlds, "cam": bpy.data.cameras,
        "mat": bpy.data.materials,
    }
    for kind, db in reversed(made):
        try:
            coll = removers.get(kind)
            if coll and db is not None:
                if kind == "obj":
                    coll.remove(db, do_unlink=True)
                else:
                    coll.remove(db)
        except Exception:
            pass


class SKETCHY_OT_save_preset(bpy.types.Operator):
    bl_idname = "sketchy.save_preset"
    bl_label = "Save User Preset"
    bl_description = "Save this line set's look (width, wobble, breakup, grain, " \
                     "color) as a named preset, available in every scene"
    bl_options = {'REGISTER'}

    preset_name: bpy.props.StringProperty(name="Name", default="My Media")

    @classmethod
    def poll(cls, context):
        return active_line_set(context.scene) is not None

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, "preset_name")

    def execute(self, context):
        name = _safe_preset_name(self.preset_name)
        if not name:
            self.report({'WARNING'}, "Give the preset a name")
            return {'CANCELLED'}
        if name in PRESETS:
            self.report({'WARNING'}, f"'{name}' is a built-in preset name, pick another")
            return {'CANCELLED'}

        obj = active_line_set(context.scene)
        mod = next((m for m in obj.modifiers
                    if m.type == 'NODES' and m.node_group
                    and m.node_group.name == NODE_GROUP_NAME), None)
        if mod is None:
            self.report({'WARNING'}, "Active line set has no sketchy modifier")
            return {'CANCELLED'}

        tree = mod.node_group
        sockets = {}
        for item in tree.interface.items_tree:
            if item.item_type != 'SOCKET' or item.in_out != 'INPUT':
                continue
            if item.name not in PRESET_SOCKET_NAMES:
                continue
            val = mi_get(mod, item.identifier)
            if val is None:
                continue
            if item.socket_type == 'NodeSocketInt':
                sockets[item.name] = int(val)
            else:
                sockets[item.name] = float(val)

        color = (0.0, 0.0, 0.0, 1.0)
        mat = mi_get(mod, socket_identifier(tree, "Material"))
        if mat and mat.node_tree:
            rgb = mat.node_tree.nodes.get("Line Color")
            if rgb:
                color = tuple(rgb.outputs[0].default_value)

        d = user_preset_dir(create=True)
        path = os.path.join(d, name + ".json")
        with open(path, "w") as f:
            json.dump({"sockets": sockets, "color": list(color)}, f, indent=2)
        self.report({'INFO'}, f"Saved preset '{name}'")
        return {'FINISHED'}


class SKETCHY_OT_delete_preset(bpy.types.Operator):
    bl_idname = "sketchy.delete_preset"
    bl_label = "Delete User Preset"
    bl_description = "Delete this saved preset file"

    preset: bpy.props.StringProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        name = _safe_preset_name(self.preset)
        path = os.path.join(user_preset_dir(), name + ".json")
        if os.path.isfile(path):
            os.remove(path)
            self.report({'INFO'}, f"Deleted preset '{name}'")
            return {'FINISHED'}
        self.report({'WARNING'}, f"Preset file for '{name}' not found")
        return {'CANCELLED'}


class SKETCHY_MT_delete_presets(bpy.types.Menu):
    bl_idname = "SKETCHY_MT_delete_presets"
    bl_label = "Delete User Preset"

    def draw(self, context):
        for n in load_user_presets():
            op = self.layout.operator("sketchy.delete_preset", text=n)
            op.preset = n


def apply_preset_data(obj, preset_name):
    """Apply a media preset's look to a line-set object. Plain function so both
    the operator and the thumbnail-picker's update callback can use it."""
    data = PRESETS.get(preset_name) or load_user_presets().get(preset_name)
    if data is None or obj is None:
        return False
    mod = next((m for m in obj.modifiers
                if m.type == 'NODES' and m.node_group
                and m.node_group.name == NODE_GROUP_NAME), None)
    if mod is None:
        return False
    tree = mod.node_group
    for item in tree.interface.items_tree:
        if item.item_type != 'SOCKET' or item.in_out != 'INPUT':
            continue
        if item.name not in data["sockets"]:
            continue
        val = data["sockets"][item.name]
        if item.socket_type == 'NodeSocketInt':
            mi_set(mod, item.identifier, int(val))
        elif item.socket_type == 'NodeSocketBool':
            mi_set(mod, item.identifier, bool(val))
        else:
            mi_set(mod, item.identifier, float(val))
    # section enables are DERIVED from their amounts (like Smudge/Overshoot),
    # so a preset with no breakup (e.g. Technical Pen) turns Breakup off and a
    # preset that uses wobble turns it on even if the set had it disabled.
    sm_id = socket_identifier(tree, "Smudge Enable")
    if sm_id is not None:
        mi_set(mod, sm_id, data["sockets"].get("Smudge", 0.0) > 0.0005)
    # a preset may introduce SMUDGE shading, but never hatching/screentone —
    # those are deliberate stylistic choices. So when a preset turns shading on,
    # force the soft Smudge style rather than inheriting the set's current style.
    if data["sockets"].get("Smudge", 0.0) > 0.0005:
        mi_set_menu(mod, socket_identifier(tree, "Shading Style"), "Smudge")
    we_id = socket_identifier(tree, "Wobble Enable")
    if we_id is not None:
        mi_set(mod, we_id, data["sockets"].get("Wobble Amount", 0.0) > 0.0005)
    be_id = socket_identifier(tree, "Breakup Enable")
    if be_id is not None:
        _bk = max(data["sockets"].get("Opacity Breakup", 0.0),
                  data["sockets"].get("Thickness Breakup", 0.0),
                  data["sockets"].get("Grain", 0.0))
        mi_set(mod, be_id, _bk > 0.0005)
    if "Overshoot" in data["sockets"] or "Overshoot Random" in data["sockets"]:
        oe_id = socket_identifier(tree, "Overshoot Enable")
        if oe_id is not None:
            ov = data["sockets"].get("Overshoot", 0.0)
            orn = data["sockets"].get("Overshoot Random", 0.0)
            mi_set(mod, oe_id, (abs(ov) > 0.0005 or orn > 0.0005))
    mat = mi_get(mod, socket_identifier(tree, "Material"))
    if mat and mat.node_tree:
        for node_name in ("Line Color", "Hidden Color"):
            n = mat.node_tree.nodes.get(node_name)
            if n:
                n.outputs[0].default_value = data["color"]
    obj.update_tag()
    return True


class SKETCHY_OT_apply_preset(bpy.types.Operator):
    bl_idname = "sketchy.apply_preset"
    bl_label = "Apply Media Preset"
    bl_description = "Set this line set's look to a traditional-media preset " \
                     "(edge selection and occlusion settings are left alone)"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.StringProperty()
    target: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.target)
        if not apply_preset_data(obj, self.preset):
            self.report({'WARNING'}, "Preset or line set not found")
            return {'CANCELLED'}
        for area in context.screen.areas:
            area.tag_redraw()
        self.report({'INFO'}, f"Applied '{self.preset}' to '{obj.name}'")
        return {'FINISHED'}


class SKETCHY_MT_presets(bpy.types.Menu):
    bl_idname = "SKETCHY_MT_presets"
    bl_label = "Style Presets"

    def draw(self, context):
        layout = self.layout
        obj = getattr(context, "sketchy_lineset", None)
        if obj is None:
            layout.label(text="No line set")
            return
        for group, names in PRESET_GROUPS:
            layout.separator()
            layout.label(text=group)
            for n in names:
                op = layout.operator("sketchy.apply_preset", text=n)
                op.preset = n
                op.target = obj.name

        user = load_user_presets()
        if user:
            layout.separator()
            layout.label(text="User")
            for n in user:
                op = layout.operator("sketchy.apply_preset", text=n, icon='USER')
                op.preset = n
                op.target = obj.name
            layout.separator()
            layout.menu("SKETCHY_MT_delete_presets", icon='TRASH')


class SKETCHY_OT_render_thumbnails(bpy.types.Operator):
    bl_idname = "sketchy.render_thumbnails"
    bl_label = "Render Preset Thumbnails"
    bl_description = "Render a preview of every preset on a standard Suzanne, for " \
                     "the browser. Doesn't touch your scene. Takes a moment"
    bl_options = {'REGISTER'}

    target: bpy.props.StringProperty()

    def execute(self, context):
        names = [n for _, ns in PRESET_GROUPS for n in ns] + list(load_user_presets().keys())
        d = user_preset_dir(create=True)
        if not d:
            self.report({'WARNING'}, "No preset folder")
            return {'CANCELLED'}
        scene, host, made = _build_preset_preview(context.scene.render.engine)
        bg_node = scene.world.node_tree.nodes["Background"]
        try:
            for n in names:
                # light-coloured lines (chalk, blueprint, other inverted styles)
                # vanish on paper — put them on a dark ground instead
                data = PRESETS.get(n) or load_user_presets().get(n) or {}
                c = data.get("color", (0.0, 0.0, 0.0, 1.0))
                lum = 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]
                bg_node.inputs[0].default_value = ((0.12, 0.12, 0.14, 1.0) if lum > 0.5
                                                   else (0.94, 0.94, 0.95, 1.0))
                apply_preset_data(host, n)
                scene.render.filepath = os.path.join(d, _safe_preset_name(n) + ".png")
                bpy.ops.render.render(write_still=True, scene=scene.name)
                if _preset_previews is not None and n in _preset_previews:
                    del _preset_previews[n]   # drop cache so the fresh PNG reloads
        finally:
            _teardown_preview(made)
        self.report({'INFO'}, f"Rendered {len(names)} preset thumbnails")
        return {'FINISHED'}


# --- native thumbnail picker (template_icon_view): the thumbnail itself is the
# clickable link; the picker opens a scrollable grid of large previews. ----------
_preset_enum_cache = []   # keep item-tuple refs alive (Blender enum gotcha)


def _preset_enum_items(self, context):
    items = []
    i = 0
    for _group, names in PRESET_GROUPS:
        for n in names:
            items.append((n, n, n, _preset_icon(n), i))
            i += 1
    for n in load_user_presets():
        items.append((n, n, n, _preset_icon(n), i))
        i += 1
    global _preset_enum_cache
    _preset_enum_cache = items
    return items


def _preset_enum_apply(self, context):
    sel = getattr(context.window_manager, "sketchy_preset_sel", "")
    obj = active_line_set(context.scene)
    if sel and obj:
        apply_preset_data(obj, sel)


# ---------------------------------------------------------------------------
# Line set management
# ---------------------------------------------------------------------------

def line_set_objects(scene):
    return [o for o in scene.objects if o.get(MARKER_PROP)]


def active_line_set(scene):
    idx = scene.sketchy_active_index
    if 0 <= idx < len(scene.objects) and scene.objects[idx].get(MARKER_PROP):
        return scene.objects[idx]
    return None


def socket_identifier(tree, name):
    for item in tree.interface.items_tree:
        if item.item_type == 'SOCKET' and item.in_out == 'INPUT' and item.name == name:
            return item.identifier
    return None


# ---------------------------------------------------------------------------
# Modifier-input compatibility. Blender 5.2 moved Geometry Nodes modifier inputs
# off the modifier's id-properties (mod["Socket_N"]) onto a per-socket struct at
# mod.properties.inputs.<id>.value. These three helpers hide the difference so
# the rest of the add-on reads/writes/draws sockets the same on 5.1 and 5.2.
# ---------------------------------------------------------------------------
def _mod_inputs(mod):
    """The 5.2 inputs struct, or None on <=5.1 (legacy id-property access)."""
    props = getattr(mod, "properties", None)
    return getattr(props, "inputs", None) if props is not None else None


def mi_get(mod, ident, default=None):
    """Read a modifier input by socket identifier (None-safe, like dict.get)."""
    if ident is None:
        return default
    inp = _mod_inputs(mod)
    if inp is None:
        v = mod.get(ident)
        return default if v is None else v
    sock = getattr(inp, ident, None)
    return default if sock is None else sock.value


def mi_set(mod, ident, val):
    """Write a modifier input by socket identifier."""
    if ident is None:
        return
    inp = _mod_inputs(mod)
    if inp is None:
        mod[ident] = val
    else:
        sock = getattr(inp, ident, None)
        if sock is not None:
            sock.value = val


def mi_prop(layout, mod, ident, **kw):
    """layout.prop() for a modifier input, keyframeable on both APIs."""
    inp = _mod_inputs(mod)
    if inp is None:
        layout.prop(mod, '["%s"]' % ident, **kw)
    else:
        sock = getattr(inp, ident, None)
        if sock is not None:
            layout.prop(sock, "value", **kw)


def mi_set_menu(mod, ident, item_name):
    """Set a menu socket to the item called `item_name`. On 5.2 the value is the
    enum identifier string; on 5.1 it's an int id-property with an items list, so
    map the name to its integer value there."""
    if ident is None:
        return
    inp = _mod_inputs(mod)
    if inp is not None:                       # 5.2: enum string
        sock = getattr(inp, ident, None)
        if sock is not None:
            sock.value = item_name
        return
    try:                                       # 5.1: int id-property
        items = mod.id_properties_ui(ident).as_dict().get("items", [])
        for it in items:
            if it[1] == item_name:
                mod[ident] = it[4]
                return
    except Exception:
        pass


class SKETCHY_OT_add_line_set(bpy.types.Operator):
    bl_idname = "sketchy.add_line_set"
    bl_label = "Add Line Set"
    bl_description = "Create a sketchy line art set for a collection (each set has " \
                     "its own collection, settings and material)"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(context.scene, "sketchy_target_collection", text="Collection")

    def execute(self, context):
        coll = context.scene.sketchy_target_collection
        if coll is None:
            self.report({'WARNING'}, "Pick a collection first")
            return {'CANCELLED'}

        tree = build_node_group()
        mesh = bpy.data.meshes.new(f"SketchwerksLines_{coll.name}")
        obj = bpy.data.objects.new(f"{LINESET_COLLECTION} — {coll.name}", mesh)
        obj[MARKER_PROP] = True
        host = bpy.data.collections.get(LINESET_COLLECTION)
        if host is None:
            host = bpy.data.collections.new(LINESET_COLLECTION)
            context.scene.collection.children.link(host)
        host.objects.link(obj)

        # The node tree treats RELATIVE space as world space, which only
        # holds while this object sits untransformed at the origin.
        obj.lock_location = obj.lock_rotation = (True, True, True)
        obj.lock_scale = (True, True, True)

        for flag in ("visible_shadow", "visible_diffuse", "visible_glossy",
                     "visible_transmission", "visible_volume_scatter"):
            if hasattr(obj, flag):
                setattr(obj, flag, False)

        mod = obj.modifiers.new(MODIFIER_NAME, 'NODES')
        mod.node_group = tree
        mat = build_line_material(f"SketchwerksLine_{coll.name}")
        smat = build_smudge_material(f"SketchwerksSmudge_{coll.name}")
        fmat = build_fill_material(f"SketchwerksFill_{coll.name}")
        mi_set(mod, socket_identifier(tree, "Line Collection"), coll)
        mi_set(mod, socket_identifier(tree, "Material"), mat)
        mi_set(mod, socket_identifier(tree, "Smudge Material"), smat)
        mi_set(mod, socket_identifier(tree, "Fill Material"), fmat)

        # menu sockets start unset (-1); default each to its first item
        for _menu in ("Draw Easing", "Shading Style"):
            mid = socket_identifier(tree, _menu)
            if mid is not None:
                try:
                    items = mod.id_properties_ui(mid).as_dict().get("items", [])
                    if items:
                        mi_set(mod, mid, items[0][4])
                except Exception:
                    pass

        # adopt the scene's shared occluder so a rebuilt set still hides behind
        # (and is hidden by) the others without re-wiring by hand
        occ_id = socket_identifier(tree, "Occlude Against")
        if occ_id is not None and context.scene.sketchy_occluder is not None:
            mi_set(mod, occ_id, context.scene.sketchy_occluder)

        context.view_layer.objects.active = obj
        idx = context.scene.objects.find(obj.name)
        if idx >= 0:
            context.scene.sketchy_active_index = idx
        self.report({'INFO'}, f"Line set created for '{coll.name}'")
        # ⚠ keep the shared occluder set current: a line set added or removed later
        # would otherwise leave it stale, and a brand new set occludes nothing at all.
        try:
            _rebuild_occluder_set(context)
        except Exception:
            pass
        return {'FINISHED'}


class SKETCHY_OT_remove_line_set(bpy.types.Operator):
    bl_idname = "sketchy.remove_line_set"
    bl_label = "Remove Line Set"
    bl_description = "Delete the selected line set object (source meshes and edge " \
                     "marks are untouched)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return active_line_set(context.scene) is not None

    def execute(self, context):
        obj = active_line_set(context.scene)
        name = obj.name
        mesh = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if mesh and mesh.users == 0:
            bpy.data.meshes.remove(mesh)
        context.scene.sketchy_active_index = 0
        self.report({'INFO'}, f"Removed '{name}'")
        # ⚠ keep the shared occluder set current: a line set added or removed later
        # would otherwise leave it stale, and a brand new set occludes nothing at all.
        try:
            _rebuild_occluder_set(context)
        except Exception:
            pass
        return {'FINISHED'}


def _apply_occluder_to_all(scene, coll):
    """Point every line set's 'Occlude Against' at `coll`. Returns the count."""
    n = 0
    for o in scene.objects:
        if not o.get(MARKER_PROP):
            continue
        mod = next((m for m in o.modifiers if m.type == 'NODES' and m.node_group
                    and m.node_group.name == NODE_GROUP_NAME), None)
        if mod is None:
            continue
        oid = socket_identifier(mod.node_group, "Occlude Against")
        if oid is not None:
            mi_set(mod, oid, coll)
            o.update_tag()
            n += 1
    return n


class SKETCHY_OT_apply_occluder(bpy.types.Operator):
    bl_idname = "sketchy.apply_occluder"
    bl_label = "Apply Occluder to All Sets"
    bl_description = "Point every line set's occlusion at the shared occluder " \
                     "collection, so they hide each other"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        n = _apply_occluder_to_all(context.scene, context.scene.sketchy_occluder)
        self.report({'INFO'}, f"Set occluder on {n} line set{'s' if n != 1 else ''}")
        return {'FINISHED'}


class SKETCHY_OT_build_proxy_occluder(bpy.types.Operator):
    bl_idname = "sketchy.build_proxy_occluder"
    bl_label = "Build Proxy Occluder"
    bl_description = "Build (or refresh) a low-poly, non-rendering proxy of the " \
                     "Occlude Against geometry and point every line set at it, so " \
                     "the occlusion raycast is cheap on dense/high-poly scenes"
    bl_options = {'REGISTER', 'UNDO'}

    ratio: bpy.props.FloatProperty(
        name="Detail", default=0.1, min=0.01, max=1.0, subtype='FACTOR',
        description="Fraction of faces the proxy keeps (0.1 = 10x lighter). Lower "
                    "is faster; raise it if silhouettes get too crude")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, "ratio", slider=True)

    def execute(self, context):
        scene = context.scene
        proxy = bpy.data.collections.get(PROXY_COLLECTION)

        # Source = current occluder, unless it already IS the proxy (a re-run),
        # in which case recover the real source we stored on the proxy collection.
        src = scene.sketchy_occluder
        if proxy is not None and src is proxy:
            src = bpy.data.collections.get(proxy.get("sk_proxy_source", ""))
        if src is None:
            self.report({'WARNING'},
                        "Set 'Occlude Against' to your source geometry first")
            return {'CANCELLED'}

        # create / relink the proxy collection at the scene root (not under the
        # source, so its own objects never get proxied on a re-run)
        if proxy is None:
            proxy = bpy.data.collections.new(PROXY_COLLECTION)
        if proxy.name not in scene.collection.children:
            try:
                scene.collection.children.link(proxy)
            except RuntimeError:
                pass  # already linked somewhere in the view layer
        proxy["sk_proxy_source"] = src.name

        # wipe previous proxy objects (mesh data is SHARED with the source, so it
        # keeps a user and is never deleted here)
        for o in list(proxy.objects):
            bpy.data.objects.remove(o, do_unlink=True)

        ray_flags = ("visible_camera", "visible_shadow", "visible_diffuse",
                     "visible_glossy", "visible_transmission", "visible_volume_scatter")
        made = 0
        for so in src.all_objects:
            if so.type != 'MESH' or so.get(MARKER_PROP) or so.get(PROXY_MARKER):
                continue
            # share the source mesh DATA so edits carry through; a Decimate
            # modifier lightens only this proxy's evaluated geometry.
            po = bpy.data.objects.new(f"SKProxy_{so.name}", so.data)
            po[PROXY_MARKER] = True
            po.display_type = 'BOUNDS'          # unobtrusive in the viewport
            po.hide_select = True
            con = po.constraints.new('COPY_TRANSFORMS')
            con.target = so                     # follow the source live
            dm = po.modifiers.new("SK Decimate", 'DECIMATE')
            dm.decimate_type = 'COLLAPSE'
            dm.ratio = self.ratio
            for flag in ray_flags:              # present for GN, invisible to render
                if hasattr(po, flag):
                    setattr(po, flag, False)
            proxy.objects.link(po)
            made += 1

        if made == 0:
            self.report({'WARNING'}, "No source meshes found to proxy")
            return {'CANCELLED'}

        # route new AND existing line sets at the proxy
        scene.sketchy_occluder = proxy
        n = _apply_occluder_to_all(scene, proxy)
        self.report({'INFO'},
                    f"Proxy built: {made} mesh{'es' if made != 1 else ''} at "
                    f"{self.ratio:.0%} — {n} line set{'s' if n != 1 else ''} occlude "
                    f"against it")
        return {'FINISHED'}


class SKETCHY_OT_reset_settings(bpy.types.Operator):
    bl_idname = "sketchy.reset_settings"
    bl_label = "Reset Look to Defaults"
    bl_description = "Reset this line set's look sliders to their defaults. Its " \
                     "collection, materials, colors and keyframes are kept"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _active_line_mod(context)[1] is not None

    def execute(self, context):
        obj, mod = _active_line_mod(context)
        tree = mod.node_group
        # leave assignments and the easing menu alone; only reset numeric/bool look
        skip = {'NodeSocketCollection', 'NodeSocketMaterial', 'NodeSocketMenu'}
        n = 0
        for it in tree.interface.items_tree:
            if it.item_type != 'SOCKET' or it.in_out != 'INPUT':
                continue
            if it.socket_type in skip or not hasattr(it, "default_value"):
                continue
            try:
                mi_set(mod, it.identifier, it.default_value)
                n += 1
            except (TypeError, ValueError):
                pass
        obj.update_tag()
        for area in context.screen.areas:
            area.tag_redraw()
        self.report({'INFO'}, f"Reset {n} settings to defaults")
        return {'FINISHED'}


class SKETCHY_OT_add_light_empty(bpy.types.Operator):
    bl_idname = "sketchy.add_light_empty"
    bl_label = "Add Light Empty"
    bl_description = "Create an Empty to aim the fake light (rotate it like a sun) " \
                     "and assign it to this line set"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _active_line_mod(context)[1] is not None

    def execute(self, context):
        obj, mod = _active_line_mod(context)
        tree = mod.node_group
        lid = socket_identifier(tree, "Light Empty")
        # reuse the one already assigned, if any
        emp = mi_get(mod, lid) if lid is not None else None
        if emp is None:
            import mathutils
            emp = bpy.data.objects.new("Sketchwerks Light", None)
            emp.empty_display_type = 'SINGLE_ARROW'
            emp.empty_display_size = 1.5
            emp.location = (3.0, -3.0, 5.0)
            # aim the arrow (the light ray) down at the scene for a 3/4 top light
            d = (mathutils.Vector((0.0, 0.0, 0.0)) - emp.location).normalized()
            emp.rotation_euler = d.to_track_quat('Z', 'Y').to_euler()
            # keep it tidy in the add-on's own collection
            host_coll = bpy.data.collections.get(LINESET_COLLECTION)
            if host_coll is None:
                host_coll = bpy.data.collections.new(LINESET_COLLECTION)
                context.scene.collection.children.link(host_coll)
            host_coll.objects.link(emp)
        if lid is not None:
            mi_set(mod, lid, emp)
        uid = socket_identifier(tree, "Use Light Angle")
        if uid is not None:
            mi_set(mod, uid, True)
        context.view_layer.objects.active = emp
        emp.select_set(True)
        obj.update_tag()
        self.report({'INFO'}, "Light empty added — rotate it to aim the shading")
        return {'FINISHED'}


def _snapshot_line_set(mod):
    tree = mod.node_group
    s = {"vals": {}, "colls": {}, "mats": {}, "objs": {}, "colors": {}}
    for it in tree.interface.items_tree:
        if it.item_type != 'SOCKET' or it.in_out != 'INPUT':
            continue
        v = mi_get(mod, it.identifier)
        if it.socket_type == 'NodeSocketCollection':
            s["colls"][it.name] = v
        elif it.socket_type == 'NodeSocketMaterial':
            s["mats"][it.name] = v
        elif it.socket_type == 'NodeSocketObject':
            s["objs"][it.name] = v
        elif it.socket_type == 'NodeSocketMenu' or isinstance(v, (int, float, bool)):
            s["vals"][it.name] = v
    lm = mi_get(mod, socket_identifier(tree, "Material"))
    if lm and lm.node_tree:
        for nn in ("Line Color", "Hidden Color"):
            n = lm.node_tree.nodes.get(nn)
            if n:
                s["colors"][("L", nn)] = tuple(n.outputs[0].default_value)
    sm = mi_get(mod, socket_identifier(tree, "Smudge Material"))
    if sm and sm.node_tree:
        n = sm.node_tree.nodes.get("Smudge Color")
        if n:
            s["colors"][("S", "Smudge Color")] = tuple(n.outputs[0].default_value)
    fm = mi_get(mod, socket_identifier(tree, "Fill Material"))
    if fm and fm.node_tree:
        for nn in ("Fill Color", "Paper Color"):
            n = fm.node_tree.nodes.get(nn)
            if n:
                s["colors"][("F", nn)] = tuple(n.outputs[0].default_value)
    return s


def _restore_line_set(mod, tree, s):
    def sidx(n):
        return socket_identifier(tree, n)
    for nm, v in s["vals"].items():
        i = sidx(nm)
        if i is None or v is None:
            continue
        it = next(x for x in tree.interface.items_tree
                  if x.item_type == 'SOCKET' and x.identifier == i)
        if it.socket_type == 'NodeSocketInt':
            mi_set(mod, i, int(v))
        elif it.socket_type == 'NodeSocketBool':
            mi_set(mod, i, bool(v))
        elif it.socket_type == 'NodeSocketMenu':
            mi_set(mod, i, v)   # 5.1: int menu value; 5.2: enum string — pass as-is
        else:
            mi_set(mod, i, float(v))
    # new menu sockets added since this set was saved start unset (-1); give
    # them their first item so the material reads a valid style (Smudge).
    for _menu in ("Shading Style",):
        if _menu not in s["vals"]:
            mi = sidx(_menu)
            if mi is not None:
                try:
                    items = mod.id_properties_ui(mi).as_dict().get("items", [])
                    if items:
                        mi_set(mod, mi, items[0][4])
                except Exception:
                    pass
    # migration: "Shading Levels" was renamed to "Tone Steps" — carry the value.
    if "Tone Steps" not in s["vals"] and "Shading Levels" in s["vals"]:
        i = sidx("Tone Steps")
        if i is not None and s["vals"]["Shading Levels"] is not None:
            mi_set(mod, i, float(s["vals"]["Shading Levels"]))
    # migration: files predating the Overshoot Enable toggle stored a nonzero
    # Overshoot value with no switch — turn it on so their look is preserved.
    if "Overshoot Enable" not in s["vals"]:
        oi = sidx("Overshoot Enable")
        if oi is not None:
            ov = s["vals"].get("Overshoot", 0.0) or 0.0
            orn = s["vals"].get("Overshoot Random", 0.0) or 0.0
            if abs(ov) > 1e-6 or orn > 1e-6:
                mi_set(mod, oi, True)
    # migration: Dashes Enable now defaults OFF — files predating the toggle that
    # had a nonzero Dash Length were intentionally dashed, so switch it back on.
    if "Dashes Enable" not in s["vals"]:
        di = sidx("Dashes Enable")
        if di is not None and (s["vals"].get("Dash Length", 0.0) or 0.0) > 1e-6:
            mi_set(mod, di, True)
    for nm, v in s["colls"].items():
        i = sidx(nm)
        if i is not None:
            mi_set(mod, i, v)
    for nm, v in s["mats"].items():
        i = sidx(nm)
        if i is not None and v is not None:
            mi_set(mod, i, v)
    for nm, v in s.get("objs", {}).items():
        i = sidx(nm)
        if i is not None:
            mi_set(mod, i, v)
    lm = mi_get(mod, sidx("Material"))
    if lm and lm.node_tree:
        for (k, nn), cv in s["colors"].items():
            if k == "L":
                n = lm.node_tree.nodes.get(nn)
                if n:
                    n.outputs[0].default_value = cv
    sm = mi_get(mod, sidx("Smudge Material"))
    if sm and sm.node_tree:
        for (k, nn), cv in s["colors"].items():
            if k == "S":
                n = sm.node_tree.nodes.get(nn)
                if n:
                    n.outputs[0].default_value = cv


def _refresh_materials(mod, tree, s):
    """Rebuild the line + smudge materials from the current add-on code so a
    material change in an update actually takes effect (e.g. the toon shading
    nodes), keeping the saved colours. Old datablocks are freed once unused."""
    lm_id = socket_identifier(tree, "Material")
    sm_id = socket_identifier(tree, "Smudge Material")
    fm_id = socket_identifier(tree, "Fill Material")
    old_lm = mi_get(mod, lm_id) if lm_id is not None else None
    old_sm = mi_get(mod, sm_id) if sm_id is not None else None
    old_fm = mi_get(mod, fm_id) if fm_id is not None else None

    lm_name = old_lm.name if old_lm else "SketchwerksLine"
    sm_name = old_sm.name if old_sm else "SketchwerksSmudge"
    fm_name = old_fm.name if old_fm else "SketchwerksFill"
    if old_lm:
        old_lm.name = lm_name + "_old"
    if old_sm:
        old_sm.name = sm_name + "_old"
    if old_fm:
        old_fm.name = fm_name + "_old"

    new_lm = build_line_material(lm_name)
    new_sm = build_smudge_material(sm_name)
    new_fm = build_fill_material(fm_name)
    tgt_by_key = {"L": new_lm, "S": new_sm, "F": new_fm}
    for (k, nn), cv in s["colors"].items():
        tgt = tgt_by_key.get(k)
        if tgt and tgt.node_tree:
            n = tgt.node_tree.nodes.get(nn)
            if n:
                n.outputs[0].default_value = cv
    if lm_id is not None:
        mi_set(mod, lm_id, new_lm)
    if sm_id is not None:
        mi_set(mod, sm_id, new_sm)
    if fm_id is not None:
        mi_set(mod, fm_id, new_fm)
    for om in (old_lm, old_sm, old_fm):
        if om is not None and om.users == 0:
            bpy.data.materials.remove(om)


def _line_sets(context):
    return [o for o in context.scene.objects if o.get(MARKER_PROP)]


def _coarsen_of(obj):
    for m in obj.modifiers:
        if m.type == 'NODES' and m.node_group:
            sid = socket_identifier(m.node_group, "Viewport Coarsen")
            if sid is not None:
                return m, sid, mi_get(m, sid)
    return None, None, None


# ⚠ Fast Viewport drives DETAIL LIMIT, not Viewport Coarsen. Both scale the same resample
# length, but Detail Limit is derived from pixel size, so it self-tunes as the camera dollies
# instead of applying one blind multiplier. Measured on FTF-802 EXT: Detail Limit 10 alone
# beat Viewport Coarsen 8 on both counts (344 K verts / 65 ms vs 465 K / 80 ms).
# Viewport Coarsen stays as the fallback for node groups built before the socket existed.
def _fast_target_of(obj):
    """(modifier, socket_id, current, kind) for whatever Fast Viewport should drive."""
    for m in obj.modifiers:
        if m.type == 'NODES' and m.node_group:
            sid = socket_identifier(m.node_group, "Viewport Detail (px)")
            if sid is not None:
                return m, sid, mi_get(m, sid), 'DETAIL'
    mod, sid, cur = _coarsen_of(obj)
    return mod, sid, cur, ('COARSEN' if mod is not None else None)


def _is_fast(obj):
    """Fast lives in its OWN socket, so the state is unambiguous.

    An earlier version drove `Detail Limit` directly and had to stash the previous value,
    because a Detail Limit above 1 is a normal permanent setting and could not be told
    apart from Fast being engaged. A separate viewport-only socket removes that problem
    AND keeps the toggle out of renders.
    """
    _mod, _sid, cur, kind = _fast_target_of(obj)
    if kind == 'COARSEN':
        return (cur or 1.0) > 1.001
    return (cur or 0.0) > 0.001


FROZEN_PROP = "sketchy_frozen"
FROZEN_SRC = "sketchy_frozen_src"


def _cleanup_frozen():
    """Freeze was removed in 1.0.0-beta.2; undo any snapshot left in an older file.

    ⚠ Without this a saved frozen set is STRANDED: the live object stays
    `hide_viewport = True` and the `(frozen)` snapshot stays linked, with no UI left to
    reverse either. Runs from the same load_post path as the name migration.
    """
    n = 0
    for f in list(bpy.data.objects):
        if not f.get(FROZEN_PROP):
            continue
        src = bpy.data.objects.get(f.get(FROZEN_SRC) or "")
        if src is not None:
            src.hide_viewport = False
        d = f.data
        bpy.data.objects.remove(f, do_unlink=True)
        if d is not None and d.users == 0:
            bpy.data.meshes.remove(d)
        n += 1
    return n


SOURCE_COLLECTION = "Sketchwerks Source"
SOURCE_PROP = "sketchy_source"


def _renderable_objects(coll, out=None, seen=None):
    """Every object under `coll` that actually renders, recursing into child collections.

    ⚠ `hide_render` is the filter because that is what BOOLEAN CUTTERS are flagged with.
    Archipack marks all 18 of its `Holes` objects `hide_render = True` (and WIRE display)
    while leaving `hide_viewport` False, so they were feeding window-shaped scribbles into
    the line art. Anyone else's cutters are conventionally flagged the same way, so this
    needs no per-scene setup.
    """
    out = [] if out is None else out
    seen = set() if seen is None else seen
    if coll.name in seen or coll.hide_render:
        return out
    seen.add(coll.name)
    for o in coll.objects:
        if o.type == 'MESH' and not o.hide_render and o.data and len(o.data.polygons):
            out.append(o)
    for ch in coll.children:
        _renderable_objects(ch, out, seen)
    return out


class SKETCHY_OT_build_source(bpy.types.Operator):
    bl_idname = "sketchy.build_source"
    bl_label = "Build Filtered Source"
    bl_description = ("Collect everything in the chosen collection that actually renders "
                      "into a source collection, skipping boolean cutters and anything set "
                      "not to render. Objects are LINKED, never moved, so a rig like "
                      "Archipack is left exactly as it was")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.sketchy_target_collection is not None

    def execute(self, context):
        scene = context.scene
        src = scene.sketchy_target_collection
        if src is not None and src.get(SOURCE_PROP):
            self.report({'WARNING'}, "That IS the filtered source - pick the original")
            return {'CANCELLED'}
        keep = _renderable_objects(src)
        if not keep:
            self.report({'WARNING'}, "Nothing renderable found in '%s'" % src.name)
            return {'CANCELLED'}
        name = "%s - %s" % (SOURCE_COLLECTION, src.name)
        out = bpy.data.collections.get(name)
        if out is None:
            out = bpy.data.collections.new(name)
        # ⚠ DO NOT LINK IT TO THE SCENE. A collection can live in bpy.data with no scene
        # parent — the GN modifier's reference keeps it alive, and it never shows in the
        # Outliner. Linking it produced a confusing duplicate of the user's rig for no
        # benefit whatsoever. (Verified during the Mographwerks work and written down; I
        # linked it anyway out of habit.)
        for parent in list(bpy.data.collections) + [scene.collection]:
            if out.name in getattr(parent, "children", {}):
                parent.children.unlink(out)
        out[SOURCE_PROP] = True
        # ⚠ UNLINK ONLY FROM OUR OWN COLLECTION. These objects live in the user's rig too;
        # `objects.unlink` here removes the link we made, never their real home.
        for o in list(out.objects):
            out.objects.unlink(o)
        for o in keep:
            out.objects.link(o)
        scene.sketchy_target_collection = out
        # ⚠⚠ REPOINT THE EXISTING LINE SETS. Setting the scene field only affects line sets
        # created AFTER this — every one already in the scene keeps its own `Line Collection`
        # socket, so the filter appeared to do nothing at all. Shipped exactly that bug.
        moved = 0
        for ls in _line_sets(context):
            for mod in ls.modifiers:
                if mod.type != 'NODES' or not mod.node_group:
                    continue
                sid = socket_identifier(mod.node_group, "Line Collection")
                if sid is None:
                    continue
                inp = _mod_inputs(mod)
                cur = mi_get(mod, sid)
                if cur is not None and cur.name != src.name:
                    continue
                if inp is None:
                    mod[sid] = out
                else:
                    getattr(inp, sid).value = out
                ls.update_tag()
                moved += 1
        self.report({'INFO'}, "Source '%s': %d object(s); repointed %d line set(s)"
                    % (name, len(keep), moved))
        return {'FINISHED'}


CAM_CULL_PROP = "sketchy_cam_culled"      # "\n"-joined names of collections it left
CULL_HOLD = "Sketchwerks Culled"


def _cull_hold_collection(create=False):
    c = bpy.data.collections.get(CULL_HOLD)
    if c is None and create:
        c = bpy.data.collections.new(CULL_HOLD)
        # ⚠ Never linked to a scene, so its contents cannot render — but it MUST have a
        # fake user or the collection itself is purged on save, taking the objects' last
        # user with it. An object left in no collection at all is purged permanently.
        c.use_fake_user = True
    return c


def _cull_restore():
    """Put every culled object back in the collections it came from."""
    hold = _cull_hold_collection()
    n = 0
    for o in list(bpy.data.objects):
        raw = o.get(CAM_CULL_PROP)
        if not raw:
            continue
        for name in str(raw).split("\n"):
            c = bpy.data.collections.get(name)
            if c is not None and o.name not in c.objects:
                c.objects.link(o)
        if hold is not None and o.name in hold.objects:
            hold.objects.unlink(o)
        del o[CAM_CULL_PROP]
        n += 1
    if hold is not None and not hold.objects:
        bpy.data.collections.remove(hold)
    return n


def _cull_source_collections(context):
    out = []
    for ls in _line_sets(context):
        for mod in ls.modifiers:
            if mod.type != 'NODES' or not mod.node_group:
                continue
            sid = socket_identifier(mod.node_group, "Line Collection")
            if sid is None:
                continue
            c = mi_get(mod, sid)
            if c is not None and c not in out:
                out.append(c)
    return out


def _visible_to_camera(scene, cam, obj, margin):
    """Does obj's world bounding box touch the camera frustum at the CURRENT frame?"""
    from bpy_extras.object_utils import world_to_camera_view
    from mathutils import Vector
    lo, hi = -margin, 1.0 + margin
    xs, ys, any_front = [], [], False
    for c in obj.bound_box:
        p = world_to_camera_view(scene, cam, obj.matrix_world @ Vector(c))
        xs.append(p.x); ys.append(p.y)
        if p.z > 0.0:
            any_front = True
    if not any_front:
        return False                      # entirely behind the camera
    # straddling counts as visible: a box can cross the frame with every corner outside
    return (max(xs) >= lo and min(xs) <= hi and
            max(ys) >= lo and min(ys) <= hi)


class SKETCHY_OT_cull_offscreen(bpy.types.Operator):
    bl_idname = "sketchy.cull_offscreen"
    bl_label = "Cull Off-Camera"
    bl_description = ("Take source objects the camera never sees across the WHOLE frame "
                      "range out of the line set, so they cost nothing. Press again to "
                      "restore. Safe for Draw On: the kept set is identical on every "
                      "frame, so stroke order never reshuffles")
    bl_options = {'REGISTER', 'UNDO'}

    margin: bpy.props.FloatProperty(
        name="Margin", default=0.05, min=0.0, max=0.5, subtype='FACTOR',
        description="Keep objects this far outside the frame, as a fraction of frame "
                    "size. Covers wobble and overshoot near the border")
    samples: bpy.props.IntProperty(
        name="Frame Samples", default=24, min=1, max=500,
        description="How many frames across the range to test. An object is kept if it "
                    "is visible at ANY sampled frame")

    @classmethod
    def poll(cls, context):
        return bool(_line_sets(context)) and context.scene.camera is not None

    def execute(self, context):
        scn = context.scene
        if any(o.get(CAM_CULL_PROP) for o in bpy.data.objects):
            n = _cull_restore()
            for ls in _line_sets(context):
                ls.update_tag()
            self.report({'INFO'}, "Restored %d off-camera object(s)" % n)
            return {'FINISHED'}

        colls = _cull_source_collections(context)
        if not colls:
            self.report({'WARNING'}, "No line set source collections found")
            return {'CANCELLED'}
        cands, seen = [], set()
        for c in colls:
            for o in c.all_objects:
                if o.type == 'MESH' and o.data and o.name not in seen:
                    seen.add(o.name)
                    cands.append(o)
        if not cands:
            self.report({'WARNING'}, "No mesh objects in the source collections")
            return {'CANCELLED'}

        # ⚠ Sample the WHOLE range, not the current frame. Culling per frame would change
        # the kept set as the camera moves, which re-indexes the splines and reshuffles
        # Draw On and Overshoot -- the exact temporal boiling this add-on exists to avoid.
        f0, f1 = sorted((scn.frame_start, scn.frame_end))
        span = f1 - f0
        if span <= 0:
            frames = [f0]
        else:
            k = max(1, min(self.samples, span + 1))
            step = span / float(k - 1) if k > 1 else span
            frames = sorted({int(round(f0 + i * step)) for i in range(k)} | {f0, f1})

        original = scn.frame_current
        unseen = list(cands)
        try:
            for fr in frames:
                if not unseen:
                    break
                scn.frame_set(fr)
                cam = scn.camera
                if cam is None:
                    continue
                unseen = [o for o in unseen
                          if not _visible_to_camera(scn, cam, o, self.margin)]
        finally:
            scn.frame_set(original)

        # ⚠ UNLINK, do not hide. Measured: Collection Info ignores hide_viewport AND
        # hide_render entirely - hiding a source object changes the line output by
        # exactly zero. Only collection membership matters.
        # ⚠ And walk the WHOLE subtree. Collection Info reads `all_objects`, so a sofa in
        # Objects/LR/Sofa Krisby is in the line set while its `users_collection` names only
        # "Sofa Krisby". Matching just the source names culled 51 of 96 and missed every
        # piece of furniture.
        hold = _cull_hold_collection(create=True) if unseen else None
        srcnames = set()
        stack = list(colls)
        while stack:
            c = stack.pop()
            if c.name in srcnames:
                continue
            srcnames.add(c.name)
            stack.extend(c.children)
        n = 0
        for o in unseen:
            left = [c.name for c in list(o.users_collection) if c.name in srcnames]
            if not left:
                continue
            for name in left:
                bpy.data.collections[name].objects.unlink(o)
            if not o.users_collection:
                hold.objects.link(o)      # never leave it homeless: 0 users = purged
            o[CAM_CULL_PROP] = "\n".join(left)
            n += 1
        if hold is not None and not hold.objects:
            bpy.data.collections.remove(hold)
        for ls in _line_sets(context):
            ls.update_tag()
        self.report({'INFO'}, "Culled %d of %d source object(s) over %d frame(s)"
                    % (n, len(cands), len(frames)))
        return {'FINISHED'}


OCCLUDER_SET = "Sketchwerks Occluders"


def _rebuild_occluder_set(context):
    """Link every STATIC line set's source into one shared collection and point all sets
    at it. Returns (linked, pointed, skipped). Safe to call repeatedly."""
    sets = _line_sets(context)
    if not sets:
        return [], [], []
    holder = bpy.data.collections.get(OCCLUDER_SET)
    if holder is None:
        holder = bpy.data.collections.new(OCCLUDER_SET)
        # ⚠ NEVER linked into the scene - see SKETCHY_OT_build_occluders.
        holder.use_fake_user = True
    linked, pointed, skipped = [], [], []
    for ls in sets:
        for mod in ls.modifiers:
            if mod.type != 'NODES' or not mod.node_group:
                continue
            lc_id = socket_identifier(mod.node_group, "Line Collection")
            oc_id = socket_identifier(mod.node_group, "Occlude Against")
            if lc_id is None or oc_id is None:
                continue
            do_id = socket_identifier(mod.node_group, "Draw On")
            is_buildon = bool(mi_get(mod, do_id, False)) if do_id else False
            src = mi_get(mod, lc_id)
            if src is not None and src.name != holder.name and not is_buildon:
                if src.name not in holder.children:
                    try:
                        holder.children.link(src)
                        linked.append(src.name)
                    except Exception:
                        pass
            elif is_buildon and src is not None and src.name in holder.children:
                holder.children.unlink(src)
                skipped.append(src.name)
            elif is_buildon and src is not None:
                skipped.append(src.name)
            mi_set(mod, oc_id, holder)
            pointed.append(ls.name)
        ls.update_tag()
    return linked, pointed, skipped


class SKETCHY_OT_build_occluders(bpy.types.Operator):
    bl_idname = "sketchy.build_occluders"
    bl_label = "Build Occluder Set"
    bl_description = ("Collect every line set's source collection into one shared "
                      "'Sketchwerks Occluders' collection and point all of them at it, so "
                      "they occlude each other. Re-run after adding a line set. Collections "
                      "are LINKED, not moved - your outliner is unchanged")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(_line_sets(context))

    def execute(self, context):
        linked, pointed, skipped = _rebuild_occluder_set(context)
        msg = "Occluder set: %d linked, %d line set(s) pointed" % (len(linked), len(pointed))
        if skipped:
            msg += " (%d build-on set(s) excluded: they occlude via their matte)" % len(skipped)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SKETCHY_OT_make_buildon(bpy.types.Operator):
    bl_idname = "sketchy.make_buildon"
    bl_label = "Make Build-On"
    bl_description = ("Configure the active line set for a draw-on build: enables Draw On "
                      "and the Colour Fill matte, ties the matte to the draw, and sizes "
                      "Draw Spread from the collection so the reveal does not strobe on a "
                      "moving camera. Then keyframe Draw Amount")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _active_line_mod(context)[1] is not None

    def execute(self, context):
        ob, mod = _active_line_mod(context)
        if mod is None or not mod.node_group:
            self.report({'WARNING'}, "No active line set")
            return {'CANCELLED'}
        ng = mod.node_group

        def sid(n):
            return socket_identifier(ng, n)

        # ⚠ Draw Spread is in METRES, so no fixed default can be right - 1.5 m suits a
        # barstool and would be a full-object wipe on a wall. Size it from the source.
        # Any value above ~0.5 reached baseline temporal stability in testing; the exact
        # number is a look choice, so this only needs to be in the right ballpark.
        spread = 1.0
        lc_id = sid("Line Collection")
        src = mi_get(mod, lc_id) if lc_id else None
        if src is not None:
            from mathutils import Vector
            pts = []
            for o in src.all_objects:
                if o.type == 'MESH' and o.data:
                    pts.extend([o.matrix_world @ Vector(c) for c in o.bound_box])
            if pts:
                lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
                hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
                spread = max(0.5, min(5.0, (hi - lo).length / 3.0))

        # ⚠ A fraction cannot be right for every build length. At the old 0.1 default a
        # 15-frame draw dissolved over 1.5 frames, and because the fill renders DITHERED
        # that lone in-between frame is raw stochastic dither, seen as a flash. Measured
        # on FTF-810: partial-alpha pixels spiked 13 K -> 142 K for ONE frame at 0.1, and
        # spread across four frames once sized. Only possible once Draw Amount is keyed,
        # so re-running this after keyframing is what tunes it.
        fade = lead = None
        did = sid("Draw Amount")
        if did:
            for fc in _all_fcurves(ob.animation_data):
                if did not in fc.data_path or len(fc.keyframe_points) < 2:
                    continue
                xs = [k.co[0] for k in fc.keyframe_points]
                span = max(xs) - min(xs)
                if span > 0:
                    fade = max(0.15, min(0.60, MATTE_FADE_FRAMES / span))
                    lead = max(0.05, min(0.30, MATTE_LEAD_FRAMES / span))
                break

        pairs = [("Draw On", True), ("Colour Fill", True),
                 ("Fill Follows Draw", True), ("Draw Spread", spread)]
        if fade is not None:
            pairs += [("Matte Fade", fade), ("Matte Lead", lead)]

        applied = {}
        for name, val in pairs:
            i = sid(name)
            if i is not None:
                mi_set(mod, i, val)
                applied[name] = round(val, 3) if isinstance(val, float) else val
        ob.update_tag()
        # a build-on must leave the raycast occluder set; it occludes via its matte
        _rebuild_occluder_set(context)
        if fade is None:
            self.report({'INFO'}, "Build-on ready: Draw Spread %.2f m. Now keyframe Draw "
                        "Amount, then run this again to size the matte dissolve" % spread)
        else:
            self.report({'INFO'}, "Build-on ready: Draw Spread %.2f m, matte dissolve %.2f "
                        "over a %d-frame draw" % (spread, fade, round(MATTE_FADE_FRAMES / fade)))
        return {'FINISHED'}


def _all_fcurves(ad):
    """Blender 5.x slotted actions: Action.fcurves no longer exists."""
    out = []
    if not ad or not ad.action:
        return out
    act = ad.action
    if hasattr(act, "fcurves"):
        return list(act.fcurves)
    for layer in getattr(act, "layers", []):
        for strip in getattr(layer, "strips", []):
            for cb in getattr(strip, "channelbags", []):
                out.extend(cb.fcurves)
    return out


class SKETCHY_OT_check_setup(bpy.types.Operator):
    bl_idname = "sketchy.check_setup"
    bl_label = "Check Setup"
    bl_description = ("Scan every line set for configuration that is known to look broken: "
                      "strobing build-ons, matte/film mismatches, geometry drawn twice, "
                      "fills that can z-fight, build-ons that occlude before they draw, "
                      "source geometry left in the View Layer, "
                      "and eased draw-on keys")
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return bool(_line_sets(context))

    def execute(self, context):
        scn = context.scene
        sets = _line_sets(context)
        issues = []

        # does the camera move? several checks only matter if it does
        cam = scn.camera
        cam_moves = False
        if cam is not None and cam.animation_data is not None:
            cam_moves = True

        seen_sources = {}
        occ_pools = {}          # collection name -> set of mesh names it occludes with
        no_occ = []             # sets pointed at nothing while others have an occluder
        has_occ = 0
        vl_objs = {o.name for o in context.view_layer.objects}
        src_shown = []          # (set, object) whose source geometry still renders
        src_hidden = []         # sets whose source is excluded from the view layer
        for ls in sets:
            mod = next((m for m in ls.modifiers
                        if m.type == 'NODES' and m.node_group), None)
            if mod is None:
                continue
            ng = mod.node_group
            name = ls.name.replace(LINESET_COLLECTION + " — ", "")

            def g(sock, default=None):
                i = socket_identifier(ng, sock)
                return mi_get(mod, i, default) if i else default

            draw_on = bool(g("Draw On", False))
            fill = bool(g("Colour Fill", False))
            spread = float(g("Draw Spread", 0.0) or 0.0)
            stagger = float(g("Draw Stagger", 0.0) or 0.0)
            matte = bool(g("Transparent Matte", False))
            sil = bool(g("Include Silhouettes", False))

            # ⚠ the strobe: view-dependent silhouettes re-index the splines every frame
            if draw_on and cam_moves and sil and stagger > 0.05 and spread <= 0.001:
                issues.append("%s: Draw Spread is 0 with silhouettes + stagger on a moving "
                              "camera - the reveal WILL strobe. Run Make Build-On." % name)
            # ⚠ a build-on that cannot occlude anything
            if draw_on and not fill:
                issues.append("%s: build-on with no Colour Fill - it will never occlude "
                              "anything, so lines behind it stay visible." % name)
            # ⚠ a static set whose fill is redundant and can z-fight on overlapping geometry
            if fill and not draw_on:
                issues.append("%s: Colour Fill on a STATIC set is redundant (the occluder "
                              "set already hides things) and z-fights where geometry "
                              "overlaps - seen as grey patches." % name)
            # ⚠ holdout with an opaque film renders dark, not invisible
            if matte and not scn.render.film_transparent:
                issues.append("%s: Transparent Matte needs Film > Transparent, or the fill "
                              "renders DARK GREY." % name)
            # ⚠ alpha silently dropped
            if matte and scn.render.image_settings.color_mode != 'RGBA':
                issues.append("%s: Transparent Matte with Color Mode %s - the alpha is "
                              "dropped on save." % (name, scn.render.image_settings.color_mode))
            # ⚠ same object in two line sets = drawn twice
            src = g("Line Collection")
            if src is not None:
                for o in src.all_objects:
                    if o.type != 'MESH':
                        continue
                    prev = seen_sources.get(o.name)
                    if prev and prev != name:
                        issues.append("%s and %s both draw '%s' - doubled linework."
                                      % (prev, name, o.name))
                        break
                    seen_sources.setdefault(o.name, name)

            # ⚠ Excluding the source collection is what makes a line set read as a DRAWING
            # rather than as shaded geometry with lines on top. Miss one and, on a
            # transparent film with nothing lighting it, that collection renders as a solid
            # BLACK shape sitting over the artwork. Only worth reporting as an
            # inconsistency: rendering geometry alongside lines is a legitimate look, but
            # doing it for exactly one set out of several never is.
            if src is not None:
                meshes = [o.name for o in src.all_objects if o.type == 'MESH']
                if meshes:
                    shown = next((n for n in meshes if n in vl_objs), None)
                    if shown:
                        src_shown.append((name, shown))
                    else:
                        src_hidden.append(name)

            # ⚠ the inverse of the no-fill case above: a build-on whose geometry sits in
            # the occluder set is raycast against from frame 1, so it hides lines long
            # before it draws. Collection Info reads all_objects, so a PARENT of the
            # build-on's collection drags it back in just as surely as the collection
            # itself, and Build Occluder Set only ever unlinks the collection itself.
            occ = g("Occlude Against")
            if occ is None:
                no_occ.append(name)
            else:
                has_occ += 1
                pool = occ_pools.get(occ.name)
                if pool is None:
                    pool = {o.name for o in occ.all_objects if o.type == 'MESH'}
                    occ_pools[occ.name] = pool
                if draw_on and src is not None:
                    hit = next((o.name for o in src.all_objects
                                if o.type == 'MESH' and o.name in pool), None)
                    if hit:
                        issues.append("%s: build-on geometry ('%s') is inside its occluder "
                                      "set '%s' - it hides lines from frame 1, before it "
                                      "draws. Look for a PARENT collection linked into the "
                                      "set, unlink it, then re-run Build Occluder Set."
                                      % (name, hit, occ.name))

            # ⚠ eased draw-on keys make the build start late and finish early
            if draw_on:
                did = socket_identifier(ng, "Draw Amount")
                for fc in _all_fcurves(ls.animation_data):
                    if did and did in fc.data_path:
                        if any(k.interpolation != 'LINEAR' for k in fc.keyframe_points):
                            issues.append("%s: Draw Amount keys are not Linear - the build "
                                          "eases in and out and uses less of its range."
                                          % name)
                        break

        if src_hidden and src_shown:
            for nm, obj in src_shown:
                issues.append("%s: its source geometry ('%s') still renders while %d other "
                              "set(s) have theirs excluded from the View Layer. Unlit "
                              "geometry on a transparent film comes out as a solid BLACK "
                              "shape over the drawing. Exclude the collection."
                              % (nm, obj, len(src_hidden)))

        # ⚠ a set created after the last Build Occluder Set run points at nothing, so it
        # occludes against nothing, not even itself. Only worth saying once the scene has
        # a shared occluder set for it to be missing from.
        if has_occ and no_occ:
            issues.append("%s: no Occlude Against collection while %d other set(s) have "
                          "one - press Build Occluder Set." % (", ".join(no_occ), has_occ))

        for msg in issues:
            print("[Sketchwerks] " + msg)
        if issues:
            self.report({'WARNING'}, "%d issue(s) found - see the Info log / console"
                        % len(issues))
        else:
            self.report({'INFO'}, "Setup looks good (%d line set(s) checked)" % len(sets))
        return {'FINISHED'}


class SKETCHY_OT_fast_viewport(bpy.types.Operator):
    bl_idname = "sketchy.fast_viewport"
    bl_label = "Fast Viewport"
    bl_description = ("Coarsen every line set for quick camera work, then flip back for an "
                      "accurate preview. Renders are never affected either way")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(_line_sets(context))

    def execute(self, context):
        sets = _line_sets(context)
        # ⚠ ONE toggle for the whole scene: a per-line-set slider is the wrong ergonomics
        # for "I just want to move the camera", which is when you have several of them.
        on = any(_is_fast(o) for o in sets)
        want = max(1.0, context.scene.sketchy_fast_amount)
        n = 0
        for o in sets:
            mod, sid, _cur, kind = _fast_target_of(o)
            if mod is None:
                continue
            if kind == 'COARSEN':
                mi_set(mod, sid, 1.0 if on else want)
            else:
                # viewport-only socket: off is simply 0, nothing to stash or restore
                mi_set(mod, sid, 0.0 if on else want)
            mod.id_data.update_tag()
            n += 1
        self.report({'INFO'}, "%s on %d line set(s)"
                    % ("Accurate" if on else "Fast (%g px)" % want, n))
        return {'FINISHED'}


class SKETCHY_OT_rebuild(bpy.types.Operator):
    bl_idname = "sketchy.rebuild"
    bl_label = "Update Node Group"
    bl_description = "Rebuild the Sketchy node group from the installed add-on, " \
                     "keeping every line set's settings, materials and keyframes. " \
                     "Run this after updating the add-on if a panel looks out of date"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bpy.data.node_groups.get(NODE_GROUP_NAME) is not None

    def execute(self, context):
        _migrate_legacy_names()          # so a pre-1.0 file is found at all
        old = bpy.data.node_groups.get(NODE_GROUP_NAME)
        snaps = []
        for o in bpy.data.objects:
            if not o.get(MARKER_PROP):
                continue
            mod = next((m for m in o.modifiers if m.type == 'NODES' and m.node_group
                        and m.node_group.name == NODE_GROUP_NAME), None)
            if mod is not None:
                snaps.append((o.name, _snapshot_line_set(mod)))
        bpy.data.node_groups.remove(old)
        newtree = build_node_group()
        for obj_name, s in snaps:
            o = bpy.data.objects.get(obj_name)
            if o is None:
                continue
            mod = next((m for m in o.modifiers if m.type == 'NODES'), None)
            if mod is None:
                continue
            mod.node_group = newtree
            if mod.name.startswith("Sketchy"):
                mod.name = MODIFIER_NAME      # cosmetic; nothing resolves it by name
            _restore_line_set(mod, newtree, s)
            _refresh_materials(mod, newtree, s)
            o.update_tag()
        context.view_layer.update()
        self.report({'INFO'},
                    f"Node group + materials updated ({len(snaps)} line sets preserved)")
        return {'FINISHED'}


class SKETCHY_UL_line_sets(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_prop):
        row = layout.row(align=True)
        row.label(text=item.name, icon='GREASEPENCIL')
        row.prop(item, "hide_viewport", text="", emboss=False)

    def filter_items(self, context, data, propname):
        objs = getattr(data, propname)
        flags = [self.bitflag_filter_item if o.get(MARKER_PROP) else 0 for o in objs]
        # An explicit order (identity = scene link order) rather than []. Returning
        # an empty order delegates sorting to Blender, which then obeys the list's
        # own "Sort Alphabetically" toggle — so renaming a line set moved it.
        return flags, list(range(len(objs)))


class SKETCHY_OT_mark_edges(bpy.types.Operator):
    bl_idname = "sketchy.mark_edges"
    bl_label = "Mark Edges"
    bl_description = "Tag the selected edges for the sketchy line art"
    bl_options = {'REGISTER', 'UNDO'}

    attribute: bpy.props.EnumProperty(items=[
        (ATTR_INCLUDE, "Line", "Force these edges to draw as lines"),
        (ATTR_EXCLUDE, "Hide", "Remove these edges from the line art"),
    ])
    clear: bpy.props.BoolProperty(default=False)

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def execute(self, context):
        count = 0
        for obj in context.objects_in_mode_unique_data:
            if obj.type != 'MESH':
                continue
            bm = bmesh.from_edit_mesh(obj.data)
            layer = bm.edges.layers.bool.get(self.attribute)
            if layer is None:
                layer = bm.edges.layers.bool.new(self.attribute)
            for e in bm.edges:
                if e.select:
                    e[layer] = not self.clear
                    count += 1
            bmesh.update_edit_mesh(obj.data)
        action = "Cleared" if self.clear else "Marked"
        what = "line" if self.attribute == ATTR_INCLUDE else "hide"
        self.report({'INFO'}, f"{action} {count} {what} edges")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# N-panel: a compact parent panel (list + style + line basics) with a
# collapsible child sub-panel per section, mirroring the modifier's panels.
# ---------------------------------------------------------------------------

def _active_line_mod(context):
    obj = active_line_set(context.scene)
    if obj is None:
        return None, None
    mod = next((m for m in obj.modifiers
                if m.type == 'NODES' and m.node_group
                and m.node_group.name == NODE_GROUP_NAME), None)
    return obj, mod


def _p(col, mod, name, label):
    ident = socket_identifier(mod.node_group, name)
    if ident is not None:
        # native property-split: labels right-align in a fixed left column with
        # controls in an aligned right column (matches Blender's stock panels,
        # e.g. Color Management / View). Decorators off for a clean, calm look.
        col.use_property_split = True
        col.use_property_decorate = False
        mi_prop(col, mod, ident, text=label)


def _color(col, mod, mat_socket, node_name, label):
    mat = mi_get(mod, socket_identifier(mod.node_group, mat_socket))
    if mat and mat.node_tree:
        n = mat.node_tree.nodes.get(node_name)
        if n:
            # property-split so the swatch sits on the label's line (like the
            # dropdowns), instead of dropping to a tall field on its own row
            row = col.row(align=True)
            row.use_property_split = True
            row.use_property_decorate = False
            row.prop(n.outputs[0], "default_value", text=label)


def _bool_val(mod, name):
    ident = socket_identifier(mod.node_group, name)
    return bool(mi_get(mod, ident)) if ident is not None else False


# ⚠ The tab name lives in ONE place. Renamed from "Sketchy" 2026-07-29; the MODULE stays
# `sketchy_lines` and the operators stay `sketchy.*` on purpose — renaming the folder would
# disable the addon and reset its preferences, and renaming operator ids would break every
# keymap binding. Only the display identity changed.
PANEL_CATEGORY = "Sketchwerks"


class SKETCHY_PT_panel(bpy.types.Panel):
    bl_label = "Sketchwerks"
    bl_idname = "SKETCHY_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY

    # ⚠ NO ICON ON THE MAIN HEADER — suite rule, decided 2026-08-05. The house style used to
    # be "a brand icon on the parent header"; it is now no icon there at all. The sub-panel
    # icons stay, and so does the header ACTION below — that one does something.

    def draw_header_preset(self, context):
        # house style: the parent's single header action (update after an update)
        self.layout.operator("sketchy.rebuild", text="", icon='FILE_REFRESH', emboss=False)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        sets = _line_sets(context)
        if sets:
            fast = any(_is_fast(o) for o in sets)
            r = layout.row(align=True)
            # ⚠ NAME THE NUMBER. Drawn bare it is just "8.000" with nothing saying what
            # it is — the same fault as Camerawerks' unlabelled move picker. The factor
            # goes in the BUTTON so the row reads as one idea, and the field keeps a label.
            r.operator("sketchy.fast_viewport",
                       text=("Accurate Viewport" if fast
                             else "Fast Viewport (%g px)" % scene.sketchy_fast_amount),
                       icon='RESTRICT_VIEW_OFF' if fast else 'MOD_DECIM',
                       depress=fast)
            r.prop(scene, "sketchy_fast_amount", text="Detail px")
            culled = any(o.get(CAM_CULL_PROP) for o in bpy.data.objects)
            c = layout.row()
            c.operator("sketchy.cull_offscreen",
                       text="Restore Off-Camera" if culled else "Cull Off-Camera",
                       icon='RESTRICT_RENDER_OFF' if culled else 'CAMERA_DATA',
                       depress=culled)
        tc = scene.sketchy_target_collection
        if tc is not None and not tc.get(SOURCE_PROP):
            skip = [o for o in tc.all_objects
                    if o.type == 'MESH' and o.hide_render and o.data
                    and len(o.data.polygons)]
            if skip:
                b = layout.box()
                w = b.row(); w.alert = True
                w.label(text="%d non-rendering object(s) in '%s'" % (len(skip), tc.name),
                        icon='ERROR')
                h = b.row(); h.enabled = False
                h.label(text="Boolean cutters draw lines too", icon='BLANK1')
                b.operator("sketchy.build_source", icon='FILTER')

        row = layout.row()
        row.template_list("SKETCHY_UL_line_sets", "", scene, "objects",
                          scene, "sketchy_active_index", rows=2)
        col = row.column(align=True)
        col.operator("sketchy.add_line_set", text="", icon='ADD')
        col.operator("sketchy.remove_line_set", text="", icon='REMOVE')

        if context.mode == 'EDIT_MESH':
            box = layout.box()
            box.label(text="Selected Edges", icon='EDITMODE_HLT')
            row = box.row(align=True)
            op = row.operator("sketchy.mark_edges", text="Mark Line")
            op.attribute, op.clear = ATTR_INCLUDE, False
            op = row.operator("sketchy.mark_edges", text="Clear")
            op.attribute, op.clear = ATTR_INCLUDE, True
            row = box.row(align=True)
            op = row.operator("sketchy.mark_edges", text="Mark Hide")
            op.attribute, op.clear = ATTR_EXCLUDE, False
            op = row.operator("sketchy.mark_edges", text="Clear")
            op.attribute, op.clear = ATTR_EXCLUDE, True

        obj, mod = _active_line_mod(context)
        if mod is None:
            return

        # collection picker full-width so it isn't cut off
        cid = socket_identifier(mod.node_group, "Line Collection")
        if cid is not None:
            col = layout.column(align=True)
            col.label(text="Collection")
            mi_prop(col, mod, cid, text="")

        # shared occluder for the whole scene: every line set hides behind the
        # meshes in this collection, so separate sets occlude each other. New
        # sets adopt it automatically; the buttons re-apply it to all / build a
        # proxy. Mirrors the Collection field above — title on its own line, the
        # picker full-width below — so the two collection fields read as a pair.
        occ = layout.column(align=True)
        occ.label(text="Occlude Collection")
        row = occ.row(align=True)
        row.prop(scene, "sketchy_occluder", text="")
        layout.operator("sketchy.build_occluders", icon='OUTLINER_COLLECTION')
        layout.operator("sketchy.make_buildon", icon='ANIM')
        layout.operator("sketchy.check_setup", icon='CHECKMARK')
        row.operator("sketchy.apply_occluder", text="", icon='FILE_REFRESH')
        row.operator("sketchy.build_proxy_occluder", text="", icon='MOD_DECIM')

        # native thumbnail picker: a big swatch of the current style; click it to
        # open a scrollable grid of all styles — the thumbnail itself is the link.
        layout.separator()
        layout.label(text="Presets")
        row = layout.row(align=True)
        row.context_pointer_set("sketchy_lineset", obj)
        row.template_icon_view(context.window_manager, "sketchy_preset_sel",
                               show_labels=True, scale=7.0, scale_popup=7.0)
        cluster = row.column(align=True)
        cluster.menu("SKETCHY_MT_presets", text="", icon='PRESET')
        cluster.operator("sketchy.render_thumbnails", text="", icon='RENDER_STILL').target = obj.name
        cluster.operator("sketchy.save_preset", text="", icon='ADD')
        cluster.operator("sketchy.reset_settings", text="", icon='LOOP_BACK')
        # Line settings live in their own collapsible sub-panel now (like Edges).


class _SketchyChild:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_parent_id = "SKETCHY_PT_panel"
    bl_options = {'DEFAULT_CLOSED'}
    panel_icon = 'NONE'
    enable_socket = None   # bool socket toggled from the header (section master switch)

    @classmethod
    def poll(cls, context):
        return _active_line_mod(context)[1] is not None

    def draw_header(self, context):
        # the section's enable checkbox (if it has one) sits left of the icon, so
        # the whole section switches on/off from the header without opening it —
        # the native sub-panel pattern (e.g. White Balance).
        layout = self.layout
        layout.use_property_decorate = False
        if self.enable_socket:
            mod = _active_line_mod(context)[1]
            if mod is not None:
                ident = socket_identifier(mod.node_group, self.enable_socket)
                if ident is not None:
                    mi_prop(layout, mod, ident, text="")
        layout.label(text="", icon=self.panel_icon)

    def _on(self, context):
        """True when this section is enabled (always True if it has no toggle)."""
        if not self.enable_socket:
            return True
        return _bool_val(_active_line_mod(context)[1], self.enable_socket)


class SKETCHY_PT_line(_SketchyChild, bpy.types.Panel):
    bl_label = "Line"
    bl_order = 0
    # core pen settings — collapsible like the others, but OPEN by default so
    # Width/Color aren't hidden on first open.
    bl_options = set()
    panel_icon = 'GREASEPENCIL'

    def draw(self, context):
        mod = _active_line_mod(context)[1]
        col = self.layout.column(align=True)
        _p(col, mod, "Line Width", "Width")
        _color(col, mod, "Material", "Line Color", "Color")
        _p(col, mod, "Screen-Space Width", "Constant On-Screen")
        if _bool_val(mod, "Screen-Space Width"):
            _p(col, mod, "Reference Distance", "Reference Dist")


class SKETCHY_PT_wobble(_SketchyChild, bpy.types.Panel):
    bl_label = "Wobble"
    bl_order = 2
    panel_icon = 'FORCE_TURBULENCE'
    enable_socket = "Wobble Enable"

    def draw(self, context):
        if not self._on(context):
            return
        mod = _active_line_mod(context)[1]
        col = self.layout.column(align=True)
        _p(col, mod, "Wobble Amount", "Amount (mm)")
        _p(col, mod, "Wobble Size", "Size (cm)")
        _p(col, mod, "Wobble Complexity", "Complexity")
        _p(col, mod, "Strokes", "Strokes")
        _p(col, mod, "Seed", "Seed")
        _p(col, mod, "Boil Rate", "Boil Rate")


class SKETCHY_PT_overshoot(_SketchyChild, bpy.types.Panel):
    bl_label = "Overshoot"
    bl_order = 3
    panel_icon = 'CON_STRETCHTO'
    enable_socket = "Overshoot Enable"

    def draw(self, context):
        mod = _active_line_mod(context)[1]
        col = self.layout.column(align=True)
        # Taper (pen-lift feathering at stroke ends) is a stroke-end quality
        # independent of the overshoot toggle, so it always shows here.
        _p(col, mod, "Line Taper", "Taper")
        if self._on(context):
            col.separator()
            _p(col, mod, "Overshoot", "Overshoot (mm)")
            _p(col, mod, "Overshoot Random", "Random (mm)")


class SKETCHY_PT_breakup(_SketchyChild, bpy.types.Panel):
    bl_label = "Breakup"
    bl_order = 4
    panel_icon = 'MOD_NOISE'
    enable_socket = "Breakup Enable"

    def draw(self, context):
        if not self._on(context):
            return
        mod = _active_line_mod(context)[1]
        col = self.layout.column(align=True)
        _p(col, mod, "Opacity Breakup", "Opacity")
        _p(col, mod, "Opacity Size", "Size (cm)")
        col.separator()
        _p(col, mod, "Thickness Breakup", "Thickness")
        _p(col, mod, "Thickness Size", "Size (cm)")
        col.separator()
        _p(col, mod, "Grain", "Grain")
        _p(col, mod, "Grain Size", "Size (cm)")


class SKETCHY_PT_dashes(_SketchyChild, bpy.types.Panel):
    bl_label = "Dashes"
    bl_order = 5
    panel_icon = 'IPO_CONSTANT'
    enable_socket = "Dashes Enable"

    def draw(self, context):
        if not self._on(context):
            return
        mod = _active_line_mod(context)[1]
        col = self.layout.column(align=True)
        _p(col, mod, "Dash Length", "Dash (cm)")
        _p(col, mod, "Dash Gap", "Gap (cm)")


class SKETCHY_PT_smudge(_SketchyChild, bpy.types.Panel):
    bl_label = "Shading"
    bl_order = 6
    panel_icon = 'BRUSH_DATA'
    enable_socket = "Smudge Enable"

    def draw(self, context):
        if not self._on(context):
            return
        mod = _active_line_mod(context)[1]
        box = self.layout.column()
        _p(box, mod, "Shading Style", "Style")
        _color(box, mod, "Smudge Material", "Smudge Color", "Color")

        tone = box.column(align=True)
        _p(tone, mod, "Smudge", "Strength")
        _p(tone, mod, "Tone Steps", "Tone Steps")

        # pattern (Scale + Angle + mark weight + sketchiness; Scale = Smudge grain)
        pat = box.column(align=True)
        _p(pat, mod, "Smudge Size", "Scale (cm)")
        _p(pat, mod, "Pattern Angle", "Pattern Angle")
        _p(pat, mod, "Pattern Weight", "Weight")
        _p(pat, mod, "Sketchiness", "Sketchiness")

        # definition: sharp-edge accent + ambient-occlusion cavity
        defn = box.column(align=True)
        _p(defn, mod, "Edge", "Edge")
        _p(defn, mod, "Smudge Cavity", "Cavity (AO)")
        if _bool_val(mod, "Smudge Cavity"):
            _p(defn, mod, "Smudge Distance", "Reach (cm)")
            eng = context.scene.render.engine
            if eng.startswith('BLENDER_EEVEE') and not getattr(
                    context.scene.eevee, "use_raytracing", False):
                defn.label(text="Enable EEVEE Raytracing for cavity", icon='INFO')

        _p(box, mod, "Shade Outer Only", "Outer Shell Only")

        # fake light — at the bottom
        lit = box.column(align=True)
        _p(lit, mod, "Use Light Angle", "Fake Light")
        if _bool_val(mod, "Use Light Angle"):
            lid = socket_identifier(mod.node_group, "Light Empty")
            if lid is not None:
                row = lit.row(align=True)
                mi_prop(row, mod, lid, text="Light")
                row.operator("sketchy.add_light_empty", text="", icon='LIGHT_SUN')
                if mi_get(mod, lid) is None:
                    lit.label(text="Add an Empty, then aim its arrow", icon='INFO')


class SKETCHY_PT_drawon(_SketchyChild, bpy.types.Panel):
    bl_label = "Draw-On Animation"
    bl_order = 8
    panel_icon = 'ANIM'
    enable_socket = "Draw On"

    def draw(self, context):
        if not self._on(context):
            return
        mod = _active_line_mod(context)[1]
        box = self.layout.column()
        _p(box, mod, "Draw Amount", "Amount")
        _p(box, mod, "Draw Stagger", "Stagger")
        _p(box, mod, "Draw Easing", "Easing")
        box.label(text="Keyframe Amount to animate", icon='INFO')


class SKETCHY_PT_hidden(_SketchyChild, bpy.types.Panel):
    bl_label = "Hidden Lines"
    bl_order = 7
    panel_icon = 'HIDE_ON'
    enable_socket = "Show Hidden Lines"

    def draw(self, context):
        mod = _active_line_mod(context)[1]
        col = self.layout.column()
        # the header toggle shows/hides the ghost lines; occlusion itself always
        # runs, so Bias + Occlude Against stay visible whether or not they show.
        if self._on(context):
            box = col.column(align=True)
            _p(box, mod, "Hidden Line Opacity", "Opacity")
            _color(box, mod, "Material", "Hidden Color", "Color")
            _p(box, mod, "Hidden Width Scale", "Width Scale")
            _p(box, mod, "Hidden Dash Length", "Dash (cm)")
            _p(box, mod, "Hidden Dash Gap", "Gap (cm)")
            col.separator()
        sub = col.column(align=True)
        _p(sub, mod, "Depth Occlusion", "Depth Occlusion")
        _did = socket_identifier(mod.node_group, "Depth Occlusion")
        if _did is not None and mi_get(mod, _did, False):
            _p(sub, mod, "Depth Bias (mm)", "Depth Bias (mm)")
        else:
            _p(sub, mod, "Occlusion Bias", "Bias (mm)")
        sub.separator()
        sub.label(text="Occlude Against")
        oid = socket_identifier(mod.node_group, "Occlude Against")
        if oid is not None:
            mi_prop(sub, mod, oid, text="")


class SKETCHY_PT_fill(_SketchyChild, bpy.types.Panel):
    bl_label = "Fill / Matte"
    bl_order = 8
    panel_icon = 'SNAP_FACE'
    enable_socket = "Colour Fill"

    def draw(self, context):
        mod = _active_line_mod(context)[1]
        if not self._on(context):
            return
        col = self.layout.column(align=True)
        _p(col, mod, "Transparent Matte", "Transparent (Holdout)")

        # ⚠ A holdout needs somewhere to punch. With Film > Transparent OFF the hole
        # composites against the opaque film and the shape renders DARK GREY - measured
        # 0.264 vs 0.654 for the normal fill. Silent and baffling, so say it here.
        tid = socket_identifier(mod.node_group, "Transparent Matte")
        if tid is not None and mi_get(mod, tid, False) \
                and not context.scene.render.film_transparent:
            w = self.layout.column(align=True)
            w.label(text="Transparent Matte needs Film > Transparent", icon='ERROR')
            w.prop(context.scene.render, "film_transparent", text="Enable Film Transparent")

        sub = self.layout.column(align=True)
        sub.separator()
        _p(sub, mod, "Fill Follows Draw", "Follow Draw On")
        fid = socket_identifier(mod.node_group, "Fill Follows Draw")
        if fid is not None and mi_get(mod, fid, False):
            _p(sub, mod, "Matte Fade", "Fade")
            _p(sub, mod, "Matte Lead", "Finish Early")
        else:
            _p(sub, mod, "Fill Opacity", "Opacity")

        style = self.layout.column(align=True)
        style.separator()
        _color(style, mod, "Fill Material", "Fill Color", "Colour")
        _p(style, mod, "Fill Choke", "Choke")
        _p(style, mod, "Fill Texture", "Texture")
        _p(style, mod, "Fill Texture Size", "Texture Size")


class SKETCHY_PT_edges(_SketchyChild, bpy.types.Panel):
    bl_label = "Edges"
    bl_order = 1   # the line source — right after Line, before the styling sections
    panel_icon = 'EDGESEL'

    def draw(self, context):
        mod = _active_line_mod(context)[1]
        col = self.layout.column(align=True)
        _p(col, mod, "Angle Threshold", "Angle")
        _p(col, mod, "Include Sharp Edges", "Sharp Edges")
        _p(col, mod, "Include Boundaries", "Boundaries")
        _p(col, mod, "Use Freestyle Marks", "Freestyle Marks")
        # Silhouettes belong with the other edge TYPES: the tests above find nothing
        # on smooth geometry (a subdivided bottle measured 512,000 edges and 0 lines),
        # and this is the one that does. ⚠ _p no-ops when the socket is missing, so a
        # file that has not had Update Node Group run simply shows the old rows.
        _p(col, mod, "Include Silhouettes", "Silhouettes")

        # Simplify is not an edge type - it changes what every test above runs ON -
        # so it reads as its own idea rather than a fifth checkbox.
        sub = self.layout.column(align=True)
        sub.separator()
        _p(sub, mod, "Simplify (mm)", "Simplify")
        # Detail Limit is the other point-count lever. Render Width only exists because
        # Geometry Nodes cannot read the output resolution; it is kept in sync
        # automatically before every render, and is editable for preview at other sizes.
        _p(sub, mod, "Detail Limit (px)", "Detail Limit")
        _p(sub, mod, "Render Width (px)", "Render Width")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def _sync_render_width(scn):
    """Push the real output width into every line set before rendering.

    Geometry Nodes has no way to read the render resolution, so `Detail Limit (px)`
    needs it handed over. Doing it on render_pre means a resolution change or a
    percentage override can never leave a stale value baked into the strokes.
    """
    try:
        width = scn.render.resolution_x * scn.render.resolution_percentage / 100.0
    except Exception:
        return
    for ob in scn.objects:
        if not ob.get(MARKER_PROP):
            continue
        for m in ob.modifiers:
            if m.type != 'NODES' or not m.node_group:
                continue
            ident = socket_identifier(m.node_group, "Render Width (px)")
            if not ident:
                continue
            # ⚠ ONLY WRITE WHEN IT ACTUALLY CHANGES. Writing unconditionally re-tagged the
            # depsgraph on every render_pre -- i.e. every frame of an animation -- at the
            # exact moment the renderer was evaluating it. Blender 5.2 crashed during a
            # render with EXC_BAD_ACCESS in BKE_layer_eval_view_layer_indexed on a
            # depsgraph task under RE_engine_render. Whether or not that was the cause,
            # dirtying geometry from inside a render callback is not defensible.
            want = float(max(width, 16.0))
            try:
                cur = mi_get(m, ident, None)
                if cur is not None and abs(float(cur) - want) < 1e-6:
                    continue
                mi_set(m, ident, want)
            except Exception:
                pass


@bpy.app.handlers.persistent
def _render_width_pre(scn, *args):
    _sync_render_width(scn)


classes = (
    SKETCHY_OT_add_line_set,
    SKETCHY_OT_remove_line_set,
    SKETCHY_OT_apply_occluder,
    SKETCHY_OT_build_proxy_occluder,
    SKETCHY_OT_reset_settings,
    SKETCHY_OT_add_light_empty,
    SKETCHY_OT_rebuild,
    SKETCHY_OT_build_occluders,
    SKETCHY_OT_make_buildon,
    SKETCHY_OT_check_setup,
    SKETCHY_OT_fast_viewport,
    SKETCHY_OT_cull_offscreen,
    SKETCHY_OT_build_source,
    SKETCHY_OT_mark_edges,
    SKETCHY_OT_apply_preset,
    SKETCHY_OT_save_preset,
    SKETCHY_OT_delete_preset,
    SKETCHY_OT_render_thumbnails,
    SKETCHY_MT_presets,
    SKETCHY_MT_delete_presets,
    SKETCHY_UL_line_sets,
    SKETCHY_PT_panel,
    SKETCHY_PT_line,
    SKETCHY_PT_wobble,
    SKETCHY_PT_overshoot,
    SKETCHY_PT_breakup,
    SKETCHY_PT_dashes,
    SKETCHY_PT_smudge,
    SKETCHY_PT_hidden,
    SKETCHY_PT_edges,
    SKETCHY_PT_fill,
    SKETCHY_PT_drawon,
)


# ⚠ Blender writes bl_* back onto the Python class during (un)register, so a hot reload
# leaves STALE values that silently override the source. On the AniTools -> Werkbench rename
# this kept the whole panel tree drawing in the DEAD tab, and separately zeroed bl_order so
# sub-panels fell back to alphabetical. Snapshot the intent at import, while the classes are
# fresh from source, and re-assert it every register.
_PANEL_INTENT = {c.__name__: (PANEL_CATEGORY, c.__dict__.get("bl_order"))
                 for c in classes if issubclass(c, bpy.types.Panel)}


def register():
    global _preset_previews
    import bpy.utils.previews
    _preset_previews = bpy.utils.previews.new()
    for cls in classes:
        intent = _PANEL_INTENT.get(cls.__name__)
        if intent is not None:
            cls.bl_category = intent[0]
            if intent[1] is not None:
                cls.bl_order = intent[1]
        bpy.utils.register_class(cls)
    bpy.types.Scene.sketchy_fast_amount = bpy.props.FloatProperty(
        name="Fast Amount", default=8.0, min=1.0, max=64.0,
        description="Detail Limit that Fast Viewport switches to, in pixels. It writes a "
                    "VIEWPORT-ONLY socket, so leaving Fast Viewport on can never coarsen a "
                    "render. Self-tuning, unlike a blind multiplier: it stays right as you "
                    "dolly in and out")
    bpy.types.Scene.sketchy_target_collection = bpy.props.PointerProperty(
        type=bpy.types.Collection, name="Collection",
        description="Collection whose meshes get sketchy line art")
    bpy.types.Scene.sketchy_active_index = bpy.props.IntProperty(
        name="Active Line Set", default=0)
    bpy.types.Scene.sketchy_occluder = bpy.props.PointerProperty(
        type=bpy.types.Collection, name="Occlude Against",
        description="Shared collection every line set hides behind, so separate "
                    "line sets occlude each other. Put your source objects (or a "
                    "parent collection containing them) here. New line sets adopt "
                    "it automatically")
    bpy.types.WindowManager.sketchy_preset_sel = bpy.props.EnumProperty(
        name="Style", description="Pick a style preset from its thumbnail",
        items=_preset_enum_items, update=_preset_enum_apply)
    if _migrate_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_migrate_load_post)
    if _render_width_pre not in bpy.app.handlers.render_pre:
        bpy.app.handlers.render_pre.append(_render_width_pre)
    # ⚠ bpy.data is RESTRICTED while Blender is starting up or mid-file-load, and
    # add-ons register in exactly that window -- touching bpy.data here raised
    # AttributeError: '_RestrictData' object has no attribute 'node_groups' and
    # FAILED REGISTRATION. Only migrate when data is actually reachable; the
    # load_post handler covers every other case.
    try:
        _migrate_legacy_names()          # for a file already open when we enable
        _cleanup_frozen()
    except Exception:
        pass


def unregister():
    global _preset_previews
    if _migrate_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_migrate_load_post)
    if _render_width_pre in bpy.app.handlers.render_pre:
        bpy.app.handlers.render_pre.remove(_render_width_pre)
    del bpy.types.WindowManager.sketchy_preset_sel
    del bpy.types.Scene.sketchy_occluder
    del bpy.types.Scene.sketchy_active_index
    del bpy.types.Scene.sketchy_target_collection
    del bpy.types.Scene.sketchy_fast_amount
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    if _preset_previews is not None:
        bpy.utils.previews.remove(_preset_previews)
        _preset_previews = None


if __name__ == "__main__":
    register()
