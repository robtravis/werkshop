# Sketchwerks

**Realtime, hand-drawn line art for Blender, built for archviz and stable under camera motion.**

Sketchwerks turns the feature edges of your models into wobbly, textured, hand-drawn
strokes (pencil, charcoal, ink, and more) using a single Geometry Nodes system. It was
built to replace Cinema 4D's Sketch & Toon workflow and to fix the problems that make
Blender's Grease Pencil Line Art and Freestyle painful for animation:

- **No jitter, no popping.** The wobble and texture are keyed to *world-space* geometry,
  never to the camera or screen, so lines can't swim or crawl as the camera moves.
- **No baking, no separate overlay.** Strokes are real mesh ribbons that render and
  anti-alias natively, identical in the viewport and the final frame.
- **Realtime.** Everything updates live as you move objects, tweak sliders, or scrub the
  timeline.

Version **1.0.0 Beta 2** · Blender **4.2+** (developed and tested on 5.2) · EEVEE.

> **Render in EEVEE.** Strokes are flat emission, so Cycles spends path-tracing effort that
> produces nothing. A lines-only pass measured 2.6 s in EEVEE at 1920x1080. Cycles also
> stresses the GPU far harder for no gain: on macOS Metal it produced a driver fault on a
> scene EEVEE handled without trouble.

---

## Installation

1. In Blender: **Edit → Preferences → Add-ons → Install…**
2. Select `sketchwerks.zip`.
3. Enable **"Sketchwerks"**.
4. Open the **N-panel** in the 3D viewport (press `N`) and go to the **Sketchwerks** tab.

Updating from an older version? Reinstall the zip, then click the **Update Node Group**
button in the panel header. It rebuilds the node group from the new code while keeping
every line set's settings, materials and keyframes.

Files made with an earlier release keep working. Sockets added in a new version only
appear after Update Node Group, so run it once per file after upgrading.

---

## Quick start

1. Put the objects you want outlined in a **collection**.
2. In the Sketchwerks tab, pick that collection, then press **+** to create a line set.
3. Choose a look from the **Style Preset** dropdown (for example *HB Pencil* or *Charcoal*).
4. Adjust **Width** and **Color**, then open any section below to refine.

A line set is a self-contained object (kept in a "Sketchwerks Lines" collection) with its
own modifier and material. Add several line sets to give different collections different
styles in the same scene. The list at the top switches between them and the panel follows.

---

## Marking edges

By default, drawn edges are auto-detected (see **Edges**). To force specific edges in or
out, enter **Edit Mode** on a source mesh, select edges, and use the buttons in the panel:

- **Mark Line / Clear** forces the selected edges to always draw.
- **Mark Hide / Clear** removes the selected edges from the line art.

These are stored as mesh attributes, so they persist in the .blend and survive edits.

---

## The controls

The top of the panel holds the essentials; everything else is a collapsible section (also
mirrored as panels in the modifier's Properties tab). On/off sections are boxed: the
checkbox is the box header, and its controls appear when it's on.

### Line
- **Collection** picks which collection's meshes get drawn.
- **Width (mm)** sets stroke width in real millimetres (world-space, so it reads thinner
  with distance like a real pen).
- **Color** is the visible line colour.
- **Constant On-Screen** anchors width to a **Reference Distance** instead, so a line keeps
  the same weight on screen wherever it sits in depth. Set Reference Distance to roughly
  your subject distance. Useful when a wide depth range makes near lines read far heavier
  than far ones.

### Wobble, the hand-drawn wander
World-locked displacement. Amount is the distance, Size is the wavelength, Complexity adds
octaves. Because it is sampled from world position it cannot swim as the camera moves.

### Overshoot, pen running past the join
Extends strokes past their corners. **Overshoot doubles stroke geometry while enabled**, so
switch it off for heavy shots.

### Breakup, media texture
Opacity and Thickness breakup, plus Grain. These vary the stroke along its length to suggest
paper tooth and pressure.

### Dashes
Dashed strokes with independent length and gap.

### Smudge, soft shading
- **Enable / Strength** turns it on and sets its darkness (0 to 2).
- **Reach (cm)** is how far the tone bleeds in from form edges.
- **Grain (cm)** is the tooth size (small for fine powder, large for rough charcoal).
- **Color** is the smudge tone.
- **Cavity (AO)** adds optional true ambient-occlusion darkening. **In EEVEE this needs
  Raytracing enabled.** The base facing tone works without it.

### Edges, what gets drawn
- **Angle** draws edges whose face angle exceeds this threshold.
- **Sharp Edges / Boundaries / Freestyle Marks** also include those edge types.
- **Silhouettes** draws the view silhouette: edges whose two faces disagree about facing the
  camera. This is the only test that finds anything on smooth geometry, where the angle test
  returns nothing. It is view-dependent, which matters for animation (see Draw Spread).
- **Simplify (mm)** merges stroke points closer together than this. It is a world measure,
  so a value that is invisible on a facade will eat mullions on a cabinet. Leave it at 0
  unless you need the speed.

### Detail, the screen-space cap
- **Detail Limit (px)** stops the system resampling strokes finer than this many pixels.
  Point spacing is otherwise set in world units by the smallest noise size, which routinely
  generates several times more geometry than the render can resolve. It is self-tuning: fine
  up close, coarse far away. 3 is the default and is visually free. Higher is cheaper.
- **Render Width (px)** is the output width the cap measures against. Geometry Nodes cannot
  read the render resolution, so it is handed over here, and it is synced automatically
  before every render.

---

## Occlusion

Occlusion always runs, by raycasting from the active camera to each stroke point.

### Hidden Lines
- **Show Hidden Lines** draws occluded lines in their own style instead of removing them,
  revealing Opacity / Color / Width Scale / Dash / Gap.
- **Bias (mm)** is how far short of a surface the visibility ray stops. Raise it above
  Wobble Amount if lines flicker on the surfaces they lie on.
- **Occlude Against** is a collection this set *also* hides behind, on top of its own
  geometry.

### Making separate line sets occlude each other
By default a line set only occludes against its own collection, so two sets ignore each
other and lines show through objects they should be behind.

Press **Build Occluder Set**. It collects every static line set's source into one shared
"Sketchwerks Occluders" collection and points all sets at it. Collections are **linked, not
moved**, so your outliner is unchanged, and it is safe to press again after adding a set.

Two things it does deliberately:

- **Build-on sets are excluded.** Raycast occlusion has no concept of time, so an object
  with Draw On enabled would punch holes in everything behind it from frame 1, long before
  it has been drawn. Build-ons occlude through their timed matte instead (see below). The
  relationship is asymmetric on purpose: static geometry occludes the build-on, never the
  reverse.
- **Anything you add by hand stays.** Drag a collection into "Sketchwerks Occluders" and the
  button leaves it alone. That is the place for geometry that should block lines but is never
  drawn, such as a ceiling or a wall you do not want linework on.

Note that Geometry Nodes reads the collection directly, so its contents occlude even when
excluded or hidden in the view layer. That is what makes a lines-only render work, and it
also means a collection you switch off in the outliner is still occluding.

### Depth Occlusion
Lets the renderer's depth buffer hide the lines instead of raycasting them. Much faster,
since the occluder geometry is never traced. It requires your objects to be present and
drawn in the view layer: if they are excluded or hidden there is no depth to test against
and **every line shows**, so it cannot be used for a lines-only render. Hidden Lines cannot
be styled in this mode, only hidden.

### Heavy scenes: the proxy occluder
The occlusion raycast scales with the occluder's polygon count, so on dense scenes it can
dominate. **Build Proxy Occluder** builds a low-poly stand-in and points every line set at
it. Choose a **Detail** ratio (0.1 is 10x lighter). The proxy meshes share your source data
so they follow edits, carry a Decimate modifier, follow the originals live via a constraint,
and are invisible to the camera. They never render; they just make the raycast cheap.

---

## Build-on animation

Lines draw themselves on over time, like a hand sketching the scene, and each object starts
occluding once it has been drawn.

### Setting one up
1. Put that stage's objects in their own collection. **Link** them (`Shift+M`) rather than
   moving them, so they stay where they are in your outliner.
2. Pick the collection and press **+** to create a line set.
3. Press **Make Build-On**. It enables Draw On and the Colour Fill matte, ties the matte to
   the draw, and sizes Draw Spread from the collection.
4. Keyframe **Draw Amount** from 0 to 1 over the frames you want, and set those keys to
   **Linear**.
5. Press **Make Build-On** again. Now that the keys exist it sizes the matte dissolve to
   them, which is the step that stops a short stage flashing.

Repeat per stage, staggering the keyframe ranges.

> **Exclude every source collection from the View Layer.** That is what makes a line set read
> as a drawing rather than as shaded geometry with lines drawn on it. Miss one and, on a
> transparent film with nothing lighting it, that collection renders as a solid black shape
> sitting over the artwork. The line art is unaffected: it reads collection membership, not
> the View Layer.

> **Do not also make the parent a line set.** An object that sits in two line-set source
> collections is drawn twice: doubled linework, doubled cost, doubled occlusion.

### Draw-On controls
- **Draw On** enables the reveal.
- **Amount** runs 0 for blank to 1 for complete. **Keyframe this.** Use Linear keys; Bezier
  eases both ends and makes a build start late and finish early.
- **Stagger** runs 0 for all lines at once to 1 for one after another.
- **Draw Spread (m)** sets the size of the spatial pattern that decides draw order. At 0 the
  order is a per-stroke random, which **strobes** if Silhouettes are on and the camera moves,
  because silhouette edges are view-dependent and the stroke set changes every frame. Above
  0, nearby strokes draw together and the order is stable. Make Build-On sizes this for you.
- **Easing** applies Linear / Ease In / Ease Out / Ease In-Out to Amount.

### The occlusion matte
A build-on needs to start hiding the background only once it has drawn, which raycast
occlusion cannot express. **Colour Fill** provides it: the object's own surfaces, rendered
flat, dissolving in as the drawing completes.

- **Colour Fill** enables the matte. Only build-ons need it. **A static set does not**, and a
  fill on overlapping geometry can z-fight into visible grey patches.
- **Follow Draw On** derives the matte's opacity from that set's own Draw Amount, so it needs
  no keyframes of its own and survives retiming.
- **Fade** is how much of the draw the dissolve spans, as a fraction, so the same number
  means different durations on different stages. On a 15 frame stage 0.1 is a frame and a
  half, and because the fill renders dithered that single in-between frame arrives as a
  flash rather than a dissolve. Make Build-On sizes this to about six frames once Draw
  Amount is keyed, which is why step 5 above matters.
- **Finish Early** slides the dissolve earlier so the occlusion is fully settled before the
  last strokes land. Make Build-On sizes it to about three frames.
- **Opacity** is the manual override when Follow Draw On is off.
- The matte is revealed **spatially**, not by fading: the dissolve raises a threshold
  against a world-locked noise pattern, so every pixel is fully matte or fully clear and the
  shape fills in region by region as the drawing lands. The grain follows **Draw Spread**.
  Partial opacity is what the fill cannot do, because it renders dithered and a half-faded
  matte comes out as an opaque noise plate over the artwork.
- **Transparent (Holdout)** renders the matte as a holdout: it still hides what is behind it
  but punches alpha to zero, so it comps as an empty matte rather than a solid shape. It
  **requires Film > Transparent**, or the fill renders dark grey instead of invisible. The
  panel warns and offers the toggle when the two disagree.
- **Colour / Choke / Texture** style the fill when it is visible.

---

## Performance

- **Detail Limit** is the first lever. It is camera-derived, so it applies to renders as well
  as the viewport.
- **Fast Viewport** switches every line set to a coarser detail limit for camera work. It
  writes a viewport-only value, so leaving it on can never coarsen a render.
- **Cull Off-Camera** takes source objects the camera never sees across the whole frame range
  out of the line sets entirely. Press again to restore. It samples the whole range rather
  than each frame, so the kept set is identical on every frame and stroke order never
  reshuffles.
- **Build Proxy Occluder** is the biggest win when the raycast dominates.

---

## Check Setup

**Check Setup** scans every line set and warns about configurations that are known to look
broken. It only reports; it never changes anything. It catches a build-on that will strobe,
a build-on that cannot occlude, a build-on that occludes before it draws, a fill on a static
set that can z-fight, a holdout with an opaque film, alpha being dropped on save, geometry
drawn twice, a source collection left in the View Layer while the others are excluded, a line
set pointed at no occluder collection, and draw-on keys that are not Linear.

Run it after building a scene's line sets, and again before rendering.

---

## Style presets

The **Style Preset** menu carries 20 media looks: Pencil (2H, HB, 6B, Colored), Charcoal
and Chalk, Pen (Technical, Fineliner, Ballpoint, Fountain), Ink and Brush, Wax and Pastel,
and Stylized (Architect Sepia, Blueprint, Boiling Sketch). Presets set the *look* only; they
never touch edge selection or occlusion.

**Save your own:** tune a line set, press **+** next to the preset menu, and name it. User
presets are JSON files in your Blender scripts folder (`presets/sketchy_lineart/`), so they
persist across sessions and .blends.

---

## Rendering a lines-only pass

1. Exclude the geometry collections from the view layer. The lines still occlude correctly,
   because Geometry Nodes reads the collections directly.
2. Keep **Depth Occlusion off**. With the geometry excluded there is no depth buffer, so the
   raycast is the only thing that can hide anything.
3. Render in **EEVEE**.
4. Set **Film > Transparent** on, and **Color Mode to RGBA**.

> **RGB silently drops the alpha.** A transparent pass saved as RGB writes the background as
> black, and with black lines on top the result is a completely black frame.

Suggested EEVEE settings for linework: **Filter Size 1.0** (measured closest to a 4x
supersampled reference; 1.5 over-blurs and 0.8 slightly under-blurs), **64 samples** (higher
measured indistinguishable on flat emission geometry), shadows and raytracing off, motion
blur off, and **View Transform: Standard**. AgX lifts the blacks and tints the paper, so it
should never be used for line art.

---

## Tips and notes

- **Line weight is world-space** by default. A 6 mm line looks bold up close and thin far
  away. Use Constant On-Screen if you want even weight through depth.
- **Smudge Cavity needs EEVEE Raytracing** (Render Properties, Raytracing).
- **Overshoot doubles stroke geometry while on.** Switch it off for heavy shots.
- **Motion blur does not work on strokes.** The geometry changes topology every frame, so
  there are no valid motion vectors to blur along.
- **After updating the add-on**, click **Update Node Group**. It rebuilds the node group while
  keeping every setting, material and keyframe.

---

## How it works (the short version)

- **World-locked wobble.** Displacement noise is sampled from each point's stored world
  position, not from view or screen space. This is what eliminates the swimming and jitter.
- **Real geometry.** Strokes are `Curve → Mesh` ribbons, so anti-aliasing is ordinary render
  sampling.
- **Occlusion by raycast.** Each point casts toward the active camera, stopping short by the
  Bias distance. Occluded points are hidden, or with *Show Hidden Lines* slid along their view
  ray to render on top.
- **Screen-space detail cap.** Resample spacing is the coarser of the noise-derived world
  length and one pixel at the subject's distance, so nothing finer than the render can show is
  ever built.
- **Grain in the shader.** Paper tooth is per-pixel world-position noise choking in from the
  stroke's silhouette, so it can be far finer than the mesh.

---

*Sketchwerks · v1.0.0 Beta 2 · by Rob Travis*
