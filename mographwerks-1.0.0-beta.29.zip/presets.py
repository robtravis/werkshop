"""Style presets for MoType: a look you can apply, save and share.

⚠⚠ A PRESET IS VALUES, NEVER SOCKETS. C4D's MoGraph carries 148 sockets because Rotation and
Scale repeat seven times, once per array type, with no shared layer to hold them. If a preset
here ever needs a socket of its own, something has gone wrong: it applies to ONE socket set.

⚠⚠ KEYED BY SOCKET NAME, NEVER BY INDEX. Socket identifiers are creation-ordered and this
codebase only ever appends, so a preset written today has to still apply after six more
builds. A name survives that; an index does not.

⚠ A STYLE PRESET CHANGES HOW THE TYPE LOOKS, NEVER WHAT IT SAYS OR WHERE IT SITS. Text, Font,
Size, Align and the text box are deliberately NOT owned — a preset you are afraid to click
because it might rewrite your layout is a preset nobody clicks.
"""

import json
import os

import bpy

from . import ng, props

SUBDIR = "presets"

# ⚠⚠ THE OWNED SET, and it is the whole design. Applying RESETS every one of these to the
# group's own default before writing the preset's values. Without that, applying preset B
# after preset A leaves A's strays behind and you get a look that exists in nobody's file but
# yours — the classic preset bug, and it is only avoidable by declaring ownership up front.
PRESET_SOCKETS = {
    "MG_Cloner_MoType": (
        "Fill Caps", "Depth", "Bevel Offset", "Bevel Segments", "Bevel Shape",
        "Squeeze", "Resample",
        "Character Spacing", "Word Spacing", "Line Spacing",
    ),
}

# ⚠ LENGTH-LIKE VALUES ARE RESCALED ON APPLY. A preset authored at Size 1.0 with Depth 0.25
# looks absurd on type at Size 0.1, and presets are meant to travel. The sockets stay ABSOLUTE
# because that is what people expect to type; the applier does the work, using the preset's
# own `authored_at_size`. Spacing needs no entry here: String to Curves already treats those
# as multipliers, so they are size-agnostic already.
SCALE_WITH_SIZE = {"Depth", "Bevel Offset"}

SCHEMA = 1


def _shipped_dir():
    return os.path.join(os.path.dirname(__file__), SUBDIR)


def user_dir(create=False):
    """Where a user's own presets live.

    ⚠⚠ NEVER INSIDE THE ADDON FOLDER. Blender replaces that whole directory on update, so a
    preset saved there is destroyed by the next Check for Updates — and the loss only shows up
    after someone has built a library worth keeping.
    """
    return bpy.utils.user_resource('CONFIG', path="mographwerks/" + SUBDIR, create=create)


def _read(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception as exc:
        print("[mographwerks] preset unreadable, skipped: %s (%s)" % (path, exc))
        return None
    if not isinstance(data, dict) or "values" not in data:
        print("[mographwerks] preset has no values, skipped: %s" % path)
        return None
    data["_path"] = path
    data.setdefault("name", os.path.splitext(os.path.basename(path))[0])
    data.setdefault("target", "MG_Cloner_MoType")
    data.setdefault("authored_at_size", 1.0)
    data.setdefault("schema", SCHEMA)
    return data


def load(target="MG_Cloner_MoType"):
    """Every preset for `target`, shipped ones first, then the user's."""
    out = []
    for d, editable in ((_shipped_dir(), False), (user_dir(), True)):
        if not d or not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            if not fn.lower().endswith(".json"):
                continue
            p = _read(os.path.join(d, fn))
            if p is not None and p.get("target") == target:
                p["_editable"] = editable
                out.append(p)
    return out


def _defaults(group, names):
    """The group's own default for each owned socket, so a reset means something."""
    out = {}
    for item in group.interface.items_tree:
        if getattr(item, "in_out", "") != 'INPUT' or item.name not in names:
            continue
        if hasattr(item, "default_value"):
            v = item.default_value
            out[item.name] = list(v) if hasattr(v, "__len__") and not isinstance(v, str) else v
    return out


def apply(mod, preset):
    """Reset the owned set, then write the preset over it. Returns (written, skipped)."""
    group = mod.node_group
    if group is None:
        return 0, []
    owned = PRESET_SOCKETS.get(group.name, ())
    if not owned:
        return 0, []
    # ⚠ RESET FIRST. See PRESET_SOCKETS above: this is what stops preset A leaking into B.
    for name, value in _defaults(group, owned).items():
        try:
            props.set(mod, name, value)
        except Exception:
            pass
    size = props.get(mod, "Size")
    try:
        ratio = float(size) / float(preset.get("authored_at_size") or 1.0)
    except Exception:
        ratio = 1.0
    written, skipped = 0, []
    for name, value in preset.get("values", {}).items():
        # ⚠ AN UNKNOWN KEY IS SKIPPED WITH ONE LINE, NEVER AN ERROR. A preset from a newer
        # build applied on an older one has to degrade, not fail.
        if name not in owned:
            skipped.append(name)
            continue
        if name in SCALE_WITH_SIZE and isinstance(value, (int, float)):
            value = value * ratio
        try:
            props.set(mod, name, value)
            written += 1
        except Exception as exc:
            skipped.append("%s (%s)" % (name, exc))
    if skipped:
        print("[mographwerks] preset %r skipped: %s" % (preset.get("name"), ", ".join(skipped)))
    return written, skipped


def capture(mod, name, description=""):
    """The owned set as it stands, ready to write out."""
    group = mod.node_group
    owned = PRESET_SOCKETS.get(group.name, ()) if group else ()
    values = {}
    for sock in owned:
        v = props.get(mod, sock)
        if v is None:
            continue
        values[sock] = list(v) if hasattr(v, "__len__") and not isinstance(v, str) else v
    return {
        "schema": SCHEMA,
        "name": name,
        "description": description,
        "target": group.name if group else "MG_Cloner_MoType",
        # ⚠ RECORDED, NOT ASSUMED. It is what lets the same preset land correctly on type at
        # any size, and guessing 1.0 here would quietly break every preset saved at another.
        "authored_at_size": float(props.get(mod, "Size") or 1.0),
        "values": values,
    }


def write(preset, filename=None):
    d = user_dir(create=True)
    safe = "".join(c for c in preset["name"] if c.isalnum() or c in " -_").strip()
    path = os.path.join(d, filename or ((safe or "preset") + ".json"))
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(preset, fh, indent=2, sort_keys=True)
    return path


# ------------------------------------------------------------------------------- operators
class MG_OT_apply_preset(bpy.types.Operator):
    """Apply this style preset to the cloner"""
    bl_idname = "mographwerks.apply_preset"
    bl_label = "Apply Preset"
    bl_options = {'REGISTER', 'UNDO'}

    mod_name: bpy.props.StringProperty()
    path: bpy.props.StringProperty()

    def execute(self, context):
        from . import cloner
        car = context.active_object
        mod = car.modifiers.get(self.mod_name) if car else None
        if mod is None:
            mod = cloner.cloner_mod(car) if car else None
        if mod is None:
            self.report({'WARNING'}, "No cloner selected")
            return {'CANCELLED'}
        preset = _read(self.path)
        if preset is None:
            self.report({'WARNING'}, "Preset could not be read")
            return {'CANCELLED'}
        written, skipped = apply(mod, preset)
        self.report({'INFO'}, "%s applied (%d values%s)"
                    % (preset["name"], written,
                       ", %d skipped" % len(skipped) if skipped else ""))
        return {'FINISHED'}


class MG_OT_save_preset(bpy.types.Operator):
    """Save this cloner's style as a preset you can reuse"""
    bl_idname = "mographwerks.save_preset"
    bl_label = "Save Style Preset"
    bl_options = {'REGISTER'}

    mod_name: bpy.props.StringProperty()
    name: bpy.props.StringProperty(name="Name", default="My Style")
    description: bpy.props.StringProperty(name="Description", default="")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        from . import cloner
        car = context.active_object
        mod = car.modifiers.get(self.mod_name) if car else None
        if mod is None:
            mod = cloner.cloner_mod(car) if car else None
        if mod is None:
            self.report({'WARNING'}, "No cloner selected")
            return {'CANCELLED'}
        path = write(capture(mod, self.name, self.description))
        self.report({'INFO'}, "Saved to %s" % path)
        return {'FINISHED'}


class MG_MT_presets(bpy.types.Menu):
    """The preset list. Shipped ones first, then anything the user saved."""
    bl_idname = "MG_MT_presets"
    bl_label = "Style Presets"

    def draw(self, context):
        from . import cloner
        layout = self.layout
        mod = cloner.cloner_mod(context.active_object)
        group = mod.node_group.name if mod and mod.node_group else "MG_Cloner_MoType"
        items = load(group)
        if not items:
            layout.label(text="No presets found", icon='INFO')
            return
        shipped = [p for p in items if not p.get("_editable")]
        mine = [p for p in items if p.get("_editable")]
        for group_items, label in ((shipped, None), (mine, "Yours")):
            if not group_items:
                continue
            if label:
                layout.separator()
                layout.label(text=label)
            for p in group_items:
                op = layout.operator("mographwerks.apply_preset", text=p["name"])
                op.path = p["_path"]
                op.mod_name = mod.name if mod else ""


_CLASSES = (MG_OT_apply_preset, MG_OT_save_preset, MG_MT_presets)


def register():
    for c in _CLASSES:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(_CLASSES):
        bpy.utils.unregister_class(c)
