"""The cloner: one MG_Cloner modifier, on the object itself or on a carrier.

⚠ A CLONER IS JUST CLONES. It creates no effector. Rob: *"an Effector should be a choice,
not added by default. There are times you'd use a cloner without an Effector."*

⚠ ONE OBJECT AND SEVERAL OBJECTS ARE DIFFERENT SHAPES, deliberately:

    one object       the modifier goes ON IT. Nothing is hidden, nothing is created but the
                     collection — the mesh simply becomes its clones.
    several objects  the sources move into a hidden `.Source` collection and a CARRIER holds
                     the modifier. Rob: "If multiple objects are selected, we do the hide
                     source like we had before."

⚠ THE CARRIER IS FORCED, not a preference. A host that reads a collection containing itself
is a dependency cycle, so with several sources the modifier cannot live on one of them.
It appears only in that case — Rob's original complaint ("Cloner is adding a new empty")
was about the single-object case, which no longer creates anything.

⚠ HIDE SOURCE DEACTIVATES THE COLLECTION — `layer_collection.exclude`, the outliner's
checkbox — exactly as v0.65.0 did. See MOGRAPHWERKS_V065_REFERENCE.md §2. It covers viewport
AND render in one toggle and stops the objects being EVALUATED, which the visibility flags do
not. `collection.hide_render` is set with it because exclude is per-view-layer while
hide_render is global, and the objects' own flags are cleared so the two cannot fight.
⚠ APPLIED AT CREATION AND FROM THE TOGGLE ONLY, never from a sync path — re-activating the
collection to edit the originals must not be undone behind your back.
⚠ EVERY VIEW LAYER, not just the active one: exclude is per-view-layer, so hiding in one and
not the others is a source that reappears the moment you switch.
"""

import bpy
import mathutils

from . import ng, props

MOD_NAME = "Cloner"


def group_of(obj):
    """The `.Cloner` collection this object was filed into, or None."""
    if obj is None:
        return None
    for c in obj.users_collection:
        if c.get("mg_group"):
            return c
    return None


def sources_of(car):
    """The hidden `.Source` collection feeding this cloner, or None."""
    m = cloner_mod(car)
    return props.get(m, "Sources") if m is not None else None


def _layer_collections(coll_name):
    """Every view layer's LayerCollection for this collection.

    ⚠ SEARCH RECURSIVELY, and across ALL view layers. `exclude` lives on the LayerCollection,
    not the collection, so there is one per view layer and hiding only the active one leaves
    the sources visible in every other.
    """
    out = []

    def walk(lc):
        if lc.collection.name == coll_name:
            out.append(lc)
        for ch in lc.children:
            walk(ch)

    for sc in bpy.data.scenes:
        for vl in sc.view_layers:
            walk(vl.layer_collection)
    return out


def set_hidden(coll, hidden):
    """Hide or reveal a source collection, v0.65.0's way."""
    if coll is None:
        return
    for o in coll.objects:
        o.hide_viewport = False
        o.hide_render = False
    coll.hide_render = hidden
    for lc in _layer_collections(coll.name):
        lc.hide_viewport = False
        lc.exclude = hidden


def _parent_of(coll):
    """The collection `coll` sits in — the scene root if nothing else claims it.

    ⚠ SEARCH, do not guess. A collection has no `parent`, so the only way to put things
    back where they came from is to find who links it.
    """
    for c in bpy.data.collections:
        if coll.name in c.children:
            return c
    return bpy.context.scene.collection


def _home_of_object(obj):
    """The collection to file a new group in — the one `obj` already lives in.

    ⚠ WHERE THE SOURCE WAS, not one level up. Rob: "The new collection should be created where
    the source object or collection was." Same rule as `_make_group`, so a cloner built from an
    object in `Objects/Props` appears in `Objects/Props` rather than climbing to `Objects`.
    ⚠ SAFE despite `_from_collection`'s "never inside" warning, and the difference is which
    SOCKET is used: that path reads a COLLECTION, so a carrier within it is a cycle. This one
    reads the OBJECT, so sharing a collection with it is not. Repointing such a cloner at this
    collection later WOULD reproduce the cycle — which is why the Source panel names both
    sockets rather than hiding one.
    """
    return obj.users_collection[0] if obj.users_collection else bpy.context.scene.collection


HIDDEN_BY = "mg_hidden_by"


def set_object_hidden(obj, hidden, car=None):
    """Hide or reveal a single object that a cloner reads through the Object socket.

    ⚠⚠ `hide_set()` — THE EYE — NEVER `hide_viewport`, THE MONITOR. The monitor takes the
    object out of EVALUATION, and the cloner reads this object: hiding it that way gives ZERO
    clones, silently, which is the same class of failure as a carrier inside its own source.
    The eye hides it from view while it goes on being evaluated.
    ⚠ STAMPED WITH WHO HID IT, so Remove Cloner reveals only what this add-on hid and leaves an
    object the user had already hidden exactly as they left it.
    """
    if obj is None:
        return
    vls = _view_layers_containing(obj)
    if hidden:
        # ⚠⚠ IF THE USER ALREADY HID IT, DO NOTHING AT ALL. Stamping unconditionally claims
        # their object, and Remove Cloner then reveals it — changing their scene on the way
        # out. The stamp means "we hid this", not "this is hidden".
        # ⚠ TEST THE EYE, NOT `hide_render`. They are independent axes: hiding with the eye
        # leaves hide_render False, so an OR of the two reports a hidden object as visible.
        # Measured — that is exactly how this claimed a user-hidden cube.
        if vls and not any(not obj.hide_get(view_layer=vl) for vl in vls):
            return
        if HIDDEN_BY not in obj:
            obj[HIDDEN_BY] = car.name if car is not None else ""
        obj.hide_render = True
        for vl in vls:
            obj.hide_set(True, view_layer=vl)
    else:
        if HIDDEN_BY in obj:
            del obj[HIDDEN_BY]
        obj.hide_render = False
        for vl in vls:
            obj.hide_set(False, view_layer=vl)


def _view_layers_containing(obj):
    """Every view layer that can see `obj` — hide_set is per view layer, like exclude."""
    out = []
    for sc in bpy.data.scenes:
        for vl in sc.view_layers:
            try:
                if obj.name in vl.objects:
                    out.append(vl)
            except (ReferenceError, RuntimeError):
                continue
    return out


def object_source_hidden(car):
    """Is this cloner's Object source hidden by us? None when there is no object source."""
    m = cloner_mod(car)
    src = props.get(m, "Source") if m is not None else None
    if src is None:
        return None
    return HIDDEN_BY in src


def _make_group(context, base, objs):
    """A new `<name>.Cloner` collection, made where these objects already live.

    ⚠ IN THE COLLECTION THE OBJECT WAS IN, not the scene root. Rob: "Cloner and Fields get
    collected in a new collection in the root of where the object was." Dropping it at the
    scene root would pull the object out of whatever the user had organised.
    """
    home = objs[0].users_collection[0] if objs[0].users_collection \
        else context.scene.collection
    grp = bpy.data.collections.new(base + ".Cloner")
    grp["mg_group"] = True
    home.children.link(grp)
    for o in objs:
        for c in list(o.users_collection):
            c.objects.unlink(o)
        grp.objects.link(o)
    return grp


def is_cloner(obj):
    return bool(obj and obj.get("mg_cloner"))


def cloner_mod(obj):
    """The MG_Cloner modifier on this object, whatever mode it is in."""
    if obj is None:
        return None
    for m in obj.modifiers:
        if m.type == 'NODES' and ng.mode_of(m) is not None:
            return m
    return None


def object_chain_depth(car):
    """How many cloners deep this one is, counting only OBJECT-socket links.

    ⚠⚠ WHY THIS EXISTS. Nesting through the **Object** socket works for TWO levels and the
    third does not expand — measured, 11 distinct positions where a full 3x3x3 is 27, and a
    Geometry-to-Instance wrapper does not change it. Through the **Collection** socket THREE
    LEVELS NEST PERFECTLY (27 of 27). So the capability is there; the Object route just cannot
    reach it, and silently under-delivers rather than failing.

    ⚠ A depth of 2 is FINE and must stay silent — that is the case beta.11 fixed and the demo
    uses. Only 3+ is worth saying anything about, or the hint becomes a nag on working setups.

    ⚠ CYCLE GUARD. A pointing at B while B points at A is a scene the user can build in two
    clicks, and an unguarded walk would hang Blender from inside a panel draw.
    """
    depth, seen = 1, set()
    cur = car
    while cur is not None and cur.name not in seen:
        seen.add(cur.name)
        m = cloner_mod(cur)
        if m is None:
            break
        nxt = props.get(m, "Source")
        if nxt is None or cloner_mod(nxt) is None:
            break
        depth += 1
        cur = nxt
    return depth


def retrigger_dependents(src):
    """Tag every cloner that clones `src`, so a NESTED cloner keeps up with its source.

    ⚠⚠ THE BUG THIS FIXES, measured: point Outer.Source at Inner (itself a cloner) and you get
    3 clones of the inner OBJECT rather than the inner's whole run repeated. Change the inner's
    Count — still 3. Add a completely UNRELATED object — and it snaps to the correct 12. The
    nesting was always right; the outer was simply never re-evaluated, so it showed a stale
    result that looked like a missing feature. A beta tester would reasonably conclude nested
    cloners are not supported.

    ⚠ SAME FAMILY AS `fields._retrigger`, and it reuses that module's cached carrier index, so
    this is O(cloners) rather than a walk of the file. Do not make it walk `bpy.data.objects`.

    ⚠ COLLECTION SOURCES TOO — a cloner reading a collection that CONTAINS `src` has the same
    dependency. That path already worked, because Collection Info re-evaluates; tagging it as
    well costs one comparison and keeps the two routes behaving identically.

    ⚠⚠ TRANSITIVELY, NOT ONE LEVEL. Tagging only DIRECT dependents updates the cloner just
    above the change and stops, so in a deep chain everything higher shows a stale result until
    an unrelated edit forces a rebuild. Rob read the symptom as a depth limit — *"looks like you
    can only do three nested cloners"* — and his four-level scene realized 16,384 clones where a
    clean build of the same shape gives 65,536. The nesting itself is fine to at least SIX
    levels; only the propagation was short.

    ⚠ `==`, NEVER `is`. This compared the Source socket to `src` with `is` — the bpy identity
    trap this project has now hit five times. Wrappers are recreated per access, so it can be
    False for the very object it was handed, and then nothing is tagged at all.
    """
    from . import effectors, fields
    carriers = [c for c in fields._indexed("carriers") if cloner_mod(c) is not None]
    frontier, seen = {src.name}, set()
    while frontier:
        cur, frontier = frontier, set()
        seen |= cur
        for car in carriers:
            # ⚠ CYCLE GUARD. A pointing at B while B points at A is two clicks away, and an
            # unguarded walk would hang Blender from inside a depsgraph handler.
            if car.name in seen:
                continue
            m = cloner_mod(car)
            s = props.get(m, "Source")
            if s is not None and s.name in cur:
                car.update_tag()
                frontier.add(car.name)
                continue
            coll = props.get(m, "Sources")
            if coll is not None and any(n in cur for n in coll.objects.keys()):
                car.update_tag()
                frontier.add(car.name)


def focus_gizmos(car):
    """Make the generator the ACTIVE modifier again, so its viewport handles keep drawing.

    ⚠⚠ BLENDER DRAWS A NODE GROUP'S GIZMOS ONLY WHILE ITS MODIFIER IS ACTIVE. The manual is
    explicit — modeling/geometry_nodes/gizmos.rst: "Gizmos that are propagated to the modifier
    always show when the modifier is active." And `modifiers.new()` MAKES THE NEW MODIFIER
    ACTIVE, so adding an effector silently took the cloner's handles off screen. Rob:
    "When you add an effector, the gizmos go away."

    ⚠ THE GRAPH WAS INNOCENT — measured before changing anything. The gizmo Transforms are
    still joined into the output (3 of them on Linear) and the clones are unaffected; nothing
    was lost, it simply stopped being DRAWN. Chasing this in the node group would have found
    nothing wrong there.

    ⚠ Nothing is given up by pinning the generator: `MG_Effector` contains no gizmo nodes at
    all, so an active effector has no handles of its own to show. Fields are separate OBJECTS
    with their own gizmo meshes and are not affected either way.
    """
    m = cloner_mod(car)
    if m is not None and car.modifiers.active is not m:
        car.modifiers.active = m


def _selected(obj):
    """⚠ `select_get()` RAISES for an object outside the view layer — which is exactly what
    Hide Source produces, so this cannot be a bare call."""
    if obj is None:
        return False
    try:
        return obj.select_get()
    except Exception:
        return False


def active(context):
    """The cloner the panel is talking about — the active object, or the cloner that owns
    the active field, so selecting a gizmo keeps its cloner's settings on screen.

    ⚠⚠ IT MUST ALSO BE **SELECTED**. Blender keeps `active_object` after a deselect-all, so
    clicking empty space to start a new cloner left the old one's Source / Distribute /
    Effectors panels on screen and no way back to "Add a Cloner". Rob, building a nested
    cloner: "When I deselect to make a new clone, the settings are still visible."
    Measured: after deselecting everything, `active_object` was still Wall with
    `select_get() == False` and `selected_objects` empty.

    ⚠ The consequence is deliberate: deselecting is now how you get back to the create grid,
    which is the gesture people already make. Hiding a cloner also deselects it, so its panel
    goes too — acceptable here because the outliner can unhide, unlike Werkbench's Transform
    panel where the panel WAS the way back (see [[werks-workflow]]).
    """
    obj = context.active_object if context else None
    if not _selected(obj):
        return None
    if is_cloner(obj):
        return obj
    if obj.get("mg_field"):
        owner = cloner_using(obj)
        if owner is not None:
            return owner
    return None


# ⚠⚠ ONE DEFINITION, USED BY BOTH. This set and `cloned_objects` below disagreed: the add
# operator accepted curves, text, surfaces and metaballs, while `cloned_objects` filtered to
# MESH only. So Set Up Material and every other "reach the thing being cloned" path silently
# did NOTHING on a curve or text cloner — no error, nothing to blame. Rob had both in one
# scene: letters cloned In Place and a curve carrier.
CLONEABLE = {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META'}


def cloned_objects(car):
    """The objects this cloner actually puts on screen.

    ⚠ THREE SOURCE ROUTES AND THEY ARE NOT INTERCHANGEABLE — a Collection, a single Object, or
    NEITHER, in which case the cloner clones its OWN geometry and the carrier is the source.
    Anything that has to reach "the thing being cloned" (a material, a colour setup) has to
    handle all three, or it silently does nothing on the flow the user happens to be using.
    ⚠ Collection wins over Object, matching MG_Instance's own rule.
    """
    if car is None:
        return []
    m = cloner_mod(car)
    if m is None:
        return []
    coll = props.get(m, "Sources")
    if coll is not None:
        return [o for o in coll.objects if o.type in CLONEABLE]
    src = props.get(m, "Source")
    if src is not None:
        return [src] if src.type in CLONEABLE else []
    return [car] if car.type in CLONEABLE else []


def cloner_using(field):
    """The cloner whose effector stack references this field, or None.

    ⚠ EVERY SLOT of every effector, not the first. Checking only slot 1 is how adding a
    third field silently cancelled — twice, in two different stacks.
    ⚠⚠ `==`, NEVER `is`. This is the guard that decides whether `remove_field` DELETES a gizmo,
    and since fields can be SHARED the answer is now routinely "another effector still reads
    it". bpy wrappers are recreated per access, so an identity test that happens to hold today
    is not a guarantee — and the failure mode here is deleting a field out from under a working
    effector. `==` compares the underlying datablock, which is the question being asked.
    """
    from . import effectors
    if field is None:
        return None
    for obj in bpy.data.objects:
        if not is_cloner(obj):
            continue
        for m in effectors.stack(obj):
            for slot in effectors.SLOTS:
                if props.get(m, slot) == field:
                    return obj
    return None


class MG_OT_add_cloner(bpy.types.Operator):
    bl_idname = "mographwerks.add_cloner"
    bl_label = "Add Cloner"
    bl_description = "Clone the selected object. A cloner makes copies and nothing else — "\
                     "add an Effector to move them"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def description(cls, context, properties):
        # ⚠ THE TOOLTIP FOLLOWS THE MODE. One operator serves both families, so a static
        # bl_description made every Fracture button claim to clone the selected object.
        return ng.describe(properties.mode) or cls.bl_description

    # ⚠ FRACTURE MODES ARE HERE TOO, so one operator makes either kind — they differ only in
    # which generator group goes on the modifier, and everything downstream treats a shard
    # exactly like a clone.
    mode: bpy.props.EnumProperty(
        name="Mode", default='GRID',
        items=[(k, k.replace("_", " ").title(), "") for k in sorted(ng.CLONER_MODES)]
        + [(k, k.title(), "") for k in sorted(ng.FRACTURE_MODES)])

    # ⚠ A NAME, NOT A POINTER. An operator property cannot hold an ID, so the panel's
    # Collection picker passes the name through and this looks it up. Empty means "use the
    # selection", which is the original path and stays the default.
    collection: bpy.props.StringProperty(
        name="From Collection", default="",
        description="Clone this existing collection where it stands, instead of the "
                    "selected objects")

    # ⚠ THE ROUTE TO NESTING. Selecting a cloner and pressing a mode is refused ("already a
    # cloner"), so the only way to clone a cloner was to point Sources at a COLLECTION — and a
    # cloner's group collection also holds its FIELD GIZMOS, which then got cloned as if they
    # were geometry. Rob hit exactly that: eight copies of a ring field marching around with
    # the spacing. Naming it "From Object" and not "Object" matters: the mode grid already has
    # an Object button, and that one means clone ONTO an object's points.
    source_object: bpy.props.StringProperty(
        name="From Object", default="",
        description="Clone this existing object where it stands — including another cloner, "
                    "which is how you nest them")

    # ⚠ THE MODULE-LEVEL SET, bound here so `self.CLONEABLE` keeps working. It used to be
    # defined twice with different contents, which is exactly the drift that broke Set Up
    # Material on curve and text cloners.
    CLONEABLE = CLONEABLE          # noqa: F821  (module scope, defined above)

    def execute(self, context):
        ng.ensure()
        # ⚠ MOTYPE HAS NO SOURCE. Every other mode needs something selected to clone; this one
        # generates its glyphs, so demanding a selection would refuse the only way to use it.
        # It goes first, before the selection checks below can reject an empty scene.
        if self.mode == 'MOTYPE' and not self.source_object and not self.collection:
            return self._motype(context)
        obj = bpy.data.objects.get(self.source_object) if self.source_object else None
        if obj is not None:
            return self._from_object(context, obj)
        coll = bpy.data.collections.get(self.collection) if self.collection else None
        if coll is not None:
            return self._from_collection(context, coll)
        act = context.active_object
        # ⚠ THE ACTIVE OBJECT NAMES EVERYTHING and goes first, so the user has a say in both.
        picked = [o for o in context.selected_objects if o.type in self.CLONEABLE]
        if act is not None and act.type in self.CLONEABLE and act not in picked:
            picked.append(act)
        picked.sort(key=lambda o: (o is not act, o.name))
        if not picked:
            self.report({'WARNING'}, "Select a mesh to clone")
            return {'CANCELLED'}
        already = [o.name for o in picked if cloner_mod(o) is not None]
        if already:
            self.report({'WARNING'}, "%s is already a cloner" % already[0])
            return {'CANCELLED'}
        base = picked[0].name
        # ⚠ EACH BRANCH FINISHES ITS OWN MODIFIER. `cloner_mod` finds a modifier by its node
        # GROUP, so a modifier that has not been given one yet is invisible to it — setting
        # the mode out here found nothing at all.
        if len(picked) == 1:
            car = self._single(context, picked[0], base)
        else:
            car = self._several(context, picked, base)
        for o in context.selected_objects:
            o.select_set(False)
        car.select_set(True)
        context.view_layer.objects.active = car
        self.report({'INFO'}, "%s cloner added — add an Effector to move the clones"
                    % self.mode.title())
        return {'FINISHED'}

    @staticmethod
    def _a_font():
        """Any font, minting Blender's built-in one if the file has none yet.

        ⚠⚠ AN EMPTY FONT SOCKET YIELDS ZERO GLYPHS, SILENTLY. A MoType cloner created without
        one looks completely broken: no error, no geometry, nothing in the outliner to blame.
        ⚠ `bpy.data.fonts` is EMPTY in a fresh file — the built-in font only comes into being
        once something asks for it, so it has to be minted via a throwaway text object rather
        than looked up.
        """
        if bpy.data.fonts:
            return bpy.data.fonts[0]
        tmp = bpy.data.curves.new("mg_tmp", 'FONT')
        fnt = tmp.font
        bpy.data.curves.remove(tmp)
        return fnt

    def _motype(self, context, base="MoType"):
        """A cloner that generates its own clones: 3D type, one per character.

        ⚠ NO SOURCE OBJECT AND NOTHING HIDDEN. There is no original to hide, which is why this
        does not go near `set_object_hidden`.
        """
        grp = bpy.data.collections.new(base + ".Cloner")
        grp["mg_group"] = True
        context.scene.collection.children.link(grp)
        car = bpy.data.objects.new(base, bpy.data.meshes.new(base))
        car["mg_cloner"] = True
        car["mg_carrier"] = True
        if context.scene.cursor is not None:
            car.location = context.scene.cursor.location.copy()
        grp.objects.link(car)
        m = car.modifiers.new(MOD_NAME, 'NODES')
        ng.swap_mode(m, 'MOTYPE')
        props.set(m, "Font", self._a_font())
        for o in context.selected_objects:
            o.select_set(False)
        car.select_set(True)
        context.view_layer.objects.active = car
        self.report({'INFO'}, "MoType added — type into the Text field")
        return {'FINISHED'}

    def _from_object(self, context, obj):
        """Clone ONE existing object where it stands — including another cloner.

        ⚠ NOTHING IS MOVED, HIDDEN OR RENAMED, and the source is NOT stamped. Same contract as
        `_from_collection`: you picked a thing that already has a place in the scene, so it
        keeps it. Remove Cloner only unmakes what the addon made, so this source survives.
        ⚠ IT DOES NOT REFUSE A CLONER. The selection path refuses one deliberately — pressing
        Grid on a cloner should not silently re-mode it — but pointing at one is the whole
        reason this exists. Verified 3 levels deep, 27 of 27.
        ⚠ THE OBJECT SOCKET, NOT THE COLLECTION ONE, which is what keeps field gizmos out of
        the clone: a cloner's group collection holds its fields, and Collection Info recurses
        into child collections, so there is no arrangement of sub-collections that hides them.
        """
        if obj.type not in self.CLONEABLE:
            self.report({'WARNING'}, "%s cannot be cloned" % obj.name)
            return {'CANCELLED'}
        base = obj.name
        grp = bpy.data.collections.new(base + ".Cloner")
        grp["mg_group"] = True
        _home_of_object(obj).children.link(grp)

        car = bpy.data.objects.new(base + ".Cloner", bpy.data.meshes.new(base + ".Cloner"))
        car["mg_cloner"] = True
        car["mg_carrier"] = True
        car.location = obj.matrix_world.translation.copy()
        grp.objects.link(car)

        m = car.modifiers.new(MOD_NAME, 'NODES')
        ng.swap_mode(m, self.mode)
        props.set(m, "Source", obj)
        # ⚠ HIDE IT, as every other path does — you almost never want the original sitting
        # inside the pattern it generated. Rob, on the first build without this: "it doesn't
        # hide the original object."
        set_object_hidden(obj, True, car)
        for o in context.selected_objects:
            o.select_set(False)
        car.select_set(True)
        context.view_layer.objects.active = car
        self.report({'INFO'}, "Cloning %s where it stands" % obj.name)
        return {'FINISHED'}

    def _from_collection(self, context, coll):
        """Clone an EXISTING collection where it stands.

        ⚠ NOTHING IS MOVED, RE-HOMED OR RENAMED. The collection keeps its place in the scene
        tree and its objects keep their collections — that is the whole point of picking it
        instead of selecting objects, and it is why this path does NOT stamp `mg_sources`.
        Remove Cloner tests that stamp, so an unstamped collection survives Remove untouched.

        ⚠⚠ THE CARRIER MUST NEVER LIVE INSIDE THE COLLECTION IT READS — a cloner whose carrier
        is inside its own source yields ZERO clones, silently, with no error. The group holding
        the carrier is linked to the SCENE ROOT so it is always beside the source, never within
        it. (This is also the trap a user falls into by hand: building a source collection that
        happens to contain the object the cloner is on.)
        """
        objs = [o for o in coll.objects if o.type in self.CLONEABLE]
        if not objs:
            self.report({'WARNING'}, "%s has nothing to clone" % coll.name)
            return {'CANCELLED'}

        base = coll.name
        grp = bpy.data.collections.new(base + ".Cloner")
        grp["mg_group"] = True
        # ⚠ BESIDE THE SOURCE, IN ITS PARENT — not at the scene root, so a cloner built from a
        # collection nested three deep does not appear at the top of the outliner. Same rule as
        # `_make_group`: things get filed where the thing they came from already lived.
        # ⚠⚠ BESIDE, NEVER INSIDE. Linking this group INTO `coll` would put the carrier within
        # the collection it reads, and a cloner whose carrier is inside its own source yields
        # ZERO clones, silently, with no error. `_parent_of` returns the scene root when
        # nothing claims the collection, which is also outside it — so both paths are safe.
        _parent_of(coll).children.link(grp)

        car = bpy.data.objects.new(base + ".Cloner", bpy.data.meshes.new(base + ".Cloner"))
        car["mg_cloner"] = True
        car["mg_carrier"] = True
        # ⚠ at the centre of what it clones, so the distribution is built around the objects
        # rather than at the world origin
        car.location = sum((o.matrix_world.translation for o in objs),
                           mathutils.Vector()) / len(objs)
        grp.objects.link(car)

        m = car.modifiers.new(MOD_NAME, 'NODES')
        ng.swap_mode(m, self.mode)
        props.set(m, "Sources", coll)
        # ⚠ HIDE THE SOURCE, exactly as the multi-object path does. Rob asked for it, and the
        # reason is that you almost never want the originals sitting inside the clone pattern
        # they generated. It is EXCLUSION, not deletion — the Source panel's Hide Source button
        # toggles it straight back, and Remove Cloner reveals it unconditionally, including for
        # a collection the add-on does not own.
        # ⚠ AFTER the socket is set: excluding a collection makes its objects unreachable from
        # the view layer, and there is still work to do with them above.
        set_hidden(coll, True)
        for o in context.selected_objects:
            o.select_set(False)
        car.select_set(True)
        context.view_layer.objects.active = car
        self.report({'INFO'}, "Cloning %s — %d object%s"
                    % (coll.name, len(objs), "" if len(objs) == 1 else "s"))
        return {'FINISHED'}

    def _single(self, context, src, base):
        """One object: the modifier goes ON IT, and nothing is hidden or created."""
        # ⚠ With no Source set, MG_Instance uses the modifier's own incoming geometry, so the
        # mesh becomes its clones. Rob: "Can it apply to the original object when only one is
        # selected?" — the collection is the only thing added.
        _make_group(context, base, [src])
        src["mg_cloner"] = True
        ng.swap_mode(src.modifiers.new(MOD_NAME, 'NODES'), self.mode)
        return src

    def _several(self, context, objs, base):
        """Several objects: a carrier clones a hidden collection of them."""
        grp = _make_group(context, base, objs)
        srcs = bpy.data.collections.new(base + ".Source")
        srcs["mg_sources"] = True
        grp.children.link(srcs)
        for o in objs:
            grp.objects.unlink(o)
            srcs.objects.link(o)
        # ⚠ A MESH CARRIER, not an Empty: a geometry-nodes modifier needs object DATA to
        # live on, and an Empty has none. Its own mesh stays empty — every point comes from
        # the cloner — so it costs nothing and renders nothing of its own.
        car = bpy.data.objects.new(base + ".Cloner", bpy.data.meshes.new(base + ".Cloner"))
        # ⚠ MARK WHAT WE MADE. Remove Cloner deletes the carrier, and "there is a source
        # collection" is NOT a safe proxy for "we created this carrier" — a single-object
        # cloner's carrier is the user's own object, and it can now have a source collection
        # too. See the ownership test in remove_cloner.
        car["mg_carrier"] = True
        grp.objects.link(car)
        # ⚠ AT THE CENTRE OF THE SELECTION, which is what v0.65.0 did and what the clones are
        # built around — a carrier left at the world origin puts the whole grid there instead
        # of where the objects were. Rob: "the collection is reverting back to world origin."
        # ⚠ Not the primary object's origin: with a spread-out selection that puts the grid
        # at one edge of it. For a single object the two rules agree anyway.
        car.location = sum((o.matrix_world.translation for o in objs),
                           mathutils.Vector()) / len(objs)
        car["mg_cloner"] = True
        m = car.modifiers.new(MOD_NAME, 'NODES')
        # ⚠ the group must exist before `props.set` can reach a socket on it
        ng.swap_mode(m, self.mode)
        props.set(m, "Sources", srcs)
        # ⚠ AFTER the socket is set: excluding a collection makes its objects unreachable
        # from the view layer, and the operator still has work to do with them.
        set_hidden(srcs, True)
        return car


class MG_OT_set_mode(bpy.types.Operator):
    bl_idname = "mographwerks.set_mode"
    bl_label = "Cloner Mode"
    bl_description = "Change how the clones are distributed. Settings the new mode shares "\
                     "are kept"
    bl_options = {'REGISTER', 'UNDO'}

    # ⚠ EVERY GENERATOR MODE, not just the cloners. The panel draws a button per mode of
    # whichever family the object belongs to, so a fracture's buttons assign 'LIVE' here —
    # and an enum that does not list it raises INSIDE draw(), which aborts the panel at that
    # point and silently swallows everything below: the Distribute settings, and only those,
    # vanished. A panel that half-draws looks like a missing feature, not a crash.
    mode: bpy.props.EnumProperty(
        name="Mode", default='GRID',
        items=[(k, k.replace("_", " ").title(), "") for k in sorted(ng.generators())])

    def execute(self, context):
        car = active(context)
        m = cloner_mod(car)
        if m is None:
            return {'CANCELLED'}
        # ⚠ swap_mode carries values across BY NAME. Splitting one mode-switching group
        # into several must not cost the ability to change your mind after creating.
        ng.swap_mode(m, self.mode)
        return {'FINISHED'}


class MG_OT_remove_cloner(bpy.types.Operator):
    bl_idname = "mographwerks.remove_cloner"
    bl_label = "Remove Cloner"
    bl_description = "Delete this cloner, its effectors and the field gizmos only it used. "\
                     "The source object is left alone"

    @classmethod
    def description(cls, context, properties):
        # ⚠ AND SO DOES THIS ONE — "Remove Cloner" on a fracture is the same wrong word.
        m = cloner_mod(active(context)) if active(context) else None
        if ng.mode_of(m) in ng.FRACTURE_MODES:
            return ("Delete this fracture, its effectors and the field gizmos only it used. "
                    "The broken mesh is left alone")
        return cls.bl_description
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from . import effectors
        car = active(context)
        if car is None:
            return {'CANCELLED'}
        grp = group_of(car)
        srcs = sources_of(car)
        # ⚠⚠ READ THE OBJECT SOURCE NOW, BEFORE THE MODIFIERS GO. Everything below strips the
        # cloner modifier, and `cloner_mod()` then returns None — so a reveal placed later
        # silently does nothing and leaves the user's object hidden with no way back. Measured.
        _osrc = props.get(cloner_mod(car), "Source") if cloner_mod(car) is not None else None
        # ⚠ Gather the fields BEFORE anything is removed, then delete only those no other
        # cloner still uses — a field can be shared, and yanking one out from under another
        # stack is worse than leaving a stray gizmo.
        owned = {props.get(m, s).name
                 for m in effectors.stack(car) for s in effectors.SLOTS
                 if props.get(m, s) is not None}
        # ⚠ THE CLONER IS THE OBJECT NOW, so removing it must NOT delete the object — it
        # strips the modifiers and hands the mesh back exactly as it was.
        for m in list(effectors.stack(car)):
            car.modifiers.remove(m)
        m = cloner_mod(car)
        if m is not None:
            car.modifiers.remove(m)
        del car["mg_cloner"]
        for name in owned:
            f = bpy.data.objects.get(name)
            if f is not None and f.get("mg_field") and cloner_using(f) is None:
                bpy.data.objects.remove(f)
        # ⚠ NOTHING IS LEFT HIDDEN AND NOTHING IS LEFT STRANDED. Rob asked for removal to put
        # things back: the sources come out of hiding into the collection the group was made
        # in, the carrier goes with the collection, and both collections are deleted.
        home = _parent_of(grp) if grp is not None else context.scene.collection
        # ⚠⚠ ONLY UNMAKE WHAT THIS ADD-ON MADE. `mg_sources` is stamped on the collection the
        # operator creates. A collection the USER pointed the Sources socket at carries no
        # stamp and must survive Remove completely untouched.
        # ⚠⚠ MEASURED 2026-08-05, and it was real data loss: without this test, removing a
        # cloner whose Collection had been repointed DELETED THE USER'S COLLECTION — and on a
        # single-object cloner it deleted THEIR OBJECT as well, because the carrier was removed
        # on the strength of "a source collection exists". That proxy was safe only while the
        # panel refused to show the Collection field on single-object cloners.
        # ⚠ AN OBJECT SOURCE WE HID MUST COME BACK, exactly as a collection source does.
        # ⚠ ONLY IF WE HID IT — the stamp is the test, so an object the user hid themselves
        # stays hidden.
        if _osrc is not None and HIDDEN_BY in _osrc:
            set_object_hidden(_osrc, False)

        ours = srcs is not None and bool(srcs.get("mg_sources"))
        if srcs is not None:
            # ⚠ REVEAL FIRST. An excluded collection's objects are not in the view layer, and
            # relinking them while they are unreachable leaves them selectable nowhere. This
            # also has to run for a collection we do NOT own — we may have excluded it.
            set_hidden(srcs, False)
        if ours:
            for o in list(srcs.objects):
                srcs.objects.unlink(o)
                home.objects.link(o)
            bpy.data.collections.remove(srcs)
        # ⚠ THE CARRIER GOES ONLY IF WE MADE IT. The `ours` fallback keeps cloners built
        # before `mg_carrier` existed behaving exactly as they always did.
        if car.get("mg_carrier") or ours:
            bpy.data.objects.remove(car)
        if grp is not None:
            for o in list(grp.objects):
                grp.objects.unlink(o)
                home.objects.link(o)
            bpy.data.collections.remove(grp)
        self.report({'INFO'}, "Cloner removed — the objects are back as they were")
        return {'FINISHED'}


class MG_OT_toggle_hide_source(bpy.types.Operator):
    bl_idname = "mographwerks.toggle_hide_source"
    bl_label = "Hide Source"
    bl_description = "Deactivate the source collection so the originals are out of the "\
                     "viewport and the render. The cloner still reads them"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        car = active(context)
        srcs = sources_of(car)
        if srcs is not None:
            lcs = _layer_collections(srcs.name)
            set_hidden(srcs, not (lcs and lcs[0].exclude))
            return {'FINISHED'}
        # ⚠ THE OBJECT SOURCE GETS THE SAME TOGGLE. Without this the button simply does not
        # appear for a From Object cloner, and a hidden original has no way back short of the
        # outliner — which is the reachability trap the material guard already exists for.
        m = cloner_mod(car)
        osrc = props.get(m, "Source") if m is not None else None
        if osrc is None:
            return {'CANCELLED'}
        set_object_hidden(osrc, HIDDEN_BY not in osrc, car)
        return {'FINISHED'}


class MG_VoronoiPG(bpy.types.PropertyGroup):
    """Voronoi settings, on the SCENE, so they can be set BEFORE the fracture runs.

    ⚠ A BAKE'S SETTINGS CANNOT LIVE ON THE RESULT. Every other generator here is a modifier,
    so its controls sit on the object and can be changed forever; this one produces real
    geometry, and by the time there is something to select the decision has been made. Rob:
    "Can we add some settings to the n-panel to adjust before you fracture?"
    ⚠ THE OPERATOR STILL OWNS ITS OWN COPIES and the PANEL BUTTON ASSIGNS THEM, which is how
    a Blender panel is meant to pass values. An `invoke` that copied them across looked
    equivalent and is not: **invoke never runs in background**, so that path could not be
    tested headlessly at all — measured, it went straight to execute and the panel's values
    were ignored in every test while appearing to work in the UI.
    ⚠ The operator keeping its own copies is what keeps F9 working: the redo panel edits the
    operator's properties, not the scene's, so a quick re-roll does not rewrite the defaults.
    """

    pieces: bpy.props.IntProperty(
        name="Pieces", default=24, min=2, max=2000,
        description="How many shards. Exact — every cell is a real Voronoi cell")
    seed: bpy.props.IntProperty(name="Seed", default=0, min=0,
                                description="Re-roll where the breaks fall")
    # ⚠ GRID GIVES REGULAR BREAKS — brick, tile, blockwork — which is the archviz case for a
    # wall. Jitter softens it back toward natural stonework; at 0 it is a true lattice.
    grid: bpy.props.BoolProperty(
        name="Grid", default=False,
        description="Break on a regular lattice instead of at random. The piece count is "
                    "approximate in this mode — a lattice can only land on so many")
    jitter: bpy.props.FloatProperty(
        name="Jitter", default=0.0, min=0.0, max=1.0, subtype='FACTOR',
        description="Push each grid point off its lattice, up to half a cell")
    # ⚠ SQUASHING an axis makes cells LONG in it: planks, slabs, splintered timber. It is a
    # change of distance metric, not a scale applied to the finished shards.
    cell_scale: bpy.props.FloatVectorProperty(
        name="Cell Scale", size=3, default=(1.0, 1.0, 1.0), min=0.01, soft_max=4.0,
        description="Cell shape per axis, MEASURED: 4 on Z gives deep planks (mean shard "
                    "1.76 against 1.0), 0.25 gives flat tiles (0.40). 1,1,1 is even")
    margin: bpy.props.FloatProperty(
        name="Margin", default=0.0, min=0.0, soft_max=0.1, subtype='DISTANCE', precision=4,
        description="Gap left between shards. 0 is watertight — they meet exactly")
    # ⚠ WHICH SLOT THE BROKEN FACES GET. The faces the cuts made are flagged and the flag
    # survives the boolean, so the inside of a shard can carry rubble while its outside keeps
    # the source's material — that is what makes a fracture read as broken.
    interior_material: bpy.props.IntProperty(
        name="Interior Material", default=0, min=0, max=32,
        description="Material slot for the broken faces. The outside keeps the source's own")
    animate: bpy.props.BoolProperty(
        name="Animate It", default=True,
        description="Join the shards and set them up as a Pieces generator")


class MG_OT_voronoi_fracture(bpy.types.Operator):
    """Cut the mesh into real Voronoi cells, then hand them to Pieces.

    ⚠ THIS REPLACED THE CELL FRACTURE BUTTON. Rob: "Can we adopt their Voronoi and settings
    instead of the Cell Fracture button?" — ours now, with our settings and our result, rather
    than opening someone else's window and gathering up the objects it leaves behind.
    ⚠ THE ALGORITHM IS STANDARD (bisect a box by the perpendicular bisectors, then boolean
    against the source); it is implemented from that, not from any addon's source.
    """

    bl_idname = "mographwerks.voronoi_fracture"
    bl_label = "Voronoi Fracture"
    bl_description = "Cut this mesh into real Voronoi shards — watertight, exactly the "\
                     "number of pieces asked for — and set them up so effectors can drive them"
    bl_options = {'REGISTER', 'UNDO'}

    pieces: bpy.props.IntProperty(
        name="Pieces", default=24, min=2, max=2000,
        description="How many shards. Unlike the Live fracture this is exact — every cell "
                    "is a real Voronoi cell, not an approximation")
    seed: bpy.props.IntProperty(name="Seed", default=0, min=0,
                                description="Re-roll where the breaks fall")
    # ⚠ GRID GIVES REGULAR BREAKS — brick, tile, blockwork — which is the archviz case for a
    # wall. Jitter softens it back toward natural stonework; at 0 it is a true lattice.
    grid: bpy.props.BoolProperty(
        name="Grid", default=False,
        description="Break on a regular lattice instead of at random. The piece count is "
                    "approximate in this mode — a lattice can only land on so many")
    jitter: bpy.props.FloatProperty(
        name="Jitter", default=0.0, min=0.0, max=1.0, subtype='FACTOR',
        description="Push each grid point off its lattice, up to half a cell")
    # ⚠ SQUASHING an axis makes cells LONG in it: planks, slabs, splintered timber. It is a
    # change of distance metric, not a scale applied to the finished shards.
    cell_scale: bpy.props.FloatVectorProperty(
        name="Cell Scale", size=3, default=(1.0, 1.0, 1.0), min=0.01, soft_max=4.0,
        description="Cell shape per axis, MEASURED: 4 on Z gives deep planks (mean shard "
                    "1.76 against 1.0), 0.25 gives flat tiles (0.40). 1,1,1 is even")
    # ⚠ 0 IS WATERTIGHT. The margin insets each shared face by the same distance, so the gap
    # between two shards is exactly this wherever they meet.
    margin: bpy.props.FloatProperty(
        name="Margin", default=0.0, min=0.0, soft_max=0.1, subtype='DISTANCE', precision=4,
        description="Gap left between shards. 0 is watertight — they meet exactly. Raise it "
                    "only if coplanar faces flicker against each other at rest")
    interior_material: bpy.props.IntProperty(
        name="Interior Material", default=0, min=0, max=32,
        description="Material slot for the broken faces. The outside keeps the source's own")
    animate: bpy.props.BoolProperty(
        name="Animate It", default=True,
        description="Join the shards and set them up as a Pieces generator so effectors "
                    "can drive them")

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH' and not o.get("mg_cloner")

    def execute(self, context):
        from . import fracture
        src = context.active_object
        if not len(src.data.polygons):
            self.report({'WARNING'}, "'%s' has no faces to fracture" % src.name)
            return {'CANCELLED'}
        if len(src.data.polygons) > 20000:
            self.report({'WARNING'}, "'%s' is heavy (%d faces) — this may take a while"
                        % (src.name, len(src.data.polygons)))
        shards = fracture.voronoi_shards(context, src, self.pieces, self.seed,
                                         self.margin, self.interior_material,
                                         grid=self.grid, jitter=self.jitter,
                                         scale=tuple(self.cell_scale))
        if not shards:
            self.report({'WARNING'}, "That produced no shards — is the mesh closed?")
            return {'CANCELLED'}
        # ⚠ KEEP THE ORIGINAL, hidden — a fracture you do not like is one un-hide away.
        src.hide_set(True)
        for o in context.selected_objects:
            o.select_set(False)
        for o in shards:
            o.select_set(True)
        context.view_layer.objects.active = shards[0]
        if len(shards) > 1:
            # ⚠ JOIN: Pieces drives ISLANDS inside ONE mesh, and this is what makes the two
            # halves of the feature meet.
            bpy.ops.object.join()
        out = context.view_layer.objects.active
        out.name = "%s.Shards" % src.name
        if self.animate:
            bpy.ops.mographwerks.add_cloner(mode='PIECES')
        self.report({'INFO'}, "%d shards%s"
                    % (len(shards), " — ready to animate" if self.animate else ""))
        return {'FINISHED'}


# ⚠ THE PROPERTY GROUP REGISTERS FIRST — a PointerProperty cannot reference a class that
# Blender has not seen yet.
class MG_OT_fracture(bpy.types.Operator):
    """The one action button behind all four fracture methods.

    ⚠ ONE BUTTON, FOUR METHODS. The panel picks the method as a tab and this runs whichever
    one is chosen — so the button always says "Fracture" and never has to be four buttons that
    each mean something slightly different. Rob: "add a Fracture button to create the
    fracture."
    ⚠ IT DELEGATES rather than reimplementing: Grid and Voronoi are the same bake with `grid`
    on or off, and Live and Pieces are generator modes. Duplicating either here would be a
    second place for them to drift.
    """

    bl_idname = "mographwerks.fracture"
    bl_label = "Fracture"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH' and not o.get("mg_cloner")

    # ⚠ EMPTY MEANS "WHATEVER THE PANEL SAYS". The panel button leaves it empty so the tabs
    # stay the single source of truth; the Add menu names one explicitly, because a menu item
    # that silently depended on a tab you cannot see would be a trap.
    method: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        return ng.describe_method(properties.method or context.scene.mg_fracture_method)

    def execute(self, context):
        method = self.method or context.scene.mg_fracture_method
        if method in {'LIVE', 'PIECES'}:
            return bpy.ops.mographwerks.add_cloner(mode=method)
        s = context.scene.mg_voronoi
        # ⚠ GRID IS THE SAME BAKE WITH THE LATTICE ON. The method IS the setting, which is why
        # `grid` is no longer drawn as a checkbox — two controls for one decision.
        return bpy.ops.mographwerks.voronoi_fracture(
            pieces=s.pieces, seed=s.seed, grid=(method == 'GRID'), jitter=s.jitter,
            cell_scale=tuple(s.cell_scale), margin=s.margin,
            interior_material=s.interior_material, animate=s.animate)


# --------------------------------------------------------------------------------- freezing
# ⚠ NOT A CONTRACT GROUP, DELIBERATELY. It is built here at runtime rather than seeded into
# nodegroups.blend, for two reasons: `ng.load()` RAISES if a CONTRACT name is missing from the
# .blend, and this group has no sockets the addon drives and no maths that could ever need a
# fix — so the refresh machinery would carry cost for nothing. Keeping it out also means
# `_dedupe_nested()` never looks at it.
FREEZE_NG = "MG_Freeze"
FREEZE_MOD = "Freeze"


def _freeze_group():
    """Group Input → Bake → Group Output. Reused by name across every frozen cloner.

    ⚠ SHARING ONE GROUP IS SAFE because a bake is stored on the MODIFIER, not the node group —
    `mod.bakes` is per-modifier — so two frozen cloners pointing at this group hold two
    completely separate bakes.
    """
    ng_ = bpy.data.node_groups.get(FREEZE_NG)
    if ng_ is not None:
        return ng_
    ng_ = bpy.data.node_groups.new(FREEZE_NG, 'GeometryNodeTree')
    ng_.interface.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    ng_.interface.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    gin = ng_.nodes.new('NodeGroupInput'); gin.location = (-260, 0)
    gout = ng_.nodes.new('NodeGroupOutput'); gout.location = (260, 0)
    bake = ng_.nodes.new('GeometryNodeBake'); bake.location = (0, 0)
    # ⚠ A BAKE NODE SHIPS WITH NO ITEMS. Without this it has no sockets and carries nothing.
    bake.bake_items.new('GEOMETRY', "Geometry")
    ng_.links.new(gin.outputs[0], bake.inputs[0])
    ng_.links.new(bake.outputs[0], gout.inputs[0])
    ng_.use_fake_user = True
    return ng_


def freeze_mod(obj):
    """The freeze modifier on this carrier, or None."""
    if obj is None:
        return None
    for m in obj.modifiers:
        if m.type == 'NODES' and m.node_group is not None \
                and m.node_group.name == FREEZE_NG:
            return m
    return None


def is_frozen(obj):
    return freeze_mod(obj) is not None


class MG_OT_freeze(bpy.types.Operator):
    """Freeze the clones where they are — effectors, fields and all.

    ⚠⚠ THE BAKE NODE GOES IN ITS OWN TRAILING MODIFIER, NEVER INSIDE A CONTRACT GROUP. Editing
    `MG_Effector` to add one would change its content hash, and `ng.reconcile()` replaces any
    group whose hash differs — the node AND the bake would be discarded on the next file open,
    silently. A separate modifier is the only safe home for it.
    ⚠ IT MUST BE LAST. The whole point is to capture what the effector stack produced, so it
    goes on the end of the stack; `modifiers.new()` appends, which is what we want.
    """

    bl_idname = "mographwerks.freeze"
    bl_label = "Freeze"
    bl_description = ("Bake the clones as they are now — effectors and fields applied — so they "
                      "stop responding to changes. Instancing is kept and the cloner stays "
                      "editable underneath")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        car = active(context)
        return car is not None and not is_frozen(car)

    def execute(self, context):
        car = active(context)
        if car is None:
            return {'CANCELLED'}
        mod = car.modifiers.new(FREEZE_MOD, 'NODES')
        mod.node_group = _freeze_group()
        # ⚠ PACKED, not DISK: a disk bake writes beside the .blend, and an UNSAVED file has no
        # `//` to resolve, so it would fail exactly when someone is trying it out.
        mod.bake_target = 'PACKED'
        # ⚠ THE MODIFIER MUST EVALUATE BEFORE `mod.bakes` EXISTS. The entry is created when
        # Blender sees the bake node, not when the modifier is added.
        car.update_tag()
        context.view_layer.update()
        if not len(mod.bakes):
            car.modifiers.remove(mod)
            self.report({'ERROR'}, "Could not prepare the bake")
            return {'CANCELLED'}
        entry = mod.bakes[0]
        entry.bake_target = 'PACKED'
        # ⚠ THE BAKE ID LIVES ON THE MODIFIER, NOT THE NODE — `node.bake_id` does not exist.
        bpy.ops.object.geometry_node_bake_single(
            session_uid=car.session_uid, modifier_name=mod.name, bake_id=entry.bake_id)
        car.update_tag()
        self.report({'INFO'}, "Frozen — the clones no longer respond to effectors or fields")
        return {'FINISHED'}


class MG_OT_unfreeze(bpy.types.Operator):
    """Drop the bake and let the cloner live again."""

    bl_idname = "mographwerks.unfreeze"
    bl_label = "Unfreeze"
    bl_description = "Discard the bake so the clones follow their effectors and fields again"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return is_frozen(active(context))

    def execute(self, context):
        car = active(context)
        mod = freeze_mod(car)
        if mod is None:
            return {'CANCELLED'}
        # ⚠ delete the bake BEFORE the modifier, or the packed data is orphaned in the file
        if len(mod.bakes):
            try:
                bpy.ops.object.geometry_node_bake_delete_single(
                    session_uid=car.session_uid, modifier_name=mod.name,
                    bake_id=mod.bakes[0].bake_id)
            except Exception:                                 # noqa: BLE001
                pass
        car.modifiers.remove(mod)
        car.update_tag()
        return {'FINISHED'}


REALIZE_NG = "MG_Realize"


def _realize_group():
    """Group Input → Realize Instances → Group Output. Built here, not seeded — see FREEZE_NG."""
    ng_ = bpy.data.node_groups.get(REALIZE_NG)
    if ng_ is not None:
        return ng_
    ng_ = bpy.data.node_groups.new(REALIZE_NG, 'GeometryNodeTree')
    ng_.interface.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    ng_.interface.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    gin = ng_.nodes.new('NodeGroupInput'); gin.location = (-260, 0)
    gout = ng_.nodes.new('NodeGroupOutput'); gout.location = (260, 0)
    rz = ng_.nodes.new('GeometryNodeRealizeInstances'); rz.location = (0, 0)
    ng_.links.new(gin.outputs[0], rz.inputs[0])
    ng_.links.new(rz.outputs[0], gout.inputs[0])
    ng_.use_fake_user = True
    return ng_


class MG_OT_convert_to_mesh(bpy.types.Operator):
    """Flatten the whole stack into plain mesh data.

    ⚠⚠ `Object ▸ Convert ▸ Mesh` ON ITS OWN GIVES AN EMPTY MESH. A cloner's evaluated geometry
    has NO mesh component — only instances — so the convert copies nothing and you get 0
    vertices with no error. Measured in 5.2. Realize Instances has to run first, and that
    non-obvious middle step is most of the reason this button exists.
    ⚠ THE OBJECT STAYS STAMPED A CLONER OTHERWISE. `is_cloner()` reads `mg_cloner`, which
    survives the convert — so the panel goes on claiming a plain mesh and keeps offering
    Remove Cloner, whose job is deleting collections and re-homing sources. The stamps come
    off here.
    ⚠ THE SOURCES ARE LEFT ALONE, DELIBERATELY. Removal only ever unmakes what the addon made,
    and quietly deleting a user's objects is the data-loss bug this project already shipped
    once. They are reported instead.
    """

    bl_idname = "mographwerks.convert_to_mesh"
    bl_label = "Convert to Mesh"
    bl_description = ("Flatten this cloner into real mesh data — effectors and fields baked in, "
                      "no modifiers left. The source objects are kept. This cannot be undone "
                      "except with Undo")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return active(context) is not None

    def execute(self, context):
        car = active(context)
        if car is None:
            return {'CANCELLED'}
        # what will be orphaned, read BEFORE the modifier goes away
        srcs = [o.name for o in cloned_objects(car) if o.name != car.name]
        group = group_of(car)
        group_name = group.name if group is not None else None

        rm = car.modifiers.new("Realize", 'NODES')
        rm.node_group = _realize_group()
        # ⚠ APPENDED, so it runs after the effectors AND after a Freeze if one is present —
        # realizing whatever the stack finally produced, which is what "convert" has to mean.
        car.update_tag()
        context.view_layer.update()

        for o in context.selected_objects:
            o.select_set(False)
        car.select_set(True)
        context.view_layer.objects.active = car
        bpy.ops.object.convert(target='MESH')

        # ⚠ the object survives the convert, its custom properties with it
        for key in ("mg_cloner", "mg_carrier"):
            if key in car:
                del car[key]

        verts = len(car.data.vertices) if getattr(car, "data", None) else 0
        if not verts:
            self.report({'WARNING'}, "Converted, but the result has no geometry")
        left = []
        if srcs:
            left.append("%d source object%s" % (len(srcs), "" if len(srcs) == 1 else "s"))
        if group_name:
            left.append("'%s'" % group_name)
        msg = "Flattened to %d vertices" % verts
        if left:
            msg += " — %s kept, delete by hand if you no longer need them" % " and ".join(left)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


CLASSES = (MG_VoronoiPG, MG_OT_add_cloner, MG_OT_set_mode, MG_OT_remove_cloner,
           MG_OT_toggle_hide_source, MG_OT_voronoi_fracture, MG_OT_fracture,
           MG_OT_freeze, MG_OT_unfreeze, MG_OT_convert_to_mesh)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.mg_voronoi = bpy.props.PointerProperty(type=MG_VoronoiPG)
    # ⚠ THE TAB ONLY EXISTS ON THE "WHAT DO YOU WANT TO MAKE" SCREEN. Once a generator is on
    # the object, THE OBJECT is the answer — a Clone/Fracture tab there would either do
    # nothing or imply you can convert between them, which you cannot: they share no sockets.
    # Rob: "You're either Cloning or Fracturing, then they would follow the same path with
    # effectors and fields." The tab governs the top section and never reaches below it.
    # ⚠ SCENE STATE CANNOT GO STALE HERE because it is only ever drawn when there is nothing
    # selected to disagree with.
    # ⚠ THE FOUR FRACTURE METHODS ARE TABS, NOT ACTION BUTTONS. Rob: "Can we make each button
    # a tab and only show the settings when it is selected and add a Fracture button to create
    # the fracture?" — the four differ in WHAT SETTINGS THEY NEED, so picking one and then
    # acting is the honest shape; the Clone grid stays immediate because a cloner mode is a
    # modifier you adjust afterwards and has nothing to set beforehand.
    # ⚠ GRID IS ITS OWN METHOD NOW, promoted out of a checkbox inside Voronoi. It is a
    # different LOOK — brick, tile, blockwork — not a modifier of another method, and burying
    # it in a tickbox is why it was easy to miss.
    bpy.types.Scene.mg_fracture_method = bpy.props.EnumProperty(
        name="Method", default='VORONOI',
        items=[('GRID', "Grid", "Break on a regular lattice — brick, tile, blockwork. "
                                "Bakes real cells, watertight", 'MESH_GRID', 0),
               ('LIVE', "Live", ng.describe('LIVE'), 'MOD_EXPLODE', 1),
               ('PIECES', "Pieces", ng.describe('PIECES'), 'MOD_SIMPLIFY', 2),
               ('VORONOI', "Voronoi", "Break into irregular Voronoi cells. Bakes real "
                                      "geometry — exact piece count, watertight",
                'MOD_REMESH', 3)])
    # ⚠ A POINTER HERE, a NAME on the operator. The picker needs to browse the file's
    # collections, which only a PointerProperty can do; the operator cannot carry an ID, so
    # the panel passes `.name` across the gap.
    bpy.types.Scene.mg_from_collection = bpy.props.PointerProperty(
        type=bpy.types.Collection, name="From Collection",
        description="Clone this collection where it stands. Leave empty to clone the "
                    "selected objects instead")
    # ⚠ THE NESTING ROUTE. Without this, cloning a cloner meant pointing Sources at its GROUP
    # collection — which also holds its field gizmos, and Collection Info recurses, so the
    # fields got cloned as geometry. Named "From Object" to stay clear of the Object MODE
    # button, which means clone ONTO an object's points.
    bpy.types.Scene.mg_from_object = bpy.props.PointerProperty(
        type=bpy.types.Object, name="From Object",
        description="Clone this object where it stands — including another cloner, which is "
                    "how you nest them. Leave empty to clone the selected objects")
    bpy.types.Scene.mg_tab = bpy.props.EnumProperty(
        name="Make", default='CLONE',
        items=[('CLONE', "Clone", "Copy objects into a pattern", 'MESH_GRID', 0),
               ('FRACTURE', "Fracture", "Break a mesh into pieces", 'MOD_EXPLODE', 1)])


def unregister():
    # ⚠ the pointer goes BEFORE the class it points at, or Blender holds a reference to a
    # class it has just been told to forget.
    for _p in ("mg_voronoi", "mg_tab", "mg_fracture_method", "mg_from_collection",
           "mg_from_object"):
        if hasattr(bpy.types.Scene, _p):
            delattr(bpy.types.Scene, _p)
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
