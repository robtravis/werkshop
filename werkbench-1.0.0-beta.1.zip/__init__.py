bl_info = {
    "name": "Werkbench",
    "author": "Vivinel",
    "description": "Object setup for archviz: origin sliders, Illustrator-style align and distribute, parametric primitives with viewport handles, and C4D-style grouping. No timeline — anything that moves lives in Motionwerks.",
    "version": (1, 0, 0),
    "warning": "Beta 1",
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > Werkbench",
    "doc_url": "https://www.vivinel.com/",
    "category": "Werks",
}

import bpy
from mathutils import Vector, Matrix

FEET_TO_METERS = 0.3048
PANEL_CATEGORY = "Werkbench"


# ----------------------------------------------------------------------------
# Generic helpers
# ----------------------------------------------------------------------------

def _iter_fcurves(action):
    """Yield all fcurves from an Action (handles legacy and slotted Blender 4.4+ actions)."""
    if action is None:
        return
    if hasattr(action, "fcurves"):
        yield from action.fcurves
        return
    for layer in action.layers:
        for strip in layer.strips:
            for cb in strip.channelbags:
                yield from cb.fcurves


def _local_bbox(obj):
    """Compute (min, max) of obj's mesh bbox from actual vertex coords (bypasses stale bound_box)."""
    verts = obj.data.vertices
    if not verts:
        return Vector(), Vector()
    xs = [v.co.x for v in verts]
    ys = [v.co.y for v in verts]
    zs = [v.co.z for v in verts]
    return (Vector((min(xs), min(ys), min(zs))),
            Vector((max(xs), max(ys), max(zs))))


AXES = ('X', 'Y', 'Z')


def _world_bbox(obj):
    """(min, max) of obj's bounding box in world space.

    Meshes go through _local_bbox because obj.bound_box lags behind
    obj.data.transform() — which the Origin tools call — so aligning straight
    after an origin move would otherwise read the previous bounds.
    """
    if obj.type == 'MESH' and obj.data and obj.data.vertices:
        lo, hi = _local_bbox(obj)
        corners = [Vector((x, y, z))
                   for x in (lo.x, hi.x) for y in (lo.y, hi.y) for z in (lo.z, hi.z)]
    else:
        corners = [Vector(c) for c in obj.bound_box]
    ws = [obj.matrix_world @ c for c in corners]
    return (Vector((min(c.x for c in ws), min(c.y for c in ws), min(c.z for c in ws))),
            Vector((max(c.x for c in ws), max(c.y for c in ws), max(c.z for c in ws))))


def _align_ref(obj, axis, mode, use_origins):
    """The coordinate on obj that alignment matches: its origin, or a bbox edge/centre."""
    i = AXES.index(axis)
    if use_origins:
        return obj.matrix_world.translation[i]
    lo, hi = _world_bbox(obj)
    if mode == 'MIN':
        return lo[i]
    if mode == 'MAX':
        return hi[i]
    return (lo[i] + hi[i]) * 0.5


def _align_extent(objs, axis, use_origins=False):
    """Extent the selection is aligned within.

    Must use the same convention as _align_ref: mixing an origin reference with
    a bounding-box target parks origins on bbox extremes, which means nothing.
    """
    i = AXES.index(axis)
    if use_origins:
        ps = [o.matrix_world.translation[i] for o in objs]
        return min(ps), max(ps)
    los, his = [], []
    for o in objs:
        lo, hi = _world_bbox(o)
        los.append(lo[i]); his.append(hi[i])
    return min(los), max(his)


def _alignable(context):
    """Selected objects worth aligning — bare Empties have no bounds to speak of."""
    return [o for o in context.selected_objects
            if o.type != 'EMPTY' or o.instance_collection]


def _move_origin_to(obj, target_world):
    """Move obj's origin to target_world, keeping the visible mesh in place.

    Pure math, no operators. Auto-unlinks shared mesh data.
    """
    if obj.type != 'MESH':
        return
    if obj.data.users > 1:
        obj.data = obj.data.copy()

    delta_world = target_world - obj.matrix_world.translation
    local_delta = obj.matrix_world.to_3x3().inverted() @ delta_world

    obj.data.transform(Matrix.Translation(-local_delta))
    obj.data.update()

    new_mw = obj.matrix_world.copy()
    new_mw.translation = target_world
    obj.matrix_world = new_mw


def _resolve_easing(easing, in_like):
    if easing == 'AUTO':
        return 'EASE_OUT' if in_like else 'EASE_IN'
    return easing


def _clear_fcurves(obj, data_path, array_index=None):
    """Remove fcurves on obj matching data_path (optionally a specific array_index)."""
    if not (obj.animation_data and obj.animation_data.action):
        return
    action = obj.animation_data.action

    def matches(fc):
        if fc.data_path != data_path:
            return False
        if array_index is not None and fc.array_index != array_index:
            return False
        return True

    if hasattr(action, "fcurves"):
        for fc in list(action.fcurves):
            if matches(fc):
                action.fcurves.remove(fc)
        return
    for layer in action.layers:
        for strip in layer.strips:
            for cb in strip.channelbags:
                for fc in list(cb.fcurves):
                    if matches(fc):
                        cb.fcurves.remove(fc)


def _apply_curve(obj, data_path, curve, easing, in_like, array_index=None):
    if not (obj.animation_data and obj.animation_data.action):
        return
    resolved = _resolve_easing(easing, in_like)
    has_easing = curve not in {'LINEAR', 'CONSTANT', 'BEZIER'}
    for fc in _iter_fcurves(obj.animation_data.action):
        if fc.data_path != data_path:
            continue
        if array_index is not None and fc.array_index != array_index:
            continue
        for kp in fc.keyframe_points:
            kp.interpolation = curve
            if has_easing:
                kp.easing = resolved


# ----------------------------------------------------------------------------
# Anchor Empty helpers
# ----------------------------------------------------------------------------

def _is_anchor(obj):
    # New marker is "_animtb_anchor"; we still recognize legacy "_animtb_pivot" empties for back-compat.
    if obj is None or obj.type != 'EMPTY':
        return False
    return bool(obj.get("_animtb_anchor")) or bool(obj.get("_animtb_pivot"))


def _resolve_anchor_target(empty):
    """Find the mesh an anchor Empty is driving."""
    name = empty.get("_animtb_target")
    if name:
        t = bpy.data.objects.get(name)
        if t and t.parent == empty:
            return t
    for c in empty.children:
        if c.type == 'MESH':
            return c
    return None


def _find_existing_anchor(target):
    # Prefer the new `_anchor` suffix; fall back to legacy `_pivot` suffix.
    for suffix in ("_anchor", "_pivot"):
        candidate = bpy.data.objects.get(f"{target.name}{suffix}")
        if _is_anchor(candidate) and _resolve_anchor_target(candidate) == target:
            return candidate
    return None


def _compute_anchor_world(target, axis, direction, uniform=False):
    bb_min, bb_max = _local_bbox(target)
    anchor_local = (bb_min + bb_max) / 2
    if uniform:
        return target.matrix_world @ anchor_local
    axis_idx = 'XYZ'.index(axis.lstrip('-'))
    axis_sign = -1 if axis.startswith('-') else 1
    # Anchor X/Y wipes at the local bottom; Z wipes use the axis-edge logic.
    if axis_idx != 2:
        anchor_local.z = bb_min.z
    if direction == 'IN':
        anchor_local[axis_idx] = bb_max[axis_idx] if axis_sign > 0 else bb_min[axis_idx]
    else:
        anchor_local[axis_idx] = bb_min[axis_idx] if axis_sign > 0 else bb_max[axis_idx]
    return target.matrix_world @ anchor_local


def _reset_anchor_to_rest(anchor):
    """Restore anchor's basis to its stored rest pose (or identity scale if none stored)."""
    if anchor.animation_data:
        anchor.animation_data.action = None
    anchor.scale = (1.0, 1.0, 1.0)
    rest = anchor.get("_animtb_rest_location")
    if rest:
        anchor.location = (rest[0], rest[1], rest[2])


def _ensure_anchor_empty(context, target, axis, direction, uniform=False):
    """Create or recreate an anchor Empty for target. Returns the Empty.

    If a legacy `_pivot`-suffixed Empty exists, we unwind and remove it, then create a fresh
    `_anchor`-suffixed one. New empties also carry the `_animtb_anchor` marker prop.
    """
    existing = _find_existing_anchor(target)

    if existing is not None:
        # Reset to rest pose so target.matrix_world reflects target's rest position
        _reset_anchor_to_rest(existing)
        context.view_layer.update()
        grandparent = existing.parent
        target_world = target.matrix_world.copy()
        target.parent = grandparent
        target.matrix_world = target_world
        bpy.data.objects.remove(existing, do_unlink=True)

    anchor_world = _compute_anchor_world(target, axis, direction, uniform=uniform)

    empty_name = f"{target.name}_anchor"
    empty = bpy.data.objects.new(empty_name, None)
    empty.empty_display_type = 'ARROWS'
    empty.empty_display_size = 0.5
    cols = list(target.users_collection)
    (cols[0] if cols else context.scene.collection).objects.link(empty)

    _, rot, _ = target.matrix_world.decompose()
    empty.matrix_world = Matrix.Translation(anchor_world) @ rot.to_matrix().to_4x4()

    original_parent = target.parent
    if original_parent:
        e_world = empty.matrix_world.copy()
        empty.parent = original_parent
        empty.matrix_world = e_world

    t_world = target.matrix_world.copy()
    target.parent = empty
    target.matrix_world = t_world

    # Snapshot the rest location so future regenerates can restore the anchor reliably
    empty["_animtb_rest_location"] = list(empty.location)

    return empty


# ----------------------------------------------------------------------------
# Shared enums + ordering
# ----------------------------------------------------------------------------

CURVE_ITEMS = [
    ('LINEAR',  "Linear",    "No easing"),
    ('SINE',    "Smooth",    "Sine ease"),
    ('CUBIC',   "Cubic",     "Cubic ease — moderate"),
    ('QUAD',    "Snap",      "Quadratic — fast start"),
    ('BACK',    "Overshoot", "Overshoots before settling"),
    ('BOUNCE',  "Bounce",    "Bounces at landing"),
    ('ELASTIC', "Elastic",   "Rubbery overshoot"),
]

EASING_ITEMS = [
    ('AUTO',        "Auto",   "Ease Out for In animations, Ease In for Out"),
    ('EASE_IN',     "In",     "Slow at start"),
    ('EASE_OUT',    "Out",    "Slow at end"),
    ('EASE_IN_OUT', "In/Out", "Symmetrical"),
]

ORDER_ITEMS = [
    ('NAME',      "Name",       "Alphabetical by object name"),
    ('X',         "X position", "World X (low → high)"),
    ('Y',         "Y position", "World Y (low → high)"),
    ('Z',         "Z position", "World Z (low → high)"),
    ('RANDOM',    "Random",     "Shuffled (re-shuffles each apply)"),
    ('SELECTION', "Selection",  "Order returned by selection (best effort)"),
]

AXIS_ITEMS = [
    ('X',  "X",  "Along +X"),
    ('Y',  "Y",  "Along +Y"),
    ('Z',  "Z",  "Along +Z"),
    ('-X', "-X", "Along -X"),
    ('-Y', "-Y", "Along -Y"),
    ('-Z', "-Z", "Along -Z"),
]


def _sort_targets(targets, order, reverse):
    if order == 'NAME':
        targets.sort(key=lambda o: o.name)
    elif order in ('X', 'Y', 'Z'):
        idx = 'XYZ'.index(order)
        targets.sort(key=lambda o: o.matrix_world.translation[idx])
    elif order == 'RANDOM':
        import random
        random.shuffle(targets)
        return
    if reverse:
        targets.reverse()


# ----------------------------------------------------------------------------
# Origin (sliders)
# ----------------------------------------------------------------------------

def _compute_origin_target(obj, x, y, z, mode):
    factor = Vector((x / 2 + 0.5, y / 2 + 0.5, z / 2 + 0.5))
    if mode == 'WORLD':
        wm = obj.matrix_world
        verts = [wm @ v.co for v in obj.data.vertices]
        if not verts:
            return obj.matrix_world.translation.copy()
        bbox_min = Vector((min(v.x for v in verts),
                           min(v.y for v in verts),
                           min(v.z for v in verts)))
        bbox_max = Vector((max(v.x for v in verts),
                           max(v.y for v in verts),
                           max(v.z for v in verts)))
        return bbox_min + (bbox_max - bbox_min) * factor

    bbox_min, bbox_max = _local_bbox(obj)
    return obj.matrix_world @ (bbox_min + (bbox_max - bbox_min) * factor)


def _apply_origin(objects, x, y, z, mode):
    for obj in objects:
        _move_origin_to(obj, _compute_origin_target(obj, x, y, z, mode))


def _on_origin_slider_update(self, context):
    objects = [o for o in context.selected_objects if o.type == 'MESH']
    if objects:
        _apply_origin(objects, self.x, self.y, self.z, self.mode)


# ----------------------------------------------------------------------------
# Property groups
# ----------------------------------------------------------------------------

class ATOriginProps(bpy.types.PropertyGroup):
    x: bpy.props.FloatProperty(name="X", default=0.0, min=-1.0, max=1.0,
                               update=_on_origin_slider_update)
    y: bpy.props.FloatProperty(name="Y", default=0.0, min=-1.0, max=1.0,
                               update=_on_origin_slider_update)
    z: bpy.props.FloatProperty(name="Z", default=0.0, min=-1.0, max=1.0,
                               update=_on_origin_slider_update)
    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('WORLD', "World", "Axis-aligned bbox in world space"),
            ('LOCAL', "Local", "Local-space bbox (follows object orientation)"),
        ],
        default='WORLD',
    )


class ATAlignProps(bpy.types.PropertyGroup):
    relative_to: bpy.props.EnumProperty(
        name="Align To",
        items=[
            ('SELECTION', "Selection", "Combined bounds of everything selected"),
            ('ACTIVE', "Active", "The active object stays put and everything else "
                                 "aligns to it (Illustrator's Key Object)"),
            ('CURSOR', "Cursor", "The 3D cursor"),
            ('WORLD', "World", "The scene origin"),
        ],
        default='SELECTION',
    )
    use_origins: bpy.props.BoolProperty(
        name="Use Origins", default=False,
        description="Align by each object's origin instead of its bounding box. Use "
                    "when the origin carries meaning — a door on its hinge, a wall on "
                    "its animation pivot",
    )
    spacing: bpy.props.FloatProperty(
        name="Spacing", default=0.0, min=0.0, unit='LENGTH',
        description="Exact gap for Distribute Gaps. 0 spreads evenly between the "
                    "outermost objects",
    )


# ----------------------------------------------------------------------------
# Origin operators
# ----------------------------------------------------------------------------

class WB_OT_origin_reapply(bpy.types.Operator):
    bl_idname = "werkbench.origin_reapply"
    bl_label = "Re-apply Origin"
    bl_description = "Re-apply current origin slider values to selected meshes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        p = context.scene.anitools_origin
        _apply_origin([o for o in context.selected_objects if o.type == 'MESH'],
                      p.x, p.y, p.z, p.mode)
        return {'FINISHED'}


class WB_OT_origin_center(bpy.types.Operator):
    bl_idname = "werkbench.origin_center"
    bl_label = "Center Origin"
    bl_description = "Reset sliders to 0 (origin at bounding-box center)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        p = context.scene.anitools_origin
        p.x = 0.0
        p.y = 0.0
        p.z = 0.0
        return {'FINISHED'}


class WB_OT_origin_reset_axis(bpy.types.Operator):
    bl_idname = "werkbench.origin_reset_axis"
    bl_label = "Reset Axis"
    bl_description = "Reset this axis slider to 0"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(items=[('X', "X", ""), ('Y', "Y", ""), ('Z', "Z", "")])

    def execute(self, context):
        setattr(context.scene.anitools_origin, self.axis.lower(), 0.0)
        return {'FINISHED'}


class WB_OT_drop_to_floor(bpy.types.Operator):
    bl_idname = "werkbench.drop_to_floor"
    bl_label = "Drop to Floor"
    bl_description = ("Put each selected mesh's origin at its lowest point and set Z to 0, "
                      "so it rests on the floor. X, Y and rotation are left alone")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        for obj in [o for o in context.selected_objects if o.type == 'MESH']:
            wm = obj.matrix_world
            verts = [wm @ v.co for v in obj.data.vertices]
            if not verts:
                continue
            bottom = min(v.z for v in verts)
            here = wm.translation.copy()

            # ⚠ Z ONLY — this is a DROP, not a reset. It used to re-centre the origin in X
            # and Y, then zero location AND rotation, so an object fell to the floor *and*
            # teleported to the world centre unrotated.
            #
            # ⚠ Zeroing rotation was also wrong on its own terms: `bottom` is measured WITH
            # the rotation applied, so un-rotating afterwards moved the geometry and the
            # object no longer sat on the floor — the one thing the operator is named for.
            _move_origin_to(obj, Vector((here.x, here.y, bottom)))

            # ⚠ Written through matrix_world, not obj.location: for a PARENTED object
            # `location` is in parent space, so `location.z = 0` would not put it on the
            # world floor. Assigning matrix_world lets Blender solve the local transform.
            mw = obj.matrix_world.copy()
            mw.translation = Vector((here.x, here.y, 0.0))
            obj.matrix_world = mw
        return {'FINISHED'}


class WB_OT_reset_transform(bpy.types.Operator):
    bl_idname = "werkbench.reset_transform"
    bl_label = "Reset Transform"
    bl_description = "Reset location, rotation, and scale of the active object"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        obj = context.active_object
        obj.location = (0.0, 0.0, 0.0)
        obj.rotation_euler = (0.0, 0.0, 0.0)
        obj.scale = (1.0, 1.0, 1.0)
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# Align / Distribute
# ----------------------------------------------------------------------------

class WB_OT_align(bpy.types.Operator):
    bl_idname = "werkbench.align"
    bl_label = "Align"
    bl_description = "Align selected objects on one axis"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(name="Axis", items=[(a, a, "") for a in AXES], default='X')
    mode: bpy.props.EnumProperty(
        name="Mode", default='CENTER',
        items=[('MIN', "Min", "Align the low sides"),
               ('CENTER', "Center", "Align centres"),
               ('MAX', "Max", "Align the high sides")])
    relative_to: bpy.props.EnumProperty(
        name="Align To", default='SELECTION',
        items=[('SELECTION', "Selection", "The combined bounds of everything selected"),
               ('ACTIVE', "Active", "The active object — Illustrator's Key Object"),
               ('CURSOR', "3D Cursor", "The 3D cursor"),
               ('WORLD', "World", "The scene origin")])
    use_origins: bpy.props.BoolProperty(
        name="Use Origins", default=False,
        description="Match object origins instead of bounding boxes")

    def execute(self, context):
        objs = _alignable(context)
        if not objs:
            self.report({'WARNING'}, "Nothing selected")
            return {'CANCELLED'}
        i = AXES.index(self.axis)

        if self.relative_to == 'WORLD':
            target = 0.0
        elif self.relative_to == 'CURSOR':
            target = context.scene.cursor.location[i]
        elif self.relative_to == 'ACTIVE':
            act = context.active_object
            if act is None:
                self.report({'WARNING'}, "No active object")
                return {'CANCELLED'}
            target = _align_ref(act, self.axis, self.mode, self.use_origins)
            # the key object anchors the others and never moves itself
            objs = [o for o in objs if o is not act]
        else:
            lo, hi = _align_extent(objs, self.axis, self.use_origins)
            target = lo if self.mode == 'MIN' else hi if self.mode == 'MAX' else (lo + hi) * 0.5

        deltas = [target - _align_ref(o, self.axis, self.mode, self.use_origins) for o in objs]
        n = 0
        for o, delta in zip(objs, deltas):
            if abs(delta) > 1e-6:   # float32 bbox precision; tighter just chases noise
                o.location[i] += delta
                n += 1

        # A no-op and a rigid group slide are both correct, and both look broken
        # in the viewport, so say which happened instead of leaving it ambiguous.
        if n == 0:
            self.report({'INFO'}, "Already aligned on %s — nothing to do" % self.axis)
        elif len(objs) > 1 and max(deltas) - min(deltas) < 1e-6:
            self.report({'WARNING'}, "Already aligned on %s — moved all %d as a group "
                                     "to the %s" % (self.axis, n, self.relative_to.lower()))
        else:
            self.report({'INFO'}, "Aligned %d object(s) on %s" % (n, self.axis))
        return {'FINISHED'}


class WB_OT_distribute(bpy.types.Operator):
    bl_idname = "werkbench.distribute"
    bl_label = "Distribute"
    bl_description = "Space selected objects evenly on one axis. The outermost two stay put"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(name="Axis", items=[(a, a, "") for a in AXES], default='X')
    mode: bpy.props.EnumProperty(
        name="Mode", default='CENTERS',
        items=[('CENTERS', "Centers", "Even spacing between centres — Illustrator's "
                                      "Distribute Objects"),
               ('GAPS', "Gaps", "Equal empty space between objects whatever their "
                                "size — Illustrator's Distribute Spacing")])
    spacing: bpy.props.FloatProperty(
        name="Spacing", default=0.0, min=0.0, unit='LENGTH',
        description="Exact gap to use. 0 spreads evenly between the outermost objects")

    def execute(self, context):
        objs = _alignable(context)
        exact = self.mode == 'GAPS' and self.spacing > 0.0
        if len(objs) < 3 and not (exact and len(objs) > 1):
            self.report({'WARNING'}, "Select at least 3 objects (or set an exact Spacing)")
            return {'CANCELLED'}
        i = AXES.index(self.axis)

        rows = []
        for o in objs:
            lo, hi = _world_bbox(o)
            rows.append({"obj": o, "lo": lo[i], "hi": hi[i],
                         "c": (lo[i] + hi[i]) * 0.5, "size": hi[i] - lo[i]})
        rows.sort(key=lambda r: r["c"])

        if self.mode == 'CENTERS':
            first, last = rows[0]["c"], rows[-1]["c"]
            step = (last - first) / (len(rows) - 1)
            for k, r in enumerate(rows[1:-1], start=1):
                r["obj"].location[i] += (first + step * k) - r["c"]
        else:
            if exact:
                gap = self.spacing
            else:
                span = rows[-1]["hi"] - rows[0]["lo"]
                gap = (span - sum(r["size"] for r in rows)) / (len(rows) - 1)
            cursor = rows[0]["hi"]
            for r in rows[1:]:
                target_lo = cursor + gap
                r["obj"].location[i] += target_lo - r["lo"]
                cursor = target_lo + r["size"]

        self.report({'INFO'}, "Distributed %d object(s) on %s" % (len(rows), self.axis))
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# Animation core
# ----------------------------------------------------------------------------

def _set_scale_keyframes(anchor, axis, direction, duration, frame_start, curve, easing, uniform=False):
    f_end = frame_start + duration

    if uniform:
        if direction == 'IN':
            anchor.scale = (0.0, 0.0, 0.0); anchor.keyframe_insert("scale", frame=frame_start)
            anchor.scale = (1.0, 1.0, 1.0); anchor.keyframe_insert("scale", frame=f_end)
        else:
            anchor.scale = (1.0, 1.0, 1.0); anchor.keyframe_insert("scale", frame=frame_start)
            anchor.scale = (0.0, 0.0, 0.0); anchor.keyframe_insert("scale", frame=f_end)
    else:
        axis_idx = 'XYZ'.index(axis.lstrip('-'))
        middle = [1.0, 1.0, 1.0]
        middle[axis_idx] = 0.0
        if direction == 'IN':
            anchor.scale = (0.0, 0.0, 0.0); anchor.keyframe_insert("scale", frame=frame_start)
            anchor.scale = middle;          anchor.keyframe_insert("scale", frame=frame_start + 1)
            anchor.scale = (1.0, 1.0, 1.0); anchor.keyframe_insert("scale", frame=f_end)
        else:
            anchor.scale = (1.0, 1.0, 1.0); anchor.keyframe_insert("scale", frame=frame_start)
            anchor.scale = middle;          anchor.keyframe_insert("scale", frame=f_end - 1)
            anchor.scale = (0.0, 0.0, 0.0); anchor.keyframe_insert("scale", frame=f_end)

    _apply_curve(anchor, "scale", curve, easing, in_like=(direction == 'IN'))


def _set_move_keyframes(obj, axis, direction, distance_ft, duration, frame_start, curve, easing):
    """IN arrives at obj's current location from `offset` away; OUT departs from current to `offset`."""
    axis_idx = 'XYZ'.index(axis.lstrip('-'))
    axis_sign = -1 if axis.startswith('-') else 1
    offset = axis_sign * abs(distance_ft) * FEET_TO_METERS

    rest = obj.location[axis_idx]
    if direction == 'IN':
        start, end = rest + offset, rest
    else:
        start, end = rest, rest + offset

    f_end = frame_start + duration
    obj.location[axis_idx] = start
    obj.keyframe_insert("location", index=axis_idx, frame=frame_start)
    obj.location[axis_idx] = end
    obj.keyframe_insert("location", index=axis_idx, frame=f_end)

    _apply_curve(obj, "location", curve, easing,
                 in_like=(direction == 'IN'), array_index=axis_idx)


def _set_rotation_keyframes(obj, axis, direction, angle_deg, duration, frame_start, curve, easing):
    """IN arrives at obj's current rotation from `+angle` offset; OUT departs from current to `+angle` offset."""
    import math
    axis_idx = 'XYZ'.index(axis.lstrip('-'))
    axis_sign = -1 if axis.startswith('-') else 1
    angle_rad = math.radians(angle_deg) * axis_sign

    rest = obj.rotation_euler[axis_idx]
    if direction == 'IN':
        start, end = rest + angle_rad, rest
    else:
        start, end = rest, rest + angle_rad

    f_end = frame_start + duration
    obj.rotation_euler[axis_idx] = start
    obj.keyframe_insert("rotation_euler", index=axis_idx, frame=frame_start)
    obj.rotation_euler[axis_idx] = end
    obj.keyframe_insert("rotation_euler", index=axis_idx, frame=f_end)

    _apply_curve(obj, "rotation_euler", curve, easing,
                 in_like=(direction == 'IN'), array_index=axis_idx)


def _set_visibility_keyframes(obj, direction, frame_start, frame_end):
    """Hard-cut visibility: IN hides before frame_start; OUT hides after frame_end. Constant interpolation."""
    if direction == 'IN':
        before, at = frame_start - 1, frame_start
        obj.hide_viewport = True
        obj.keyframe_insert("hide_viewport", frame=before)
        obj.hide_render = True
        obj.keyframe_insert("hide_render", frame=before)
        obj.hide_viewport = False
        obj.keyframe_insert("hide_viewport", frame=at)
        obj.hide_render = False
        obj.keyframe_insert("hide_render", frame=at)
    else:
        at, after = frame_end, frame_end + 1
        obj.hide_viewport = False
        obj.keyframe_insert("hide_viewport", frame=at)
        obj.hide_render = False
        obj.keyframe_insert("hide_render", frame=at)
        obj.hide_viewport = True
        obj.keyframe_insert("hide_viewport", frame=after)
        obj.hide_render = True
        obj.keyframe_insert("hide_render", frame=after)

    # Constant interpolation so the cut is binary, not eased
    if obj.animation_data and obj.animation_data.action:
        for fc in _iter_fcurves(obj.animation_data.action):
            if fc.data_path in ("hide_viewport", "hide_render"):
                for kp in fc.keyframe_points:
                    kp.interpolation = 'CONSTANT'


def _apply_animation(context, target, p, frame_start):
    """Run the configured Scale/Move/Rotation/Visibility animation on `target`. Returns the anchor (or None)."""
    anchor = None
    secondary_animator = target  # the thing Move and Rotation animate

    needs_anchor = p.scale_enabled or p.rotation_enabled

    if needs_anchor:
        # For rotation without scale, use uniform mode so the anchor sits at bbox center
        # (more natural rotation pivot than an axis edge).
        use_uniform = p.scale_uniform if p.scale_enabled else True
        axis_for_anchor = p.scale_axis if p.scale_enabled else 'Z'
        anchor = _ensure_anchor_empty(context, target, axis_for_anchor, p.direction,
                                      uniform=use_uniform)
        secondary_animator = anchor
        _clear_fcurves(anchor, "scale")
        _clear_fcurves(anchor, "rotation_euler")
        _clear_fcurves(anchor, "location")
        if p.scale_enabled:
            _set_scale_keyframes(
                anchor, p.scale_axis, p.direction, p.scale_frames,
                frame_start, p.curve, p.easing, uniform=p.scale_uniform,
            )
    else:
        # Move-only: if an anchor already exists for this target, animate it.
        existing = _find_existing_anchor(target)
        if existing:
            secondary_animator = existing
            _clear_fcurves(existing, "scale")
            _clear_fcurves(existing, "rotation_euler")
            _reset_anchor_to_rest(existing)

    move_start = frame_start + p.pause
    rot_start = frame_start + p.rotation_pause

    if p.move_enabled:
        axis_idx = 'XYZ'.index(p.move_axis.lstrip('-'))
        if secondary_animator is target and anchor is None:
            _clear_fcurves(target, "location", array_index=axis_idx)
        # (anchor location was already cleared above)
        _set_move_keyframes(
            secondary_animator, p.move_axis, p.direction, p.move_distance_ft,
            p.move_frames, move_start, p.curve, p.easing,
        )

    if p.rotation_enabled:
        axis_idx = 'XYZ'.index(p.rotation_axis.lstrip('-'))
        if secondary_animator is target and anchor is None:
            _clear_fcurves(target, "rotation_euler", array_index=axis_idx)
        _set_rotation_keyframes(
            secondary_animator, p.rotation_axis, p.direction, p.rotation_angle_deg,
            p.rotation_frames, rot_start, p.curve, p.easing,
        )

    # Compute overall animation end frame for visibility cut
    end_candidates = [frame_start]
    if p.scale_enabled:
        end_candidates.append(frame_start + p.scale_frames)
    if p.move_enabled:
        end_candidates.append(move_start + p.move_frames)
    if p.rotation_enabled:
        end_candidates.append(rot_start + p.rotation_frames)
    animation_end = max(end_candidates)

    if p.visibility_enabled:
        vis_target = anchor if anchor else (
            _find_existing_anchor(target) if _find_existing_anchor(target) else target
        )
        _clear_fcurves(vis_target, "hide_viewport")
        _clear_fcurves(vis_target, "hide_render")
        _set_visibility_keyframes(vis_target, p.direction, frame_start, animation_end)

    if anchor:
        anchor["_animtb_anchor"] = True       # new marker
        # Clear legacy marker if present, so we don't end up with both
        if "_animtb_pivot" in anchor.keys():
            del anchor["_animtb_pivot"]
        anchor["_animtb_target"] = target.name
        anchor["_animtb_direction"] = p.direction
        anchor["_animtb_scale_enabled"] = p.scale_enabled
        anchor["_animtb_scale_uniform"] = p.scale_uniform
        anchor["_animtb_scale_axis"] = p.scale_axis
        anchor["_animtb_scale_frames"] = p.scale_frames
        anchor["_animtb_move_enabled"] = p.move_enabled
        anchor["_animtb_move_axis"] = p.move_axis
        anchor["_animtb_move_distance_ft"] = p.move_distance_ft
        anchor["_animtb_move_frames"] = p.move_frames
        anchor["_animtb_rotation_enabled"] = p.rotation_enabled
        anchor["_animtb_rotation_axis"] = p.rotation_axis
        anchor["_animtb_rotation_angle_deg"] = p.rotation_angle_deg
        anchor["_animtb_rotation_frames"] = p.rotation_frames
        anchor["_animtb_rotation_pause"] = p.rotation_pause
        anchor["_animtb_visibility_enabled"] = p.visibility_enabled
        anchor["_animtb_pause"] = p.pause
        anchor["_animtb_curve"] = p.curve
        anchor["_animtb_easing"] = p.easing
        anchor["_animtb_frame_start"] = frame_start

    return anchor


# ----------------------------------------------------------------------------
# Animate operators
# ----------------------------------------------------------------------------

def _unwrap_anchor(empty):
    """Unwrap a single anchor Empty: reparent target back to grandparent and delete the anchor."""
    target = _resolve_anchor_target(empty)
    if target is None:
        return False
    if empty.animation_data:
        empty.animation_data.action = None
    empty.scale = (1.0, 1.0, 1.0)
    bpy.context.view_layer.update()
    grandparent = empty.parent
    t_world = target.matrix_world.copy()
    target.parent = grandparent
    target.matrix_world = t_world
    bpy.data.objects.remove(empty, do_unlink=True)
    return True


# ----------------------------------------------------------------------------
# Material transition
# ----------------------------------------------------------------------------

_MAT_SKIP_COPY_PROPS = {
    'rna_type', 'type', 'location', 'name', 'select', 'parent',
    'inputs', 'outputs', 'internal_links', 'width', 'width_hidden',
    'height', 'dimensions', 'show_options', 'show_preview', 'show_texture',
}


def _copy_node_tree_into(src_tree, dst_tree, x_offset=0, skip_output=True):
    """Copy every node from src_tree into dst_tree, preserving links.
    Returns (node_map, output_surface_node), where output_surface_node is
    whatever node fed the Surface socket of the source Material Output.
    """
    node_map = {}
    src_output_surface_link_from = None

    for n in src_tree.nodes:
        if skip_output and n.type == 'OUTPUT_MATERIAL':
            if n.inputs['Surface'].is_linked:
                src_output_surface_link_from = n.inputs['Surface'].links[0].from_node
            continue
        try:
            new_n = dst_tree.nodes.new(n.bl_idname)
        except RuntimeError:
            continue
        new_n.location = (n.location.x + x_offset, n.location.y)
        for prop_name in n.bl_rna.properties.keys():
            if prop_name in _MAT_SKIP_COPY_PROPS:
                continue
            if n.bl_rna.properties[prop_name].is_readonly:
                continue
            try:
                setattr(new_n, prop_name, getattr(n, prop_name))
            except Exception:
                pass
        for i, inp in enumerate(n.inputs):
            if i >= len(new_n.inputs):
                continue
            if hasattr(inp, 'default_value') and hasattr(new_n.inputs[i], 'default_value'):
                try:
                    new_n.inputs[i].default_value = inp.default_value
                except Exception:
                    pass
        node_map[n] = new_n

    for l in src_tree.links:
        if l.from_node not in node_map or l.to_node not in node_map:
            continue
        try:
            dst_tree.links.new(node_map[l.from_node].outputs[l.from_socket.name],
                                node_map[l.to_node].inputs[l.to_socket.name])
        except Exception:
            pass

    output_surface_node = node_map.get(src_output_surface_link_from)
    return node_map, output_surface_node


def _build_transition_material(name, mat_a, mat_b, axis, coord_type,
                                softness, noise_amount, noise_scale, b_is_alpha):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()

    out = nt.nodes.new('ShaderNodeOutputMaterial')
    out.location = (1000, 0)

    mix_shader = nt.nodes.new('ShaderNodeMixShader')
    mix_shader.location = (800, 0)
    nt.links.new(mix_shader.outputs['Shader'], out.inputs['Surface'])

    frame_a = nt.nodes.new('NodeFrame')
    frame_a.label = f"Material A: {mat_a.name}"
    a_map, a_surface = _copy_node_tree_into(mat_a.node_tree, nt, x_offset=-1400)
    for n in a_map.values():
        n.parent = frame_a
    if a_surface is not None:
        nt.links.new(a_surface.outputs[0], mix_shader.inputs[1])

    if b_is_alpha:
        transparent = nt.nodes.new('ShaderNodeBsdfTransparent')
        transparent.location = (600, -250)
        nt.links.new(transparent.outputs['BSDF'], mix_shader.inputs[2])
        mat.surface_render_method = 'DITHERED'
        mat.use_backface_culling = False
    else:
        frame_b = nt.nodes.new('NodeFrame')
        frame_b.label = f"Material B: {mat_b.name}"
        b_map, b_surface = _copy_node_tree_into(mat_b.node_tree, nt, x_offset=-1400)
        for n in b_map.values():
            n.location.y -= 600
            n.parent = frame_b
        if b_surface is not None:
            nt.links.new(b_surface.outputs[0], mix_shader.inputs[2])

    frame_t = nt.nodes.new('NodeFrame')
    frame_t.label = "Transition Control"

    tex_coord = nt.nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (0, 400)
    tex_coord.parent = frame_t

    sep_xyz = nt.nodes.new('ShaderNodeSeparateXYZ')
    sep_xyz.name = "Transition Axis Source"
    sep_xyz.location = (200, 400)
    sep_xyz.parent = frame_t
    coord_socket = 'Generated' if coord_type == 'GENERATED' else 'Object'
    nt.links.new(tex_coord.outputs[coord_socket], sep_xyz.inputs['Vector'])

    slider = nt.nodes.new('ShaderNodeValue')
    slider.name = "Transition Slider"
    slider.label = "Transition Slider"
    slider.location = (0, 200)
    slider.outputs[0].default_value = 0.5
    slider.parent = frame_t

    width = nt.nodes.new('ShaderNodeValue')
    width.name = "Transition Width"
    width.label = "Transition Width"
    width.location = (0, 50)
    width.outputs[0].default_value = max(softness, 0.001)
    width.parent = frame_t

    width_floor = nt.nodes.new('ShaderNodeMath')
    width_floor.name = "Transition Width Floor"
    width_floor.operation = 'MAXIMUM'
    width_floor.inputs[1].default_value = 0.0005  # hard-edge floor; keeps Map Range from dividing by zero
    width_floor.location = (100, 50)
    width_floor.parent = frame_t
    nt.links.new(width.outputs[0], width_floor.inputs[0])

    half_width = nt.nodes.new('ShaderNodeMath')
    half_width.operation = 'DIVIDE'
    half_width.inputs[1].default_value = 2.0
    half_width.location = (200, 50)
    half_width.parent = frame_t
    nt.links.new(width_floor.outputs[0], half_width.inputs[0])

    from_min = nt.nodes.new('ShaderNodeMath')
    from_min.operation = 'SUBTRACT'
    from_min.location = (400, 150)
    from_min.parent = frame_t
    nt.links.new(slider.outputs[0], from_min.inputs[0])
    nt.links.new(half_width.outputs[0], from_min.inputs[1])

    from_max = nt.nodes.new('ShaderNodeMath')
    from_max.operation = 'ADD'
    from_max.location = (400, -50)
    from_max.parent = frame_t
    nt.links.new(slider.outputs[0], from_max.inputs[0])
    nt.links.new(half_width.outputs[0], from_max.inputs[1])

    noise_scale_node = nt.nodes.new('ShaderNodeValue')
    noise_scale_node.name = "Noise Scale"
    noise_scale_node.label = "Noise Scale"
    noise_scale_node.location = (0, -150)
    noise_scale_node.outputs[0].default_value = noise_scale
    noise_scale_node.parent = frame_t

    noise_amount_node = nt.nodes.new('ShaderNodeValue')
    noise_amount_node.name = "Noise Amount"
    noise_amount_node.label = "Noise Amount"
    noise_amount_node.location = (0, -300)
    noise_amount_node.outputs[0].default_value = noise_amount
    noise_amount_node.parent = frame_t

    noise_tex = nt.nodes.new('ShaderNodeTexNoise')
    noise_tex.location = (200, -200)
    noise_tex.parent = frame_t
    nt.links.new(tex_coord.outputs[coord_socket], noise_tex.inputs['Vector'])
    nt.links.new(noise_scale_node.outputs[0], noise_tex.inputs['Scale'])

    noise_centered = nt.nodes.new('ShaderNodeMath')
    noise_centered.operation = 'SUBTRACT'
    noise_centered.inputs[1].default_value = 0.5
    noise_centered.location = (400, -200)
    noise_centered.parent = frame_t
    nt.links.new(noise_tex.outputs['Fac'], noise_centered.inputs[0])

    noise_scaled = nt.nodes.new('ShaderNodeMath')
    noise_scaled.operation = 'MULTIPLY'
    noise_scaled.location = (600, -200)
    noise_scaled.parent = frame_t
    nt.links.new(noise_centered.outputs[0], noise_scaled.inputs[0])
    nt.links.new(noise_amount_node.outputs[0], noise_scaled.inputs[1])

    # Gate noise by edge width: at the hard-edge floor, noise contributes nothing,
    # so "Edge Softness = 0" stays a true hard cut no matter what Noise Amount is set to.
    # Noise ramps back to full strength once width reaches 5% (matches prior behavior
    # at typical softness values).
    noise_gate = nt.nodes.new('ShaderNodeMapRange')
    noise_gate.name = "Transition Noise Gate"
    noise_gate.location = (600, -50)
    noise_gate.parent = frame_t
    noise_gate.clamp = True
    noise_gate.inputs['From Min'].default_value = 0.0005
    noise_gate.inputs['From Max'].default_value = 0.05
    noise_gate.inputs['To Min'].default_value = 0.0
    noise_gate.inputs['To Max'].default_value = 1.0
    nt.links.new(width_floor.outputs[0], noise_gate.inputs['Value'])

    noise_gated = nt.nodes.new('ShaderNodeMath')
    noise_gated.operation = 'MULTIPLY'
    noise_gated.location = (700, -200)
    noise_gated.parent = frame_t
    nt.links.new(noise_scaled.outputs[0], noise_gated.inputs[0])
    nt.links.new(noise_gate.outputs['Result'], noise_gated.inputs[1])

    channel_plus_noise = nt.nodes.new('ShaderNodeMath')
    channel_plus_noise.name = "Transition Axis Mix"
    channel_plus_noise.operation = 'ADD'
    channel_plus_noise.location = (600, 300)
    channel_plus_noise.parent = frame_t
    nt.links.new(sep_xyz.outputs[axis], channel_plus_noise.inputs[0])
    nt.links.new(noise_gated.outputs[0], channel_plus_noise.inputs[1])

    map_range = nt.nodes.new('ShaderNodeMapRange')
    map_range.location = (800, 200)
    map_range.parent = frame_t
    map_range.clamp = True
    map_range.inputs['To Min'].default_value = 0.0
    map_range.inputs['To Max'].default_value = 1.0
    nt.links.new(channel_plus_noise.outputs[0], map_range.inputs['Value'])
    nt.links.new(from_min.outputs[0], map_range.inputs['From Min'])
    nt.links.new(from_max.outputs[0], map_range.inputs['From Max'])

    nt.links.new(map_range.outputs['Result'], mix_shader.inputs['Fac'])

    return mat


# ----------------------------------------------------------------------------
# Camera reveal
# ----------------------------------------------------------------------------

def _scene_focus_point(context):
    """Bbox center of selected meshes, or world origin if nothing is selected."""
    meshes = [o for o in context.selected_objects if o.type == 'MESH']
    if not meshes:
        return Vector((0, 0, 0))
    pts = []
    for o in meshes:
        for c in o.bound_box:
            pts.append(o.matrix_world @ Vector(c))
    return Vector((
        (min(p.x for p in pts) + max(p.x for p in pts)) / 2,
        (min(p.y for p in pts) + max(p.y for p in pts)) / 2,
        (min(p.z for p in pts) + max(p.z for p in pts)) / 2,
    ))


# ----------------------------------------------------------------------------
# Preset save/load/delete
# ----------------------------------------------------------------------------

def _copy_props(src, dst, fields):
    """Copy each named field from src to dst, skipping fields that don't exist or have bad enum values."""
    for f in fields:
        if not hasattr(src, f) or not hasattr(dst, f):
            continue
        try:
            setattr(dst, f, getattr(src, f))
        except (TypeError, ValueError):
            pass


# ----------------------------------------------------------------------------
# Parametric primitives
# ----------------------------------------------------------------------------
# Blender's Add Mesh primitives are only adjustable in the redo panel, and only
# until the next action. These build the same shapes as a Geometry Nodes group on
# the object, so every parameter stays live and keyframable forever.

PRIM_NG_VERSION = 4

# kind -> (label, node bl_idname or None, icon)
PRIM_KINDS = (
    ('PLANE',     "Plane",      'GeometryNodeMeshGrid',      'MESH_PLANE'),
    ('CUBE',      "Cube",       'GeometryNodeMeshCube',      'MESH_CUBE'),
    ('CIRCLE',    "Circle",     'GeometryNodeMeshCircle',    'MESH_CIRCLE'),
    ('UVSPHERE',  "UV Sphere",  'GeometryNodeMeshUVSphere',  'MESH_UVSPHERE'),
    ('ICOSPHERE', "Ico Sphere", 'GeometryNodeMeshIcoSphere', 'MESH_ICOSPHERE'),
    ('CYLINDER',  "Cylinder",   'GeometryNodeMeshCylinder',  'MESH_CYLINDER'),
    ('CONE',      "Cone",       'GeometryNodeMeshCone',      'MESH_CONE'),
    # There is no GeometryNodeMeshTorus in 5.2 — built from two curve circles.
    ('TORUS',     "Torus",      None,                        'MESH_TORUS'),
)
_PRIM = {k: (label, idname, icon) for k, label, idname, icon in PRIM_KINDS}

_SOCKET_FOR = {
    'VALUE': 'NodeSocketFloat', 'INT': 'NodeSocketInt',
    'VECTOR': 'NodeSocketVector', 'BOOLEAN': 'NodeSocketBool',
}

# ----------------------------------------------------------------------------
# Parameter names — Cinema 4D's vocabulary
# ----------------------------------------------------------------------------
# (node socket, panel name), in the order the panel should show them.
#
# ⚠ C4D'S WORDS, NOT BLENDER'S, because that is the language this addon's user thinks in and
# the whole point of Werkbench is the C4D setup gestures. The wins are real rather than
# cosmetic: `Depth` becomes **Height** (the ordinary word for the dimension it is), and the
# torus's `Major`/`Minor` become **Ring**/**Pipe** — naming the two circles you can see
# instead of ranking them.
#
# ⚠ THE ORDER IS C4D'S TOO: size first, resolution after. Blender's Cylinder node lists
# Vertices, Side Segments, Fill Segments, Radius, Depth — the counts before the dimensions,
# which is the reverse of what you reach for. Listing the sockets explicitly here rather than
# walking `node.inputs` is what buys that.
#
# ⚠ "Seg" NOT "Segments", because the label column of a nested panel truncates around eleven
# characters and `Rotation Segments` is seventeen. Adopting C4D's names ALONE would have made
# the truncation worse, not better — the abbreviation is what makes them fit.
#
# ⚠ SOCKET NAMES ARE THE GROUP'S INTERFACE. Renaming them means a new `PRIM_NG_VERSION`;
# primitives already in a file keep their old group and old names until re-added. PRIM_HANDLES
# keys on these names, so the two tables move together — a handle whose socket is missing is
# silently skipped, which the gizmo suite catches as a wrong handle count.
PRIM_SOCKETS = {
    # C4D Plane: Width / Height, and their segment counts
    'PLANE':     (("Size X", "Width"), ("Size Y", "Height"),
                  ("Vertices X", "Width Seg"), ("Vertices Y", "Height Seg")),
    # ⚠ "Size" is the VECTOR socket; the splitter turns it into Size X/Y/Z
    'CUBE':      (("Size", "Size"),
                  ("Vertices X", "Seg X"), ("Vertices Y", "Seg Y"),
                  ("Vertices Z", "Seg Z")),
    # C4D Disc. Its "Outer Radius" implies an inner one, which this has not got.
    'CIRCLE':    (("Radius", "Radius"), ("Vertices", "Rotation Seg")),
    'UVSPHERE':  (("Radius", "Radius"), ("Segments", "Rotation Seg"), ("Rings", "Rings")),
    'ICOSPHERE': (("Radius", "Radius"), ("Subdivisions", "Subdiv")),
    'CYLINDER':  (("Radius", "Radius"), ("Depth", "Height"),
                  ("Vertices", "Rotation Seg"), ("Side Segments", "Height Seg"),
                  ("Fill Segments", "Cap Seg")),
    # ⚠ BOTTOM BEFORE TOP, as C4D lists them and as the shape reads from the ground up.
    'CONE':      (("Radius Bottom", "Bottom Radius"), ("Radius Top", "Top Radius"),
                  ("Depth", "Height"), ("Vertices", "Rotation Seg"),
                  ("Side Segments", "Height Seg"), ("Fill Segments", "Cap Seg")),
}


# ----------------------------------------------------------------------------
# Viewport handles
# ----------------------------------------------------------------------------
# One entry per draggable dimension:
#
#     (socket, factor, axis, colour, {axis: (socket, factor)} offsets)
#
# The handle drives `socket`, sits `factor * socket` along `axis`, and is shifted
# by the offsets on any axis. Everything else follows from that.
#
# ⚠ THE FACTOR IS WHAT KEEPS THE HANDLE UNDER THE CURSOR. A gizmo moves its value
# one-for-one with the drag, so the handle only tracks your mouse if its POSITION
# moves at that same rate. "Size X" is the FULL width, so a handle on the face at
# half the width must drive half the width — the 0.5 goes on both the position and
# the Value, and Blender inverts the multiply on the way back to make Size X move
# twice as far. Radius needs no factor: the rim IS the value.
# ⚠ THIS IS WHY MOGRAPHWERKS' RULE ("Value comes straight from the group input") is
# a special case rather than a law. The manual is explicit that gizmos propagate
# back through math nodes — "Multiply or divide nodes can be used if the values
# should change at different rates" — so a scaled handle is supported, and it is
# what lets the handle live ON the surface it controls instead of floating off it.
PRIM_HANDLES = {
    'PLANE':     (("Width", 0.5, 0, 'X', {}),
                  ("Height", 0.5, 1, 'Y', {})),
    # ⚠ THE CUBE'S SIZE IS SPLIT INTO THREE FLOATS FOR THIS. A linear gizmo drives a
    # FLOAT and cannot drive one lane of a vector — the same thing that forced the
    # Linear cloner's Offset apart in Mographwerks.
    'CUBE':      (("Size X", 0.5, 0, 'X', {}),
                  ("Size Y", 0.5, 1, 'Y', {}),
                  ("Size Z", 0.5, 2, 'Z', {})),
    'CIRCLE':    (("Radius", 1.0, 0, 'X', {}),),
    'UVSPHERE':  (("Radius", 1.0, 0, 'X', {}),),
    'ICOSPHERE': (("Radius", 1.0, 0, 'X', {}),),
    'CYLINDER':  (("Radius", 1.0, 0, 'X', {}),
                  ("Height", 0.5, 2, 'Z', {})),
    # ⚠⚠ THE CONE IS NOT CENTRED AND THE CYLINDER IS. Measured: a default cone spans
    # z 0 to Depth, a cylinder -Depth/2 to +Depth/2. So the cone's base sits at z=0 and
    # its Depth handle rides the top at the FULL value, where the cylinder's takes the
    # half. Assuming the two were symmetrical put all three cone handles in the wrong
    # place, and only measuring against the real mesh caught it.
    # ⚠ NO HANDLE FOR RADIUS TOP, deliberately: it is 0 by default, which would park it
    # on the axis exactly under the Depth handle — two handles at one point. It is a
    # frustum switch more than a size tweak, so it stays a modifier field.
    'CONE':      (("Bottom Radius", 1.0, 0, 'X', {}),
                  ("Height", 1.0, 2, 'Z', {})),
    # ⚠ THE MINOR HANDLE RIDES THE TOP OF THE TUBE, not its outer equator. On the
    # equator both handles were red, on the same axis, on the same line, a minor
    # radius apart — Rob: "two red handles overlapping". Straight up from the tube's
    # centreline it gets its own axis, its own colour, and reads as "thicken this".
    # ⚠ BLUE BECAUSE IT DRAGS ALONG Z, not merely to be a different colour. A blue
    # handle that moved along X would contradict Blender's own axis colours, which is
    # a worse confusion than the one it fixes.
    # ⚠ It still moves one-for-one — z is exactly the minor radius — and it rides
    # along the major radius as that changes underneath it.
    'TORUS':     (("Ring Radius", 1.0, 0, 'X', {}),
                  ("Pipe Radius", 1.0, 2, 'Z', {0: ("Ring Radius", 1.0)})),
}


def _prim_handle(ng, out_for, spec, y):
    """Build one draggable handle. Returns its Transform output, or None."""
    name, factor, axis, colour, offsets = spec
    src = out_for.get(name)
    if src is None:
        return None

    def scaled(sock, f, yy):
        if f == 1.0:
            return sock
        m = ng.nodes.new('ShaderNodeMath'); m.location = (-620.0, yy)
        m.operation = 'MULTIPLY'
        m.inputs[1].default_value = f
        ng.links.new(sock, m.inputs[0])
        return m.outputs[0]

    val = scaled(src, factor, y)
    terms = {}
    for ax, (oname, ofac) in offsets.items():
        o = out_for.get(oname)
        if o is not None:
            terms[ax] = scaled(o, ofac, y - 40.0 - 40.0 * ax)
    if axis in terms:
        add = ng.nodes.new('ShaderNodeMath'); add.location = (-460.0, y)
        add.operation = 'ADD'
        ng.links.new(val, add.inputs[0])
        ng.links.new(terms[axis], add.inputs[1])
        terms[axis] = add.outputs[0]
    else:
        terms[axis] = val

    pos = ng.nodes.new('ShaderNodeCombineXYZ'); pos.location = (-300.0, y - 40.0)
    for ax, sock in terms.items():
        ng.links.new(sock, pos.inputs[ax])

    gz = ng.nodes.new('GeometryNodeGizmoLinear'); gz.location = (-120.0, y)
    gz.draw_style = 'BOX'
    gz.color_id = colour
    ng.links.new(val, gz.inputs["Value"])
    ng.links.new(pos.outputs[0], gz.inputs["Position"])
    gz.inputs["Direction"].default_value = tuple(
        1.0 if i == axis else 0.0 for i in range(3))
    return gz.outputs["Transform"]


def _prim_group(kind):
    """The node group for one primitive, built on demand and reused by name.

    Versioned like Mographwerks' groups: a group left over from an older build is
    rebuilt rather than silently reused with the wrong sockets.
    """
    label, idname, _icon = _PRIM[kind]
    name = "WB_" + label.replace(" ", "")
    ng = bpy.data.node_groups.get(name)
    if ng is not None and ng.get("wb_version") == PRIM_NG_VERSION:
        return ng
    if ng is not None:
        stale, ng = ng, None
        stale.name = name + ".old"
    ng = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    ng["wb_version"] = PRIM_NG_VERSION

    itf = ng.interface
    itf.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    gin = ng.nodes.new('NodeGroupInput'); gin.location = (-420.0, 0.0)
    gout = ng.nodes.new('NodeGroupOutput'); gout.location = (320.0, 0.0)

    # name -> the group input socket carrying it, for the handles to hang off
    out_for = {}

    if idname is not None:
        node = ng.nodes.new(idname); node.location = (0.0, 0.0)
        idx = 0
        # ⚠ DRIVEN BY PRIM_SOCKETS, NOT BY `node.inputs` ORDER. That is what puts Radius and
        # Height above the segment counts instead of below them, and what lets each socket
        # carry C4D's name rather than Blender's.
        # ⚠ A NAME THAT IS NOT ON THE NODE IS A BUILD ERROR, not something to skip past — a
        # skipped socket is a control that silently vanishes from the panel, and a Blender
        # release that renames a primitive input would do exactly that.
        for node_name, display in PRIM_SOCKETS[kind]:
            sock = node.inputs.get(node_name)
            if sock is None:
                raise KeyError("%s has no input %r (has: %s)"
                               % (idname, node_name, [x.name for x in node.inputs]))
            stype = _SOCKET_FOR.get(sock.type)
            if stype is None:
                continue
            if stype == 'NodeSocketVector':
                # ⚠ ONE FLOAT PER AXIS, not a vector: a linear gizmo drives a float and
                # cannot drive one lane of a vector, so the Cube's Size has to come apart
                # before a handle can reach it. It reads better in the modifier too — three
                # named fields instead of one three-up row.
                comb = ng.nodes.new('ShaderNodeCombineXYZ')
                comb.location = (-200.0, -60.0)
                for ax, axis in enumerate("XYZ"):
                    nm = "%s %s" % (display, axis)
                    iface = itf.new_socket(nm, in_out='INPUT',
                                           socket_type='NodeSocketFloat')
                    try:
                        iface.default_value = sock.default_value[ax]
                    except Exception:
                        pass
                    ng.links.new(gin.outputs[idx], comb.inputs[ax])
                    out_for[nm] = gin.outputs[idx]
                    idx += 1
                ng.links.new(comb.outputs[0], sock)
                continue
            iface = itf.new_socket(display, in_out='INPUT', socket_type=stype)
            try:
                iface.default_value = sock.default_value
            except Exception:
                pass
            ng.links.new(gin.outputs[idx], sock)
            out_for[display] = gin.outputs[idx]
            idx += 1
        mesh = node.outputs["Mesh"]
    else:
        # Torus: sweep a small circle along a large one.
        major = ng.nodes.new('GeometryNodeCurvePrimitiveCircle'); major.location = (-220.0, 120.0)
        minor = ng.nodes.new('GeometryNodeCurvePrimitiveCircle'); minor.location = (-220.0, -120.0)
        sweep = ng.nodes.new('GeometryNodeCurveToMesh'); sweep.location = (60.0, 0.0)
        # ⚠ C4D's words: the big circle is the RING, the tube swept along it is the PIPE.
        specs = (("Ring Radius", 'NodeSocketFloat', 1.0, major, "Radius"),
                 ("Pipe Radius", 'NodeSocketFloat', 0.25, minor, "Radius"),
                 ("Ring Seg", 'NodeSocketInt', 48, major, "Resolution"),
                 ("Pipe Seg", 'NodeSocketInt', 12, minor, "Resolution"))
        for i, (nm, stype, default, node, sock_name) in enumerate(specs):
            iface = itf.new_socket(nm, in_out='INPUT', socket_type=stype)
            try:
                iface.default_value = default
                iface.min_value = 3 if stype == 'NodeSocketInt' else 0.0
            except Exception:
                pass
            ng.links.new(gin.outputs[i], node.inputs[sock_name])
            out_for[nm] = gin.outputs[i]
        ng.links.new(major.outputs["Curve"], sweep.inputs["Curve"])
        ng.links.new(minor.outputs["Curve"], sweep.inputs["Profile Curve"])
        mesh = sweep.outputs["Mesh"]

    # ⚠ THE HANDLES MUST BE JOINED INTO THE GEOMETRY, not left dangling. An unjoined
    # gizmo is never evaluated and NO HANDLE APPEARS AT ALL — silent, because the graph
    # builds and the shape is still correct. Mographwerks lost a round to this one.
    handles = [t for t in
               (_prim_handle(ng, out_for, spec, -220.0 - 200.0 * i)
                for i, spec in enumerate(PRIM_HANDLES.get(kind, ())))
               if t is not None]
    if handles:
        join = ng.nodes.new('GeometryNodeJoinGeometry'); join.location = (140.0, 0.0)
        ng.links.new(mesh, join.inputs[0])
        for t in handles:
            ng.links.new(t, join.inputs[0])
        mesh = join.outputs[0]
    ng.links.new(mesh, gout.inputs[0])
    return ng


class WB_OT_add_primitive(bpy.types.Operator):
    bl_idname = "werkbench.add_primitive"
    bl_label = "Add Parametric Primitive"
    bl_description = ("Add a primitive whose parameters stay editable after creation, "
                      "unlike Blender's own Add Mesh")
    bl_options = {'REGISTER', 'UNDO'}

    kind: bpy.props.EnumProperty(
        name="Kind", items=[(k, label, label) for k, label, _i, _ic in PRIM_KINDS])

    def execute(self, context):
        label = _PRIM[self.kind][0]
        ng = _prim_group(self.kind)
        obj = bpy.data.objects.new(label, bpy.data.meshes.new(label))
        context.collection.objects.link(obj)
        obj.location = context.scene.cursor.location
        obj.modifiers.new(label, 'NODES').node_group = ng
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        self.report({'INFO'}, "Added %s - parameters stay editable in the modifier" % label)
        return {'FINISHED'}


def _strip_dupe_suffix(name):
    """"Chair.001" -> "Chair". Blender's numeric duplicate suffix carries no meaning
    worth propagating into a group name."""
    parts = name.rsplit(".", 1)
    if len(parts) == 2 and len(parts[1]) == 3 and parts[1].isdigit():
        return parts[0]
    return name


def _group_box_mesh(name, lo, hi):
    """Edges-only box for a group handle. No faces, so you can only ever select it
    by its wires — clicking through the middle picks whatever is actually there."""
    me = bpy.data.meshes.new(name)
    verts = [(x, y, z) for z in (lo.z, hi.z) for y in (lo.y, hi.y) for x in (lo.x, hi.x)]
    edges = [(0, 1), (2, 3), (4, 5), (6, 7),
             (0, 2), (1, 3), (4, 6), (5, 7),
             (0, 4), (1, 5), (2, 6), (3, 7)]
    me.from_pydata(verts, edges, [])
    me.update()
    return me


def _active_group(context):
    """The group handle in play: the active object if it is one, else its parent."""
    o = context.active_object
    if o is None:
        return None
    if o.get("wb_group"):
        return o
    if o.parent is not None and o.parent.get("wb_group"):
        return o.parent
    return None


class WB_OT_ungroup(bpy.types.Operator):
    bl_idname = "werkbench.ungroup"
    bl_label = "Ungroup"
    bl_description = ("Release a group: children keep their place, the handle and its "
                      "collection are removed")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _active_group(context) is not None

    def execute(self, context):
        grp = _active_group(context)
        kids = list(grp.children)
        coll = next((c for c in grp.users_collection), None)

        # where the contents go back to: whatever holds the group's collection
        host = context.scene.collection
        if coll is not None:
            for cand in list(bpy.data.collections) + [context.scene.collection]:
                if coll.name in [ch.name for ch in cand.children]:
                    host = cand
                    break

        for o in kids:
            world = o.matrix_world.copy()
            o.parent = None
            o.matrix_world = world        # unparent without moving anything
            for c in list(o.users_collection):
                c.objects.unlink(o)
            if o.name not in host.objects:
                host.objects.link(o)

        name = grp.name
        me = grp.data
        bpy.data.objects.remove(grp, do_unlink=True)
        if me is not None and me.users == 0:
            bpy.data.meshes.remove(me)
        if coll is not None and not coll.objects and not coll.children:
            bpy.data.collections.remove(coll)

        for o in context.selected_objects:
            o.select_set(False)
        for o in kids:
            o.select_set(True)
        if kids:
            context.view_layer.objects.active = kids[0]
        self.report({'INFO'}, "Ungrouped %d object(s) from %s" % (len(kids), name))
        return {'FINISHED'}


class WB_OT_group_to_empty(bpy.types.Operator):
    bl_idname = "werkbench.group_to_empty"
    bl_label = "Group to Empty"
    bl_description = ("Parent the selection to a new Empty and gather both into a new "
                      "collection, named after the active object. C4D's null grouping")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and len(context.selected_objects) > 0

    def execute(self, context):
        act = context.active_object
        objs = list(context.selected_objects)
        if act not in objs:
            objs.append(act)
        # never swallow an existing group empty's own children twice
        objs = [o for o in objs if o.parent not in objs]

        name = _strip_dupe_suffix(act.name) + ".Group"

        # Fit the handle to what it holds. An Empty's CUBE display is a UNIFORM
        # half-extent, so it can only ever be a cube — on a long thin group that is
        # a huge box around nothing. Scaling the Empty non-uniformly would fit, but
        # a non-uniform parent scale SHEARS rotated children, which is worse.
        # So the handle is a wireframe MESH: the box lives in the mesh data, the
        # object transform stays clean (rot 0, scale 1), and nothing shears.
        lo = Vector((1e30, 1e30, 1e30))
        hi = Vector((-1e30, -1e30, -1e30))
        for o in objs:
            b_lo, b_hi = _world_bbox(o)
            for i in range(3):
                lo[i] = min(lo[i], b_lo[i])
                hi[i] = max(hi[i], b_hi[i])
        centre = (lo + hi) * 0.5

        empty = bpy.data.objects.new(name, _group_box_mesh(name, lo - centre, hi - centre))
        empty.display_type = 'WIRE'
        empty.hide_render = True          # a handle, never geometry
        empty.location = centre
        empty["wb_group"] = True          # what Ungroup looks for

        coll = bpy.data.collections.new(name)
        # nest the new collection where the active object already lived, so grouping
        # does not yank things out to the scene root
        host = act.users_collection[0] if act.users_collection else context.scene.collection
        host.children.link(coll)
        coll.objects.link(empty)

        # NOT empty.matrix_world.inverted(): matrix_world is still identity here
        # because the depsgraph has not evaluated the location just set. The handle
        # is a pure translation, so build the inverse directly and exactly.
        inv = Matrix.Translation(-centre)
        for o in objs:
            for c in list(o.users_collection):
                c.objects.unlink(o)
            coll.objects.link(o)
            o.parent = empty
            o.matrix_parent_inverse = inv

        # Making the handle active is a convenience, not the job. The view layer does
        # not always re-sync collection membership inside an operator, and select_set()
        # on an object it has not caught up with RAISES — which would roll back a
        # perfectly good group. So never let it fail the operation.
        context.view_layer.update()
        try:
            for o in context.selected_objects:
                o.select_set(False)
            empty.select_set(True)
            context.view_layer.objects.active = empty
        except RuntimeError:
            pass
        self.report({'INFO'}, "Grouped %d object(s) into %s" % (len(objs), name))
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# Panels
# ----------------------------------------------------------------------------

def _parametric_mod(obj):
    """The Werkbench primitive modifier on obj, if it has one. Identified by the
    node group's wb_version stamp, not by name, so a renamed modifier still works."""
    if obj is None:
        return None
    for m in obj.modifiers:
        if (m.type == 'NODES' and m.node_group is not None
                and m.node_group.get("wb_version") is not None):
            return m
    return None


_ICON_FOR_GROUP = {"WB_" + label.replace(" ", ""): icon
                   for _k, label, _i, icon in PRIM_KINDS}


def _prim_icon(mod):
    """The primitive's own icon — a cylinder header shows a cylinder, not a generic modifier.

    ⚠ MATCHED ON THE STRIPPED GROUP NAME. A group left by an older build is renamed
    `WB_Cylinder.old`, and a linked-in duplicate becomes `WB_Cylinder.001`; neither should
    cost the header its icon.
    """
    ng = getattr(mod, "node_group", None)
    if ng is None:
        return 'MODIFIER'
    base = ng.name[:-4] if ng.name.endswith(".old") else ng.name
    return _ICON_FOR_GROUP.get(_strip_dupe_suffix(base), 'MODIFIER')


def _draw_gn_inputs(layout, mod):
    """Draw a GN modifier's inputs as native, keyframable controls. Blender 5.2
    addresses them by socket IDENTIFIER, not name."""
    for sock in mod.node_group.interface.items_tree:
        if getattr(sock, "in_out", "") != 'INPUT':
            continue
        if sock.bl_socket_idname == 'NodeSocketGeometry':
            continue
        try:
            layout.prop(getattr(mod.properties.inputs, sock.identifier),
                        "value", text=sock.name)
        except (AttributeError, TypeError):
            pass


def _prefs(context=None):
    """Addon preferences, or None if the addon is mid-(un)register."""
    context = context or bpy.context
    try:
        return context.preferences.addons[__name__].preferences
    except (KeyError, AttributeError):
        return None


def _panel_enabled(cls):
    """A panel draws unless its preference toggle says otherwise. Defaults to ON so a
    missing pref never hides a panel."""
    p = _prefs()
    if p is None or getattr(cls, "pref_toggle", None) is None:
        return True
    return getattr(p, cls.pref_toggle, True)


class _ATChild:
    """House style: every sub-panel carries a header icon via panel_icon."""
    panel_icon = 'NONE'
    pref_toggle = None

    @classmethod
    def poll(cls, context):
        return _panel_enabled(cls)

    def draw_header(self, context):
        self.layout.label(text="", icon=self.panel_icon)


def _split(layout, align=False, decorate=False):
    """A column in Blender's native property-split layout: right-aligned labels
    in a fixed left column, controls aligned in the right column, decorators off
    — matches the stock panels (and the Sketchy Lines pass). Operator rows,
    expand-enums and custom pickers stay OUT of these so they read normally.

    ⚠ `decorate=True` turns on Blender's own keyframe diamonds — the same control the
    Properties editor draws, not a lookalike. It stays OFF by default because a decorator
    on a value that cannot be animated draws a dead column of dots."""
    c = layout.column(align=align)
    c.use_property_split = True
    c.use_property_decorate = decorate
    return c


def _toggle(layout, data, prop, text):
    """A standalone on/off checkbox drawn left-justified (no property-split), so
    it hugs its label instead of floating out in the split's control column."""
    row = layout.row()
    row.use_property_split = False
    row.use_property_decorate = False
    row.prop(data, prop, text=text)


def _axis_row(layout, axis):
    """One labelled row of a button grid: the axis letter in a narrow fixed column
    so the buttons below it line up, then the buttons filling the rest."""
    split = layout.split(factor=0.12, align=True)
    lbl = split.row()
    lbl.alignment = 'RIGHT'
    lbl.label(text=axis)
    return split.row(align=True)


class WB_PT_main(bpy.types.Panel):
    bl_label = "Werkbench"
    bl_idname = "WB_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY

    # ⚠ NO ICON ON THE MAIN HEADER — suite rule, decided 2026-08-05, and applied to
    # Mographwerks, Motionwerks and Sketchwerks the same day. The old house style was "a brand
    # icon on the parent header"; it drew the addon's own name twice. Sub-panels keep theirs —
    # there an icon labels a department, which is a different job.

    def draw(self, context):
        pass


class WB_PT_origin(_ATChild, bpy.types.Panel):
    bl_label = "Origin"
    bl_parent_id = "WB_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_order = 0
    pref_toggle = 'show_origin'
    panel_icon = 'OBJECT_ORIGIN'

    def draw(self, context):
        layout = self.layout
        p = context.scene.anitools_origin

        row = layout.row(align=True)
        row.operator("werkbench.drop_to_floor", text="Drop to Floor")
        row.operator("werkbench.reset_transform", text="Reset Transform")

        box = layout.box()
        col = box.column(align=True)
        col.row(align=True).prop(p, "mode", expand=True)
        col.separator()

        for axis in ('x', 'y', 'z'):
            row = col.row(align=True)
            row.prop(p, axis, slider=True)
            op = row.operator("werkbench.origin_reset_axis", text="", icon='LOOP_BACK')
            op.axis = axis.upper()

        col.separator()
        row = col.row(align=True)
        row.operator("werkbench.origin_center", text="", icon='PIVOT_BOUNDBOX')
        row.operator("werkbench.origin_reapply", text="Re-apply")


class WB_PT_alignwerks(_ATChild, bpy.types.Panel):
    bl_label = "Align"
    bl_parent_id = "WB_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_order = 1
    pref_toggle = 'show_align'
    panel_icon = 'SNAP_FACE_CENTER'

    def draw(self, context):
        layout = self.layout
        p = context.scene.anitools_align
        n = len(_alignable(context))

        _split(layout).prop(p, "relative_to")
        _toggle(layout, p, "use_origins", "Use Origins")

        # Text, not icons: ALIGN_LEFT/RIGHT read as left/right, which is only
        # meaningful on X — on Y and Z the same glyph would mislead.
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Align")
        col.separator()
        col.enabled = n >= 1
        for axis in AXES:
            row = _axis_row(col, axis)
            for mode in ('MIN', 'CENTER', 'MAX'):
                op = row.operator("werkbench.align", text=mode.title())
                op.axis = axis
                op.mode = mode
                op.relative_to = p.relative_to
                op.use_origins = p.use_origins

        box = layout.box()
        col = box.column(align=True)
        col.label(text="Distribute")
        col.separator()
        # Exact spacing only needs a pair; spreading between the outermost needs three.
        col.enabled = n >= 3 or (p.spacing > 0.0 and n >= 2)
        for axis in AXES:
            row = _axis_row(col, axis)
            for mode in ('CENTERS', 'GAPS'):
                op = row.operator("werkbench.distribute", text=mode.title())
                op.axis = axis
                op.mode = mode
                op.spacing = p.spacing
        _split(box).prop(p, "spacing")

        if n < 3:
            layout.label(text="Distribute needs 3 objects, or an exact Spacing",
                         icon='INFO')


class WB_PT_dimensions(_ATChild, bpy.types.Panel):
    bl_label = "Transform"
    bl_parent_id = "WB_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_order = 3
    pref_toggle = 'show_transform'
    panel_icon = 'OBJECT_DATA'

    @classmethod
    def poll(cls, context):
        # context.object, NOT context.active_object: hiding an object deselects it,
        # and active_object can drop out from under the panel — which would take the
        # Show In toggles away with it, leaving no way to unhide from here.
        return _panel_enabled(cls) and context.object is not None

    def draw(self, context):
        obj = context.object
        layout = self.layout

        # ⚠ DECORATORS ON, and these are Blender's OWN keyframe diamonds rather than
        # anything of ours — same click, same shortcuts, same colours for keyed, animated
        # and driven. Everything drawn in this column is animatable, so none of them is dead.
        col = _split(layout, align=True, decorate=True)
        col.prop(obj, "location")
        col.separator()
        col.prop(obj, "rotation_euler", text="Rotation")
        col.separator()
        col.prop(obj, "scale")

        # ⚠ A WERKBENCH PRIMITIVE'S REAL CONTROLS ARE ITS NODE INPUTS, and they now have
        # their own panel above this one. Dimensions stays here as a READOUT — greyed, not
        # gone: editing it would write a scale that fights the parameters, but seeing the
        # size the parameters produced is exactly what you want next to them.
        mod = _parametric_mod(obj)
        layout.separator()
        # ⚠ DECORATE ON FOR THE SPACING, NOT FOR A DIAMOND. `dimensions` is DERIVED from
        # scale x bounding box, so RNA marks it non-animatable and `keyframe_insert` raises —
        # Blender draws a blank in the decorator column rather than a dead key. Turning the
        # column on anyway is what makes these fields end at the same x as Location and Scale
        # instead of running wider than everything above them.
        dims = _split(layout, align=True, decorate=True)
        dims.enabled = mod is None
        dims.prop(obj, "dimensions")
        if mod is not None:
            note = layout.row()
            note.enabled = False
            note.label(text="Size is driven by %s above" % mod.name, icon='INFO')

        # ⚠ THE WARNING STAYS IN THE PARENT, not in the Visibility sub-panel it points at.
        # A collapsed sub-panel would hide the one message telling you why the object is not
        # on screen — the alert has to survive the panel being shut.
        if obj.hide_viewport or obj.hide_render:
            layout.separator()
            warn = layout.row()
            warn.alert = True
            warn.label(text="Hidden — see Visibility below", icon='HIDE_ON')


class WB_PT_visibility(_ATChild, bpy.types.Panel):
    """Where the object shows up, nested under Transform.

    ⚠ "VISIBILITY", NOT "SHOW IN" — it is what Blender calls this exact pair of properties in
    Object Properties, and matching the host's vocabulary costs nothing and saves a lookup.
    "Show In" survives as the sense of the two buttons rather than as a heading.
    ⚠ NO PREF TOGGLE OF ITS OWN. A hidden parent hides its children anyway, so a fifth
    checkbox in Preferences would only be a way to lose these two controls.
    """
    bl_label = "Visibility"
    bl_parent_id = "WB_PT_dimensions"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_order = 0
    panel_icon = 'HIDE_OFF'

    @classmethod
    def poll(cls, context):
        return _panel_enabled(cls) and context.object is not None

    def draw(self, context):
        obj = context.object
        # ⚠ STACKED, NOT SIDE BY SIDE. Two toggles on one row can only take one pair of
        # decorators at the far right, and a diamond that is not beside its own button is a
        # diamond you have to work out. One row each puts every key next to what it keys.
        # ⚠ IN THE PROPERTY-SPLIT COLUMN, so the buttons start at the same x as Location and
        # Scale above them instead of spanning the full width of the panel.
        col = _split(self.layout, align=True)
        for prop, text in (("hide_viewport", "Viewports"), ("hide_render", "Renders")):
            row = col.row(align=True)
            row.prop(obj, prop, text=text, invert_checkbox=True, toggle=True)
            # ⚠ HAND-PLACED DECORATOR, because this row is not a property-split column — the
            # automatic ones only appear inside one. Both toggles are animatable, which is
            # how you make something appear or vanish on a frame.
            # ⚠ IT DECORATES THE PROPERTY, NOT THE INVERTED CHECKBOX: `invert_checkbox`
            # flips what the box DRAWS, so a keyed "hidden" reads as an unticked Viewports
            # box with a filled diamond beside it. Correct — the diamond keys `hide_viewport`.
            row.prop_decorator(obj, prop)


class WB_PT_create(_ATChild, bpy.types.Panel):
    bl_label = "Create"
    bl_parent_id = "WB_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_order = 2
    pref_toggle = 'show_create'
    panel_icon = 'MESH_DATA'

    def draw(self, context):
        # ⚠ GROUP/UNGROUP ON TOP so the primitive grid sits DIRECTLY above the parameters
        # panel nested underneath it. Putting them at the bottom (v2.14.0) drove a wedge
        # between the button that makes a shape and the controls that shape it.
        row = self.layout.row(align=True)
        row.operator("werkbench.group_to_empty", text="Group", icon='OUTLINER_OB_EMPTY')
        row.operator("werkbench.ungroup", text="Ungroup", icon='X')
        self.layout.separator()
        grid = self.layout.grid_flow(row_major=True, columns=2, align=True)
        for kind, label, _idname, icon in PRIM_KINDS:
            grid.operator("werkbench.add_primitive", text=label, icon=icon).kind = kind


class WB_PT_primitive(_ATChild, bpy.types.Panel):
    """The selected primitive's own parameters, nested inside Create.

    ⚠ A CHILD OF CREATE, not a sibling. It is what the buttons directly above it just made,
    and the two belong to one idea; as a sibling it read as a fifth department of the addon.
    ⚠ IT POLLS ON THE OBJECT, so it is simply absent unless an editable primitive is
    selected — no empty box, no greyed panel that looks broken.
    ⚠ NO STATIC TITLE. `bl_label` is empty and the header is drawn per-object, so it says
    "Cylinder" rather than "Primitive". The old in-Transform box named the modifier and the
    move to a panel lost that; a panel that describes what is selected is worth the header
    override.
    """
    bl_label = ""
    bl_parent_id = "WB_PT_create"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_order = 0
    pref_toggle = 'show_primitive'

    @classmethod
    def poll(cls, context):
        return _panel_enabled(cls) and _parametric_mod(context.object) is not None

    def draw_header(self, context):
        mod = _parametric_mod(context.object)
        if mod is None:
            return
        self.layout.label(text=mod.name, icon=_prim_icon(mod))

    def draw(self, context):
        mod = _parametric_mod(context.object)
        if mod is None:
            return
        # ⚠ DECORATORS HERE TOO: "every parameter stays keyframable" is the whole reason
        # these are node inputs rather than a baked mesh, and until now there was nothing in
        # the panel that said so.
        _draw_gn_inputs(_split(self.layout, align=True, decorate=True), mod)
        hint = self.layout.row()
        hint.enabled = False
        hint.label(text="Drag the viewport handles to size it", icon='INFO')


def _draw_axis_picker(layout, prop_holder, prop_name):
    col = layout.column(align=True)
    row = col.row(align=True)
    for a in ('X', 'Y', 'Z'):
        row.prop_enum(prop_holder, prop_name, a)
    row = col.row(align=True)
    for a in ('-X', '-Y', '-Z'):
        row.prop_enum(prop_holder, prop_name, a)


# ----------------------------------------------------------------------------
# Preferences
# ----------------------------------------------------------------------------

def _find_user_keyconfig(key):
    if key not in addon_keymaps:
        return None
    km, kmi = addon_keymaps[key]
    user_km = bpy.context.window_manager.keyconfigs.user.keymaps.get(km.name)
    if not user_km:
        return None
    for item in user_km.keymap_items:
        if item.idname == kmi.idname:
            return item
    return None


def _update_keymaps(self, context):
    """Disable rather than unregister: kmi.active is reversible and cannot lose the
    user's own rebinding the way a re-register would."""
    for km, kmi in addon_keymaps.values():
        try:
            kmi.active = self.use_keymaps
        except (RuntimeError, ReferenceError):
            pass


class ATPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    show_origin: bpy.props.BoolProperty(name="Origin", default=True)
    show_align: bpy.props.BoolProperty(name="Align", default=True)
    show_transform: bpy.props.BoolProperty(name="Transform", default=True)
    show_create: bpy.props.BoolProperty(name="Create", default=True)
    show_primitive: bpy.props.BoolProperty(name="Primitive", default=True)
    use_keymaps: bpy.props.BoolProperty(
        name="Enable Shortcuts", default=True, update=_update_keymaps,
        description="Turn every Werkbench shortcut off in one go, without losing "
                    "any rebinding you have done")

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text="Panels", icon='MENU_PANEL')
        row = box.row(align=True)
        for prop in ("show_origin", "show_align", "show_create",
                     "show_primitive", "show_transform"):
            row.prop(self, prop, toggle=True)

        box = layout.box()
        header = box.row()
        header.label(text="Shortcuts", icon='KEYINGSET')
        header.prop(self, "use_keymaps", text="")

        col = box.column()
        col.enabled = self.use_keymaps
        kc = context.window_manager.keyconfigs.addon
        if kc is None or not addon_keymaps:
            col.label(text="Shortcuts unavailable in this session", icon='INFO')
            return
        try:
            import rna_keymap_ui
        except ImportError:
            # fall back to a read-only display rather than showing nothing
            for km, kmi in addon_keymaps.values():
                r = col.row()
                r.label(text=kmi.idname)
                r.prop(kmi, "type", text="", full_event=True)
            return
        for km, kmi in addon_keymaps.values():
            rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)


# ----------------------------------------------------------------------------
# Registration
# ----------------------------------------------------------------------------

classes = (
    ATOriginProps,
    ATAlignProps,
    WB_OT_origin_reapply,
    WB_OT_origin_center,
    WB_OT_origin_reset_axis,
    WB_OT_drop_to_floor,
    WB_OT_reset_transform,
    WB_OT_align,
    WB_OT_distribute,
    WB_OT_add_primitive,
    WB_OT_group_to_empty,
    WB_OT_ungroup,
    WB_PT_main,
    WB_PT_origin,
    WB_PT_alignwerks,
    WB_PT_create,
    WB_PT_primitive,
    WB_PT_dimensions,
    WB_PT_visibility,
    ATPreferences,
)

# Blender writes bl_* values back onto the Python class during (un)register, so a
# hot reload can leave a STALE bl_category or bl_order that silently overrides what
# this file says — a renamed tab keeps the old category, and zeroed orders make
# sub-panels fall back to alphabetical. Snapshot the intended values now, while the
# classes are freshly built from source, and re-assert them in register().
_PANEL_INTENT = {c.__name__: (PANEL_CATEGORY, c.__dict__.get("bl_order"))
                 for c in classes if issubclass(c, bpy.types.Panel)}


addon_keymaps = {}

KEYMAP_BINDINGS = (
    # (key,             op_id,                       letter, ctrl, shift, alt, oskey, props)
    ('drop_to_floor',   'werkbench.drop_to_floor',   'D', True, True, False, False, None),
    ('reset_transform', 'werkbench.reset_transform', 'T', True, True, False, False, None),
    ('origin_center',   'werkbench.origin_center',   'C', True, True, True,  False, None),
    ('origin_reapply',  'werkbench.origin_reapply',  'A', True, True, True,  False, None),
    # Cmd+G, deliberately overriding collection.create — this IS that gesture, plus
    # the parent Empty and the naming, so the plain version is not worth keeping on
    # the shortcut. Note oskey is Cmd on macOS but the Super key on Windows/Linux.
    ('group_to_empty',  'werkbench.group_to_empty',  'G', False, False, False, True, None),
    # Cmd+Shift+G, over collection.objects_add_active — the mirror of the above.
    ('ungroup',         'werkbench.ungroup',         'G', False, True,  False, True, None),
)


def register():
    for cls in classes:
        intent = _PANEL_INTENT.get(cls.__name__)
        if intent is not None:
            cls.bl_category = intent[0]
            if intent[1] is not None:
                cls.bl_order = intent[1]
        bpy.utils.register_class(cls)

    bpy.types.Scene.anitools_origin = bpy.props.PointerProperty(type=ATOriginProps)
    bpy.types.Scene.anitools_align = bpy.props.PointerProperty(type=ATAlignProps)

    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='Object Mode', space_type='EMPTY')
        for key, op_id, letter, ctrl, shift, alt, oskey, props in KEYMAP_BINDINGS:
            kmi = km.keymap_items.new(op_id, letter, 'PRESS',
                                      ctrl=ctrl, shift=shift, alt=alt, oskey=oskey)
            if props:
                for k, v in props.items():
                    setattr(kmi.properties, k, v)
            addon_keymaps[key] = (km, kmi)


def unregister():
    for km, kmi in addon_keymaps.values():
        try:
            km.keymap_items.remove(kmi)
        except (RuntimeError, ReferenceError):
            pass
    addon_keymaps.clear()


    for attr in ("anitools_origin", "anitools_align",):
        if hasattr(bpy.types.Scene, attr):
            delattr(bpy.types.Scene, attr)

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
