bl_info = {
    "name": "Motionwerks",
    "author": "Vivinel",
    "version": (1, 0, 0),
    "warning": "Beta 17",
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > Motionwerks",
    "description": "Archviz phasing: numbered 'cue' collections triggered on voiceover "
                   "markers. Preset picker with save/revert, In/Out, axis grids, per-cue Timing "
                   "and Spacing, UIList reorder; cues start on their marker. Cue actions: Motion, "
                   "Material Transition and Drives (any Geometry Nodes Progress handle). One tab "
                   "with two modes: Cues, and Camera for shot-based camera moves.",
    "doc_url": "https://www.vivinel.com/",
    "category": "Werks",
}

import math

import bpy
from mathutils import Vector, Matrix, Euler
from mathutils.geometry import interpolate_bezier

FEET_TO_METERS = 0.3048
PANEL_CATEGORY = "Motionwerks"
MASTER = "Motionwerks Cues"


def _tab(context):
    """Which half of the tab is showing.

    ⚠ getattr with a default, not a bare attribute read: register() registers the panel
    CLASSES before it registers Scene.mw_tab, and unregister() drops the property before it
    unregisters the classes. A redraw landing in either window would raise straight out of
    poll(), which is not somewhere an exception can be caught.
    """
    return getattr(context.scene, "mw_tab", 'CUES')


# ---------------------------------------------------------------------------
# Per-cue item (one object in a cue). List position = animate order, and each
# item may override the cue's motion with its own preset.
# ---------------------------------------------------------------------------
class MW_ItemPG(bpy.types.PropertyGroup):
    """One object in a cue. A cue keeps ONE list of objects; these flags say which of
    the cue's actions each object takes part in. Before 1.3.0 every action carried its
    own object list, which meant adding the same object two or three times and left
    Sync unable to find objects that weren't in the cue collection."""
    obj: bpy.props.PointerProperty(type=bpy.types.Object)
    # Per-item preset override: empty = inherit the cue's motion. A name that no longer
    # exists in the library also falls back to the cue's motion.
    preset: bpy.props.StringProperty(default="")
    use_motion: bpy.props.BoolProperty(
        name="Motion", default=True,
        description="This object moves/scales/rotates with the cue's Motion action")
    use_material: bpy.props.BoolProperty(
        name="Material", default=False,
        description="This object takes part in the cue's Material Transition")


# Enum identifiers mirror Motionwerks (AXIS/CURVE/EASING) so preset values copy
# straight across on Sync and the dropdowns match what users author in MW.
_AXIS_ITEMS = [
    ('X', "X", "Along +X"), ('Y', "Y", "Along +Y"), ('Z', "Z", "Along +Z"),
    ('-X', "-X", "Along -X"), ('-Y', "-Y", "Along -Y"), ('-Z', "-Z", "Along -Z"),
]
_CURVE_ITEMS = [
    ('LINEAR', "Linear", "No easing"),
    ('SINE', "Smooth", "Sine ease"),
    ('CUBIC', "Cubic", "Cubic ease — moderate"),
    ('QUAD', "Snap", "Quadratic — fast start"),
    ('BACK', "Overshoot", "Overshoots before settling"),
    ('BOUNCE', "Bounce", "Bounces at landing"),
    ('ELASTIC', "Elastic", "Rubbery overshoot"),
]
_EASING_ITEMS = [
    ('AUTO', "Auto", "Ease Out for In, Ease In for Out"),
    ('EASE_IN', "In", "Slow at start"),
    ('EASE_OUT', "Out", "Slow at end"),
    ('EASE_IN_OUT', "In/Out", "Symmetrical"),
]
_DIRECTION_ITEMS = [('IN', "In", "Build on / arrive"), ('OUT', "Out", "Build off / depart")]


# ---------------------------------------------------------------------------
# A Motionwerks preset — a full PSR motion spec, owned by Motionwerks and applied to
# every object in a cue. Editable in Motionwerks (Presets panel / per-cue override)
# AND importable one-way from Motionwerks; identifiers match MW so values copy.
# ---------------------------------------------------------------------------
class MW_PresetPG(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Name", default="Preset")
    direction: bpy.props.EnumProperty(name="Direction", items=_DIRECTION_ITEMS, default='IN')
    scale_enabled: bpy.props.BoolProperty(name="Scale", default=False)
    scale_uniform: bpy.props.BoolProperty(name="Uniform", default=False)
    scale_axis: bpy.props.EnumProperty(name="Scale Axis", items=_AXIS_ITEMS, default='Z')
    scale_frames: bpy.props.IntProperty(name="Scale Frames", default=15, min=1)
    move_enabled: bpy.props.BoolProperty(name="Move", default=False)
    move_axis: bpy.props.EnumProperty(name="Move Axis", items=_AXIS_ITEMS, default='-Z')
    move_distance_ft: bpy.props.FloatProperty(name="Distance (ft)", default=8.0)
    move_frames: bpy.props.IntProperty(name="Move Frames", default=15, min=1)
    rotation_enabled: bpy.props.BoolProperty(name="Rotate", default=False)
    rotation_axis: bpy.props.EnumProperty(name="Rotate Axis", items=_AXIS_ITEMS, default='Z')
    rotation_angle_deg: bpy.props.FloatProperty(name="Angle", default=360.0)
    rotation_frames: bpy.props.IntProperty(name="Rotate Frames", default=15, min=1)
    rotation_pause: bpy.props.IntProperty(name="Rotate Pause", default=0, min=0)
    visibility_enabled: bpy.props.BoolProperty(name="Visibility Cut", default=False)
    pause: bpy.props.IntProperty(name="Move Pause", default=0, min=0)
    curve: bpy.props.EnumProperty(name="Curve", items=_CURVE_ITEMS, default='SINE')
    easing: bpy.props.EnumProperty(name="Easing", items=_EASING_ITEMS, default='AUTO')


class MW_MaterialPG(bpy.types.PropertyGroup):
    """A cue's Material action: blend A -> B across its own object list, on the cue's beat."""
    enabled: bpy.props.BoolProperty(
        name="Material Transition", default=False,
        description="Blend this cue's material objects from A to B on the cue's marker")
    mat_a: bpy.props.PointerProperty(name="From", type=bpy.types.Material)
    mat_b: bpy.props.PointerProperty(name="To", type=bpy.types.Material)
    b_is_alpha: bpy.props.BoolProperty(
        name="To Transparent", default=False,
        description="Instead of a second material, dissolve into transparency")
    axis: bpy.props.EnumProperty(
        name="Axis", default='X',
        items=[('X', "X", "Sweep along local X"), ('Y', "Y", "Sweep along local Y"),
               ('Z', "Z", "Sweep along local Z")])
    coord_type: bpy.props.EnumProperty(
        name="Coordinates", default='GENERATED',
        items=[('GENERATED', "Generated", "Normalised to each object's bounding box"),
               ('OBJECT', "Object", "Object local space, unnormalised")])
    softness: bpy.props.FloatProperty(name="Softness", default=0.15, min=0.0, max=1.0,
                                      description="0 = hard edge, higher = softer gradient")
    noise_amount: bpy.props.FloatProperty(name="Noise", default=0.3, min=0.0, max=1.0,
                                          description="Breaks up the transition edge")
    noise_scale: bpy.props.FloatProperty(name="Noise Scale", default=8.0, min=0.01, max=1000.0)
    reverse: bpy.props.BoolProperty(name="Reverse", default=False,
                                    description="Play the transition B to A instead")
    per_object: bpy.props.BoolProperty(
        name="Stagger Objects", default=False,
        description="Give each object its own material so they can transition one after "
                    "another. Off = all objects sweep together")
    timing: bpy.props.IntProperty(name="Timing", default=30, min=1, soft_max=240,
                                  description="Frames the transition takes")
    spacing: bpy.props.IntProperty(name="Spacing", default=6, min=0, soft_max=60,
                                   description="Frames between objects (needs Stagger Objects)")
    curve: bpy.props.EnumProperty(name="Curve", items=_CURVE_ITEMS, default='SINE')
    easing: bpy.props.EnumProperty(name="Easing", items=_EASING_ITEMS, default='AUTO')
    items: bpy.props.CollectionProperty(type=MW_ItemPG)
    active_item: bpy.props.IntProperty(default=0, min=0)
    built: bpy.props.PointerProperty(name="Built Material", type=bpy.types.Material)

















class MW_DrivePG(bpy.types.PropertyGroup):
    """One external handle this cue drives.

    A module (Mographwerks cloner, fracture, anything) exposes a single keyframable 0->1
    Progress; the cue keys it on its marker. That is the whole integration surface, which
    is why adding a new module costs this panel one row rather than a new action.
    """
    obj: bpy.props.PointerProperty(name="Target", type=bpy.types.Object)
    # An EMPTY data_path means "find the Progress input" — the original contract, kept as
    # the convenience default. Anything else is driven literally.
    data_path: bpy.props.StringProperty(
        name="Path", default="",
        description="Property to drive, relative to its owning ID. Leave empty to find "
                    "the target's Geometry Nodes Progress input automatically")
    use_data: bpy.props.BoolProperty(
        name="On Object Data", default=False,
        description="Drive a property of the object's DATA (camera lens, depth of field) "
                    "rather than the object itself. Blender cannot key a path that spans "
                    "two ID blocks, so the owner has to be named explicitly")
    array_index: bpy.props.IntProperty(
        name="Index", default=-1, min=-1, soft_max=3,
        description="Component of a vector property. -1 drives every component")
    value_from: bpy.props.FloatProperty(name="From", default=0.0)
    value_to: bpy.props.FloatProperty(name="To", default=1.0)
    timing: bpy.props.IntProperty(name="Timing", default=40, min=1, soft_max=480,
        description="Frames the driven build takes, from this cue's marker")
    delay: bpy.props.IntProperty(name="Delay", default=0, min=0, soft_max=240,
        description="Frames to wait after the marker before this one starts")
    reverse: bpy.props.BoolProperty(name="Reverse", default=False,
        description="Drive 1 -> 0 instead, so it un-builds")
    curve: bpy.props.EnumProperty(name="Curve", items=_CURVE_ITEMS, default='SINE')
    easing: bpy.props.EnumProperty(name="Easing", items=_EASING_ITEMS, default='AUTO')



# ===========================================================================
# ENGINE (vendored from Werkbench, when it was AnimationToolbox v2.2.1)
# ---------------------------------------------------------------------------
# Motionwerks carries its own copy of the anchor + keyframe engine so it has no
# runtime dependency on Motionwerks. The two stay interoperable because they
# share the same anchor marker props ("_animtb_anchor"/"_animtb_target") and
# the same math — an anchor made by either tool is recognized by the other.
# SYNC CONTRACT: if Motionwerks' engine changes, re-vendor this block.
# ===========================================================================
def _iter_fcurves(action):
    """Yield all fcurves from an Action (legacy and slotted Blender 4.4+ actions)."""
    if action is None:
        return
    if hasattr(action, "fcurves"):
        yield from action.fcurves
        return
    for layer in action.layers:
        for strip in layer.strips:
            for cb in strip.channelbags:
                yield from cb.fcurves


def _local_bbox(obj):
    """(min, max) of obj's mesh bbox from actual vertex coords (bypasses stale bound_box)."""
    verts = obj.data.vertices
    if not verts:
        return Vector(), Vector()
    xs = [v.co.x for v in verts]
    ys = [v.co.y for v in verts]
    zs = [v.co.z for v in verts]
    return (Vector((min(xs), min(ys), min(zs))),
            Vector((max(xs), max(ys), max(zs))))


def _resolve_easing(easing, in_like):
    if easing == 'AUTO':
        return 'EASE_OUT' if in_like else 'EASE_IN'
    return easing


def _clear_fcurves(obj, data_path, array_index=None):
    """Remove fcurves on obj matching data_path (optionally a specific array_index)."""
    if not (obj.animation_data and obj.animation_data.action):
        return
    action = obj.animation_data.action

    def matches(fc):
        if fc.data_path != data_path:
            return False
        if array_index is not None and fc.array_index != array_index:
            return False
        return True

    if hasattr(action, "fcurves"):
        for fc in list(action.fcurves):
            if matches(fc):
                action.fcurves.remove(fc)
        return
    for layer in action.layers:
        for strip in layer.strips:
            for cb in strip.channelbags:
                for fc in list(cb.fcurves):
                    if matches(fc):
                        cb.fcurves.remove(fc)


def _apply_curve(obj, data_path, curve, easing, in_like, array_index=None):
    if not (obj.animation_data and obj.animation_data.action):
        return
    resolved = _resolve_easing(easing, in_like)
    has_easing = curve not in {'LINEAR', 'CONSTANT', 'BEZIER'}
    for fc in _iter_fcurves(obj.animation_data.action):
        if fc.data_path != data_path:
            continue
        if array_index is not None and fc.array_index != array_index:
            continue
        for kp in fc.keyframe_points:
            kp.interpolation = curve
            if has_easing:
                kp.easing = resolved


def _is_anchor(obj):
    if obj is None or obj.type != 'EMPTY':
        return False
    return bool(obj.get("_animtb_anchor")) or bool(obj.get("_animtb_pivot"))


def _resolve_anchor_target(empty):
    """Find the mesh an anchor Empty is driving."""
    name = empty.get("_animtb_target")
    if name:
        t = bpy.data.objects.get(name)
        if t and t.parent == empty:
            return t
    for c in empty.children:
        if c.type == 'MESH':
            return c
    return None


def _find_existing_anchor(target):
    for suffix in ("_anchor", "_pivot"):
        candidate = bpy.data.objects.get(f"{target.name}{suffix}")
        if _is_anchor(candidate) and _resolve_anchor_target(candidate) == target:
            return candidate
    return None


def _compute_anchor_world(target, axis, direction, uniform=False):
    bb_min, bb_max = _local_bbox(target)
    anchor_local = (bb_min + bb_max) / 2
    if uniform:
        return target.matrix_world @ anchor_local
    axis_idx = 'XYZ'.index(axis.lstrip('-'))
    axis_sign = -1 if axis.startswith('-') else 1
    if axis_idx != 2:
        anchor_local.z = bb_min.z
    if direction == 'IN':
        anchor_local[axis_idx] = bb_max[axis_idx] if axis_sign > 0 else bb_min[axis_idx]
    else:
        anchor_local[axis_idx] = bb_min[axis_idx] if axis_sign > 0 else bb_max[axis_idx]
    return target.matrix_world @ anchor_local


def _reset_anchor_to_rest(anchor):
    """Restore anchor's basis to its stored rest pose (or identity scale if none stored)."""
    if anchor.animation_data:
        anchor.animation_data.action = None
    anchor.scale = (1.0, 1.0, 1.0)
    rest = anchor.get("_animtb_rest_location")
    if rest:
        anchor.location = (rest[0], rest[1], rest[2])


def _ensure_anchor_empty(context, target, axis, direction, uniform=False):
    """Create or recreate an anchor Empty for target (inserted between target and its
    parent, so reference-point parenting is preserved). Returns the Empty."""
    existing = _find_existing_anchor(target)

    if existing is not None:
        _reset_anchor_to_rest(existing)
        context.view_layer.update()
        grandparent = existing.parent
        target_world = target.matrix_world.copy()
        target.parent = grandparent
        target.matrix_world = target_world
        bpy.data.objects.remove(existing, do_unlink=True)

    anchor_world = _compute_anchor_world(target, axis, direction, uniform=uniform)

    empty_name = f"{target.name}_anchor"
    empty = bpy.data.objects.new(empty_name, None)
    empty.empty_display_type = 'ARROWS'
    empty.empty_display_size = 0.5
    cols = list(target.users_collection)
    (cols[0] if cols else context.scene.collection).objects.link(empty)

    _, rot, _ = target.matrix_world.decompose()
    empty.matrix_world = Matrix.Translation(anchor_world) @ rot.to_matrix().to_4x4()

    original_parent = target.parent
    if original_parent:
        e_world = empty.matrix_world.copy()
        empty.parent = original_parent
        empty.matrix_world = e_world

    t_world = target.matrix_world.copy()
    target.parent = empty
    target.matrix_world = t_world

    empty["_animtb_rest_location"] = list(empty.location)
    return empty


def _set_scale_keyframes(anchor, axis, direction, duration, frame_start, curve, easing, uniform=False):
    f_end = frame_start + duration
    if uniform:
        if direction == 'IN':
            anchor.scale = (0.0, 0.0, 0.0); anchor.keyframe_insert("scale", frame=frame_start)
            anchor.scale = (1.0, 1.0, 1.0); anchor.keyframe_insert("scale", frame=f_end)
        else:
            anchor.scale = (1.0, 1.0, 1.0); anchor.keyframe_insert("scale", frame=frame_start)
            anchor.scale = (0.0, 0.0, 0.0); anchor.keyframe_insert("scale", frame=f_end)
    else:
        axis_idx = 'XYZ'.index(axis.lstrip('-'))
        middle = [1.0, 1.0, 1.0]
        middle[axis_idx] = 0.0
        if direction == 'IN':
            anchor.scale = (0.0, 0.0, 0.0); anchor.keyframe_insert("scale", frame=frame_start)
            anchor.scale = middle;          anchor.keyframe_insert("scale", frame=frame_start + 1)
            anchor.scale = (1.0, 1.0, 1.0); anchor.keyframe_insert("scale", frame=f_end)
        else:
            anchor.scale = (1.0, 1.0, 1.0); anchor.keyframe_insert("scale", frame=frame_start)
            anchor.scale = middle;          anchor.keyframe_insert("scale", frame=f_end - 1)
            anchor.scale = (0.0, 0.0, 0.0); anchor.keyframe_insert("scale", frame=f_end)
    _apply_curve(anchor, "scale", curve, easing, in_like=(direction == 'IN'))


def _set_move_keyframes(obj, axis, direction, distance_ft, duration, frame_start, curve, easing):
    """IN arrives at obj's current location from `offset` away; OUT departs from current to `offset`."""
    axis_idx = 'XYZ'.index(axis.lstrip('-'))
    axis_sign = -1 if axis.startswith('-') else 1
    offset = axis_sign * abs(distance_ft) * FEET_TO_METERS

    rest = obj.location[axis_idx]
    if direction == 'IN':
        start, end = rest + offset, rest
    else:
        start, end = rest, rest + offset

    f_end = frame_start + duration
    obj.location[axis_idx] = start
    obj.keyframe_insert("location", index=axis_idx, frame=frame_start)
    obj.location[axis_idx] = end
    obj.keyframe_insert("location", index=axis_idx, frame=f_end)

    _apply_curve(obj, "location", curve, easing,
                 in_like=(direction == 'IN'), array_index=axis_idx)


def _set_rotation_keyframes(obj, axis, direction, angle_deg, duration, frame_start, curve, easing):
    """IN arrives at obj's current rotation from `+angle` offset; OUT departs to `+angle` offset."""
    import math
    axis_idx = 'XYZ'.index(axis.lstrip('-'))
    axis_sign = -1 if axis.startswith('-') else 1
    angle_rad = math.radians(angle_deg) * axis_sign

    rest = obj.rotation_euler[axis_idx]
    if direction == 'IN':
        start, end = rest + angle_rad, rest
    else:
        start, end = rest, rest + angle_rad

    f_end = frame_start + duration
    obj.rotation_euler[axis_idx] = start
    obj.keyframe_insert("rotation_euler", index=axis_idx, frame=frame_start)
    obj.rotation_euler[axis_idx] = end
    obj.keyframe_insert("rotation_euler", index=axis_idx, frame=f_end)

    _apply_curve(obj, "rotation_euler", curve, easing,
                 in_like=(direction == 'IN'), array_index=axis_idx)


def _set_visibility_keyframes(obj, direction, frame_start, frame_end):
    """Hard-cut visibility: IN hides before frame_start; OUT hides after frame_end. Constant interp."""
    if direction == 'IN':
        before, at = frame_start - 1, frame_start
        obj.hide_viewport = True;  obj.keyframe_insert("hide_viewport", frame=before)
        obj.hide_render = True;    obj.keyframe_insert("hide_render", frame=before)
        obj.hide_viewport = False; obj.keyframe_insert("hide_viewport", frame=at)
        obj.hide_render = False;   obj.keyframe_insert("hide_render", frame=at)
    else:
        at, after = frame_end, frame_end + 1
        obj.hide_viewport = False; obj.keyframe_insert("hide_viewport", frame=at)
        obj.hide_render = False;   obj.keyframe_insert("hide_render", frame=at)
        obj.hide_viewport = True;  obj.keyframe_insert("hide_viewport", frame=after)
        obj.hide_render = True;    obj.keyframe_insert("hide_render", frame=after)
    if obj.animation_data and obj.animation_data.action:
        for fc in _iter_fcurves(obj.animation_data.action):
            if fc.data_path in ("hide_viewport", "hide_render"):
                for kp in fc.keyframe_points:
                    kp.interpolation = 'CONSTANT'


def _stamp_anchor(anchor, target, frame_start):
    """Minimal anchor provenance so _is_anchor / Sync recognize a Motionwerks-made anchor."""
    anchor["_animtb_anchor"] = True
    if "_animtb_pivot" in anchor.keys():
        del anchor["_animtb_pivot"]
    anchor["_animtb_target"] = target.name
    anchor["_animtb_frame_start"] = int(frame_start)


# ===========================================================================
# MATERIAL ENGINE (vendored from AnimationToolbox v2.2.1)
# ---------------------------------------------------------------------------
# Builds one material that blends Material A -> Material B (or -> transparent)
# along an axis. The blend is driven by a Value node named "Transition Slider",
# which is what Motionwerks keyframes to schedule the transition on a cue.
# ===========================================================================
SLIDER_NODE = "Transition Slider"
SLIDER_PATH = f'nodes["{SLIDER_NODE}"].outputs[0].default_value'

_MAT_SKIP_COPY_PROPS = {
    'rna_type', 'type', 'location', 'name', 'select', 'parent',
    'inputs', 'outputs', 'internal_links', 'width', 'width_hidden',
    'height', 'dimensions', 'show_options', 'show_preview', 'show_texture',
}


def _copy_node_tree_into(src_tree, dst_tree, x_offset=0, skip_output=True):
    """Copy every node from src_tree into dst_tree, preserving links.
    Returns (node_map, output_surface_node)."""
    node_map = {}
    src_output_surface_link_from = None

    for n in src_tree.nodes:
        if skip_output and n.type == 'OUTPUT_MATERIAL':
            if n.inputs['Surface'].is_linked:
                src_output_surface_link_from = n.inputs['Surface'].links[0].from_node
            continue
        try:
            new_n = dst_tree.nodes.new(n.bl_idname)
        except RuntimeError:
            continue
        new_n.location = (n.location.x + x_offset, n.location.y)
        for prop_name in n.bl_rna.properties.keys():
            if prop_name in _MAT_SKIP_COPY_PROPS:
                continue
            if n.bl_rna.properties[prop_name].is_readonly:
                continue
            try:
                setattr(new_n, prop_name, getattr(n, prop_name))
            except Exception:
                pass
        for i, inp in enumerate(n.inputs):
            if i >= len(new_n.inputs):
                continue
            if hasattr(inp, 'default_value') and hasattr(new_n.inputs[i], 'default_value'):
                try:
                    new_n.inputs[i].default_value = inp.default_value
                except Exception:
                    pass
        node_map[n] = new_n

    for l in src_tree.links:
        if l.from_node not in node_map or l.to_node not in node_map:
            continue
        try:
            dst_tree.links.new(node_map[l.from_node].outputs[l.from_socket.name],
                               node_map[l.to_node].inputs[l.to_socket.name])
        except Exception:
            pass

    return node_map, node_map.get(src_output_surface_link_from)


def _build_transition_material(name, mat_a, mat_b, axis, coord_type,
                               softness, noise_amount, noise_scale, b_is_alpha):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()

    out = nt.nodes.new('ShaderNodeOutputMaterial'); out.location = (1000, 0)
    mix_shader = nt.nodes.new('ShaderNodeMixShader'); mix_shader.location = (800, 0)
    nt.links.new(mix_shader.outputs['Shader'], out.inputs['Surface'])

    frame_a = nt.nodes.new('NodeFrame'); frame_a.label = f"Material A: {mat_a.name}"
    a_map, a_surface = _copy_node_tree_into(mat_a.node_tree, nt, x_offset=-1400)
    for n in a_map.values():
        n.parent = frame_a
    if a_surface is not None:
        nt.links.new(a_surface.outputs[0], mix_shader.inputs[1])

    if b_is_alpha:
        transparent = nt.nodes.new('ShaderNodeBsdfTransparent'); transparent.location = (600, -250)
        nt.links.new(transparent.outputs['BSDF'], mix_shader.inputs[2])
        try:
            mat.surface_render_method = 'DITHERED'
        except Exception:
            pass
        mat.use_backface_culling = False
    else:
        frame_b = nt.nodes.new('NodeFrame'); frame_b.label = f"Material B: {mat_b.name}"
        b_map, b_surface = _copy_node_tree_into(mat_b.node_tree, nt, x_offset=-1400)
        for n in b_map.values():
            n.location.y -= 600
            n.parent = frame_b
        if b_surface is not None:
            nt.links.new(b_surface.outputs[0], mix_shader.inputs[2])

    frame_t = nt.nodes.new('NodeFrame'); frame_t.label = "Transition Control"

    tex_coord = nt.nodes.new('ShaderNodeTexCoord'); tex_coord.location = (0, 400); tex_coord.parent = frame_t
    sep_xyz = nt.nodes.new('ShaderNodeSeparateXYZ')
    sep_xyz.name = "Transition Axis Source"; sep_xyz.location = (200, 400); sep_xyz.parent = frame_t
    coord_socket = 'Generated' if coord_type == 'GENERATED' else 'Object'
    nt.links.new(tex_coord.outputs[coord_socket], sep_xyz.inputs['Vector'])

    slider = nt.nodes.new('ShaderNodeValue')
    slider.name = SLIDER_NODE; slider.label = SLIDER_NODE
    slider.location = (0, 200); slider.outputs[0].default_value = 0.0; slider.parent = frame_t

    width = nt.nodes.new('ShaderNodeValue')
    width.name = "Transition Width"; width.label = "Transition Width"
    width.location = (0, 50); width.outputs[0].default_value = max(softness, 0.001); width.parent = frame_t

    width_floor = nt.nodes.new('ShaderNodeMath')
    width_floor.name = "Transition Width Floor"; width_floor.operation = 'MAXIMUM'
    width_floor.inputs[1].default_value = 0.0005
    width_floor.location = (100, 50); width_floor.parent = frame_t
    nt.links.new(width.outputs[0], width_floor.inputs[0])

    half_width = nt.nodes.new('ShaderNodeMath'); half_width.operation = 'DIVIDE'
    half_width.inputs[1].default_value = 2.0; half_width.location = (200, 50); half_width.parent = frame_t
    nt.links.new(width_floor.outputs[0], half_width.inputs[0])

    from_min = nt.nodes.new('ShaderNodeMath'); from_min.operation = 'SUBTRACT'
    from_min.location = (400, 150); from_min.parent = frame_t
    nt.links.new(slider.outputs[0], from_min.inputs[0])
    nt.links.new(half_width.outputs[0], from_min.inputs[1])

    from_max = nt.nodes.new('ShaderNodeMath'); from_max.operation = 'ADD'
    from_max.location = (400, -50); from_max.parent = frame_t
    nt.links.new(slider.outputs[0], from_max.inputs[0])
    nt.links.new(half_width.outputs[0], from_max.inputs[1])

    noise_scale_node = nt.nodes.new('ShaderNodeValue')
    noise_scale_node.name = "Noise Scale"; noise_scale_node.label = "Noise Scale"
    noise_scale_node.location = (0, -150); noise_scale_node.outputs[0].default_value = noise_scale
    noise_scale_node.parent = frame_t

    noise_amount_node = nt.nodes.new('ShaderNodeValue')
    noise_amount_node.name = "Noise Amount"; noise_amount_node.label = "Noise Amount"
    noise_amount_node.location = (0, -300); noise_amount_node.outputs[0].default_value = noise_amount
    noise_amount_node.parent = frame_t

    noise_tex = nt.nodes.new('ShaderNodeTexNoise'); noise_tex.location = (200, -200); noise_tex.parent = frame_t
    nt.links.new(tex_coord.outputs[coord_socket], noise_tex.inputs['Vector'])
    nt.links.new(noise_scale_node.outputs[0], noise_tex.inputs['Scale'])

    noise_centered = nt.nodes.new('ShaderNodeMath'); noise_centered.operation = 'SUBTRACT'
    noise_centered.inputs[1].default_value = 0.5
    noise_centered.location = (400, -200); noise_centered.parent = frame_t
    nt.links.new(noise_tex.outputs['Fac'], noise_centered.inputs[0])

    noise_scaled = nt.nodes.new('ShaderNodeMath'); noise_scaled.operation = 'MULTIPLY'
    noise_scaled.location = (600, -200); noise_scaled.parent = frame_t
    nt.links.new(noise_centered.outputs[0], noise_scaled.inputs[0])
    nt.links.new(noise_amount_node.outputs[0], noise_scaled.inputs[1])

    # Gate noise by edge width so Softness 0 stays a true hard cut.
    noise_gate = nt.nodes.new('ShaderNodeMapRange')
    noise_gate.name = "Transition Noise Gate"; noise_gate.location = (600, -50); noise_gate.parent = frame_t
    noise_gate.clamp = True
    noise_gate.inputs['From Min'].default_value = 0.0005
    noise_gate.inputs['From Max'].default_value = 0.05
    noise_gate.inputs['To Min'].default_value = 0.0
    noise_gate.inputs['To Max'].default_value = 1.0
    nt.links.new(width_floor.outputs[0], noise_gate.inputs['Value'])

    noise_gated = nt.nodes.new('ShaderNodeMath'); noise_gated.operation = 'MULTIPLY'
    noise_gated.location = (700, -200); noise_gated.parent = frame_t
    nt.links.new(noise_scaled.outputs[0], noise_gated.inputs[0])
    nt.links.new(noise_gate.outputs['Result'], noise_gated.inputs[1])

    channel_plus_noise = nt.nodes.new('ShaderNodeMath')
    channel_plus_noise.name = "Transition Axis Mix"; channel_plus_noise.operation = 'ADD'
    channel_plus_noise.location = (600, 300); channel_plus_noise.parent = frame_t
    nt.links.new(sep_xyz.outputs[axis], channel_plus_noise.inputs[0])
    nt.links.new(noise_gated.outputs[0], channel_plus_noise.inputs[1])

    map_range = nt.nodes.new('ShaderNodeMapRange'); map_range.location = (800, 200); map_range.parent = frame_t
    map_range.clamp = True
    map_range.inputs['To Min'].default_value = 0.0
    map_range.inputs['To Max'].default_value = 1.0
    nt.links.new(channel_plus_noise.outputs[0], map_range.inputs['Value'])
    nt.links.new(from_min.outputs[0], map_range.inputs['From Min'])
    nt.links.new(from_max.outputs[0], map_range.inputs['From Max'])

    nt.links.new(map_range.outputs['Result'], mix_shader.inputs['Fac'])
    return mat


def _slider_of(mat):
    """The Value node Motionwerks keyframes, or None if this isn't a transition material."""
    if not (mat and mat.use_nodes):
        return None
    return mat.node_tree.nodes.get(SLIDER_NODE)


def _key_slider(mat, frame_start, frame_end, reverse=False, curve='SINE', easing='AUTO'):
    """Keyframe a transition material's slider from 0->1 (or 1->0 when reversed)."""
    nt = mat.node_tree
    if _slider_of(mat) is None:
        return False
    if nt.animation_data and nt.animation_data.action:
        act = nt.animation_data.action
        for fc in list(_iter_fcurves(act)):
            if fc.data_path == SLIDER_PATH:
                try:
                    _fcurve_container_remove(act, fc)
                except Exception:
                    pass
    a, b = (1.0, 0.0) if reverse else (0.0, 1.0)
    node = _slider_of(mat)
    node.outputs[0].default_value = a
    nt.keyframe_insert(data_path=SLIDER_PATH, frame=frame_start)
    node.outputs[0].default_value = b
    nt.keyframe_insert(data_path=SLIDER_PATH, frame=frame_end)

    resolved = _resolve_easing(easing, in_like=not reverse)
    has_easing = curve not in {'LINEAR', 'CONSTANT', 'BEZIER'}
    if nt.animation_data and nt.animation_data.action:
        for fc in _iter_fcurves(nt.animation_data.action):
            if fc.data_path != SLIDER_PATH:
                continue
            for kp in fc.keyframe_points:
                kp.interpolation = curve
                if has_easing:
                    kp.easing = resolved
    return True


def _fcurve_container_remove(action, fcurve):
    """Remove an fcurve from a legacy or slotted action."""
    if hasattr(action, "fcurves"):
        action.fcurves.remove(fcurve)
        return
    for layer in action.layers:
        for strip in layer.strips:
            for cb in strip.channelbags:
                if fcurve in list(cb.fcurves):
                    cb.fcurves.remove(fcurve)
                    return


# ===========================================================================
# Per-cue motion presets — a full PSR spec, owned by Motionwerks, authored in
# Motionwerks and pulled in via "Sync from Motionwerks". Motionwerks keeps
# authority over object ORDER (the UIList) and the stagger + lock-to-marker;
# the preset supplies the motion shape and each item's internal frame counts.
# ===========================================================================
# Motion fields mirrored from a Motionwerks preset (ATAnimPreset). MW's own
# stagger/order fields are intentionally NOT imported — Motionwerks owns those.
PRESET_FIELDS = (
    "direction",
    "scale_enabled", "scale_uniform", "scale_axis", "scale_frames",
    "move_enabled", "move_axis", "move_distance_ft", "move_frames",
    "rotation_enabled", "rotation_axis", "rotation_angle_deg", "rotation_frames", "rotation_pause",
    "visibility_enabled", "pause", "curve", "easing",
)

_PRESET_DEFAULTS = {
    "direction": 'IN',
    "scale_enabled": False, "scale_uniform": False, "scale_axis": 'Z', "scale_frames": 15,
    "move_enabled": False, "move_axis": '-Z', "move_distance_ft": 8.0, "move_frames": 15,
    "rotation_enabled": False, "rotation_axis": 'Z', "rotation_angle_deg": 360.0,
    "rotation_frames": 15, "rotation_pause": 0,
    "visibility_enabled": False, "pause": 0, "curve": 'SINE', "easing": 'AUTO',
}

# Seeded so Motionwerks works before any sync and even with Motionwerks uninstalled.
BUILTIN_PRESETS = [
    {"name": "Scale On",   "scale_enabled": True, "scale_uniform": True,  "scale_axis": 'Z',
     "scale_frames": 15, "direction": 'IN', "curve": 'SINE', "easing": 'EASE_OUT'},
    {"name": "Grow Up",    "scale_enabled": True, "scale_uniform": False, "scale_axis": 'Z',
     "scale_frames": 15, "direction": 'IN', "curve": 'SINE', "easing": 'EASE_OUT'},
    {"name": "Slide On X", "move_enabled": True, "move_axis": 'X', "move_distance_ft": 8.0,
     "move_frames": 15, "direction": 'IN', "curve": 'SINE', "easing": 'EASE_OUT'},
    {"name": "Drop In",    "move_enabled": True, "move_axis": 'Z', "move_distance_ft": 8.0,
     "move_frames": 15, "direction": 'IN', "curve": 'SINE', "easing": 'EASE_OUT'},
    {"name": "Scale Off",  "scale_enabled": True, "scale_uniform": True,  "scale_axis": 'Z',
     "scale_frames": 15, "direction": 'OUT', "curve": 'SINE', "easing": 'EASE_IN'},
]


def _write_preset(dst, data):
    """Fill a MW_PresetPG from a plain dict, defaulting any unspecified field."""
    for f in PRESET_FIELDS:
        setattr(dst, f, data.get(f, _PRESET_DEFAULTS[f]))


def _ensure_builtin_presets(scene):
    """Seed the built-in presets into a scene if missing (called on register + file load)."""
    if not hasattr(scene, "motionwerks_presets"):
        return
    existing = {pr.name for pr in scene.motionwerks_presets}
    for data in BUILTIN_PRESETS:
        if data["name"] in existing:
            continue
        dst = scene.motionwerks_presets.add()
        dst.name = data["name"]
        _write_preset(dst, data)


def _find_preset(scene, name):
    if not name:
        return None
    for pr in scene.motionwerks_presets:
        if pr.name == name:
            return pr
    return None


def _preset_length(pr):
    """Total frames the preset's motion spans (used to lock completion on the marker)."""
    d = 1
    if pr.scale_enabled:
        d = max(d, pr.scale_frames)
    if pr.move_enabled:
        d = max(d, pr.pause + pr.move_frames)
    if pr.rotation_enabled:
        d = max(d, pr.rotation_pause + pr.rotation_frames)
    return d


def _preset_summary(pr):
    parts = []
    if pr.scale_enabled:
        parts.append(f"Scale {'' if pr.scale_uniform else pr.scale_axis + ' '}{pr.scale_frames}f")
    if pr.move_enabled:
        parts.append(f"Move {pr.move_axis} {pr.move_distance_ft:g}ft")
    if pr.rotation_enabled:
        parts.append(f"Rot {pr.rotation_axis} {pr.rotation_angle_deg:g}°")
    if pr.visibility_enabled:
        parts.append("Vis")
    return " · ".join(parts) if parts else "(no motion)"


def _apply_spec(context, target, pr, frame_start, time_scale=1.0):
    """Apply a full-PSR preset `pr` to `target`, starting at frame_start. `time_scale`
    stretches all frame counts together (overall build-timing control), so a combined
    scale+move stays proportional. Ported from Motionwerks' _apply_animation."""
    def _sf(frames):
        return max(1, round(frames * time_scale))

    def _sp(frames):
        return round(frames * time_scale)

    scale_frames = _sf(pr.scale_frames)
    move_frames = _sf(pr.move_frames)
    rot_frames = _sf(pr.rotation_frames)
    pause = _sp(pr.pause)
    rot_pause = _sp(pr.rotation_pause)

    # Restore the object to rest before (re)anchoring, so a re-apply never reads a
    # displaced position as rest (which would stack move distance on every reorder).
    _neutralize_object_motion(target, pr.direction)

    anchor = None
    animator = target
    # Move goes through an anchor too — the anchor stores its rest and is reset on every
    # re-apply, so translation can't accumulate. (Only visibility-only presets skip it.)
    needs_anchor = pr.scale_enabled or pr.rotation_enabled or pr.move_enabled

    if needs_anchor:
        use_uniform = pr.scale_uniform if pr.scale_enabled else True
        axis_for_anchor = pr.scale_axis if pr.scale_enabled else 'Z'
        anchor = _ensure_anchor_empty(context, target, axis_for_anchor, pr.direction, uniform=use_uniform)
        animator = anchor
        for dp in ("location", "rotation_euler", "scale"):
            _clear_fcurves(target, dp)          # object is anchor-driven now
        _clear_fcurves(anchor, "scale")
        _clear_fcurves(anchor, "location")
        _clear_fcurves(anchor, "rotation_euler")
        if pr.scale_enabled:
            _set_scale_keyframes(anchor, pr.scale_axis, pr.direction, scale_frames,
                                 frame_start, pr.curve, pr.easing, uniform=pr.scale_uniform)
    else:
        existing = _find_existing_anchor(target)
        if existing:
            animator = existing
            _reset_anchor_to_rest(existing)
        else:
            _clear_fcurves(target, "location")
            _clear_fcurves(target, "rotation_euler")

    move_start = frame_start + pause
    rot_start = frame_start + rot_pause

    if pr.move_enabled:
        _set_move_keyframes(animator, pr.move_axis, pr.direction, pr.move_distance_ft,
                            move_frames, move_start, pr.curve, pr.easing)
    if pr.rotation_enabled:
        _set_rotation_keyframes(animator, pr.rotation_axis, pr.direction, pr.rotation_angle_deg,
                                rot_frames, rot_start, pr.curve, pr.easing)

    end_candidates = [frame_start]
    if pr.scale_enabled:
        end_candidates.append(frame_start + scale_frames)
    if pr.move_enabled:
        end_candidates.append(move_start + move_frames)
    if pr.rotation_enabled:
        end_candidates.append(rot_start + rot_frames)
    animation_end = max(end_candidates)

    # Visibility is keyed on the actual mesh AND everything parented under it (door
    # panels, hardware, …) — hiding the anchor empty does NOT hide its child mesh.
    # Clear any prior keys (on the tree + anchor) so toggling Visibility Cut off removes them.
    vis_tree = [target] + _descendants(target)
    for vo in vis_tree:
        _clear_fcurves(vo, "hide_viewport")
        _clear_fcurves(vo, "hide_render")
    if anchor is not None:
        _clear_fcurves(anchor, "hide_viewport")
        _clear_fcurves(anchor, "hide_render")
    if pr.visibility_enabled:
        for vo in vis_tree:
            _set_visibility_keyframes(vo, pr.direction, frame_start, animation_end)

    # Stamp the anchor's marker props. A freshly-created anchor isn't recognized by
    # _is_anchor yet (no marker prop), so key off `anchor`, not _is_anchor(animator).
    if anchor is not None:
        _stamp_anchor(anchor, target, frame_start)
        return anchor
    if animator is not target and _is_anchor(animator):
        _stamp_anchor(animator, target, frame_start)
        return animator
    return None


# ---------------------------------------------------------------------------
# Object / keyframe helpers (used by reorder + sync)
# ---------------------------------------------------------------------------
def _all_fcurves(obj):
    ad = obj.animation_data
    if not (ad and ad.action):
        return []
    return list(_iter_fcurves(ad.action))


def _shift_keyframes(obj, delta, path_filter=None):
    """Shift every keyframe on obj by delta. `obj` is anything with animation_data —
    an Object, or a material's node_tree. `path_filter` narrows it to specific
    data_paths so we can retime one action's curves without touching the rest."""
    if not delta:
        return
    for fc in _all_fcurves(obj):
        if path_filter is not None and not path_filter(fc.data_path):
            continue
        for kp in fc.keyframe_points:
            kp.co.x += delta
            kp.handle_left.x += delta
            kp.handle_right.x += delta
        fc.update()


def _anchor_of(obj):
    if obj.parent and _is_anchor(obj.parent):
        return obj.parent
    return None


def _descendants(obj):
    """All objects parented under obj, recursively (e.g. door panels under a door),
    skipping Motionwerks anchor empties."""
    out = []
    for c in obj.children:
        if _is_anchor(c):
            continue
        out.append(c)
        out.extend(_descendants(c))
    return out


def _neutralize_object_motion(obj, direction):
    """Restore obj to the rest pose implied by its OWN location/rotation fcurves, then remove
    them. No-op if obj has none (already at rest, or driven by an anchor). This lets a fresh
    anchor capture the true rest instead of a mid-animation frame — without it, re-applying a
    move (e.g. on reorder) would read a displaced position as rest and stack the distance."""
    for path in ("location", "rotation_euler"):
        fcs = [fc for fc in _all_fcurves(obj) if fc.data_path == path]
        if not fcs:
            continue
        vec = list(getattr(obj, path))
        for fc in fcs:
            kps = sorted(fc.keyframe_points, key=lambda k: k.co.x)
            if not kps:
                continue
            # IN animations settle at their last key; OUT departs from their first key
            vec[fc.array_index] = kps[-1].co.y if direction == 'IN' else kps[0].co.y
        setattr(obj, path, vec)
        _clear_fcurves(obj, path)


def _kf_target(obj):
    """Where the object's animation lives — its anchor, or itself."""
    a = _anchor_of(obj)
    return a if a else obj


def _ref_frame(target):
    mins = [min(k.co.x for k in fc.keyframe_points)
            for fc in _all_fcurves(target) if fc.keyframe_points]
    return min(mins) if mins else None


# ---------------------------------------------------------------------------
# Cue = numbered collection under the master "Cues" collection
# ---------------------------------------------------------------------------
def _master(scene, create=False):
    m = bpy.data.collections.get(MASTER)
    if m is None and create:
        m = bpy.data.collections.new(MASTER)
        scene.collection.children.link(m)
    if m is not None and m.name not in scene.collection.children and create:
        try:
            scene.collection.children.link(m)
        except Exception:
            pass
    return m


def _cue_frame(scene, coll):
    mk = scene.timeline_markers.get(coll.get("mw_marker", ""))
    return mk.frame if mk else int(coll.get("mw_frame", 0))


# ---------------------------------------------------------------------------
# ⚠⚠ MARKER NAMES ARE THE ONLY HANDLE THERE IS, AND BLENDER DOES NOT MAKE THEM UNIQUE.
#
# A cue binds with `coll["mw_marker"] = mk.name` and resolves with
# `timeline_markers.get(name)`, which returns the FIRST match. Two markers called "Cue" and
# every cue bound to that name lands on the earlier one — the whole sequence collapses onto
# one frame. Reported 2026-08-07: three cues, markers "Cue"@1 and "Cue"@24, everything on f1.
#
# ⚠ There is no alternative key. Probed on 5.2: a TimelineMarker exposes only
# `camera / frame / name / select`, and `marker["x"] = 1` raises
# "id properties not supported for this type" — so it cannot be stamped with an id.
#
# ⚠ The invariant was assumed EVERYWHERE and enforced NOWHERE: `populate_from_markers` also
# keys on `mk.name` and silently skips the second marker of a duplicated pair, and
# Camerawerks shots bind the same way (`sh.marker = mk.name`, `_shot_frame`).
# ---------------------------------------------------------------------------
def _free_marker_name(scene, base):
    """A marker name nothing else is using.

    ⚠ Blender does NOT uniquify timeline marker names — two markers can both be called
    "Shot 03". Cues and shots both bind BY NAME and every lookup is
    `timeline_markers.get(name)`, which returns whichever one it finds first, so a duplicate
    silently binds to the wrong frame.

    ⚠ MOVED UP HERE 2026-08-07 and it is the ONLY such helper. It was written for the
    Camerawerks half and I added a second copy (`_unique_marker_name`) on the cue side a day
    later without reading this one — two functions, one job. If you need this, it is here.
    """
    names = {m.name for m in scene.timeline_markers}
    if base not in names:
        return base
    i = 1
    while "%s.%03d" % (base, i) in names:
        i += 1
    return "%s.%03d" % (base, i)


def _strip_number(name):
    """'03 Kitchen' -> 'Kitchen'. Anything without a two-digit prefix is left alone.

    Shared by cues and shots so both number the same way — 01, 02, 03 in playing order, with
    the name you typed kept as the base.
    """
    head, _, tail = name.partition(" ")
    return tail if (len(head) == 2 and head.isdigit() and tail) else name


def _strip_dup_suffix(name):
    """'Cue.001' -> 'Cue'. Blender's datablock-collision suffix.

    ⚠ Needed because _renumber now takes the base from the CURRENT name (so renaming a row
    sticks). Without this, a cue that picked up a ".001" from the old one-pass renumber would
    have that suffix adopted as its real base and keep it for ever, instead of healing on the
    next renumber the way it used to. The two-pass renumber cannot create new ones, so any
    suffix still around is legacy debris.
    """
    head, dot, tail = name.rpartition(".")
    return head if (dot and len(tail) == 3 and tail.isdigit() and head) else name


def _duplicate_marker_names(scene):
    """{name: [frames]} for every name more than one marker is using.

    Cheap enough to call from draw (one pass over the markers) and worth it — the failure is
    silent otherwise, which is exactly why it cost a confused bug report."""
    seen = {}
    for m in scene.timeline_markers:
        seen.setdefault(m.name, []).append(m.frame)
    return {n: sorted(f) for n, f in seen.items() if len(f) > 1}


def _cue_colls(scene):
    m = _master(scene)
    if not m:
        return []
    return sorted(list(m.children), key=lambda c: _cue_frame(scene, c))


def _renumber(scene):
    ordered = _cue_colls(scene)          # sorted by marker frame
    # ⚠⚠ TWO PASSES, and it has to be two. Renaming in place COLLIDES: inserting a cue at f30
    # means the f30 cue is given "03 Cue" while the f48 cue is still holding that name, so
    # Blender appends ".001" and the cue is called "03 Cue.001" for ever. (Rob hit exactly
    # this — the next _renumber would clear it, but nothing calls one.) Park everything on a
    # name nothing can want, then assign the real ones.
    # ⚠ Base from the CURRENT name, not from the stored mw_name — the cue list now lets you
    # rename a row in place, and preferring the stored value would silently undo every rename
    # on the next add. Same rule as _renumber_shots, deliberately.
    for i, c in enumerate(ordered):
        base = _strip_dup_suffix(_strip_number(c.name).strip()) or c.get("mw_name") or "Cue"
        c["mw_name"] = base
        c.name = "__mw_renumber_%d__" % i
    for i, c in enumerate(ordered):
        c.name = f"{i + 1:02d} {c['mw_name']}"
    # The outliner lists child collections in DATA (link) order, not by name, so
    # relink them in frame order to make the outliner match the numbering.
    m = _master(scene)
    if m is not None:
        for c in ordered:
            try:
                m.children.unlink(c)
            except Exception:
                pass
        for c in ordered:
            m.children.link(c)


def _active_cue(scene):
    """⚠ THE LIST INDEX IS THE SOURCE OF TRUTH since 2026-08-07, because that is what the
    UIList drives. It indexes `master.children` — LINK order, which `_renumber` keeps in frame
    order. `motionwerks_active` (a marker NAME) is still written alongside it, but is no
    longer read here: with the old name lookup the highlighted row and the cue being edited
    could point at different cues, and a duplicated marker name resolved to the first match.
    """
    m = _master(scene)
    if m is None:
        return None
    ch = list(m.children)
    i = getattr(scene, "mw_cue_active", 0)
    return ch[i] if 0 <= i < len(ch) else None


def _set_active_cue(scene, coll):
    """Select a cue from code. Writes BOTH the index (what the list shows) and the marker key
    (what older paths read), so the two can never disagree."""
    scene.motionwerks_active = coll.get("mw_marker", "") if coll is not None else ""
    m = _master(scene)
    if m is not None and coll is not None:
        try:
            scene.mw_cue_active = list(m.children).index(coll)
        except ValueError:
            pass


def _cue_active_update(self, context):
    """Picking a cue keeps the marker key in step and — with Follow Selection on — jumps the
    playhead to it, so the list becomes a way of REVIEWING the sequence. `self` is the Scene.

    ⚠ This is an `update=` callback, NOT draw, which is the only reason `_ensure_items` may
    run here: it syncs the cue's object list to collection membership and writing that during
    a draw can loop the redraw.
    """
    c = _active_cue(self)
    self.motionwerks_active = c.get("mw_marker", "") if c is not None else ""
    if c is None:
        return
    try:
        _ensure_items(c)
        _migrate_cue(c, self)
        if getattr(self, "mw_cue_follow", False):
            mk = self.timeline_markers.get(c.get("mw_marker", ""))
            if mk is not None:
                self.frame_set(mk.frame)
    except Exception:
        pass


def _cue_objects(coll):
    # cloner sources (parented under a Mograph carrier) are templates, not cue motion objects
    return [o for o in coll.objects if o.type == 'MESH' and not o.get("mw_cloner_source")]


_ITEM_TYPES = {'MESH', 'CURVE', 'SURFACE', 'META'}


def _all_items(coll):
    """Every valid object in the cue, whatever actions it takes part in."""
    return [it for it in coll.mw_items if it.obj]


def _ordered_items(coll):
    """Motion participants, in list order (list order = animate order)."""
    return [it for it in coll.mw_items if it.obj and it.use_motion]


def _items_objs(coll):
    """Read-only: the cue's animate-ordered objects."""
    return [it.obj for it in _ordered_items(coll)]


def _active_item(coll):
    """The MW_ItemPG highlighted in the object list, or None."""
    i = coll.mw_active_item
    if 0 <= i < len(coll.mw_items):
        it = coll.mw_items[i]
        if it.obj:
            return it
    return None


def _ensure_items(coll):
    """Sync the mw_items list to the cue's mesh membership (MUST be called from an
    operator, never draw). Prunes stale entries and appends new meshes; seeds order
    from legacy mw_order the first time so pre-0.5.0 cues migrate cleanly."""
    for i in range(len(coll.mw_items) - 1, -1, -1):
        o = coll.mw_items[i].obj
        if o is None or o.name not in coll.objects or o.type not in _ITEM_TYPES:
            coll.mw_items.remove(i)
    present = {it.obj.name for it in coll.mw_items if it.obj}
    missing = [o for o in _cue_objects(coll)
               if o.name not in present and o.type in _ITEM_TYPES]
    missing.sort(key=lambda o: o.get("mw_order", 1e9))   # legacy-order migration
    for o in missing:
        it = coll.mw_items.add()
        it.obj = o
    if coll.mw_active_item >= len(coll.mw_items):
        coll.mw_active_item = max(0, len(coll.mw_items) - 1)


# Read-only ordered objects (kept name for the rest of the module).
def _cue_ordered(coll):
    return _items_objs(coll)


# ---------------------------------------------------------------------------
# Each cue owns one editable PSR block (mw_motion) + mw_spacing, edited directly
# in the Motion panel. Presets just load into / save from mw_motion (like MW).
# ---------------------------------------------------------------------------
def _copy_preset(src, dst):
    """Copy the PSR motion fields from one MW_PresetPG to another."""
    for f in PRESET_FIELDS:
        setattr(dst, f, getattr(src, f))


def _has_motion(pr):
    return pr.scale_enabled or pr.move_enabled or pr.rotation_enabled or pr.visibility_enabled


def _item_motion(scene, coll, item):
    """The motion an item animates with: its own preset override if set (and still in the
    library), otherwise the cue's motion."""
    if item.preset:
        pr = _find_preset(scene, item.preset)
        if pr is not None:
            return pr
    return coll.mw_motion


def _active_motion(scene, coll):
    """The motion the highlighted object actually animates with — its assigned preset, or
    the cue's shared motion when it's on 'Cue default'. All motion editing targets this,
    so what you tweak is always what the selected object does."""
    it = _active_item(coll)
    if it is not None:
        return _item_motion(scene, coll, it)
    return coll.mw_motion


def _longest_item(scene, coll):
    """Authored length of the longest item in the cue — the reference the overall Timing
    scales against (items can differ once per-item presets are in play)."""
    lens = [_preset_length(_item_motion(scene, coll, it)) for it in _ordered_items(coll)]
    return max(lens) if lens else _preset_length(coll.mw_motion)


def _natural_build(scene, coll):
    """Overall frames the cue's build spans at its current per-item Timing:
    (n-1)*Spacing + Timing."""
    n = max(1, len(_ordered_items(coll)))
    return (n - 1) * coll.mw_spacing + max(1, coll.mw_timing)


def _load_into_cue(scene, coll, src):
    """Copy a preset into a cue's settings; reset Timing to the preset's authored length
    and Duration to the resulting overall build."""
    _copy_preset(src, coll.mw_motion)
    coll.mw_source = src.name
    coll.mw_timing = max(1, _longest_item(scene, coll))   # per-item keyframe duration
    coll.mw_duration = _natural_build(scene, coll)        # overall build


def _time_scale(scene, coll):
    """Stretch factor so each item's motion lasts mw_timing frames. One factor for every
    item, so mixed per-item presets keep their relative proportions."""
    ref = _longest_item(scene, coll)
    if ref <= 0 or coll.mw_timing <= 0:
        return 1.0
    return coll.mw_timing / ref


# Duration (overall) and Timing (per-item) are two views of the same schedule, related by
# Spacing and item count. Editing either keeps the other in step; the guard stops recursion.
_sync_guard = False


def _on_timing_change(self, context):
    global _sync_guard
    if _sync_guard:
        return
    _sync_guard = True
    try:
        n = max(1, len(_ordered_items(self)))
        self.mw_duration = (n - 1) * self.mw_spacing + max(1, self.mw_timing)
    finally:
        _sync_guard = False


def _on_duration_change(self, context):
    global _sync_guard
    if _sync_guard:
        return
    _sync_guard = True
    try:
        n = max(1, len(_ordered_items(self)))
        self.mw_timing = max(1, self.mw_duration - (n - 1) * self.mw_spacing)
    finally:
        _sync_guard = False


def _migrate_actions(coll):
    """1.2 -> 1.3: fold the per-action object lists into the cue's single list.

    Objects that only ever belonged to a Material or Fracture action may not be members
    of the cue collection at all, so link them in first — cue membership is what the one
    list is built from. Anything arriving this way gets use_motion OFF: it was never a
    motion participant, and defaulting it on would silently animate it.
    """
    pairs = ((coll.mw_material, "use_material"),)
    if not any(len(pg.items) for pg, _ in pairs):
        return 0
    already = {o.name for o in _cue_objects(coll)}
    moved = 0
    for pg, flag in pairs:
        objs = [it.obj for it in pg.items if it.obj]
        if objs:
            _link_archipack_safe(coll, objs)
    _ensure_items(coll)
    for pg, flag in pairs:
        for it_old in pg.items:
            o = it_old.obj
            if o is None:
                continue
            for it in coll.mw_items:
                if it.obj is not None and it.obj.name == o.name:
                    setattr(it, flag, True)
                    if o.name not in already:
                        it.use_motion = False
                    moved += 1
                    break
        pg.items.clear()
    return moved


def _migrate_cue(coll, scene):
    """Give a cue a populated mw_motion. New/empty cues load from their legacy
    preset name (pre-0.8 custom prop) or the first library preset. Safe to repeat."""
    legacy = None
    if "mw_preset" in coll.keys():
        legacy = coll["mw_preset"]
        del coll["mw_preset"]
    if "mw_spacing" in coll.keys():
        try:
            coll.mw_spacing = int(coll["mw_spacing"])
        except Exception:
            pass
        del coll["mw_spacing"]
    if "mw_duration" in coll.keys():        # pre-0.11 leftover (renamed to mw_timing)
        del coll["mw_duration"]
    _migrate_actions(coll)
    if _has_motion(coll.mw_motion):
        if coll.mw_timing <= 0:
            coll.mw_timing = max(1, _longest_item(scene, coll))
        if coll.mw_duration <= 0:                    # cues made before Duration existed
            coll.mw_duration = _natural_build(scene, coll)
        return
    src = _find_preset(scene, legacy) if legacy else None
    if src is None and len(scene.motionwerks_presets):
        src = scene.motionwerks_presets[0]
    if src is not None:
        _load_into_cue(scene, coll, src)


def _apply_motion(context, coll):
    """Apply each item's motion (its own preset override, else the cue's), staggered so
    the cue STARTS on its marker. Records the marker frame for Sync."""
    scene = context.scene
    _ensure_items(coll)
    mk = scene.timeline_markers.get(coll.get("mw_marker", ""))
    frame = mk.frame if mk else _cue_frame(scene, coll)

    spacing = coll.mw_spacing
    tscale = _time_scale(scene, coll)
    items = _ordered_items(coll)            # LIST order drives the animate order
    for i, it in enumerate(items):
        # first item STARTS on the marker; later items are staggered after it
        start = frame + i * spacing
        _apply_spec(context, it.obj, _item_motion(scene, coll, it), start, time_scale=tscale)
    coll["mw_marker_frame"] = frame


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------
def _link_archipack_safe(coll, objs):
    """Link objects into the cue collection; Archipack items keep their other
    memberships (don't move them), plain objects are moved out of loose collections."""
    for o in objs:
        is_archi = any("archipack" in k.lower() for k in
                       (list(o.keys()) + (list(o.data.keys()) if o.data and hasattr(o.data, "keys") else [])))
        if o.name in coll.objects:
            continue
        if not is_archi:
            for c in list(o.users_collection):
                if c is not coll:
                    c.objects.unlink(o)
        coll.objects.link(o)


class MW_OT_cue_add(bpy.types.Operator):
    bl_idname = "motionwerks.cue_add"
    bl_label = "Add Cue"
    bl_description = "Create a cue: a numbered collection under 'Cues', triggered by a marker at the playhead"
    bl_options = {'REGISTER', 'UNDO'}
    name: bpy.props.StringProperty(name="Name", default="Cue")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        col = self.layout.column()
        col.prop(self, "name")
        col.label(text=f"Trigger marker at frame {context.scene.frame_current}", icon='MARKER')

    def execute(self, context):
        scene = context.scene
        master = _master(scene, create=True)
        mk = next((m for m in scene.timeline_markers if m.frame == scene.frame_current), None)
        if mk is None:
            # ⚠ NOT self.name — the dialog defaults to "Cue", so adding two cues without
            # renaming made two markers called "Cue" and every cue bound to that name
            # resolved to the first. Reusing a marker already at this frame is still right;
            # only a NEW one needs the collision guard.
            mk = scene.timeline_markers.new(_free_marker_name(scene, self.name),
                                            frame=scene.frame_current)

        coll = bpy.data.collections.new(self.name)
        master.children.link(coll)
        coll["mw_name"] = self.name
        coll["mw_marker"] = mk.name
        sel = [o for o in context.selected_objects if o.type == 'MESH']
        _link_archipack_safe(coll, sel)
        _ensure_items(coll)

        _migrate_cue(coll, scene)       # seed mw_motion from the first library preset
        _renumber(scene)
        # ⚠ AFTER _renumber — it relinks every child into frame order, so an index taken
        # before it would point at whatever has since moved into that slot.
        _set_active_cue(scene, coll)
        _apply_motion(context, coll)
        self.report({'INFO'}, f"Cue '{self.name}' on marker '{mk.name}' (f{mk.frame})")
        return {'FINISHED'}


class MW_OT_populate(bpy.types.Operator):
    bl_idname = "motionwerks.populate_from_markers"
    bl_label = "Cues from Markers"
    bl_description = "Create a cue (numbered collection) for every timeline marker that doesn't have one yet"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        master = _master(scene, create=True)
        have = {c.get("mw_marker", "") for c in _cue_colls(scene)}
        made = 0
        for mk in scene.timeline_markers:
            if mk.name in have:
                continue
            coll = bpy.data.collections.new(mk.name)
            master.children.link(coll)
            coll["mw_name"] = mk.name
            coll["mw_marker"] = mk.name
            coll["mw_marker_frame"] = mk.frame
            made += 1
        _renumber(scene)
        if made and _active_cue(scene) is None:
            first = _cue_colls(scene)
            if first:
                _set_active_cue(scene, first[0])
        self.report({'INFO'}, f"Added {made} cue(s) from markers")
        return {'FINISHED'}


class MW_OT_cue_remove(bpy.types.Operator):
    bl_idname = "motionwerks.cue_remove"
    bl_label = "Remove Cue"
    bl_description = "Remove the active cue's collection (objects are kept in the scene)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        coll = _active_cue(scene)
        if coll:
            bpy.data.collections.remove(coll)
            _renumber(scene)
            # ⚠ Clamp, don't zero. Removing row 3 of 5 should leave you on the cue that took
            # its place, the way every other Blender list behaves — jumping back to the top
            # loses your position in a long sequence.
            m = _master(scene)
            n = len(m.children) if m is not None else 0
            scene.mw_cue_active = max(0, min(scene.mw_cue_active, n - 1))
            _set_active_cue(scene, _active_cue(scene))
        return {'FINISHED'}


# MW_OT_cue_select is GONE (2026-08-07): the UIList's own highlight replaced the
# RADIOBUT_ON/OFF button that was its only caller. Left-behind operators that nothing can
# reach are worse than no operator — they read as a feature when they are debris.


# MW_OT_cue_jump is GONE (2026-08-07): Follow Selection jumps the playhead when a row
# is picked, exactly as the shot list's sync_view does, so the ▶ button had nothing
# left to do. Same rule as MW_OT_cue_select.


class MW_OT_cue_object_move(bpy.types.Operator):
    bl_idname = "motionwerks.cue_object_move"
    bl_label = "Move in Cue"
    bl_description = "Reorder the active object in the cue — list position is the animate order; the cue's motion is re-timed to match"
    bl_options = {'REGISTER', 'UNDO'}
    dir: bpy.props.IntProperty(default=-1)   # -1 up, +1 down

    def execute(self, context):
        coll = _active_cue(context.scene)
        if coll is None:
            return {'CANCELLED'}
        _ensure_items(coll)
        n = len(coll.mw_items)
        i = coll.mw_active_item
        j = i + self.dir
        if not (0 <= i < n and 0 <= j < n):
            return {'CANCELLED'}
        coll.mw_items.move(i, j)
        coll.mw_active_item = j
        # recompute the whole cue so keyframes follow the new order (clean, no swapping)
        if coll.get("mw_marker_frame") is not None:
            _apply_motion(context, coll)
        return {'FINISHED'}


class MW_OT_cue_objects_add(bpy.types.Operator):
    bl_idname = "motionwerks.cue_objects_add"
    bl_label = "Add Selected to Cue"
    bl_description = "Add the selected objects to the active cue, appended to the animate order"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        coll = _active_cue(context.scene)
        if coll is None:
            self.report({'WARNING'}, "No active cue"); return {'CANCELLED'}
        sel = [o for o in context.selected_objects if o.type == 'MESH']
        _link_archipack_safe(coll, sel)
        _ensure_items(coll)          # appends the newly-linked meshes as items
        if coll.mw_items:
            coll.mw_active_item = len(coll.mw_items) - 1
        return {'FINISHED'}


class MW_OT_cue_object_remove(bpy.types.Operator):
    bl_idname = "motionwerks.cue_object_remove"
    bl_label = "Remove from Cue"
    bl_description = "Remove the active object from the cue (the object itself is kept in the scene)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        coll = _active_cue(context.scene)
        if coll is None:
            return {'CANCELLED'}
        _ensure_items(coll)
        i = coll.mw_active_item
        if not (0 <= i < len(coll.mw_items)):
            return {'CANCELLED'}
        o = coll.mw_items[i].obj
        if o and o.name in coll.objects:
            coll.objects.unlink(o)
        coll.mw_items.remove(i)
        coll.mw_active_item = min(i, max(0, len(coll.mw_items) - 1))
        return {'FINISHED'}


class MW_OT_cue_apply(bpy.types.Operator):
    bl_idname = "motionwerks.cue_apply"
    bl_label = "Apply Cue"
    bl_description = "Apply this cue's actions (motion + material + drives) on its marker"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        coll = _active_cue(scene)
        if coll is None:
            self.report({'WARNING'}, "No active cue"); return {'CANCELLED'}
        _apply_motion(context, coll)
        mk = scene.timeline_markers.get(coll.get("mw_marker", ""))
        frame = mk.frame if mk else _cue_frame(scene, coll)
        n_mat = _apply_material_action(context, coll, frame)
        n_drv = _apply_drives(context, coll, frame)
        label = f"cue '{coll.get('mw_name', coll.name)}'"
        extra = []
        if n_mat:
            extra.append(f"{n_mat} material object(s)")
        if n_drv:
            extra.append(f"{n_drv} driven handle(s)")
        self.report({'INFO'},
                    f"Applied motion + {' + '.join(extra)} to {label}" if extra
                    else f"Applied motion to {label}")
        return {'FINISHED'}




class MW_OT_action_toggle_all(bpy.types.Operator):
    bl_idname = "motionwerks.action_toggle_all"
    bl_label = "Toggle Action"
    bl_description = ("Turn this action on or off for every object in the cue. "
                      "It's a shortcut for the per-object toggles in the list above — "
                      "not a separate switch")
    bl_options = {'REGISTER', 'UNDO'}
    key: bpy.props.StringProperty()

    def execute(self, context):
        cue = _active_cue(context.scene)
        if cue is None:
            return {'CANCELLED'}
        if self.key == 'MOGRAPH':
            cue.mw_action_active = 'MOGRAPH'
            return {'FINISHED'}
        if self.key == 'DRIVES':
            cue.mw_action_active = 'DRIVES'
            return {'FINISHED'}
        flag = _action_flag(self.key)
        if flag is None:
            return {'CANCELLED'}
        state, _on, _total = _action_state(cue, self.key)
        target = (state != 'ALL')          # any partial/empty state fills in
        for it in _all_items(cue):
            setattr(it, flag, target)
        cue.mw_action_active = self.key
        return {'FINISHED'}


class MW_OT_action_select(bpy.types.Operator):
    bl_idname = "motionwerks.action_select"
    bl_label = "Select Action"
    bl_description = "Open this action and switch it on"
    bl_options = {'REGISTER', 'UNDO'}
    key: bpy.props.StringProperty()

    def execute(self, context):
        cue = _active_cue(context.scene)
        if cue is None:
            return {'CANCELLED'}
        cue.mw_action_active = self.key
        # Clicking the NAME both opens and switches on — one click, one outcome.
        # Previously the name only opened and the checkbox only switched on, so a
        # click on the obvious target appeared to do nothing.
        flag = _action_flag(self.key)
        if flag is not None:
            state, _on, _total = _action_state(cue, self.key)
            if state == 'NONE':
                for it in _all_items(cue):
                    setattr(it, flag, True)
        return {'FINISHED'}




class MW_OT_drive_add(bpy.types.Operator):
    bl_idname = "motionwerks.drive_add"
    bl_label = "Add Selected"
    bl_description = ("Have this cue drive the selected object(s). Anything with a "
                      "Geometry Nodes 'Progress' input qualifies — a Mographwerks cloner, "
                      "a fracture, or your own node group")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        coll = _active_cue(context.scene)
        if coll is None:
            self.report({'WARNING'}, "No active cue"); return {'CANCELLED'}
        have = {d.obj.name for d in coll.mw_drives if d.obj}
        added, skipped = 0, 0
        for o in context.selected_objects:
            if o.name in have:
                continue
            if not _drivable(o):
                skipped += 1
                continue
            d = coll.mw_drives.add(); d.obj = o
            have.add(o.name); added += 1
        if coll.mw_drives:
            coll.mw_drives_active = len(coll.mw_drives) - 1
        coll.mw_action_active = 'DRIVES'
        if added:
            self.report({'INFO'}, f"Driving {added} handle(s)")
        else:
            self.report({'WARNING'},
                        "Nothing added — selected object(s) expose no Progress input"
                        if skipped else "Nothing to add")
        return {'FINISHED'}
















class MW_OT_drive_bind(bpy.types.Operator):
    """Right-click any animatable property -> Bind to Cue."""
    bl_idname = "motionwerks.drive_bind"
    bl_label = "Bind to Cue"
    bl_description = "Have the active cue drive this property from its marker"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (_active_cue(context.scene) is not None
                and getattr(context, "button_prop", None) is not None)

    def execute(self, context):
        coll = _active_cue(context.scene)
        if coll is None:
            self.report({'WARNING'}, "No active cue"); return {'CANCELLED'}
        ptr = getattr(context, "button_pointer", None)
        prop = getattr(context, "button_prop", None)
        if ptr is None or prop is None:
            self.report({'WARNING'}, "No property under the cursor"); return {'CANCELLED'}

        # id_data is the ID that will actually own the fcurve, and path_from_id is the
        # path relative to it — exactly the pair keyframe_insert needs.
        owner = ptr.id_data
        try:
            path = ptr.path_from_id(prop.identifier)
        except Exception:
            self.report({'WARNING'}, "That property cannot be addressed by path")
            return {'CANCELLED'}
        if path is None:
            self.report({'WARNING'}, "That property cannot be addressed by path")
            return {'CANCELLED'}

        obj = owner if isinstance(owner, bpy.types.Object) else None
        use_data = False
        if obj is None:
            # a data-block (camera, light...) — find an object using it
            obj = next((o for o in context.scene.objects if o.data == owner), None)
            use_data = True
        if obj is None:
            self.report({'WARNING'}, "No object in this scene owns that property")
            return {'CANCELLED'}

        try:
            cur = float(ptr.path_resolve(prop.identifier)
                        if not prop.is_array else ptr.path_resolve(prop.identifier)[0])
        except Exception:
            cur = 0.0

        d = coll.mw_drives.add()
        d.obj = obj
        d.data_path = path
        d.use_data = use_data
        d.array_index = -1
        d.value_from = cur
        d.value_to = cur if cur else 1.0
        coll.mw_drives_active = len(coll.mw_drives) - 1
        coll.mw_action_active = 'DRIVES'
        self.report({'INFO'}, "Cue drives %s.%s — set From/To in the Drives list"
                    % (owner.name, path))
        return {'FINISHED'}


def _drive_context_menu(self, context):
    if getattr(context, "button_prop", None) is not None and _active_cue(context.scene):
        self.layout.separator()
        self.layout.operator("motionwerks.drive_bind", icon='DRIVER')


class MW_OT_drive_remove(bpy.types.Operator):
    bl_idname = "motionwerks.drive_remove"
    bl_label = "Remove"
    bl_description = "Stop driving this handle (its keyframes are left alone)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        coll = _active_cue(context.scene)
        if coll is None:
            return {'CANCELLED'}
        i = coll.mw_drives_active
        if not (0 <= i < len(coll.mw_drives)):
            return {'CANCELLED'}
        coll.mw_drives.remove(i)
        coll.mw_drives_active = min(i, max(0, len(coll.mw_drives) - 1))
        return {'FINISHED'}


def _sync_cues(context, only=None):
    """Retime cues to their markers' current frames. Returns how many moved.

    `only` limits the walk to cues whose marker NAME is in that set. The live watcher
    knows exactly which marker moved, so it does a fraction of the work the Sync
    button does — the button passes None and walks every cue.

    ⚠ The delta comes from `coll["mw_marker_frame"]`, NOT from the caller, so this is
    self-correcting: a second run is a no-op, and a run after several unsynced moves
    catches up in one go.
    """
    scene = context.scene
    moved = 0
    for coll in _cue_colls(scene):
        name = coll.get("mw_marker", "")
        if only is not None and name not in only:
            continue
        mk = scene.timeline_markers.get(name)
        if mk is None:
            continue
        delta = mk.frame - int(coll.get("mw_marker_frame", mk.frame))
        if delta == 0:
            continue
        shifted_whole = set()
        for o in _cue_objects(coll):
            a = _anchor_of(o)
            tgt = a if a else o
            _shift_keyframes(tgt, delta)
            shifted_whole.add(tgt.name)
            if a is not None and "_animtb_frame_start" in a.keys():
                a["_animtb_frame_start"] = int(a["_animtb_frame_start"]) + delta

        # Material's slider keyframes live on the MATERIAL's node tree, not on any
        # object, so no object-walk can reach them. One material may be shared by
        # several objects — shift it once.
        seen_mats = set()
        for it in _material_items(coll):
            for slot in it.obj.material_slots:
                mat = slot.material
                if mat is None or mat.name in seen_mats or mat.node_tree is None:
                    continue
                if _slider_of(mat) is None:
                    continue
                seen_mats.add(mat.name)
                _shift_keyframes(mat.node_tree, delta,
                                 path_filter=lambda p: p == SLIDER_PATH)

        # Driven handles live on other objects entirely — shift only their
        # Progress curve, and skip anything already shifted wholesale.
        for d in _drive_items(coll):
            target, p = _drive_target(d)
            if target is None:
                continue
            # object-level drives on a cue member already moved with the wholesale
            # shift; data-level ones live on another ID and never do.
            if target == d.obj and d.obj.name in shifted_whole:
                continue
            _shift_keyframes(target, delta, path_filter=lambda q, _p=p: q == _p)

        coll["mw_marker_frame"] = mk.frame
        moved += 1

    # The camera track is DERIVED from the shots and their marker frames, so it is
    # rebuilt rather than shifted — no per-key arithmetic to get wrong, and it self-
    # corrects if markers were reordered.
    if moved:
        _rebuild_camera(context)          # shots bound to markers follow them
    return moved



class MW_OT_sync(bpy.types.Operator):
    bl_idname = "motionwerks.sync"
    bl_label = "Sync to Markers"
    bl_description = "Retime every cue to its marker's current frame (move markers, then Sync)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        moved = _sync_cues(context)
        self.report({'INFO'}, f"Synced {moved} cue(s)")
        return {'FINISHED'}

_item_pick_cache = []
_ITEM_DEFAULT = '__cue_default__'


def _item_preset_pick_items(self, context):
    """Presets available to a single item, plus 'Cue default' to clear the override."""
    _item_pick_cache.clear()
    _item_pick_cache.append((_ITEM_DEFAULT, "Cue default", "Use the cue's motion"))
    scene = getattr(context, "scene", None) if context else None
    if scene:
        for pr in scene.motionwerks_presets:
            _item_pick_cache.append((pr.name, pr.name, _preset_summary(pr)))
    return list(_item_pick_cache)


class MW_OT_item_preset_pick(bpy.types.Operator):
    bl_idname = "motionwerks.item_preset_pick"
    bl_label = "Item Preset"
    bl_description = "Give this object its own preset, or fall back to the cue's motion"
    bl_options = {'REGISTER', 'UNDO'}
    preset: bpy.props.EnumProperty(name="Preset", items=_item_preset_pick_items)

    def execute(self, context):
        scene = context.scene
        coll = _active_cue(scene)
        if coll is None:
            return {'CANCELLED'}
        _ensure_items(coll)
        item = _active_item(coll)
        if item is None:
            self.report({'WARNING'}, "No active object in the cue"); return {'CANCELLED'}
        item.preset = "" if self.preset == _ITEM_DEFAULT else self.preset
        if coll.get("mw_marker_frame") is not None:
            _apply_motion(context, coll)        # re-time so the change is visible
        return {'FINISHED'}


class MW_OT_items_apply_preset(bpy.types.Operator):
    bl_idname = "motionwerks.items_apply_preset"
    bl_label = "Apply to All"
    bl_description = "Give every object in this cue the selected object's preset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        coll = _active_cue(scene)
        if coll is None:
            return {'CANCELLED'}
        _ensure_items(coll)
        act = _active_item(coll)
        if act is None:
            self.report({'WARNING'}, "No active object in the cue"); return {'CANCELLED'}
        target = act.preset
        for it in coll.mw_items:
            it.preset = target
        if coll.get("mw_marker_frame") is not None:
            _apply_motion(context, coll)
        label = target or "Cue default"
        self.report({'INFO'}, f"All objects now use '{label}'")
        return {'FINISHED'}


class MW_OT_item_reset(bpy.types.Operator):
    bl_idname = "motionwerks.item_reset"
    bl_label = "Reset Item"
    bl_description = ("Unwind this object's anchor and clear its Motionwerks keyframes, so you can "
                     "reposition it and apply again from clean")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        coll = _active_cue(scene)
        if coll is None:
            return {'CANCELLED'}
        _ensure_items(coll)
        item = _active_item(coll)
        if item is None:
            self.report({'WARNING'}, "No active object in the cue"); return {'CANCELLED'}
        o = item.obj

        # unwind the anchor: reset it to rest, hand the object back to the anchor's parent
        anchor = _anchor_of(o)
        if anchor is not None:
            _reset_anchor_to_rest(anchor)
            context.view_layer.update()
            grandparent = anchor.parent
            world = o.matrix_world.copy()
            o.parent = grandparent
            o.matrix_world = world
            bpy.data.objects.remove(anchor, do_unlink=True)

        # drop the object's own animation + visibility keys, and its children's visibility
        tree = [o] + _descendants(o)
        for t in tree:
            for dp in ("location", "rotation_euler", "scale", "hide_viewport", "hide_render"):
                _clear_fcurves(t, dp)
            t.hide_viewport = False         # clearing keys can leave it stuck hidden
            t.hide_render = False
        self.report({'INFO'}, f"Reset '{o.name}' — reposition it, then Apply Motion")
        return {'FINISHED'}


class MW_OT_preset_save(bpy.types.Operator):
    bl_idname = "motionwerks.preset_save"
    bl_label = "Save as Preset"
    bl_description = ("Save the selected object's current motion as a preset and assign it "
                     "(overwrites a preset with the same name)")
    bl_options = {'REGISTER', 'UNDO'}
    name: bpy.props.StringProperty(name="Name", default="Preset")

    def invoke(self, context, event):
        coll = _active_cue(context.scene)
        if coll is not None:
            it = _active_item(coll)
            if it is not None and it.preset:
                self.name = it.preset
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene
        coll = _active_cue(scene)
        if coll is None:
            self.report({'WARNING'}, "No active cue"); return {'CANCELLED'}
        nm = self.name.strip()
        if not nm:
            self.report({'WARNING'}, "Preset name cannot be empty"); return {'CANCELLED'}
        dst = _find_preset(scene, nm)
        if dst is None:
            dst = scene.motionwerks_presets.add()
        dst.name = nm
        _copy_preset(_active_motion(scene, coll), dst)
        it = _active_item(coll)
        if it is not None:
            it.preset = nm          # the object now uses the preset it was saved from
        self.report({'INFO'}, f"Saved preset '{nm}'")
        return {'FINISHED'}


# ===========================================================================
# MATERIAL ACTION — the second thing a cue can do, alongside Motion.
# Same shape as Motion: its own object list + its own schedule, timed off the
# cue's marker. (Motion + Material are the first two "actions"; once the UI
# settles these generalise into one typed Action list.)
# ===========================================================================
def _ensure_transition_material(name, mat_a, mat_b, axis, coord_type,
                                softness, noise_amount, noise_scale, b_is_alpha):
    """Build (or rebuild in place) a named transition material, so re-applying a cue
    doesn't pile up duplicate materials or break existing assignments."""
    existing = bpy.data.materials.get(name)
    fresh = _build_transition_material(
        name=name + "__tmp", mat_a=mat_a, mat_b=mat_b, axis=axis, coord_type=coord_type,
        softness=softness, noise_amount=noise_amount, noise_scale=noise_scale,
        b_is_alpha=b_is_alpha)
    if existing is None:
        fresh.name = name
        return fresh
    # move the freshly-built node tree into the existing datablock, keeping assignments
    existing.use_nodes = True
    existing.node_tree.nodes.clear()
    _copy_node_tree_into(fresh.node_tree, existing.node_tree, skip_output=False)
    try:
        existing.surface_render_method = fresh.surface_render_method
    except Exception:
        pass
    existing.use_backface_culling = fresh.use_backface_culling
    bpy.data.materials.remove(fresh)
    return existing


def _material_items(coll):
    """Read-only: the cue objects taking part in the Material action, in order."""
    return [it for it in coll.mw_items
            if it.obj and it.use_material and it.obj.type in _ITEM_TYPES]


def _apply_material_action(context, coll, frame):
    """Assign a transition material to the action's objects and keyframe its slider so the
    change plays out from the cue's marker."""
    m = coll.mw_material
    if m.mat_a is None or (m.mat_b is None and not m.b_is_alpha):
        return 0
    items = _material_items(coll)
    if not items:
        return 0

    b_label = "Alpha" if m.b_is_alpha else m.mat_b.name
    base = f"MW_{coll.get('mw_name', coll.name)}_{m.mat_a.name}_{b_label}"
    span = max(1, m.timing)

    for i, it in enumerate(items):
        o = it.obj
        # one material per object lets them stagger; shared means they sweep together
        name = f"{base}_{o.name}" if m.per_object else base
        mat = _ensure_transition_material(
            name=name, mat_a=m.mat_a, mat_b=m.mat_b, axis=m.axis, coord_type=m.coord_type,
            softness=m.softness, noise_amount=m.noise_amount, noise_scale=m.noise_scale,
            b_is_alpha=m.b_is_alpha)
        if o.data and hasattr(o.data, "materials"):
            if mat.name not in [ms.name for ms in o.data.materials if ms]:
                o.data.materials.clear()
                o.data.materials.append(mat)
        start = frame + (i * m.spacing if m.per_object else 0)
        _key_slider(mat, start, start + span, reverse=m.reverse,
                    curve=m.curve, easing=m.easing)
        if not m.per_object and i == 0:
            m.built = mat
        elif m.per_object:
            m.built = mat
    return len(items)






































# ---------------------------------------------------------------------------
# MOGRAPH — a per-cue cloner. Reuses MW_Cloner (generator) + MW_InstanceMotion
# (driver), the same driver fracture uses. The clones live on a generated carrier
# object so nothing in the cue's object list is touched.
# ---------------------------------------------------------------------------



























# ---------------------------------------------------------------------------
# CUE BINDING — driving external module handles
# ---------------------------------------------------------------------------
def _progress_path_of(obj):
    """The keyframable Progress path on obj, or None.

    THE CONTRACT: any GN modifier with a float input named "Progress" is drivable. No
    import of the module's addon, no registration — discovery only, so this keeps working
    if Mographwerks is absent, renamed, or replaced by something hand-built. An object may
    override the search by publishing `obj["werks_progress"]` directly.
    """
    if obj is None:
        return None
    explicit = obj.get("werks_progress")
    if explicit:
        return explicit
    for m in obj.modifiers:
        if m.type != 'NODES' or m.node_group is None:
            continue
        for s in m.node_group.interface.items_tree:
            if getattr(s, "in_out", "") == 'INPUT' and s.name == "Progress":
                return 'modifiers["%s"].properties.inputs.%s.value' % (m.name, s.identifier)
    return None


def _drivable(obj):
    return _progress_path_of(obj) is not None


def _drive_target(d):
    """(owning ID, path) for a drive, or (None, None) if it cannot be resolved.

    ⚠ Blender REFUSES to keyframe a path that spans two ID blocks ("path spans ID
    blocks"), so a camera's lens must be keyed on the Camera DATA, not the Object.
    That is what `use_data` names — the owner, not a convenience.
    """
    obj = d.obj
    if obj is None:
        return None, None
    if not d.data_path:                      # the original auto-Progress contract
        p = _progress_path_of(obj)
        return (obj, p) if p else (None, None)
    owner = obj.data if d.use_data else obj
    if owner is None:
        return None, None
    try:
        owner.path_resolve(d.data_path)
    except Exception:
        return None, None
    return owner, d.data_path


def _drive_items(coll):
    """Read-only: the cue's drives whose target still resolves."""
    return [d for d in coll.mw_drives if _drive_target(d)[0] is not None]


def _drive_set_value(id_block, path, array_index, value):
    """Write a value at an arbitrary path. Splits owner from property so paths with
    subscripts (modifiers["X"].levels) and nested structs (dof.focus_distance) work."""
    owner_path, _, prop = path.rpartition(".")
    try:
        owner = id_block.path_resolve(owner_path) if owner_path else id_block
        cur = getattr(owner, prop)
        if hasattr(cur, "__len__") and not isinstance(cur, str):
            if array_index is not None and array_index >= 0:
                cur[array_index] = value
            else:
                for i in range(len(cur)):
                    cur[i] = value
        else:
            setattr(owner, prop, type(cur)(value) if isinstance(cur, (bool, int)) else value)
        return True
    except Exception:
        return False


def _clear_drive_anim(obj, path):
    if not (obj.animation_data and obj.animation_data.action):
        return
    for fc in list(_iter_fcurves(obj.animation_data.action)):
        if fc.data_path == path:
            _fcurve_container_remove(obj.animation_data.action, fc)














_CAM_PATHS = ("location", "rotation_euler")




















def _apply_drives(context, coll, frame):
    """Key each driven handle 0 -> 1 from the cue's marker."""
    n = 0
    for d in _drive_items(coll):
        target, path = _drive_target(d)
        if target is None:
            continue
        _clear_drive_anim(target, path)
        start = frame + d.delay
        end = start + max(1, d.timing)
        a, b = d.value_from, d.value_to
        if d.reverse:
            a, b = b, a
        idx = d.array_index if d.array_index >= 0 else None
        kw = {} if idx is None else {"index": idx}
        if not _drive_set_value(target, path, d.array_index, a):
            continue
        target.keyframe_insert(data_path=path, frame=start, **kw)
        _drive_set_value(target, path, d.array_index, b)
        target.keyframe_insert(data_path=path, frame=end, **kw)
        _apply_curve(target, path, d.curve, d.easing,
                     in_like=(b >= a), array_index=idx)
        n += 1
    return n




# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# ACTIONS — a cue's actions are a fixed set of types, drawn as a stack. Adding a
# new one (Camera, Mograph) means a row here plus a _draw_action_* function.
# ---------------------------------------------------------------------------
_ACTION_DEFS = (
    ('MOTION', "Motion", 'FORCE_HARMONIC'),
    ('MATERIAL', "Material", 'MATERIAL'),
    ('DRIVES', "Drives", 'DRIVER'),
)


_ACTION_FLAG = {'MOTION': "use_motion", 'MATERIAL': "use_material"}


def _action_flag(key):
    return _ACTION_FLAG.get(key)


def _action_state(coll, key):
    """('ALL' | 'SOME' | 'NONE', n_on, n_total) for an action across the cue's objects.

    There is exactly ONE piece of state behind an action: which objects take part in
    it. Before 1.4.0 there was also a per-action `enabled` switch, so an object could
    be toggled on for an action that was itself off and nothing would happen — two
    gates for one idea, which is what made the panel hard to read.
    """
    if key == 'DRIVES':
        n = len(_drive_items(coll))
        return ('ALL', n, n) if n else ('NONE', 0, len(coll.mw_drives))
    flag = _action_flag(key)
    items = _all_items(coll)
    if flag is None or not items:
        return 'NONE', 0, len(items)
    on = sum(1 for it in items if getattr(it, flag))
    if on == 0:
        return 'NONE', 0, len(items)
    return ('ALL' if on == len(items) else 'SOME'), on, len(items)


def _action_on(coll, key):
    """An action runs when at least one object takes part in it."""
    return _action_state(coll, key)[0] != 'NONE'


def _action_items(coll, key):
    if key == 'MOTION':
        return _ordered_items(coll)
    if key == 'MATERIAL':
        return _material_items(coll)
    if key == 'DRIVES':
        return _drive_items(coll)
    return []


def _cue_action_badges(coll):
    """Icons for the actions a cue actually has, for the cue list."""
    return [icon for key, _label, icon in _ACTION_DEFS
            if _action_on(coll, key) and _action_items(coll, key)]


def _split(layout):
    c = layout.column(align=True)
    c.use_property_split = True
    c.use_property_decorate = False
    return c


def _draw_axis(layout, pr, prop):
    """A 2x3 X/Y/Z / -X/-Y/-Z toggle grid, like Motionwerks."""
    g = layout.grid_flow(row_major=True, columns=3, align=True)
    for ax in ('X', 'Y', 'Z', '-X', '-Y', '-Z'):
        g.prop_enum(pr, prop, ax)


def _draw_psr(layout, pr):
    """Editable PSR controls for a cue's mw_motion, styled to match Motionwerks."""
    layout.prop(pr, "direction", expand=True)      # In / Out toggle

    b = layout.box().column(align=True)
    b.prop(pr, "scale_enabled", text="Scale")
    if pr.scale_enabled:
        b.prop(pr, "scale_uniform", text="Uniform")
        if not pr.scale_uniform:
            _draw_axis(b, pr, "scale_axis")
        f = b.row(); f.use_property_split = True
        f.prop(pr, "scale_frames", text="Frames")

    b = layout.box().column(align=True)
    b.prop(pr, "move_enabled", text="Move")
    if pr.move_enabled:
        _draw_axis(b, pr, "move_axis")
        f = b.column(align=True); f.use_property_split = True
        f.prop(pr, "move_distance_ft", text="Distance")
        f.prop(pr, "move_frames", text="Frames")
        f.prop(pr, "pause", text="Pause")

    b = layout.box().column(align=True)
    b.prop(pr, "rotation_enabled", text="Rotation")
    if pr.rotation_enabled:
        _draw_axis(b, pr, "rotation_axis")
        f = b.column(align=True); f.use_property_split = True
        f.prop(pr, "rotation_angle_deg", text="Angle")
        f.prop(pr, "rotation_frames", text="Frames")
        f.prop(pr, "rotation_pause", text="Pause")


class MW_UL_objects(bpy.types.UIList):
    """The cue's objects. Row order = animate order; the toggles on the right say which
    of the cue's actions each object takes part in."""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            o = item.obj
            if not o:
                layout.label(text="(missing object)", icon='ERROR')
                return
            row = layout.row(align=True)
            row.label(text=o.name, icon='OBJECT_DATA')
            if item.preset:
                sub = row.row()
                sub.alignment = 'RIGHT'
                sub.label(text=item.preset, icon='PRESET')
            # ⚠ NO `toggle=True` HERE. A toggle draws its own pressed-button chrome, so on
            # the selected row — already painted blue by the UIList — you got a highlight
            # inside a highlight. Rob: "This highlight on highlight feels a little weird."
            # `emboss=False` removes the button entirely and `active` carries the state by
            # dimming, which is the same idiom the Actions stack already uses.
            # ⚠ `active`, NOT `enabled`: enabled would grey the control AND stop it being
            # clicked, so an action switched off for an object could never be switched back
            # on from this row. Same trap as the Shake section's own checkbox.
            t = row.row(align=True)
            t.alignment = 'RIGHT'
            for _flag, _icon in (("use_motion", 'FORCE_HARMONIC'),
                                 ("use_material", 'MATERIAL')):
                sub = t.row(align=True)
                sub.active = getattr(item, _flag)
                sub.prop(item, _flag, text="", icon=_icon, emboss=False)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='OBJECT_DATA')


class _MWChild:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_parent_id = "MW_PT_main"
    panel_icon = 'NONE'

    # Every cue-side panel hides in Camera mode. Held here rather than on each class so a
    # new cue panel cannot forget it and leak into the other mode.
    @classmethod
    def poll(cls, context):
        return _tab(context) == 'CUES'

    def draw_header(self, context):
        self.layout.label(text="", icon=self.panel_icon)


class MW_PT_main(bpy.types.Panel):
    bl_label = "Motionwerks"
    bl_idname = "MW_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY

    # ⚠ NO ICON ON THE MAIN HEADER — suite rule, decided 2026-08-05. It was drawn here AND on
    # the object row below, which is the redundancy Rob objected to. Sub-panels keep theirs:
    # there the icon labels a department rather than repeating the addon's own name.

    def draw(self, context):
        # ⚠ ONE INSTALL, ONE TAB. Camerawerks had its own sidebar tab from v2.5.0 until
        # 2026-08-07; a tester read two tabs as two add-ons and could not find the one they
        # had not installed. The mode row says outright that this is one thing with two
        # halves. Shape borrowed from Mographwerks' Clone/Fracture row.
        # ⚠ The row is ALWAYS drawn, unlike Mographwerks' — there the tab picks what you are
        # about to MAKE and vanishes once you have one, whereas Cues and Camera are two
        # standing modes you move between all session.
        if hasattr(context.scene, "mw_tab"):
            self.layout.prop(context.scene, "mw_tab", expand=True)

        # ⚠ DRAWN IN BOTH MODES, deliberately: cues AND shots both bind by marker name, so a
        # duplicate breaks either one. Silence is what made this cost a bug report — the cues
        # simply stacked on one frame with nothing on screen to say why.
        dups = _duplicate_marker_names(context.scene)
        if dups:
            box = self.layout.box()
            r = box.row()
            r.label(text="Markers share a name", icon='ERROR')
            n = box.column(align=True)
            n.enabled = False
            # ⚠ SHORT LINES — panel labels truncate, they do not wrap, and the informative
            # tail is always what gets cut.
            for name, frames in list(dups.items())[:3]:
                n.label(text="'%s' at %s" % (name, " ".join("f%d" % f for f in frames)))
            if len(dups) > 3:
                n.label(text="...and %d more" % (len(dups) - 3))
            n.label(text="Bound by name, so they all")
            n.label(text="follow the first. Rename one.")


# ---------------------------------------------------------------------------
# Action bodies — each draws one action's settings into the cue panel.
# ---------------------------------------------------------------------------
def _draw_action_motion(layout, context, cue):
    scene = context.scene
    act = _active_item(cue)
    pr = _active_motion(scene, cue)

    # ONE preset control, following the selected object. "Apply to All" makes it the
    # group setting.
    row = layout.row(align=True)
    row.operator_menu_enum("motionwerks.item_preset_pick", "preset",
                           text=(act.preset if (act and act.preset) else "Cue default"))
    row.operator("motionwerks.preset_save", text="", icon='ADD')
    row.operator("motionwerks.items_apply_preset", text="Apply to All", icon='CHECKMARK')
    if act is not None and act.obj is not None:
        sel = layout.row(); sel.enabled = False
        sel.label(text=f"editing: {act.obj.name}", icon='OBJECT_DATA')

    items = _ordered_items(cue)
    n = max(1, len(items))
    distinct = len({it.preset for it in items})

    col = _split(layout)
    col.prop(cue, "mw_duration", text="Duration")
    col.prop(cue, "mw_timing", text="Timing")
    col.prop(cue, "mw_spacing", text="Spacing")
    ce = _split(layout)
    ce.prop(pr, "curve")
    ce.prop(pr, "easing")
    layout.box().prop(pr, "visibility_enabled", text="Visibility Cut", icon='HIDE_OFF')

    # Scale/Move/Rotation detail, collapsed by default so the panel stays short.
    box = layout.box()
    hdr = box.row(align=True)
    hdr.prop(cue, "mw_detail_open", text="", emboss=False,
             icon='TRIA_DOWN' if cue.mw_detail_open else 'TRIA_RIGHT')
    hdr.label(text="Motion Detail")
    if cue.mw_detail_open:
        _draw_psr(box, pr)

    hint = layout.row(); hint.enabled = False
    hint.label(text=f"{cue.mw_duration}f build · {max(1, cue.mw_timing)}f per item · "
                    f"{n} object(s)" + ("" if distinct <= 1 else f" · {distinct} presets"),
               icon='TIME')


def _draw_action_material(layout, context, cue):
    m = cue.mw_material
    col = _split(layout)
    col.prop(m, "mat_a", text="From")
    if not m.b_is_alpha:
        col.prop(m, "mat_b", text="To")
    col.prop(m, "b_is_alpha", text="To Transparent")

    layout.prop(m, "axis", expand=True)          # sweep direction
    col = _split(layout)
    col.prop(m, "softness")
    col.prop(m, "noise_amount", text="Noise")
    col.prop(m, "noise_scale", text="Noise Scale")
    col.prop(m, "coord_type", text="Coords")

    col = _split(layout)
    col.prop(m, "timing", text="Timing")
    col.prop(m, "reverse")
    col.prop(m, "per_object", text="Stagger Objects")
    if m.per_object:
        col.prop(m, "spacing", text="Spacing")
    col.prop(m, "curve")
    col.prop(m, "easing")

    if m.built:
        info = layout.row(); info.enabled = False
        info.label(text=m.built.name, icon='MATERIAL')






class MW_UL_drives(bpy.types.UIList):
    """External handles this cue drives."""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            o = item.obj
            row = layout.row(align=True)
            if o is None:
                row.label(text="(missing)", icon='ERROR'); return
            target, path = _drive_target(item)
            ok = target is not None
            label = o.name if not item.data_path else "%s . %s" % (o.name, item.data_path)
            row.label(text=label, icon='DRIVER' if ok else 'ERROR')
            sub = row.row(); sub.alignment = 'RIGHT'; sub.enabled = False
            sub.label(text=f"{item.timing}f" if ok else "unresolved")
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='DRIVER')


def _draw_action_drives(layout, context, cue):
    items = _drive_items(cue)
    layout.label(text=f"Driven handles ({len(items)})")
    row = layout.row()
    row.template_list("MW_UL_drives", "", cue, "mw_drives", cue, "mw_drives_active", rows=3)
    side = row.column(align=True)
    side.operator("motionwerks.drive_add", text="", icon='ADD')
    side.operator("motionwerks.drive_remove", text="", icon='REMOVE')

    i = cue.mw_drives_active
    if 0 <= i < len(cue.mw_drives):
        d = cue.mw_drives[i]
        col = _split(layout)
        col.prop(d, "obj", text="Target")
        col.prop(d, "data_path", text="Path")
        if d.data_path:
            col.prop(d, "use_data", text="On Object Data")
            col.prop(d, "array_index", text="Index")
            row = col.row(align=True)
            row.prop(d, "value_from", text="From")
            row.prop(d, "value_to", text="To")
        col.separator()
        col.prop(d, "timing")
        col.prop(d, "delay")
        col.prop(d, "curve")
        col.prop(d, "easing")
        col.prop(d, "reverse")
        target, path = _drive_target(d)
        if d.obj is None:
            pass
        elif target is None:
            w = layout.row()
            w.label(text="Path does not resolve on this target", icon='ERROR')
        elif not d.data_path:
            w = layout.row(); w.enabled = False
            w.label(text="Auto: %s" % path, icon='CHECKMARK')
    hint = layout.row(); hint.enabled = False
    hint.label(text="Right-click any property -> Bind to Cue", icon='INFO')






_ACTION_DRAW = {
    'MOTION': _draw_action_motion,
    'MATERIAL': _draw_action_material,
    'DRIVES': _draw_action_drives,
}


class MW_UL_cues(bpy.types.UIList):
    """The cue list, as a native UIList.

    ⚠ It was a hand-rolled column of RADIOBUT_ON/OFF operator buttons until 2026-08-07. Rob:
    *"Right now it is dot selectors. Camera panel is selectable highlights. We should try to
    use Blender native UI whenever possible."* A template_list brings the highlight, inline
    rename, search, scrolling and drag-resize for free, and makes the two lists in this add-on
    behave identically.

    ⚠ It binds to `master.children` — a real bpy_prop_collection of Collections, so
    template_list takes it directly. The active index therefore indexes LINK order, which
    `_renumber` keeps in frame order anyway; the sort below is what guarantees it on screen.
    """
    def filter_items(self, context, data, propname):
        cues = getattr(data, propname)
        helper = bpy.types.UI_UL_list
        flt_flags = []
        if self.filter_name:
            flt_flags = helper.filter_items_by_name(
                self.filter_name, self.bitflag_filter_item, cues, "name")
        if not flt_flags:
            flt_flags = [self.bitflag_filter_item] * len(cues)
        if self.use_filter_sort_alpha:
            return flt_flags, helper.sort_items_by_name(cues, "name")
        scene = context.scene
        return flt_flags, helper.sort_items_helper(
            [(i, _cue_frame(scene, c)) for i, c in enumerate(cues)], key=lambda t: t[1])

    def draw_item(self, context, layout, data, item, icon, active_data, active_prop, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.label(text="", icon='SEQUENCE')
            # bare prop is correct INSIDE a UIList row — this is the rename affordance
            row.prop(item, "name", text="", emboss=False)
            sub = row.row(align=True)
            sub.alignment = 'RIGHT'
            sub.enabled = False
            for ic in _cue_action_badges(item):       # which actions this cue carries
                sub.label(text="", icon=ic)
            sub.label(text="f%d" % _cue_frame(context.scene, item))
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='SEQUENCE')


class MW_PT_cues(_MWChild, bpy.types.Panel):
    """Everything about a cue in one place: its objects, its actions, and the settings
    of whichever action is selected.

    ⚠ NO HEADER. Rob: "Cues and Camera do not need to be hideable headers." The mode row
    directly above already says Cues, so the header repeated it AND offered to collapse the
    only thing in the mode — a control whose sole effect is to empty the panel you just
    switched to. `HIDE_HEADER` keeps it a panel (so it still orders) and drops the bar.
    ⚠ `_MWChild.draw_header` is therefore never called here; the icon goes with the bar.
    """
    bl_label = "Cues"
    bl_order = 0
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        row = layout.row(align=True)
        row.operator("motionwerks.cue_add", text="Add Cue", icon='ADD')
        row.operator("motionwerks.populate_from_markers", text="From Markers", icon='MARKER')

        cues = _cue_colls(scene)
        if not cues:
            layout.label(text="No cues — add one, or pull from your markers", icon='INFO')
            return

        master = _master(scene)
        if not hasattr(scene, "mw_cue_active"):
            return                       # mid-register/unregister; see _tab() for the why
        row = layout.row()
        row.template_list("MW_UL_cues", "", master, "children",
                          scene, "mw_cue_active", rows=4)
        # Side column mirrors the shot list's: remove, then jump to the selected one.
        # ⚠ MIRRORS THE SHOT LIST'S SIDE COLUMN, position for position: remove, then Follow
        # Selection, live markers, and the manual rebuild. Rob: "Camera and cues should feel
        # similar." The Sync sub-panel that used to hold the last two is gone — a whole panel
        # for two buttons, sitting below the list they act on.
        side = row.column(align=True)
        side.operator("motionwerks.cue_remove", text="", icon='REMOVE')
        side.separator()
        side.prop(scene, "mw_cue_follow", text="", icon='PLAY', toggle=True)
        side.prop(scene, "mw_live_sync", text="", icon='MARKER_HLT', toggle=True)
        side.operator("motionwerks.sync", text="", icon='FILE_REFRESH')

        if scene.mw_live_sync:
            h = layout.row(); h.enabled = False
            h.label(text="Cues follow their markers as you drag", icon='INFO')

        cue = _active_cue(scene)
        if cue is None:
            return

        # ⚠ ONE BOX FOR THE ACTIVE CUE, with Actions nested inside it. Rob: "Cues, Actions,
        # Motion should feel cohesive. Actions describe a Cue, Motion describes an Action."
        # That hierarchy was flat before — three sibling blocks separated by blank space, so
        # nothing said the Actions belonged to the cue above them rather than to the panel.
        # Containment states it without a word of explanation.
        # ⚠ TWO LEVELS OF BOX, no more. Mographwerks nests box-in-box once (field stacks
        # inside an effector) and a third would be more chrome than structure in a sidebar.
        cbox = layout.box()
        hdr = cbox.row()
        hdr.label(text=cue.name, icon='OUTLINER_COLLECTION')

        items = _all_items(cue)
        # ⚠ was "Objects (0) — order = animate order", which truncated at sidebar widths.
        cbox.label(text=f"Objects ({len(items)}) — animate order")
        row = cbox.row()
        row.template_list("MW_UL_objects", "", cue, "mw_items",
                          cue, "mw_active_item", rows=5)
        side = row.column(align=True)
        side.operator("motionwerks.cue_objects_add", text="", icon='ADD')
        side.operator("motionwerks.cue_object_remove", text="", icon='REMOVE')
        side.separator()
        side.operator("motionwerks.cue_object_move", text="", icon='TRIA_UP').dir = -1
        side.operator("motionwerks.cue_object_move", text="", icon='TRIA_DOWN').dir = 1
        side.separator()
        side.operator("motionwerks.item_reset", text="", icon='LOOP_BACK')

        # --- the action stack, INSIDE the cue box -----------------------------
        # ⚠ No separator before this. The gap it left read as "unrelated block below" —
        # exactly the opposite of the containment being drawn. Rob: "Can we fix this spacing
        # between Active Cue and Actions?" The list also grew to rows=5 so it fills the side
        # column instead of leaving dead space under itself.
        abox = cbox.box()
        abox.label(text="Actions")
        stack = abox.column(align=True)
        for key, label, icon in _ACTION_DEFS:
            sel = (cue.mw_action_active == key)
            state, on, total = _action_state(cue, key)
            r = stack.row(align=True)
            # all / some / none across the cue's objects — clicking fills or clears
            box_icon = {'ALL': 'CHECKBOX_HLT', 'SOME': 'LAYER_USED',
                        'NONE': 'CHECKBOX_DEHLT'}[state]
            # ⚠ NO RED. This was `r.alert = sel`, which painted the open action's whole row
            # red — Rob: "we should not use red anywhere". `depress` is Blender's own active
            # state (the blue a pressed toggle gets), so a selection reads as a selection and
            # not as an error. Mographwerks uses `alert` ZERO times; this file used it 13.
            r.operator("motionwerks.action_toggle_all", text="", icon=box_icon,
                       emboss=False).key = key
            op = r.operator("motionwerks.action_select", text=label,
                            icon=icon, depress=sel)
            op.key = key
            # ⚠ "—" MEANT NOTHING. Rob: "What are the dashes next to the actions?" It was
            # drawn whenever no object took part, so an empty cue showed three mystery
            # dashes. Now it is always "on/total" when the cue HAS objects — 0/3 says the
            # same thing and says it in units — and blank when there is nothing to count.
            # ⚠ RESERVE THE COUNT COLUMN. Rob: "Drives is longer than Motion and Material."
            # Drives counts DRIVES, not objects, so a cue with none gave total == 0, the
            # count drew as an empty string, the column collapsed to nothing and the button
            # stretched to fill the row. `ui_units_x` fixes the column's width whatever is
            # in it, so all three rows are the same length however they are counted.
            cnt = r.row(); cnt.alignment = 'RIGHT'; cnt.enabled = False
            cnt.ui_units_x = 2.2
            cnt.label(text=(f"{on}/{total}" if total else ""))

        key = cue.mw_action_active
        draw = _ACTION_DRAW.get(key)
        if draw is not None:
            # ⚠ The selected action's settings sit in the SAME box as the action rows,
            # directly under the highlighted one — that is what makes "Motion describes an
            # Action" visible. It also drops the box's old repeated "Motion" heading: the
            # depressed row two lines up already says which action this is.
            abox.separator()
            inner = abox.column()
            if key not in {'MOGRAPH', 'DRIVES'} and not _action_items(cue, key):
                # ⚠ RE-LOOK UP THE LABEL. Dropping the body's heading also dropped the
                # `label = ...` that fed this line, and `label` then resolved to the LAST
                # value left by the `for key, label, icon` loop above — so the hint said
                # "No objects use Drives" whichever action was open. A leaked loop variable
                # that still reads plausibly is the worst kind.
                sel_label = dict((k, l) for k, l, _i in _ACTION_DEFS).get(key, key)
                warn = inner.row(); warn.enabled = False
                # ⚠ SHORT. This read "No objects — toggle {label} on an object above" and
                # rendered as "No objects — togg…n an object above" in Rob's sidebar: panel
                # labels TRUNCATE, they do not wrap, and the informative tail is what goes.
                warn.label(text=f"No objects use {sel_label}", icon='INFO')
            draw(inner, context, cue)

        # ⚠ INSIDE the cue box: Apply acts on the ACTIVE cue, not on the panel. Outside it
        # read as a global apply. scale_y 1.2 is Mographwerks' weight for a section's action.
        cbox.separator()
        ap = cbox.row()
        ap.scale_y = 1.2
        ap.operator("motionwerks.cue_apply", text="Apply Cue", icon='KEYFRAME')


# ---------------------------------------------------------------------------
# CAMERAWERKS — a shot sequence on ONE camera, the Camera half of the tab.
#
# Independent of cues on purpose: camera work happens with or without them. A shot
# may OPTIONALLY follow a marker, which is the whole integration story — bind one to
# a cue's marker and the shot goes wherever that cue goes.
#
# ⚠ It had its own sidebar TAB from v2.5.0 until 2026-08-07. That split was reasoned
# ("there are times you would do camera animation without motionwerks") but a tester
# read two tabs from one install as two add-ons, so the separation now costs more than
# it buys. Same code, same independence — one tab with a mode row.
# ⚠ The generated objects and collection are still called "Camerawerks" (CAM_COLLECTION
# below, "Camerawerks Cam", "Camerawerks Path" …). Renaming those would orphan every
# object in every saved file that the stamp-based delete and _own() find by name.
# ---------------------------------------------------------------------------
_CAM_PATHS = ("location", "rotation_euler")


CAM_COLLECTION = "Camerawerks"


def _cam_collection(context):
    """One home for everything Camerawerks generates, so it never litters the scene root.

    ⚠ Linked FIRST, because cameras belong at the top of the Outliner. `children.link()`
    appends and there is no `children.move()`, so the only way to get first place is to
    relink every sibling after ours.

    ⚠ This only shows if the Outliner's **Filter ▸ Sort Alphabetically** is OFF — it
    defaults ON, and then the Outliner ignores link order entirely and sorts by name.
    Nothing an addon can do about that; it is a per-editor view setting.
    """
    c = bpy.data.collections.get(CAM_COLLECTION)
    if c is None:
        c = bpy.data.collections.new(CAM_COLLECTION)
        root = context.scene.collection
        others = list(root.children)
        root.children.link(c)
        for o in others:
            root.children.unlink(o)
            root.children.link(o)
    return c


def _own(context, obj):
    """Move a generated object into the Camerawerks collection."""
    coll = _cam_collection(context)
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    if obj.name not in coll.objects:
        coll.objects.link(obj)
    return obj


def _is_camera(self, obj):
    return obj.type == 'CAMERA'


FRAME_CAM = "Camerawerks Framing"


def _framing_cam(context):
    """The throwaway camera you frame through, or None."""
    c = context.scene.mw_camrig.frame_cam
    return c if (c is not None and c.name in bpy.data.objects) else None


def _look_through(context, cam):
    """Point every 3D view at `cam` and enter camera view."""
    if cam is None or not context.screen:
        return
    for area in context.screen.areas:
        if area.type != 'VIEW_3D':
            continue
        for sp in area.spaces:
            if sp.type == 'VIEW_3D' and sp.region_3d is not None:
                sp.camera = cam
                sp.region_3d.view_perspective = 'CAMERA'


def _end_framing(context, keep_view=False):
    """Leave framing mode: restore the scene camera and delete the throwaway.

    ⚠ Called defensively from the rebuild as well as from the operators, so a framing
    camera left behind by a crash or an undo cannot linger and quietly become the
    render camera.
    """
    rig = context.scene.mw_camrig
    cam = _framing_cam(context)
    prev = bpy.data.objects.get(rig.frame_prev_cam)
    rig.frame_cam = None
    rig.frame_prev_cam = ""
    if cam is None:
        return False
    if context.scene.camera is cam:
        context.scene.camera = prev if prev is not None else rig.camera
    for area in context.screen.areas if context.screen else ():
        if area.type != 'VIEW_3D':
            continue
        for sp in area.spaces:
            if sp.type == 'VIEW_3D' and getattr(sp, "camera", None) is cam:
                sp.camera = None
            if sp.type == 'VIEW_3D' and getattr(sp, "region_3d", None) is not None:
                # ⚠ lock_camera is on SpaceView3D, not RegionView3D
                sp.lock_camera = False
                if not keep_view and sp.region_3d.view_perspective == 'CAMERA':
                    sp.region_3d.view_perspective = 'PERSP'
    data = cam.data
    bpy.data.objects.remove(cam, do_unlink=True)
    if data is not None and data.users == 0:
        bpy.data.cameras.remove(data)
    return True


def _view_matrix(context):
    """World matrix of the current viewport view — what a camera placed 'here' would be.

    ⚠ In framing mode the FRAMING camera is the answer, not the view: you fly it with
    Lock Camera to View, so its own transform is exactly what you framed — and reading it
    directly is what removes the circularity that made capturing-in-camera-view impossible.
    """
    fc = _framing_cam(context)
    if fc is not None:
        return fc.matrix_world.copy()
    sd = getattr(context, "space_data", None)
    if sd is None or sd.type != 'VIEW_3D':
        return None
    r3d = getattr(sd, "region_3d", None)
    if r3d is None:
        qv = getattr(sd, "region_quadviews", None)
        r3d = qv[-1] if qv else None
    return r3d.view_matrix.inverted() if r3d else None


_CAM_CURVE_ITEMS = [
    ('EASE', "Ease", "Adjustable ease at each end — set the percentages below"),
    ('LINEAR', "Linear", "Constant speed, no ease"),
    ('SINE', "Smooth", "Sine ease"),
    ('CUBIC', "Cubic", "Moderate"),
    ('QUAD', "Snap", "Fast start"),
    ('BACK', "Overshoot", "Overshoots before settling"),
    ('BOUNCE', "Bounce", "Bounces at landing"),
    ('ELASTIC', "Elastic", "Rubbery overshoot"),
]


# Position (m), rotation (deg), speed. Tuned so each reads as its name at 24fps.
_SHAKE_PRESETS = {
    'BREATH':    (0.008, 0.08,  5.0),
    'HANDHELD':  (0.035, 0.45, 12.0),
    'SHOULDER':  (0.080, 0.90, 16.0),
    'RUNNING':   (0.260, 3.20, 34.0),
    'VEHICLE':   (0.030, 0.35, 55.0),
}

_SHAKE_ITEMS = [
    ('BREATH', "Tripod Breath", "Barely there — a locked-off camera that is still alive"),
    ('HANDHELD', "Handheld", "Normal handheld hold"),
    ('SHOULDER', "Shoulder", "Documentary, weightier and looser"),
    ('RUNNING', "Running", "Hard motion"),
    ('VEHICLE', "Vehicle", "Small and fast — engine rumble rather than sway"),
    ('CUSTOM', "Custom", "Set the three values yourself"),
]


def _on_shake_preset(self, context):
    """Presets write the values, then the sliders stay editable — picking one is a
    starting point, not a mode you are locked into."""
    vals = _SHAKE_PRESETS.get(self.shake_preset)
    if vals is not None:
        self.shake_strength, self.shake_rot, self.shake_scale = vals
    _cam_update(self, context)


def _cam_update(self, context):
    """Any Camerawerks setting rebuilds immediately.

    Without this every control needed a manual Rebuild press, which reads as the tool
    ignoring you — the single most confusing thing about the first version.
    """
    try:
        _rebuild_camera(context)
    except Exception:
        pass          # never let a UI edit raise mid-draw


# A MOVE is what the camera DOES DURING a shot. The shot's captured framing is where the
# move STARTS; the move defines where it ENDS.
#
# ⚠ This corrects the v2.28 model, which derived a shot's pose from the PREVIOUS shot — so
# the motion could only happen during a morph INTO the shot, and on a cut it collapsed into
# a one-frame teleport. Measured on a real file: static, a 2.0m jump in a single frame,
# static. A move has to belong to the shot that performs it.
#
# FLY_NEXT ('W') is the unification: a morph is just a move whose destination is read off
# the NEXT shot instead of computed from an axis. It lands exactly on that framing, so there
# is nothing to cut to — A MORPH IS A CUT YOU CANNOT SEE. Hence there is no `transition`
# property: whether a boundary reads as a cut is DERIVED from the move.
#
# ⚠ PAN turns about WORLD Z, not the camera's local Y. A tripod pans about the vertical;
# panning a tilted camera about its own up axis would ROLL THE HORIZON. TILT is local X.
#
# Each entry is a COMPLETE RECIPE — kind, axis, amount, frames, ease_in, ease_out — because
# adding a preset must produce a finished move with nothing left to dial: "sliders should
# tweak the move, not expose it". `frames` is a CREATION-TIME default used to place the next
# shot; it is never stored, so the frame remains the single source of truth.
_MOVE_DEFS = {                     # kind, axis, amount, frames, ease_in, ease_out
    'FLY_NEXT': ('W', None,                       0.0, 60, 30.0, 30.0),
    'PUSH_IN':  ('T', Vector((0.0, 0.0, -1.0)),   2.5, 60, 30.0, 40.0),
    'PULL_OUT': ('T', Vector((0.0, 0.0, 1.0)),    3.0, 72, 30.0, 40.0),
    'DOLLY_L':  ('T', Vector((-1.0, 0.0, 0.0)),   3.0, 48, 25.0, 25.0),
    'DOLLY_R':  ('T', Vector((1.0, 0.0, 0.0)),    3.0, 48, 25.0, 25.0),
    'BOOM_UP':  ('T', Vector((0.0, 1.0, 0.0)),    2.0, 60, 35.0, 45.0),
    'BOOM_DN':  ('T', Vector((0.0, -1.0, 0.0)),   2.0, 60, 35.0, 45.0),
    'PAN':      ('R', 'WORLD_Z',    math.radians(30.0), 36, 20.0, 30.0),
    'TILT':     ('R', 'LOCAL_X',    math.radians(20.0), 36, 25.0, 35.0),
    # Same mechanisms, different numbers — this is where a preset LIBRARY earns its name,
    # and it is why ~15 parametric moves cover a 120-entry baked pack.
    'WHIP_PAN': ('R', 'WORLD_Z',    math.radians(90.0),  8,  0.0,  0.0),
    'SNAP_TILT':('R', 'LOCAL_X',    math.radians(25.0), 10,  0.0, 10.0),
    'SLOW_PUSH':('T', Vector((0.0, 0.0, -1.0)),   1.2, 120, 50.0, 50.0),
    'CRASH_IN': ('T', Vector((0.0, 0.0, -1.0)),   6.0,  14,  0.0, 15.0),
    # ⚠ 'C' uses BOTH properties: move_dist booms, move_angle tilts. The axis slot carries
    # the default TILT so Add Move can seed both from one recipe.
    'CRANE':    ('C', math.radians(-12.0),        2.5,  72, 35.0, 45.0),
    # ⚠ 'O' orbits the TRACK TO target. The constraint aims the camera at every intermediate
    # point, so an orbit only has to solve POSITION — which is why it needs no rotation keys
    # and stays ONE shot rather than the several the original plan costed.
    'ORBIT':    ('O', 'WORLD_Z',    math.radians(90.0), 96, 25.0, 35.0),
}

_MOVE_ITEMS = [
    # ⚠ THE NUMBERS ARE STORAGE, THE ORDER IS UI. Blender persists an enum by its NUMBER,
    # so renumbering silently rewrites every saved file: inserting FLY_NEXT at 1 turned a
    # real shot's Push In into a Fly to Next. Existing identifiers KEEP their original
    # numbers for ever; anything new is APPENDED, wherever it sits in this list.
    ('NONE',     "Cut",         "Hold this framing, then cut to the next shot",
     'IPO_CONSTANT', 0),
    ('FLY_NEXT', "Fly to Next", "Move onto the next shot's framing. It arrives exactly on "
     "it, so there is no visible cut", 'IPO_EASE_IN_OUT', 9),
    ('PUSH_IN',  "Push In",     "Move toward what this shot is looking at", 'TRIA_UP', 1),
    ('PULL_OUT', "Pull Out",    "Move back away from this framing", 'TRIA_DOWN', 2),
    ('DOLLY_L',  "Dolly Left",  "Track sideways to camera left", 'TRIA_LEFT', 3),
    ('DOLLY_R',  "Dolly Right", "Track sideways to camera right", 'TRIA_RIGHT', 4),
    ('BOOM_UP',  "Boom Up",     "Rise straight up, framing unchanged", 'ANCHOR_TOP', 5),
    ('BOOM_DN',  "Boom Down",   "Drop straight down, framing unchanged", 'ANCHOR_BOTTOM', 6),
    ('PAN',      "Pan",         "Turn on the spot about the vertical, like a tripod head",
     'ORIENTATION_GIMBAL', 7),
    ('TILT',     "Tilt",        "Angle up or down on the spot", 'ORIENTATION_VIEW', 8),
    ('ORBIT',    "Orbit",       "Swing around the Track To target, staying the same "
     "distance from it. Needs Aim set to Track To", 'FORCE_VORTEX', 15),
    ('CRANE',    "Crane",       "Boom up while tilting down, the way a jib holds a subject "
     "as it rises", 'CON_PIVOT', 14),
    ('WHIP_PAN', "Whip Pan",    "A fast turn with no ease at either end", 'FF', 10),
    ('SNAP_TILT',"Snap Tilt",   "A sharp tilt that arrives almost immediately",
     'PREV_KEYFRAME', 11),
    ('SLOW_PUSH',"Slow Push",   "A long, barely perceptible creep forward", 'SORTTIME', 12),
    ('CRASH_IN', "Crash In",    "A violent shove toward the subject", 'CON_ROTLIKE', 13),
]

# ⚠ Position comes from the curve in path mode, so a TRANSLATION move cannot be expressed
# there. Pan and Tilt can — they do not move the camera at all.
_MOVE_TRANSLATES = {k for k, v in _MOVE_DEFS.items() if v[0] == 'T'}

# The list row wears the move's OWN icon, so a sequence can be read at a glance. It also
# states the boundary without a second badge: Fly to Next is the only continuous one, so
# its icon IS the "no visible cut" marker and everything else implies a cut.
_MOVE_ICON = {it[0]: it[3] for it in _MOVE_ITEMS}

# Stored eulers are read back as XYZ everywhere else in this file, so derived rotations must
# use the same order or a derived pose and a captured one disagree about the same numbers.
_ROT_ORDER = 'XYZ'


def _shot_start(sh):
    """Where a shot BEGINS — always its own captured framing. Never derived."""
    return (Vector(sh.shot_loc), Euler(tuple(sh.shot_rot), _ROT_ORDER), sh.shot_lens)


ORBIT_PREFIX = "Camerawerks Orbit"
_K = 0.5522847498307936          # circular Bezier handle constant, 4*(sqrt(2)-1)/3


def _clear_orbits(context, cam):
    """Drop every generated orbit constraint and its curve, by identity.

    Regenerated wholesale like everything else — a stale circle from an edited shot would
    otherwise keep driving the camera round the old radius.
    """
    for con in list(cam.constraints):
        if con.name.startswith(ORBIT_PREFIX):
            cam.constraints.remove(con)
    for obj in [o for o in bpy.data.objects
                if o.get("mw_orbit") and o.name.startswith(ORBIT_PREFIX)]:
        d = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if d is not None and d.users == 0:
            bpy.data.curves.remove(d)


def _make_orbit_curve(context, name, centre, start, ang):
    """An OPEN Bezier arc from the camera's own position, spanning exactly `ang`.

    ⚠ NOT a cyclic circle. A closed spline's `offset_factor` 0 is not control point 0, so
    the camera started 10.5 units off its framing. An open arc spanning exactly the orbit
    means factor 0 IS the shot's framing and factor 1 IS the end — nothing to map.

    Handle length `(4/3)·tan(θ/4)·r` makes each Bezier segment a TRUE circular arc for any
    θ, so one segment per 90° is exact rather than an approximation.
    """
    v = Vector((start.x - centre.x, start.y - centre.y, 0.0))
    r = v.length
    if r < 1e-6 or abs(ang) < 1e-6:
        return None
    a0 = math.atan2(v.y, v.x)
    segs = max(1, int(math.ceil(abs(ang) / (math.pi / 2.0))))
    step = ang / segs
    h = r * (4.0 / 3.0) * math.tan(step / 4.0)
    cu = bpy.data.curves.new(name, 'CURVE')
    cu.dimensions = '3D'
    cu.use_path = True
    sp = cu.splines.new('BEZIER')
    sp.bezier_points.add(segs)
    for i, bp in enumerate(sp.bezier_points):
        aa = a0 + step * i
        p = Vector((centre.x + r * math.cos(aa), centre.y + r * math.sin(aa), centre.z))
        t = Vector((-math.sin(aa), math.cos(aa), 0.0)) * h
        bp.co = p
        bp.handle_left_type = bp.handle_right_type = 'FREE'
        bp.handle_left = p - t
        bp.handle_right = p + t
    obj = bpy.data.objects.new(name, cu)
    obj["mw_camrig"] = True
    obj["mw_orbit"] = True
    context.scene.collection.objects.link(obj)
    _own(context, obj)
    return obj


def _orbit_pos(rig, start, ang):
    """A point on the orbit: the camera's offset from the target, turned about world Z."""
    t = rig.track_target
    if t is None:
        return start.copy()
    piv = t.matrix_world.translation
    return piv + (Matrix.Rotation(ang, 3, Vector((0.0, 0.0, 1.0))) @ (start - piv))


def _shot_end(shots, i, rig=None):
    """Where shot i's move FINISHES.

    ⚠ No chaining. Every shot starts from its OWN framing, so a move is local: editing one
    cannot ripple down the list, and there is nothing to re-seed or bake.
    """
    sh = shots[i]
    s_loc, s_rot, s_lens = _shot_start(sh)
    d = _MOVE_DEFS.get(sh.move)
    if d is None:
        return s_loc.copy(), s_rot.copy(), s_lens
    kind, ax = d[0], d[1]
    if kind == 'O':
        if rig is None or rig.aim != 'TRACK' or rig.track_target is None:
            return s_loc.copy(), s_rot.copy(), s_lens
        return _orbit_pos(rig, s_loc, sh.move_angle), s_rot.copy(), s_lens
    if kind == 'C':
        # boom along local Y and tilt about local X, together — the one classic move that
        # needs two axes at once
        basis = s_rot.to_matrix()
        loc = s_loc + (basis @ Vector((0.0, 1.0, 0.0))) * sh.move_dist
        rm = Matrix.Rotation(sh.move_angle, 3, basis @ Vector((1.0, 0.0, 0.0)))
        return loc, (rm @ basis).to_euler(_ROT_ORDER, s_rot), s_lens
    if kind == 'W':
        if i + 1 >= len(shots):
            return s_loc.copy(), s_rot.copy(), s_lens          # nothing to fly to
        n_loc, n_rot, n_lens = _shot_start(shots[i + 1])
        # compatible euler, so the turn takes the short way round the +/-180 seam
        return n_loc, n_rot.to_matrix().to_euler(_ROT_ORDER, s_rot), n_lens
    basis = s_rot.to_matrix()
    if kind == 'T':
        return s_loc + (basis @ ax) * sh.move_dist, s_rot.copy(), s_lens
    if ax == 'WORLD_Z':
        rm = Matrix.Rotation(sh.move_angle, 3, Vector((0.0, 0.0, 1.0)))
    else:
        rm = Matrix.Rotation(sh.move_angle, 3, basis @ Vector((1.0, 0.0, 0.0)))
    return s_loc.copy(), (rm @ basis).to_euler(_ROT_ORDER, s_rot), s_lens


class MW_ShotPG(bpy.types.PropertyGroup):
    """One framing, and what the camera does while it is on it."""
    name: bpy.props.StringProperty(default="Shot")
    frame: bpy.props.IntProperty(name="Frame", default=1, update=_cam_update,
        description="When this shot happens. Ignored while it follows a marker")
    marker: bpy.props.StringProperty(name="Marker", default="", update=_cam_update,
        description="Follow this marker instead of a fixed frame. Point it at a cue's "
                    "marker and the shot moves whenever that cue does")

    # ⚠ There is no `transition`. What happens at the boundary is DERIVED from the move:
    # Fly to Next lands on the next framing so there is no visible cut; anything else
    # leaves the camera elsewhere, and that IS the cut.
    move: bpy.props.EnumProperty(name="Move", items=_MOVE_ITEMS, default='NONE',
        update=_cam_update,
        description="What the camera does during this shot. Cut holds the framing and cuts "
                    "away; Fly to Next moves onto the next shot's framing so there is no "
                    "visible cut; the rest are camera moves out of this framing")
    move_dist: bpy.props.FloatProperty(name="Distance", default=2.5, subtype='DISTANCE',
        update=_cam_update, description="How far to travel. Negative reverses the move")
    move_angle: bpy.props.FloatProperty(name="Angle", default=math.radians(30.0),
        subtype='ANGLE', update=_cam_update,
        description="How far to turn. Negative reverses the move")

    shot_loc: bpy.props.FloatVectorProperty(size=3, subtype='TRANSLATION')
    shot_rot: bpy.props.FloatVectorProperty(size=3, subtype='EULER')
    shot_lens: bpy.props.FloatProperty(default=50.0, min=1.0)

    # ⚠ The property ID stays `hold` — renaming it would drop the value out of every saved
    # file.
    #
    # ⚠ The LABEL was "Offset" between 2026-07-29 and 2026-07-30, on the argument that it
    # "was never a hold". Reverted at Rob's request, and the codebase agrees with him: the
    # rule is "a shot HOLDS its captured framing for `hold` frames, then performs its MOVE",
    # the internals are `hold_end` / `h_end` / "the hold", and Zoom's own description
    # already read "across the hold" — so the UI was contradicting itself.
    hold: bpy.props.IntProperty(name="Hold", default=0, min=0, soft_max=480,
        update=_cam_update,
        description="Frames this shot holds its captured framing before its move begins. "
                    "0 starts moving immediately")
    # ⚠ "Timing", not "Duration" — and NOT for style. The cue Motion panel already draws
    # Duration / Timing / Spacing, where `mw_timing` is "each object's keyframe duration in
    # frames": the same concept as this. Calling this one "Duration" made that word mean the
    # OVERALL span in one tab and a SINGLE move's length in the other. Now Duration always
    # means the whole span and Timing always means how long one action takes. It is also the
    # animator's term — Timing is how many frames an action takes, Spacing is the
    # distribution inside them, which here is Curve / Easing.
    move_frames: bpy.props.IntProperty(name="Timing", default=0, min=0, soft_max=480,
        update=_cam_update,
        description="How many frames the move takes. 0 fills the rest of the shot. "
                    "Whatever is left over is stillness before the cut")
    # ⚠ Zoom is a LENS change, not a dolly, which is why it is not a move: a Zoom move
    # would occupy the shot's single move slot and you could not zoom AND Fly to Next.
    zoom: bpy.props.FloatProperty(name="Zoom", default=0.0, min=-50.0, max=50.0,
        subtype='PERCENTAGE', update=_cam_update,
        description="Focal length change across the hold — positive pushes in, negative "
                    "eases out. Runs alongside whatever the move is doing")

    curve: bpy.props.EnumProperty(name="Curve", items=_CAM_CURVE_ITEMS, default='EASE',
        update=_cam_update)
    easing: bpy.props.EnumProperty(name="Easing", items=_EASING_ITEMS, default='EASE_IN_OUT',
        update=_cam_update)
    # Blender's presets are fixed shapes. A BEZIER segment with adjustable handle lengths is
    # the same thing continuously — 0% is linear, 100% a full hold, the ends independent.
    # ⚠ These describe THIS shot's OWN move now. They used to be "Ease Out of Previous" /
    # "Ease Into This" because a transition lived BETWEEN two shots and had to be owned by
    # one of them — which is exactly why they were confusing.
    ease_in: bpy.props.FloatProperty(name="Ease In", default=40.0,
        min=0.0, max=100.0, subtype='PERCENTAGE', update=_cam_update,
        description="How gently this shot's move gets going. 0 starts at full speed — "
                    "which is what a match cut out of an edit needs")
    ease_out: bpy.props.FloatProperty(name="Ease Out", default=40.0,
        min=0.0, max=100.0, subtype='PERCENTAGE', update=_cam_update,
        description="How gently this shot's move comes to rest. 0 runs at full speed right "
                    "into the edit — which is what a match cut into one needs")

    # A lens does not rack between two numbers you typed — it arrives slightly wrong and
    # corrects. SHELVED 2026-07-27; properties kept so the experiment can be resumed.
    focus_snap: bpy.props.FloatProperty(name="Focus Snap", default=0.0,
        min=0.0, max=150.0, subtype='PERCENTAGE', update=_cam_update,
        description="How hard the lens hunts as it lands on this shot, as a percentage "
                    "of the focus distance")
    focus_settle: bpy.props.IntProperty(name="Find", default=12, min=0, soft_max=120,
        update=_cam_update,
        description="Frames AFTER the shot lands before focus is found")
    focus_bounces: bpy.props.FloatProperty(name="Bounces", default=3.0, min=1.0, max=12.0,
        update=_cam_update,
        description="Roughly how many times the pull swings past the subject")
    focus_lead: bpy.props.IntProperty(name="Pull", default=20, min=0, soft_max=120,
        update=_cam_update,
        description="Frames BEFORE the landing that the pull starts")

class MW_CamRigPG(bpy.types.PropertyGroup):
    camera: bpy.props.PointerProperty(name="Camera", type=bpy.types.Object, poll=_is_camera,
        update=_cam_update)

    # ⚠ A Track To constraint OVERRIDES keyframed rotation (verified: (90,0,0) became
    # (84.9,0,-26.6)), so aiming is a MODE, not an extra. Either each shot's captured
    # framing decides where the camera looks, or the target does.
    aim: bpy.props.EnumProperty(name="Aim", default='SHOT', update=_cam_update,
        items=[('SHOT', "Shot Framing", "Each shot aims the camera exactly as you framed it"),
               ('TRACK', "Track To", "Always point at a target. Shot framing sets position "
                                     "only — the target decides the aim")])
    track_target: bpy.props.PointerProperty(name="Target", type=bpy.types.Object,
        update=_cam_update)

    # ⚠ Blender IGNORES focus_distance whenever focus_object is set, and focus_object is
    # not animatable — so these are mutually exclusive too.
    focus_mode: bpy.props.EnumProperty(name="Focus", default='NONE', update=_cam_update,
        items=[('NONE', "Off", "Leave depth of field alone"),
               # ⚠ "Object", not "Follow Object" — three expanded items in a sidebar left it
               # as "Follow Obj…". Only the DISPLAY NAME changed: the identifier and the
               # item's POSITION are untouched, because Blender persists an enum by its
               # NUMBER and renumbering would silently rewrite saved rigs. The full sentence
               # still lives in the description, which is where a long explanation belongs.
               ('OBJECT', "Object", "Blender holds focus on the object exactly. "
                                    "No settle — focus is simply always correct"),
               ('DISTANCE', "Pull Focus", "Key the focus distance to the subject at each "
                                          "shot, so it can miss and recover like a real "
                                          "lens. Set the snap per shot")])
    focus_target: bpy.props.PointerProperty(name="Focus On", type=bpy.types.Object,
        update=_cam_update)
    # A subject is OPTIONAL. With none, focus sits at this distance and can still
    # snap and breathe — you do not need something to point at to have a lens.
    focus_auto: bpy.props.BoolProperty(name="Auto", default=True, update=_cam_update,
        description="Focus on whatever the camera is actually pointing at, measured per "
                    "shot. Falls back to the fixed distance if the ray hits nothing")
    focus_distance: bpy.props.FloatProperty(name="Distance", default=10.0, min=0.01,
        soft_max=200.0, unit='LENGTH', subtype='DISTANCE', update=_cam_update,
        description="Focus distance when no subject is set")
    focus_breathe: bpy.props.FloatProperty(name="Breathe", default=0.0, min=0.0, max=25.0,
        subtype='PERCENTAGE', update=_cam_update,
        description="Continuous micro-hunting around the focus distance, as a "
                    "percentage of it. A couple of percent reads as a lens that is "
                    "alive rather than locked")
    focus_breathe_speed: bpy.props.FloatProperty(name="Breathe Speed", default=6.0,
        min=0.1, soft_max=60.0, update=_cam_update,
        description="Lower is slower and lazier")
    shots: bpy.props.CollectionProperty(type=MW_ShotPG)
    def _active_update(self, context):
        """Selecting a shot jumps to it — the list becomes a way of REVIEWING the sequence
        rather than just picking a row to edit."""
        if not self.sync_view:
            return
        try:
            if 0 <= self.active < len(self.shots):
                context.scene.frame_set(_shot_frame(context.scene, self.shots[self.active]))
                if self.camera is not None and _framing_cam(context) is None:
                    _look_through(context, self.camera)
        except Exception:
            pass

    active: bpy.props.IntProperty(default=0, update=_active_update)
    sync_view: bpy.props.BoolProperty(name="Follow Selection", default=True,
        description="Selecting a shot jumps the playhead to it and looks through the "
                    "camera, so you see the framing you are editing")
    live_markers: bpy.props.BoolProperty(name="Live Markers", default=True,
        description="Rebuild automatically when a marker a shot follows is moved, so "
                    "cameras track cues with no Sync step")
    frame_cam: bpy.props.PointerProperty(type=bpy.types.Object)
    frame_prev_cam: bpy.props.StringProperty(default="")
    use_path: bpy.props.BoolProperty(name="Use Path", default=False, update=_cam_update,
        description="Fly the camera along an editable Bezier through the shots. Once the "
                    "path exists IT decides the route — drag it in the viewport and the "
                    "shots become waypoints rather than a straight line between poses")
    path_object: bpy.props.PointerProperty(name="Path", type=bpy.types.Object)
    path_resolution: bpy.props.IntProperty(name="Resolution", default=12, min=1, max=64,
        update=_cam_update, description="Curve subdivision — higher is smoother")

    shake_preset: bpy.props.EnumProperty(name="Preset", items=_SHAKE_ITEMS,
        default='HANDHELD', update=_on_shake_preset)
    use_shake: bpy.props.BoolProperty(name="Shake", default=False, update=_cam_update,
        description="Handheld wobble across the whole sequence, on top of the shot moves")
    shake_strength: bpy.props.FloatProperty(name="Position", default=0.05, min=0.0,
        soft_max=1.0, update=_cam_update)
    shake_rot: bpy.props.FloatProperty(name="Rotation", default=0.6, min=0.0,
        soft_max=20.0, update=_cam_update)
    shake_scale: bpy.props.FloatProperty(name="Speed", default=12.0, min=0.1,
        soft_max=100.0, update=_cam_update)


def _shot_frame(scene, shot):
    """A bound shot reads its marker LIVE, so it can never drift out of step — unlike a
    stored delta, which is what Sync exists to repair for cues."""
    if shot.marker:
        mk = scene.timeline_markers.get(shot.marker)
        if mk is not None:
            return mk.frame
    return shot.frame


def _ordered_shots(scene):
    return sorted(scene.mw_camrig.shots, key=lambda sh: _shot_frame(scene, sh))


def _legacy_shot_base(base):
    """'f48' -> 'Shot'.

    ⚠ Shots used to be named from the frame they landed on, and `_renumber_shots` then carried
    that as the base for ever — so a shot captured at f48 stayed "01 f48" even after it moved.
    Rob: "It should auto name Shot 01, Shot 02 and not take the f number." Same shape as
    `_strip_dup_suffix`: heal the legacy name instead of adopting it.
    ⚠ Only a bare f-then-digits is touched, so a shot you deliberately called "f-stop" or
    "focus" keeps its name.
    """
    if len(base) > 1 and base[0] == "f" and base[1:].isdigit():
        return "Shot"
    # ⚠ "Shot 01" is what the old Markers-from-Shots called them, and a shot that adopted such
    # a marker took the whole thing as its base — giving "01 Shot 01". The number in it was
    # never this shot's number.
    head, _, tail = base.partition(" ")
    if head == "Shot" and tail.isdigit():
        return "Shot"
    return base


def _renumber_shots(shots):
    """Number the shots 01, 02, … in playing order, matching how cues are numbered.

    ⚠ The base is re-derived from the CURRENT name every time rather than stored in its own
    property, so renaming a row in the list just works — type "Kitchen" and it comes back as
    "03 Kitchen". (Cues keep a separate `mw_name`, which is why renaming a cue collection in
    the outliner gets overwritten instead.)
    ⚠ Called from _rebuild_camera, never from draw — writing data during draw can loop the
    redraw and is illegal during render. Every add, remove and frame change rebuilds, so
    that one call site covers all of them.
    """
    for i, sh in enumerate(shots, 1):
        new = "%02d %s" % (i, _legacy_shot_base(_strip_number(sh.name).strip()) or "Shot")
        if sh.name != new:
            sh.name = new


def _rig_camera(context, create=False):
    rig = context.scene.mw_camrig
    cam = rig.camera
    if cam is not None and cam.name in bpy.data.objects:
        return cam
    if not create:
        return None
    data = bpy.data.cameras.new("Camerawerks Cam")
    cam = bpy.data.objects.new("Camerawerks Cam", data)
    cam["mw_camrig"] = True          # so we can tell ours from one the user picked
    context.scene.collection.objects.link(cam)
    _own(context, cam)
    rig.camera = cam
    if context.scene.camera is None:
        context.scene.camera = cam
    return cam


def _clear_camera_anim(cam):
    if cam is None:
        return
    if cam.animation_data and cam.animation_data.action:
        act = cam.animation_data.action
        for fc in list(_iter_fcurves(act)):
            # ⚠ ".influence" too, or an orbit's constraint keys SURVIVE the rebuild and
            # accumulate — a stale key at the old frame_end re-engaged Follow Path at the
            # end of the timeline and threw the camera off long after the orbit finished.
            if (fc.data_path in _CAM_PATHS or "offset_factor" in fc.data_path
                    or ".influence" in fc.data_path):
                for m in list(fc.modifiers):
                    fc.modifiers.remove(m)
                _fcurve_container_remove(act, fc)
    d = cam.data
    if d is not None and d.animation_data and d.animation_data.action:
        act = d.animation_data.action
        for fc in list(_iter_fcurves(act)):
            if fc.data_path in ("lens", "dof.focus_distance"):
                for m in list(fc.modifiers):
                    fc.modifiers.remove(m)
                _fcurve_container_remove(act, fc)


def _apply_ease(idb, path, start, end, ease_in, ease_out):
    """Continuous ease via BEZIER handles, instead of a fixed preset shape.

    A handle reaching X% across the segment holds that end that much longer, so 0%
    is linear and the two ends are independent — one control per thing you can
    actually see, rather than a menu of named curves.
    """
    ad = getattr(idb, "animation_data", None)
    if not ad or not ad.action:
        return
    span = max(1.0, float(end - start))
    for fc in _iter_fcurves(ad.action):
        if fc.data_path != path:
            continue
        for kp in fc.keyframe_points:
            f = kp.co[0]
            if abs(f - start) < 0.5:
                kp.interpolation = 'BEZIER'
                # ⚠ The handle we do NOT set stays AUTO, which is computed to run
                # SMOOTHLY THROUGH the key — so the curve sails past the shot and comes
                # back. That overshoot is the wobble on landing. AUTO_CLAMPED keeps the
                # flow but refuses to pass the keyed value.
                kp.handle_left_type = 'AUTO_CLAMPED'
                kp.handle_right_type = 'FREE'
                kp.handle_right = (f + span * (ease_in / 100.0), kp.co[1])
            elif abs(f - end) < 0.5:
                # interpolation too, not just handles — an unstamped key inherits from
                # whatever preceded it and passes that on to the next key inserted
                kp.interpolation = 'BEZIER'
                kp.handle_right_type = 'AUTO_CLAMPED'
                kp.handle_left_type = 'FREE'
                kp.handle_left = (f - span * (ease_out / 100.0), kp.co[1])


def _key_scalar(idb, path, value, frame):
    """Set-and-key an arbitrary scalar (used for the path's offset_factor)."""
    owner_path, _, prop = path.rpartition(".")
    try:
        owner = idb.path_resolve(owner_path) if owner_path else idb
        setattr(owner, prop, value)
        idb.keyframe_insert(data_path=path, frame=frame)
    except Exception:
        pass


def _key_pose(cam, loc, rot, lens, frame, skip_loc=False):
    # In path mode the constraint supplies position, so keying location would fight
    # it — and because Follow Path ADDS to location, a stale key offsets every shot.
    if not skip_loc:
        cam.location = loc
        cam.keyframe_insert(data_path="location", frame=frame)
    cam.rotation_euler = rot
    cam.keyframe_insert(data_path="rotation_euler", frame=frame)
    if cam.data is not None:
        cam.data.lens = lens
        cam.data.keyframe_insert(data_path="lens", frame=frame)


def _set_interp_path(cam, path, frame, interp):
    """Interpolation on ONE data path at one frame — `_set_interp` hits every curve at that
    frame, which would stamp CONSTANT onto the orbit's offset_factor and freeze the move."""
    for ad in (cam.animation_data, cam.data.animation_data if cam.data else None):
        if not ad or not ad.action:
            continue
        for fc in _iter_fcurves(ad.action):
            if fc.data_path != path:
                continue
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 0.5:
                    kp.interpolation = interp


def _set_interp(cam, frame, interp):
    """How a CUT is expressed on a single camera: hold the previous pose, then jump."""
    for ad in (cam.animation_data, cam.data.animation_data if cam.data else None):
        if not ad or not ad.action:
            continue
        for fc in _iter_fcurves(ad.action):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 0.5:
                    kp.interpolation = interp


def _add_focus_hunt(cam, hunts):
    """Autofocus hunting as an F-Curve MODIFIER, not keyframes.

    A real lens does not overshoot once and glide back — it rings down. A restricted
    -range SIN generator with blend_out gives exactly that, and because it rides ON
    the curve it adds no keys, leaves the underlying focus animation hand-editable,
    and can be muted or deleted without touching anything else.

    Amplitude is linear in the control (verified 25%% -> 2.51, 10%% -> 1.00 on a 12m
    subject); the 1.2 corrects for the sine not peaking exactly on the landing frame.
    """
    d = cam.data
    if d is None or not hunts:
        return
    ad = d.animation_data
    if not ad or not ad.action:
        return
    for fc in _iter_fcurves(ad.action):
        if fc.data_path != "dof.focus_distance":
            continue
        for frame, dist, snap, settle, lead, bounces in hunts:
            if not snap:
                continue
            # The pull STRADDLES the landing: fishing during the move, still hunting
            # as the camera settles, focus found a beat later. Resolving exactly on the
            # landing frame is tidier than reality and reads as automation.
            find = max(0, settle)
            span = max(2, lead + find)
            m = fc.modifiers.new('NOISE')
            # ⚠ NOISE, not a sine. A real pull is not a damped oscillator — it is a
            # hand searching for the mark: irregular, and the LATER swings are often
            # the biggest because you overcorrect. A decaying wave reads as the lens
            # gently giving up, which is the opposite of what happens.
            m.strength = dist * (snap / 100.0) * 5.0   # peak ~= strength * 0.2
            m.scale = max(0.5, span / max(1.0, bounces))
            m.depth = 1                                # a little roughness on top
            m.phase = float((frame * 7) % 97)          # each pull differs
            m.use_restricted_range = True
            m.frame_start = frame - lead
            m.frame_end = frame + find
            m.blend_in = 0.0
            # Only a couple of frames of blend, so focus is FOUND rather than drifted
            # onto. Full strength right up to the last moment.
            m.blend_out = min(3.0, span * 0.15)


def _add_focus_breathe(cam, rig):
    """Micro-hunting around the focus distance — the same trick as camera shake, on
    the focus curve. Unrestricted range, so the lens is alive for the whole sequence."""
    d = cam.data
    if d is None or rig.focus_breathe <= 0.0:
        return
    ad = d.animation_data
    if not ad or not ad.action:
        return
    for fc in _iter_fcurves(ad.action):
        if fc.data_path != "dof.focus_distance":
            continue
        base = fc.keyframe_points[0].co[1] if fc.keyframe_points else rig.focus_distance
        m = fc.modifiers.new('NOISE')
        m.strength = abs(base) * (rig.focus_breathe / 100.0)
        m.scale = max(0.1, 100.0 / max(0.1, rig.focus_breathe_speed))
        m.phase = 17.0


def _add_shake(cam, rig):
    if not (cam.animation_data and cam.animation_data.action):
        return
    for fc in _iter_fcurves(cam.animation_data.action):
        if fc.data_path not in _CAM_PATHS:
            continue
        amp = rig.shake_strength if fc.data_path == "location" else math.radians(rig.shake_rot)
        if amp <= 0.0:
            continue
        m = fc.modifiers.new('NOISE')
        m.strength = amp
        m.scale = max(0.1, 100.0 / max(0.1, rig.shake_scale))
        m.phase = (hash(fc.data_path) % 97) + fc.array_index * 13


TRACK_CON = "Camerawerks Track"


def _apply_aim(cam, rig):
    """Track To when asked, and NOT otherwise — a stale constraint would silently
    override every shot's framing."""
    con = cam.constraints.get(TRACK_CON)
    if rig.aim == 'TRACK' and rig.track_target is not None:
        if con is None:
            con = cam.constraints.new('TRACK_TO')
            con.name = TRACK_CON
        con.target = rig.track_target
        con.track_axis = 'TRACK_NEGATIVE_Z'
        con.up_axis = 'UP_Y'
        # ⚠⚠ TRACK TO MUST EVALUATE LAST. Constraints run in stack order, so a Track To
        # sitting above a Follow Path computes its aim from the location BEFORE the path
        # moves the camera — during an orbit that is (0,0,0), giving 86.6 degrees of aim
        # error for the whole move while the POSITION measured perfect. The stack is not
        # cleared between rebuilds, so an existing Track To keeps whatever index it had.
        idx = list(cam.constraints).index(con)
        if idx != len(cam.constraints) - 1:
            cam.constraints.move(idx, len(cam.constraints) - 1)
    elif con is not None:
        cam.constraints.remove(con)


def _apply_focus_mode(cam, rig):
    d = cam.data
    if d is None:
        return
    if rig.focus_mode == 'OBJECT' and rig.focus_target is not None:
        d.dof.use_dof = True
        d.dof.focus_object = rig.focus_target
    else:
        # ⚠ Blender ignores focus_distance entirely while focus_object is set, so the
        # pull-focus mode cannot work until this is cleared.
        d.dof.focus_object = None


PATH_CON = "Camerawerks Path"


def _knot_factors(spline):
    """Arc-length fraction of every control point.

    ⚠ `offset_factor` is measured along ARC LENGTH, not by control-point index — a
    knot two thirds of the way through the points can be a tenth of the way through
    the distance. Verified: segments of 2 and 18 give factors 0.0 / 0.1 / 1.0.
    Recomputed on every rebuild, because dragging one point changes the length
    before every later one.
    """
    bps = list(spline.bezier_points)
    if len(bps) < 2:
        return [0.0]
    lengths = []
    for a, b in zip(bps, bps[1:]):
        pts = interpolate_bezier(a.co, a.handle_right, b.handle_left, b.co, 32)
        lengths.append(sum((pts[i + 1] - pts[i]).length for i in range(len(pts) - 1)))
    total = sum(lengths)
    if total <= 1e-9:
        return [i / max(1, len(bps) - 1) for i in range(len(bps))]
    out, run = [0.0], 0.0
    for L in lengths:
        run += L
        out.append(run / total)
    return out


def _ensure_path(context, shots):
    """The curve object: seeded from the shots, then EDITABLE and authoritative.

    ⚠ "The curve wins" only makes sense for a curve that belongs to THESE shots. A
    path left over from an earlier set of shots would otherwise be preserved as if
    it were deliberate shaping, and the camera would fly the old route while the
    shot list said something else.

    So each control point is stamped with the shot position it was seeded from. A
    point whose shot has since moved (re-take, add, remove) is re-seeded; every
    other point keeps whatever you shaped it into.
    """
    rig = context.scene.mw_camrig
    obj = rig.path_object
    if obj is not None and obj.name not in bpy.data.objects:
        obj = None
    if obj is None:
        cu = bpy.data.curves.new("Camerawerks Path", 'CURVE')
        cu.dimensions = '3D'
        cu.use_path = True
        obj = bpy.data.objects.new("Camerawerks Path", cu)
        obj["mw_camrig"] = True
        context.scene.collection.objects.link(obj)
        _own(context, obj)
        rig.path_object = obj
    cu = obj.data
    cu.resolution_u = rig.path_resolution

    want = len(shots)
    cur = [tuple(round(v, 4) for v in sh.shot_loc) for sh in shots]
    seed = list(obj.get("mw_seed", ()))
    old_seed = [tuple(seed[i:i + 3]) for i in range(0, len(seed), 3)]

    spline = cu.splines[0] if cu.splines else None
    if spline is not None and spline.type != 'BEZIER':
        cu.splines.remove(spline)
        spline = None

    if spline is None or len(spline.bezier_points) != want:
        kept = []
        if spline is not None:
            kept = [(bp.co.copy(), bp.handle_left.copy(), bp.handle_right.copy(),
                     bp.handle_left_type, bp.handle_right_type)
                    for bp in spline.bezier_points]
            cu.splines.remove(spline)
        spline = cu.splines.new('BEZIER')
        if want > 1:
            spline.bezier_points.add(want - 1)
        for i, bp in enumerate(spline.bezier_points):
            unchanged = i < len(old_seed) and i < len(cur) and old_seed[i] == cur[i]
            if unchanged and i < len(kept):
                co, hl, hr, tl, tr = kept[i]
                bp.co = co
                bp.handle_left_type, bp.handle_right_type = tl, tr
                bp.handle_left, bp.handle_right = hl, hr
            else:
                bp.co = shots[i].shot_loc
                bp.handle_left_type = bp.handle_right_type = 'AUTO'
    else:
        # Same count: re-seed only the points whose shot actually moved.
        for i, bp in enumerate(spline.bezier_points):
            moved = i >= len(old_seed) or old_seed[i] != cur[i]
            if moved:
                bp.co = shots[i].shot_loc
                bp.handle_left_type = bp.handle_right_type = 'AUTO'

    obj["mw_seed"] = [c for p in cur for c in p]
    return obj


def _focus_ray(context, rig, origin, rot):
    """Distance to whatever the camera is pointing at.

    A fixed distance is almost never right — the reason focus 'never comes back' is
    usually that it is returning to a number nothing sits at. Measuring per shot is
    what a focus puller does.
    """
    try:
        dg = context.evaluated_depsgraph_get()
    except Exception:
        return None
    if rig.aim == 'TRACK' and rig.track_target is not None:
        direction = (rig.track_target.matrix_world.translation - origin)
        if direction.length < 1e-6:
            return None
        direction = direction.normalized()
    else:
        direction = (rot.to_matrix() @ Vector((0.0, 0.0, -1.0))).normalized()
    hit, loc, _n, _i, obj, _m = context.scene.ray_cast(dg, origin, direction)
    if not hit or (obj is not None and obj.get("mw_camrig")):
        return None
    d = (loc - origin).length
    return d if d > 1e-4 else None


def _shot_point(rig, shots, i, fallback):
    """Where the camera really is at shot i — the PATH control point when a path is
    driving, since a shaped curve no longer passes through the captured position."""
    if rig.use_path and rig.path_object is not None:
        sp = rig.path_object.data.splines[0] if rig.path_object.data.splines else None
        if sp is not None and i < len(sp.bezier_points):
            return rig.path_object.matrix_world @ sp.bezier_points[i].co
    return fallback


def _apply_path_constraint(cam, rig, path_obj):
    con = cam.constraints.get(PATH_CON)
    if rig.use_path and path_obj is not None:
        if con is None:
            con = cam.constraints.new('FOLLOW_PATH')
            con.name = PATH_CON
        con.target = path_obj
        con.use_fixed_location = True
        con.use_curve_follow = False      # rotation stays ours, keyed from the shots
        # ⚠ The constraint ADDS to the object's own location, so it must be zeroed
        # or every shot is offset by whatever the camera happened to sit at.
        cam.location = (0.0, 0.0, 0.0)
        return con
    if con is not None:
        cam.constraints.remove(con)
    return None


def _rebuild_camera(context):
    """Regenerate the camera's whole track from the shot list.

    ONE RULE: a shot holds its captured framing for `hold` frames, then performs its MOVE
    across the rest of its span. What happens at the boundary is DERIVED, never stored — a
    Fly to Next lands exactly on the next shot's framing so there is nothing to cut to, and
    anything else leaves the camera somewhere else, which IS the cut.

    Regenerated wholesale, never patched: there is no stored state to drift.
    """
    scene = context.scene
    rig = scene.mw_camrig
    shots = _ordered_shots(scene)
    _renumber_shots(shots)
    cam = _rig_camera(context)
    if cam is None or not shots:
        return 0
    _clear_orbits(context, cam)
    _clear_camera_anim(cam)

    path_obj = _ensure_path(context, shots) if rig.use_path else None
    con = _apply_path_constraint(cam, rig, path_obj)
    factors = (_knot_factors(path_obj.data.splines[0])
               if con is not None and path_obj.data.splines else None)
    fac_path = 'constraints["%s"].offset_factor' % PATH_CON if con is not None else None

    frames = [_shot_frame(scene, sh) for sh in shots]
    n = len(shots)
    _focus_subj = rig.focus_target or (rig.track_target if rig.aim == 'TRACK' else None)
    _focus_varies = _focus_subj is not None or rig.focus_auto
    _focus_keyed = False
    _focus_hunts = []

    # ⚠ Eases and cuts are applied AFTER all keying, not inline. Blender copies the
    # PRECEDING key's interpolation into a newly inserted one, so a CONSTANT written during
    # the loop leaks forward into every key inserted after it — the bug that made every cut
    # landing silently CONSTANT in v2.27. Deferring removes the ordering hazard entirely.
    segments = []          # (start, end, curve, easing, ease_in, ease_out)
    cuts = []              # frames whose key must hold until the next one

    prev_rot = None
    for i, sh in enumerate(shots):
        f = frames[i]
        nxt = frames[i + 1] if i + 1 < n else None
        # ⚠ The LAST shot has no next frame to bound its move — run it to the scene end.
        last_frame = (nxt - 1) if nxt is not None else max(f + 1, scene.frame_end)

        s_loc, s_rot, s_lens = _shot_start(sh)
        # ⚠ Eulers captured independently can be numerically far apart while visually close
        # (179 vs -179); rebuilding compatible with the previous one pins the short path.
        if prev_rot is not None:
            s_rot = s_rot.to_matrix().to_euler(_ROT_ORDER, prev_rot)
        e_loc, e_rot, e_lens = _shot_end(shots, i, rig)
        e_rot = e_rot.to_matrix().to_euler(_ROT_ORDER, s_rot)

        fly = (sh.move == 'FLY_NEXT' and nxt is not None)
        # A Fly lands ON the next shot's own key, so it owns one frame more than a move
        # that has to be cut away from.
        cap = nxt if fly else last_frame
        hold_end = min(f + sh.hold, cap)
        # ⚠ Timing CAPS the move; the remainder is stillness before the cut. 0 fills the
        # span, which is exactly the old behaviour, so nothing existing changes.
        move_end = (min(hold_end + sh.move_frames, cap) if sh.move_frames > 0 else cap)
        moves = sh.move != 'NONE' and move_end > hold_end
        # ⚠ In path mode position comes from the curve, so a TRANSLATION move cannot be
        # expressed. Pan and Tilt still work — they do not move the camera at all.
        if con is not None and sh.move in _MOVE_TRANSLATES:
            e_loc = s_loc.copy()

        s_fac = factors[i] if factors is not None and i < len(factors) else None
        e_fac = (factors[i + 1] if fly and factors is not None and i + 1 < len(factors)
                 else s_fac)

        # --- the framing, on the shot's own frame ---
        _key_pose(cam, s_loc, s_rot, s_lens, f, skip_loc=con is not None)
        if fac_path is not None and s_fac is not None:
            _key_scalar(cam, fac_path, s_fac, f)

        # --- the hold. Static, except Zoom, which is a LENS change rather than motion ---
        z_lens = s_lens * (1.0 + sh.zoom / 100.0)
        if hold_end > f:
            _key_pose(cam, s_loc, s_rot, z_lens, hold_end, skip_loc=con is not None)
            if fac_path is not None and s_fac is not None:
                _key_scalar(cam, fac_path, s_fac, hold_end)

        # --- the move ---
        if moves and sh.move == 'ORBIT' and con is None \
                and rig.aim == 'TRACK' and rig.track_target is not None:
            # ⚠ A REAL CIRCLE, not sampled keys. Two keys cut the chord and many keys ripple
            # (AUTO_CLAMPED flattens a sinusoid at every sample). A curve is the arc exactly,
            # and it puts the easing back on ONE scalar so `_apply_ease` works as it does
            # for every other move.
            t = rig.track_target.matrix_world.translation
            centre = Vector((t.x, t.y, s_loc.z))
            oc = _make_orbit_curve(context, "%s %d" % (ORBIT_PREFIX, i),
                                         centre, s_loc, sh.move_angle)
            if oc is not None:
                ocon = cam.constraints.new('FOLLOW_PATH')
                ocon.name = "%s %d" % (ORBIT_PREFIX, i)
                ocon.target = oc
                ocon.use_fixed_location = True
                ocon.use_curve_follow = False
                op = 'constraints["%s"].offset_factor' % ocon.name
                ip = 'constraints["%s"].influence' % ocon.name
                # ⚠ Follow Path ADDS to location, so location must be ZERO while it drives.
                # Both switches are CONSTANT so the handover is atomic — a blended frame
                # would put the camera somewhere between the keyed pose and the circle.
                _key_scalar(cam, ip, 0.0, f)
                _key_pose(cam, s_loc, s_rot, s_lens, f)
                _key_scalar(cam, ip, 1.0, hold_end)
                _key_pose(cam, Vector((0.0, 0.0, 0.0)), s_rot, z_lens, hold_end)
                _key_scalar(cam, op, 0.0, hold_end)
                _key_scalar(cam, op, 1.0, move_end)   # the arc IS the orbit
                _key_scalar(cam, ip, 1.0, move_end)
                # ⚠⚠ HAND THE CAMERA BACK. Without this the constraint stays at influence 1
                # for the rest of the timeline and Follow Path keeps ADDING the arc's end
                # position to every later shot — measured 7.455 units of displacement on the
                # very next one. Verifying only INSIDE the orbit span is what hid it.
                if nxt is not None:
                    _key_scalar(cam, ip, 0.0, nxt)
                    _set_interp_path(cam, ip, nxt, 'CONSTANT')
                for fr in (f, hold_end, move_end):
                    _set_interp_path(cam, ip, fr, 'CONSTANT')
                _set_interp_path(cam, "location", f, 'CONSTANT')
                _set_interp_path(cam, "location", hold_end, 'CONSTANT')
                segments.append((hold_end, move_end, sh.curve, sh.easing,
                                 sh.ease_in, sh.ease_out, op))
            prev_rot = s_rot          # the track constraint owns rotation here
        elif moves:
            _key_pose(cam, e_loc, e_rot, e_lens if fly else z_lens, move_end,
                      skip_loc=con is not None)
            if fac_path is not None and e_fac is not None:
                _key_scalar(cam, fac_path, e_fac, move_end)
            segments.append((hold_end, move_end, sh.curve, sh.easing,
                             sh.ease_in, sh.ease_out))
            # ⚠ hold the END pose through the leftover, or the move's last key would
            # interpolate straight on into the next shot and the duration would mean nothing
            if move_end < last_frame:
                _key_pose(cam, e_loc, e_rot, e_lens if fly else z_lens, last_frame,
                          skip_loc=con is not None)
                if fac_path is not None and e_fac is not None:
                    _key_scalar(cam, fac_path, e_fac, last_frame)
            prev_rot = e_rot
        else:
            # nothing happens for the rest of the shot: carry the framing to the edit
            if last_frame > hold_end:
                _key_pose(cam, s_loc, s_rot, z_lens, last_frame, skip_loc=con is not None)
                if fac_path is not None and s_fac is not None:
                    _key_scalar(cam, fac_path, s_fac, last_frame)
            prev_rot = s_rot

        # --- the boundary ---
        if nxt is not None and not fly:
            cuts.append(last_frame)

        if rig.focus_mode == 'DISTANCE' and cam.data is not None:
            subj = _focus_subj
            here = _shot_point(rig, shots, i, s_loc)
            dist = ((here - subj.matrix_world.translation).length if subj is not None
                    else (_focus_ray(context, rig, here, s_rot) or rig.focus_distance
                          if rig.focus_auto else rig.focus_distance))
            if dist and dist > 1e-4:
                cam.data.dof.use_dof = True
                if _focus_varies or not _focus_keyed:
                    _focus_keyed = True
                    cam.data.dof.focus_distance = dist
                    cam.data.keyframe_insert(data_path="dof.focus_distance", frame=f)
                _focus_hunts.append((f, dist, sh.focus_snap, sh.focus_settle,
                                     sh.focus_lead, sh.focus_bounces))

    # --- shape every move, then express the cuts. Order matters: CONSTANT must win. ---
    paths = list(_CAM_PATHS) if con is None else ["rotation_euler"]
    if fac_path is not None:
        paths.append(fac_path)
    for seg in segments:
        a, b, curve, easing, ei, eo = seg[:6]
        segpaths = [seg[6]] if len(seg) > 6 else paths
        if curve == 'EASE':
            for p in segpaths:
                _apply_ease(cam, p, a, b, ei, eo)
            if cam.data is not None and len(seg) <= 6:
                _apply_ease(cam.data, "lens", a, b, ei, eo)
        else:
            for p in segpaths:
                _apply_curve(cam, p, curve, easing, in_like=True)
            if cam.data is not None:
                _apply_curve(cam.data, "lens", curve, easing, in_like=True)
    for cf in cuts:
        _set_interp(cam, cf, 'CONSTANT')

    # File our generated objects every rebuild, not just at creation: anything made before
    # this existed (or dragged out by hand) gets put back.
    for obj in (cam, rig.path_object, rig.track_target, rig.focus_target):
        if obj is not None and obj.get("mw_camrig"):
            _own(context, obj)

    _apply_aim(cam, rig)
    _apply_focus_mode(cam, rig)
    if rig.use_shake:
        _add_shake(cam, rig)
    if rig.focus_mode == 'DISTANCE':
        # SHELVED 2026-07-27 — the focus-hunt experiment never read convincingly. Focus
        # TRACKING and BREATHING stay; re-enable the hunt by restoring its call here.
        _add_focus_breathe(cam, rig)
    return len(shots)


def _looking_through_rig(context):
    """True when the viewport is looking through OUR camera.

    ⚠ In camera view `region_3d.view_matrix` IS the camera's matrix, so capturing
    'the current view' just reads back the camera's own animated pose — you get the
    previous shot again. Looking through a DIFFERENT camera is fine: that is a real
    framing worth capturing.
    """
    sd = getattr(context, "space_data", None)
    if sd is None or sd.type != 'VIEW_3D':
        return False
    r3d = getattr(sd, "region_3d", None)
    if r3d is None or r3d.view_perspective != 'CAMERA':
        return False
    rig_cam = context.scene.mw_camrig.camera
    if rig_cam is None:
        return False
    active = sd.camera or context.scene.camera
    return active == rig_cam


class MWCAM_OT_shot_add(bpy.types.Operator):
    bl_idname = "camerawerks.shot_add"
    bl_label = "Add Shot from View"
    bl_description = ("Capture what you are looking at now as a shot. Creates the sequence "
                      "camera the first time. Captured on a marker, the shot follows it")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        sd = getattr(context, "space_data", None)
        return sd is not None and sd.type == 'VIEW_3D'

    def execute(self, context):
        if _looking_through_rig(context):
            self.report({'ERROR'},
                        "You are looking through the sequence camera, so the view IS the "
                        "previous shot. Press Look Through again to get a free view, frame "
                        "the new shot, then add it.")
            return {'CANCELLED'}
        m = _view_matrix(context)
        if m is None:
            self.report({'WARNING'}, "No 3D viewport view to read"); return {'CANCELLED'}
        scene = context.scene
        rig = scene.mw_camrig
        # Camerawerks REGENERATES the whole camera track, so pointing it at a camera
        # that already carries animation would destroy that animation. Refuse instead.
        existing = rig.camera
        if existing is not None and not existing.get("mw_camrig"):
            ad = existing.animation_data
            has_anim = bool(ad and ad.action and any(
                fc.data_path in _CAM_PATHS for fc in _iter_fcurves(ad.action)))
            if has_anim:
                self.report({'ERROR'},
                            "'%s' already has its own animation — Camerawerks would "
                            "overwrite it. Clear the Camera field to make a new one."
                            % existing.name)
                return {'CANCELLED'}
        first = not len(rig.shots)
        cam = _rig_camera(context, create=True)

        sh = rig.shots.add()
        # ⚠ TWO SHOTS ON ONE FRAME silently destroy each other: both poses get keyed at the
        # same frame, the later write wins, and the framing you just set is discarded.
        # Follow Selection parks the playhead ON a shot, so capturing used to land straight
        # on top of it — measured as an 18.55-unit error between stored and actual pose.
        taken = {_shot_frame(scene, x) for x in rig.shots if x != sh}
        # ⚠ snapshot it: setting rig.active below fires _active_update, which moves
        # frame_current to the new shot — so comparing against it later always says
        # "not nudged" and the message never appears.
        asked = scene.frame_current
        want = asked
        while want in taken:
            want += 1
        sh.frame = want
        # Sitting on a marker is a clear statement of intent, so bind to it — that is
        # what makes a shot follow its cue with no explicit linking step.
        # ⚠ Only when the frame was NOT nudged: a marker on the frame we were pushed off
        # would drag the shot straight back into the collision, because _shot_frame reads
        # the marker LIVE.
        mk = (next((k for k in scene.timeline_markers if k.frame == want), None)
              if want == asked else None)
        # ⚠⚠ AUTO-CREATE ONE IF THERE ISN'T ONE, exactly as cue_add does. Rob: "Shouldn't we
        # auto make markers like Cues? They should functionally work exactly the same." A
        # shot bound to a marker cannot drift and can be retimed by dragging in the timeline
        # — the contract cues have had since the start, and the asymmetry is the whole reason
        # "Markers from Shots" had to exist as a manual catch-up.
        # ⚠ Named "Shot"/"Shot.001" rather than after the numbered shot: cue markers are
        # "Cue"/"Cue.001" while the cue is "01 Cue", and a marker named for a number would go
        # stale the moment the shot list renumbers.
        made_marker = mk is None
        if made_marker:
            mk = scene.timeline_markers.new(_free_marker_name(scene, "Shot"), frame=want)
        sh.marker = mk.name
        # A shot that adopted somebody else's marker takes its name, which says at a glance
        # which cue it is riding. One we made ourselves is just "Shot"; _renumber_shots adds
        # the number.
        sh.name = "Shot" if made_marker else mk.name
        sh.shot_loc = m.translation
        sh.shot_rot = m.to_euler(cam.rotation_mode)
        # ⚠ THE LENS COMES FROM THE CAMERA YOU FRAMED WITH. Reading it off the rig camera
        # captured whatever its animation evaluated to at the current frame — framing at
        # 28mm stored 50mm, a 22mm field-of-view jump the moment you let go.
        _fcam = _framing_cam(context)
        _lens_src = _fcam if _fcam is not None else cam
        sh.shot_lens = _lens_src.data.lens if _lens_src.data else 50.0
        # no transition to set: a new shot defaults to Cut (move NONE), which is the
        # simpler thing to reason about and the more common sequence
        rig.active = len(rig.shots) - 1

        # ⚠ keep_view: framing ends by looking through the RIG camera at the shot just
        # captured, not by dumping you into a free perspective view. Bouncing out made you
        # lose the framing you had just set, which is the one thing you wanted to see.
        _end_framing(context, keep_view=True)
        _look_through(context, cam)
        n = _rebuild_camera(context)
        moved = "" if want == asked else " at f%d (f%d was taken)" % (want, asked)
        follows = (" (marker '%s')" % mk.name) if made_marker else (" (follows '%s')" % mk.name)
        self.report({'INFO'}, "Shot added%s%s — %d in sequence" % (moved, follows, n))
        return {'FINISHED'}


class MWCAM_OT_move_add(bpy.types.Operator):
    bl_idname = "camerawerks.move_add"
    bl_label = "Add Move"
    bl_description = ("Add a shot derived from the selected one - a push, dolly, boom, pan "
                      "or tilt - instead of framing it by hand")
    bl_options = {'REGISTER', 'UNDO'}

    move: bpy.props.EnumProperty(name="Move", items=_MOVE_ITEMS[1:], default='PUSH_IN')

    @classmethod
    def poll(cls, context):
        return len(context.scene.mw_camrig.shots) > 0

    def execute(self, context):
        scene = context.scene
        rig = scene.mw_camrig
        shots = _ordered_shots(scene)
        src = rig.shots[rig.active] if 0 <= rig.active < len(rig.shots) else shots[-1]
        # ⚠⚠ REMEMBER THE INDEX, NOT JUST THE REFERENCE. `rig.shots.add()` below can
        # reallocate the collection, after which `src` no longer compares equal to anything
        # in it and the `list(rig.shots).index(src)` this used to end with raised
        # "MW_ShotPG is not in list". `.add()` APPENDS, so an index taken now stays valid.
        src_index = rig.active if 0 <= rig.active < len(rig.shots) else list(rig.shots).index(src)
        i = shots.index(src)
        here = _shot_frame(scene, src)
        # 48 frames on, but never past the shot that already follows - a move that landed
        # after the next shot would reorder the sequence behind the user's back.
        nxt = _shot_frame(scene, shots[i + 1]) if i + 1 < len(shots) else None
        span = _MOVE_DEFS[self.move][3]
        frame = (here + span if nxt is None
                 else max(here + 1, min(here + span, nxt - 1)))
        if nxt is not None and nxt - here < 2:
            self.report({'ERROR'},
                        "No room between this shot and the next - move the next shot "
                        "later, or select the last shot and add the move there")
            return {'CANCELLED'}

        # ⚠ The MOVE goes on the shot we are standing on — it is what that shot DOES.
        # The new shot is only where the sequence continues afterwards, and it inherits the
        # move's end pose so the cut lands somewhere sensible rather than back at the start.
        d = _MOVE_DEFS[self.move]
        src.move = self.move
        if d[0] in {'R', 'O'}:
            src.move_angle = d[2]
        elif d[0] == 'C':
            src.move_dist = d[2]        # boom
            src.move_angle = d[1]       # ...and the tilt that holds the subject
        else:
            src.move_dist = d[2]
        src.ease_in, src.ease_out = d[4], d[5]
        src.move_frames = d[3]        # the recipe's pace, now a real editable duration

        shots_now = _ordered_shots(scene)
        e_loc, e_rot, e_lens = _shot_end(shots_now, shots_now.index(src), rig)
        sh = rig.shots.add()
        sh.frame = frame
        label = next(it[1] for it in _MOVE_ITEMS if it[0] == self.move)
        sh.name = "after %s" % label
        # ⚠ A DERIVED SHOT GETS A MARKER TOO. shot_add started making one on capture, but
        # Add Move did not — so every move left an unmarked shot behind and "Markers from
        # Shots" kept reappearing as if something were broken. Rob's rule is that shots and
        # cues work the same way, and a shot is a shot however it was made.
        _mk = next((k for k in scene.timeline_markers if k.frame == frame), None)
        if _mk is None:
            _mk = scene.timeline_markers.new(_free_marker_name(scene, "Shot"), frame=frame)
        sh.marker = _mk.name
        sh.shot_loc = e_loc
        sh.shot_rot = e_rot
        sh.shot_lens = e_lens
        rig.active = src_index

        n = _rebuild_camera(context)
        self.report({'INFO'}, "%s added at f%d - %d in sequence" % (label, frame, n))
        return {'FINISHED'}


class MWCAM_OT_move_match(bpy.types.Operator):
    bl_idname = "camerawerks.move_match"
    bl_label = "Match to Previous"
    bl_description = ("Scale this shot's move so it leaves the cut at exactly the speed the "
                      "previous shot's move arrived at it - the match cut, by number")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = context.scene.mw_camrig
        if not (0 <= rig.active < len(rig.shots)):
            return False
        sh = rig.shots[rig.active]
        return sh.move not in {'NONE', 'FLY_NEXT'}

    def execute(self, context):
        scene = context.scene
        rig = scene.mw_camrig
        sh = rig.shots[rig.active]
        shots = _ordered_shots(scene)
        i = shots.index(sh)
        if i < 1:
            self.report({'ERROR'}, "Nothing before this shot to match")
            return {'CANCELLED'}
        prev = shots[i - 1]
        if prev.move == 'NONE':
            self.report({'ERROR'},
                        "The previous shot has no move to match - give it one first")
            return {'CANCELLED'}
        out = _move_speed(scene, shots, i - 1)
        unit = _move_speed(scene, shots, i)
        if out <= 1e-9 or unit <= 1e-9:
            self.report({'ERROR'}, "One of the two moves covers no distance")
            return {'CANCELLED'}
        # ⚠ EASE AND A MATCH CUT ARE MUTUALLY EXCLUSIVE AT THE EDIT. Ease brings a move to
        # rest, which is the one thing the cut cannot survive: the outgoing move decelerates
        # to nothing just as the cut arrives, and the incoming one starts from a standstill.
        # So matching zeroes them rather than fighting them.
        eased = []
        if prev.ease_out > 0.0:
            prev.ease_out = 0.0; eased.append("%s's Ease Out" % prev.name)
        if sh.ease_in > 0.0:
            sh.ease_in = 0.0; eased.append("%s's Ease In" % sh.name)
        # speed is linear in the amount, so one measurement gives the scale factor - and
        # solving THROUGH _move_speed keeps this from becoming a second copy of the maths
        k = out / unit
        if _MOVE_DEFS[sh.move][0] == 'R':
            sh.move_angle *= k
        else:
            sh.move_dist *= k
        self.report({'INFO'}, "Matched at %.3f/f%s"
                    % (out, " - cleared %s" % " and ".join(eased) if eased else ""))
        return {'FINISHED'}


def _new_helper_empty(context, name, display, at):
    e = bpy.data.objects.new(name, None)
    e.empty_display_type = display
    e.empty_display_size = 0.6
    e.show_name = True
    e.location = at
    e["mw_camrig"] = True
    context.scene.collection.objects.link(e)
    _own(context, e)
    return e


def _helper_at(context):
    """Where a new helper empty goes: THE 3D CURSOR.

    ⚠ This used to be the mean of visible mesh ORIGINS, which sounds principled and is not
    — a ground plane with its origin at the world origin drags it to (0,0,0), and any
    object whose origin sits off in a corner skews it, so on an archviz scene it could land
    inside a wall. The cursor is Blender's universal "put it here": an INSTRUCTION rather
    than a guess, already in the user's muscle memory, and wrong in a predictable way.
    """
    return context.scene.cursor.location.copy()


def _helper_label(context, verb, noun):
    """Name the OUTCOME, including the object.

    ⚠ "Use Selected" named neither what it would use nor what it would make — it did not
    even say whether an empty gets created (it does not; it points straight at the object).
    Showing the name lets you see before you click whether it grabbed what you meant.
    """
    sel = [o for o in context.selected_objects if o.type != 'CAMERA']
    if sel:
        return "%s '%s'" % (verb, sel[0].name)
    return "New %s at Cursor" % noun


class MWCAM_OT_add_track_empty(bpy.types.Operator):
    bl_idname = "camerawerks.add_track_empty"
    bl_label = "Add Track Empty"
    bl_description = ("Aim the camera at the selected object. With nothing selected, "
                      "creates an empty to aim at, at the 3D cursor")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        rig = context.scene.mw_camrig
        sel = [o for o in context.selected_objects if o.type != 'CAMERA']
        if sel:
            rig.track_target = sel[0]
            rig.aim = 'TRACK'
            _rebuild_camera(context)
            self.report({'INFO'}, "Aiming at %s" % sel[0].name)
            return {'FINISHED'}
        e = _new_helper_empty(context, "Camera Target", 'SPHERE', _helper_at(context))
        rig.track_target = e
        rig.aim = 'TRACK'
        _rebuild_camera(context)
        self.report({'INFO'}, "Created %s at the 3D cursor — move it to aim" % e.name)
        return {'FINISHED'}


class MWCAM_OT_add_focus_empty(bpy.types.Operator):
    bl_idname = "camerawerks.add_focus_empty"
    bl_label = "Add Focus Empty"
    bl_description = ("Hold focus on the selected object. With nothing selected, creates "
                      "an empty to focus on, at the 3D cursor")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        rig = context.scene.mw_camrig
        # Only choose a mode when none is set — forcing OBJECT here used to drag the
        # user out of Pull Focus the moment they picked a subject for it.
        if rig.focus_mode == 'NONE':
            rig.focus_mode = 'DISTANCE'
        sel = [o for o in context.selected_objects if o.type != 'CAMERA']
        if sel:
            rig.focus_target = sel[0]
            _rebuild_camera(context)
            self.report({'INFO'}, "Focusing on %s" % sel[0].name)
            return {'FINISHED'}
        e = _new_helper_empty(context, "Camera Focus", 'PLAIN_AXES', _helper_at(context))
        rig.focus_target = e
        _rebuild_camera(context)
        self.report({'INFO'}, "Created %s at the 3D cursor — move it to pull focus"
                    % e.name)
        return {'FINISHED'}


class MWCAM_OT_shot_retake(bpy.types.Operator):
    bl_idname = "camerawerks.shot_retake"
    bl_label = "Re-take from View"
    bl_description = "Replace this shot's framing with the current view"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        sd = getattr(context, "space_data", None)
        rig = context.scene.mw_camrig
        return sd is not None and sd.type == 'VIEW_3D' and 0 <= rig.active < len(rig.shots)

    def execute(self, context):
        if _looking_through_rig(context):
            self.report({'ERROR'},
                        "You are looking through the sequence camera — leave camera view "
                        "first, or you will just re-take the pose it already has.")
            return {'CANCELLED'}
        m = _view_matrix(context)
        if m is None:
            self.report({'WARNING'}, "No 3D viewport view to read"); return {'CANCELLED'}
        rig = context.scene.mw_camrig
        sh = rig.shots[rig.active]
        cam = _rig_camera(context, create=True)
        sh.shot_loc = m.translation
        sh.shot_rot = m.to_euler(cam.rotation_mode)
        sh.shot_lens = cam.data.lens if cam.data else sh.shot_lens
        # Re-taking a derived shot is a statement that THIS framing is the
        # one wanted, so it stops being derived - otherwise the capture
        # would be silently discarded on the very next rebuild.
        sh.move = 'NONE'
        _rebuild_camera(context)
        self.report({'INFO'}, "Re-took %s" % sh.name)
        return {'FINISHED'}


def _unmarked_shots(scene):
    """Shots with no usable marker — including one whose marker has since been deleted."""
    return [sh for sh in _ordered_shots(scene)
            if not sh.marker or scene.timeline_markers.get(sh.marker) is None]


class MWCAM_OT_markers_from_shots(bpy.types.Operator):
    bl_idname = "camerawerks.markers_from_shots"
    bl_label = "Markers from Shots"
    bl_description = ("Give every shot that has none a timeline marker at its frame, so it "
                      "can be dragged and followed. Shots already following a marker are "
                      "left exactly as they are.\n\n"
                      "Since beta.14 a shot gets its marker when it is captured, so this is "
                      "a REPAIR — it only appears for shots made before that, or whose "
                      "marker was deleted")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = getattr(context.scene, "mw_camrig", None)
        return rig is not None and len(rig.shots) > 0

    def execute(self, context):
        scene = context.scene
        shots = _ordered_shots(scene)
        made, reused = [], []
        for pos, sh in enumerate(shots, 1):
            if sh.marker and scene.timeline_markers.get(sh.marker) is not None:
                continue
            f = _shot_frame(scene, sh)
            # ⚠ Same rule as shot_add and cue_add: a marker already AT that frame is the one
            # you meant, whoever put it there. That is what lets a shot and a cue share one.
            mk = next((m for m in scene.timeline_markers if m.frame == f), None)
            if mk is None:
                mk = scene.timeline_markers.new(
                    _free_marker_name(scene, "Shot %02d" % pos), frame=f)
                made.append(mk.name)
            else:
                reused.append(mk.name)
            sh.marker = mk.name
        if not made and not reused:
            self.report({'INFO'}, "Every shot already follows a marker")
            return {'CANCELLED'}
        _rebuild_camera(context)
        bits = []
        if made:
            bits.append("created %d" % len(made))
        if reused:
            bits.append("reused %d" % len(reused))
        self.report({'INFO'}, "Markers: %s" % ", ".join(bits))
        return {'FINISHED'}


class MWCAM_OT_shot_remove(bpy.types.Operator):
    bl_idname = "camerawerks.shot_remove"
    bl_label = "Remove Shot"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = context.scene.mw_camrig
        return 0 <= rig.active < len(rig.shots)

    def execute(self, context):
        rig = context.scene.mw_camrig
        rig.shots.remove(rig.active)
        rig.active = max(0, rig.active - 1)
        cam = _rig_camera(context)
        if cam is not None:
            _clear_camera_anim(cam)
        _rebuild_camera(context)
        return {'FINISHED'}


class MWCAM_OT_delete_all(bpy.types.Operator):
    bl_idname = "camerawerks.delete_all"
    bl_label = "Delete Camerawerks Camera"
    bl_description = ("Remove the sequence camera, its path and helpers, every shot, and all "
                      "the animation Camerawerks wrote. This cannot be undone by rebuilding")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = context.scene.mw_camrig
        return rig.camera is not None or len(rig.shots) > 0

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        rig = scene.mw_camrig
        _end_framing(context)
        gone = []

        # ⚠ A camera the USER assigned is never deleted — only its Camerawerks animation is
        # stripped. The `mw_camrig` stamp is the whole basis for telling them apart, and it
        # is what `shot_add`'s overwrite guard already relies on.
        borrowed = (rig.camera if (rig.camera is not None
                                   and not rig.camera.get("mw_camrig")) else None)
        if borrowed is not None:
            _clear_camera_anim(borrowed)
            for con in list(borrowed.constraints):
                if con.name in (PATH_CON, TRACK_CON):
                    borrowed.constraints.remove(con)

        # ⚠ ONLY stamped objects, and only these four by identity. NEVER a keep-list sweep
        # over bpy.data.objects — that destroyed two of Rob's objects in an earlier session.
        targets = [o for o in (rig.camera, rig.path_object, rig.track_target,
                               rig.focus_target)
                   if o is not None and o.name in bpy.data.objects and o.get("mw_camrig")]
        # ⚠ orbit curves are generated per shot, so they are not on the rig's four pointers
        # — they would be left orphaned in the scene. Still by identity, still stamped.
        targets += [o for o in bpy.data.objects if o.get("mw_orbit")]
        seen = set()
        for o in targets:
            if o.name in seen:
                continue
            seen.add(o.name)
            data = o.data
            if scene.camera is o:
                scene.camera = None
            gone.append(o.name)
            bpy.data.objects.remove(o, do_unlink=True)
            if data is not None and data.users == 0:
                if isinstance(data, bpy.types.Camera):
                    bpy.data.cameras.remove(data)
                elif isinstance(data, bpy.types.Curve):
                    bpy.data.curves.remove(data)

        coll = bpy.data.collections.get(CAM_COLLECTION)
        if coll is not None:
            # ⚠ Removing a collection ORPHANS its contents rather than deleting them, so
            # re-home anything the user put in here before it disappears.
            kept = []
            for o in list(coll.objects):
                coll.objects.unlink(o)
                if not o.users_collection:
                    scene.collection.objects.link(o)
                kept.append(o.name)
            if not coll.children and not coll.objects:
                bpy.data.collections.remove(coll)
            if kept:
                self.report({'WARNING'},
                            "Moved %d object(s) out of the collection: %s"
                            % (len(kept), ", ".join(kept[:4])))

        rig.shots.clear()
        rig.camera = None
        rig.path_object = None
        rig.track_target = None
        rig.focus_target = None
        rig.frame_cam = None
        rig.frame_prev_cam = ""
        rig.active = 0
        rig.use_path = False
        # ⚠ Leaving the scene with NO camera is its own kind of breakage — fall back to any
        # other camera present before giving up.
        if scene.camera is None:
            scene.camera = next((o for o in scene.objects if o.type == 'CAMERA'), None)

        self.report({'INFO'}, "Camerawerks cleared%s%s"
                    % (" — removed %s" % ", ".join(gone) if gone else "",
                       "; kept your camera '%s'" % borrowed.name if borrowed else ""))
        return {'FINISHED'}


class MWCAM_OT_frame_start(bpy.types.Operator):
    bl_idname = "camerawerks.frame_start"
    bl_label = "Frame a Shot"
    bl_description = ("Fly a temporary camera to frame with, so you can see the real frame, "
                      "aspect and guides. Add Shot then captures exactly what you framed")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        sd = getattr(context, "space_data", None)
        return sd is not None and sd.type == 'VIEW_3D'

    def execute(self, context):
        scene = context.scene
        rig = scene.mw_camrig
        _end_framing(context, keep_view=True)          # never stack two
        src = rig.camera
        # ⚠ A THROWAWAY camera, not the rig camera. Flying the rig camera would need its
        # animation muted, and a rig left muted looks exactly like a broken addon. This
        # cannot leave any state wrong: worst case is a stray empty camera.
        data = src.data.copy() if (src is not None and src.data is not None) \
            else bpy.data.cameras.new(FRAME_CAM)
        data.name = FRAME_CAM
        cam = bpy.data.objects.new(FRAME_CAM, data)
        cam["mw_camrig"] = True
        cam["mw_framing"] = True
        scene.collection.objects.link(cam)
        _own(context, cam)

        # start from the shot you are on, so framing is an ADJUSTMENT rather than a restart
        if 0 <= rig.active < len(rig.shots):
            sh = rig.shots[rig.active]
            cam.location = sh.shot_loc
            cam.rotation_euler = sh.shot_rot
            data.lens = sh.shot_lens
        else:
            m = _view_matrix(context)
            if m is not None:
                cam.matrix_world = m

        rig.frame_prev_cam = scene.camera.name if scene.camera is not None else ""
        rig.frame_cam = cam
        scene.camera = cam
        # ⚠ Give the throwaway the SAME aim as the rig, or the preview lies: with Track To
        # the rig camera's rotation is overridden, so the angle you frame by eye is thrown
        # away on capture. With the constraint on, what you see IS what you get — and you
        # are choosing position only, which is the truth of that mode.
        _apply_aim(cam, rig)
        sd = context.space_data
        if sd is not None and sd.type == 'VIEW_3D' and sd.region_3d is not None:
            sd.camera = cam
            sd.region_3d.view_perspective = 'CAMERA'
            sd.lock_camera = True     # ⚠ on the SPACE; navigating now MOVES the camera
        self.report({'INFO'}, "Framing - fly the view, then Capture (or Cancel)")
        return {'FINISHED'}


class MWCAM_OT_frame_cancel(bpy.types.Operator):
    bl_idname = "camerawerks.frame_cancel"
    bl_label = "Cancel Framing"
    bl_description = "Leave framing mode without capturing anything"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _framing_cam(context) is not None

    def execute(self, context):
        _end_framing(context)
        self.report({'INFO'}, "Framing cancelled")
        return {'FINISHED'}


class MWCAM_OT_shot_jump(bpy.types.Operator):
    bl_idname = "camerawerks.shot_jump"
    bl_label = "Jump to Shot"
    bl_options = {'REGISTER', 'UNDO'}
    index: bpy.props.IntProperty()

    def execute(self, context):
        rig = context.scene.mw_camrig
        if not (0 <= self.index < len(rig.shots)):
            return {'CANCELLED'}
        rig.active = self.index
        context.scene.frame_set(_shot_frame(context.scene, rig.shots[self.index]))
        return {'FINISHED'}


class MWCAM_OT_path_smooth(bpy.types.Operator):
    bl_idname = "camerawerks.path_smooth"
    bl_label = "Smooth Path"
    bl_description = ("Set every control point to automatic handles — the flowing "
                      "version of whatever route you have drawn")
    bl_options = {'REGISTER', 'UNDO'}

    style: bpy.props.EnumProperty(
        items=[('AUTO', "Smooth", "Flowing curve through the points"),
               ('VECTOR', "Angular", "Straight legs with corners at each point")],
        default='AUTO')

    @classmethod
    def poll(cls, context):
        p = context.scene.mw_camrig.path_object
        return p is not None and p.data.splines

    def execute(self, context):
        sp = context.scene.mw_camrig.path_object.data.splines[0]
        for bp in sp.bezier_points:
            bp.handle_left_type = bp.handle_right_type = self.style
        _rebuild_camera(context)
        self.report({'INFO'}, "Path set to %s" % self.style.lower())
        return {'FINISHED'}


class MWCAM_OT_path_reset(bpy.types.Operator):
    bl_idname = "camerawerks.path_reset"
    bl_label = "Reset Path to Shots"
    bl_description = ("Throw away your curve edits and put the path back through the "
                      "captured shot positions")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.mw_camrig.path_object is not None

    def execute(self, context):
        rig = context.scene.mw_camrig
        shots = _ordered_shots(context.scene)
        sp = rig.path_object.data.splines[0] if rig.path_object.data.splines else None
        if sp is None or not shots:
            return {'CANCELLED'}
        for bp, sh in zip(sp.bezier_points, shots):
            bp.handle_left_type = bp.handle_right_type = 'AUTO'
            bp.co = sh.shot_loc
        _rebuild_camera(context)
        self.report({'INFO'}, "Path reset through %d shot(s)" % len(shots))
        return {'FINISHED'}


class MWCAM_OT_path_select(bpy.types.Operator):
    bl_idname = "camerawerks.path_select"
    bl_label = "Edit Path"
    bl_description = "Select the path so you can shape it in the viewport"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.mw_camrig.path_object is not None

    def execute(self, context):
        p = context.scene.mw_camrig.path_object
        for o in context.selected_objects:
            o.select_set(False)
        p.select_set(True)
        context.view_layer.objects.active = p
        self.report({'INFO'}, "Path selected — Tab into edit mode to shape it")
        return {'FINISHED'}


class MWCAM_OT_look_through(bpy.types.Operator):
    bl_idname = "camerawerks.look_through"
    bl_label = "Look Through"
    bl_description = ("Look through the sequence camera, or step back out to a free view "
                      "so you can frame the next shot")
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        sd = getattr(context, "space_data", None)
        return sd is not None and sd.type == 'VIEW_3D'

    def execute(self, context):
        r3d = context.space_data.region_3d
        # A toggle, because framing a NEW shot requires being OUT of camera view —
        # without a way back the tool traps you.
        if _looking_through_rig(context):
            r3d.view_perspective = 'PERSP'
            self.report({'INFO'}, "Free view — frame your next shot")
            return {'FINISHED'}
        cam = _rig_camera(context)
        if cam is None:
            self.report({'WARNING'}, "No sequence camera yet"); return {'CANCELLED'}
        context.scene.camera = cam
        r3d.view_perspective = 'CAMERA'
        return {'FINISHED'}


class MWCAM_OT_rebuild(bpy.types.Operator):
    bl_idname = "camerawerks.rebuild"
    bl_label = "Rebuild Sequence"
    bl_description = "Regenerate the camera animation from the shot list"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        n = _rebuild_camera(context)
        self.report({'INFO'}, "Rebuilt %d shot(s)" % n)
        return {'FINISHED'}


def _move_speed(scene, shots, i):
    """AVERAGE units per frame across shot i's move.

    ⚠ Speed, not percentage: the two sides of a cut differ in length, so equal amounts are
    not equal speeds and a match cannot be dialled by copying a number across.

    ⚠ AVERAGE, not the speed AT the edit. With any Ease the move accelerates, so the
    instantaneous speed at the cut is higher — measured 0.107/f where the average was
    0.068/f. Matching averages still lands the match exactly WHEN BOTH SIDES SHARE AN EASE
    PROFILE, which is why the panel labels this "avg" and warns whenever an edit-side ease
    is non-zero rather than quietly implying the number is the edge speed.
    """
    if i < 0 or i >= len(shots):
        return 0.0
    sh = shots[i]
    if sh.move == 'NONE':
        return 0.0
    nxt = _shot_frame(scene, shots[i + 1]) if i + 1 < len(shots) else None
    f = _shot_frame(scene, sh)
    last_frame = (nxt - 1) if nxt is not None else max(f + 1, scene.frame_end)
    fly = (sh.move == 'FLY_NEXT' and nxt is not None)
    cap = nxt if fly else last_frame
    h_end = min(f + sh.hold, cap)
    move_end = (min(h_end + sh.move_frames, cap) if sh.move_frames > 0 else cap)
    span = move_end - h_end
    if span <= 0:
        return 0.0
    return (_shot_end(shots, i, scene.mw_camrig)[0]
            - _shot_start(sh)[0]).length / float(span)


class MWCAM_UL_shots(bpy.types.UIList):
    def filter_items(self, context, data, propname):
        """The list reads CHRONOLOGICALLY however the shots were added.

        ⚠ This sorts the DISPLAY, never the stored collection. A shot bound to a marker
        reads its frame LIVE (`_shot_frame`), so the running order can change with no edit
        of the user's own — recomputing here on every draw follows a dragged marker for
        free. Reordering the CollectionProperty instead would need the 4 Hz marker watcher
        to notice, and would have to remap `rig.active` mid-drag — whose `update=` moves
        the playhead and the viewport, so the view would lurch while the user drags.

        Safe because NOTHING reads `rig.shots` positionally: every order-sensitive path
        goes through `_ordered_shots()`, and the rest is `rig.active`, `len()`, `add()`,
        `remove()` or an identity lookup. So the stored order stays insertion order and
        no saved file needs migrating.
        """
        shots = getattr(data, propname)
        helper = bpy.types.UI_UL_list
        flt_flags = []
        if self.filter_name:
            flt_flags = helper.filter_items_by_name(
                self.filter_name, self.bitflag_filter_item, shots, "name")
        if not flt_flags:
            flt_flags = [self.bitflag_filter_item] * len(shots)
        # Defining filter_items means WE own sorting — the built-in alphabetical toggle is
        # drawn either way, so honour it rather than shipping a control that does nothing.
        if self.use_filter_sort_alpha:
            return flt_flags, helper.sort_items_by_name(shots, "name")
        # neworder maps org_idx -> new_idx. sorted() is stable, so shots sharing a frame
        # keep the order they were added in.
        scene = context.scene
        flt_neworder = helper.sort_items_helper(
            [(i, _shot_frame(scene, sh)) for i, sh in enumerate(shots)],
            key=lambda t: t[1])
        return flt_flags, flt_neworder

    def draw_item(self, context, layout, data, item, icon, active_data, active_prop, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            # IPO_CONSTANT / IPO_EASE_IN_OUT are literally the interpolation each
            # transition produces, so the icon states the mechanism.
            row.label(text="", icon=_MOVE_ICON.get(item.move, 'IPO_CONSTANT'))
            row.prop(item, "name", text="", emboss=False)
            sub = row.row(align=True)
            sub.alignment = 'RIGHT'
            # ⚠ DIMMED, matching the cue row. The cue list set `enabled = False` on this
            # trailing block and the shot list did not, so the same information — a frame you
            # cannot edit here — read as prominent on one list and secondary on the other.
            # Rob: "f number is greyed out on Cues and full opacity on Shots."
            sub.enabled = False
            if item.zoom:
                sub.label(text="", icon='IPO_LINEAR')
            # ⚠ NO MARKER BADGE. It meant "this shot follows a marker", which was worth
            # saying while only some did — but every shot gets one on capture now, so it
            # appeared on every row and carried nothing. Rob: "Not sure what the ^ icon is
            # doing." Cue rows never had one for the same reason. The shot box still shows
            # WHICH marker under "Follows".
            sub.label(text="f%d" % _shot_frame(context.scene, item))
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='CAMERA_DATA')


class _MWCamChild:
    """The camera half of the one Motionwerks tab.

    ⚠ These were their own sidebar tab (v2.5.0 → 2026-08-07) and are now siblings of the cue
    panels under MW_PT_main, gated on the mode row instead. They are deliberately FLAT rather
    than nested under Shots: three levels of sub-panel in a sidebar is a lot of chrome, and
    Path/Aim/Focus/Shake are peers of the shot list, not details of it.
    """
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_parent_id = "MW_PT_main"

    @classmethod
    def extra_poll(cls, context):
        """Per-panel condition. Override this, NOT poll — the mode gate lives in poll and a
        subclass that overrode poll would silently draw its panel in Cues mode."""
        return True

    @classmethod
    def poll(cls, context):
        return _tab(context) == 'CAMERA' and cls.extra_poll(context)


class MWCAM_PT_main(_MWCamChild, bpy.types.Panel):
    # ⚠ "Shots", not "Camerawerks" — the mode row already says Camera, and repeating it here
    # is the same redundancy the main header's icon was removed for. It also completes the
    # v3.2.0 taxonomy: single-word siblings, Shots · Path · Aim · Focus · Shake · Remove.
    # ⚠ NO HEADER, same reason as MW_PT_cues: the Camera mode button is directly above it.
    bl_label = "Shots"
    bl_idname = "MWCAM_PT_main"
    bl_order = 10
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):
        scene = context.scene
        rig = scene.mw_camrig
        layout = self.layout

        # Nothing set up yet: say what the one button will do, rather than showing an
        # empty camera field the user has to reason about.
        if rig.camera is None:
            box = layout.box()
            box.label(text="No camera yet", icon='CAMERA_DATA')
            col = box.column()
            col.scale_y = 1.5
            col.operator("camerawerks.shot_add", text="Add Camera & First Shot",
                         icon='VIEW_CAMERA')
            hint = box.column(align=True)
            hint.enabled = False
            hint.label(text="Frame your opening shot in the viewport,", icon='INFO')
            hint.label(text="then press the button. Each later cue adds a shot.")
            return

        through = _looking_through_rig(context)
        framing = _framing_cam(context) is not None
        if framing:
            b = layout.box()
            r = b.row()
            r.label(text="FRAMING - fly the view to frame the shot", icon='CAMERA_DATA')
            h = b.row(); h.enabled = False
            h.label(text="The viewport is driving a temporary camera", icon='INFO')
            if rig.aim == 'TRACK' and rig.track_target is not None:
                # ⚠ TRACK_TO overrides keyed rotation, so the angle you frame by eye will
                # NOT survive. Position will. Saying it here beats discovering it after.
                t = b.row(); t.enabled = False
                t.label(text="Aim is Track To — you are choosing position", icon='INFO')
        # ⚠ TWO CREATION ROUTES, SIDE BY SIDE — the same shape as the cue panel's
        # "Add Cue | From Markers". Rob: "Can Add and Frame be side by side?"
        # ⚠ SHORTER LABELS. "Add Shot from View" and "Capture This Framing" do not fit half a
        # sidebar; panel buttons truncate rather than wrap, and the tail is what goes.
        # ⚠ NO scale_y. It was 1.4, which made this row visibly taller than the cue panel's
        # "Add Cue | From Markers" — Rob spotted it immediately. The icons were never the
        # cause and are kept; matching height is what makes the two modes read as one tool.
        top = layout.row(align=True)
        add = top.row(align=True)
        add.enabled = framing or not through
        add.operator("camerawerks.shot_add",
                     text="Capture" if framing else "Add Shot",
                     icon='VIEW_CAMERA')
        if framing:
            top.operator("camerawerks.frame_cancel", text="Cancel", icon='X')
        else:
            top.operator("camerawerks.frame_start", text="Frame a Shot",
                         icon='CON_CAMERASOLVER')
        if through and not framing:
            w = layout.row()
            w.label(text="Camera view — use Frame a Shot", icon='ERROR')

        if not len(rig.shots):
            info = layout.row(); info.enabled = False
            info.label(text="Frame it in the viewport, then press the button", icon='INFO')
            return

        shots = _ordered_shots(scene)
        row = layout.row()
        # ⚠ rows=4 and a FOUR-button side column, identical to the cue list: remove, then
        # Follow Selection, live markers, rebuild. Rob: "Can we move Look Through and Retake
        # below so the side buttons match?" Neither belonged in the list's own column —
        # Retake acts on the selected SHOT and Look Through is a viewport toggle — and with
        # them gone the two columns are literally the same column, which is the point.
        row.template_list("MWCAM_UL_shots", "", rig, "shots", rig, "active", rows=4)
        side = row.column(align=True)
        side.operator("camerawerks.shot_remove", text="", icon='REMOVE')
        side.separator()
        side.prop(rig, "sync_view", text="", icon='PLAY', toggle=True)
        side.prop(rig, "live_markers", text="", icon='MARKER_HLT', toggle=True)
        side.operator("camerawerks.rebuild", text="", icon='FILE_REFRESH')

        # ⚠ LABELLED now they are out of the icon column, and side by side like Add Shot |
        # Frame a Shot above. Retake kept IMPORT because it still pulls the view IN, and Look
        # Through kept the camera — the two glyphs no longer sit three rows apart unexplained.
        acts = layout.row(align=True)
        acts.operator("camerawerks.shot_retake", text="Retake", icon='IMPORT')
        acts.operator("camerawerks.look_through",
                      text="Look Through", icon='VIEW_CAMERA', depress=through)

        # ⚠ UNDER the list, not up with Add/Frame. Rob: "Do we need Add Move?" — yes: it is
        # the ONLY entry point to the move-preset library, and hiding it re-creates the
        # v2.28.2 complaint ("I don't see the presets in camerawerks"). But it APPENDS a shot
        # derived from the selected one, which makes it a list action, not a third way to
        # start. operator_menu_enum IS the picker: the enum's icons and descriptions carry
        # the whole library in one line.
        layout.operator_menu_enum("camerawerks.move_add", "move",
                                  text="Add Move", icon='CON_FOLLOWPATH')

        # Offered ONLY when it would do something, and the count goes in the BUTTON so the
        # row reads as one idea rather than a button plus a number somewhere else.
        unmarked = _unmarked_shots(scene)
        if unmarked:
            n = len(unmarked)
            layout.operator("camerawerks.markers_from_shots", icon='MARKER_HLT',
                            text="Markers from %d Shot%s" % (n, "" if n == 1 else "s"))

        if not (0 <= rig.active < len(rig.shots)):
            return
        sh = rig.shots[rig.active]
        pos = shots.index(sh) + 1 if sh in shots else 0
        box = layout.box()
        head = box.row()
        # ⚠ The shot's NAME, matching the cue box's "02 Cue". "Shot 1 of 2" restated the
        # list position, which the highlighted row already shows.
        head.label(text=sh.name, icon='CAMERA_DATA')
        head.operator("camerawerks.shot_jump", text="", icon='PLAY').index = rig.active

        col = _split(box)
        if sh.marker:
            col.prop_search(sh, "marker", scene, "timeline_markers", text="Follows")
        else:
            col.prop(sh, "frame")
            col.prop_search(sh, "marker", scene, "timeline_markers", text="Follow Marker")

        i = shots.index(sh)
        nxt_f = _shot_frame(scene, shots[i + 1]) if i + 1 < len(shots) else None
        f_here = _shot_frame(scene, sh)
        last_f = (nxt_f - 1) if nxt_f is not None else max(f_here + 1, scene.frame_end)
        fly = (sh.move == 'FLY_NEXT' and nxt_f is not None)
        cap_f = nxt_f if fly else last_f
        h_end = min(f_here + sh.hold, cap_f)
        m_end = (min(h_end + sh.move_frames, cap_f) if sh.move_frames > 0 else cap_f)

        mv = box.box()
        col = _split(mv)
        col.prop(sh, "move")
        if sh.move == 'FLY_NEXT' and nxt_f is None:
            w = mv.row()
            w.label(text="Nothing after this shot to fly to", icon='ERROR')
        if sh.move not in {'NONE', 'FLY_NEXT'}:
            kind = _MOVE_DEFS[sh.move][0]
            if kind == 'C':
                col.prop(sh, "move_dist", text="Boom")
                col.prop(sh, "move_angle", text="Tilt")
            else:
                col.prop(sh, "move_angle" if kind in {'R', 'O'} else "move_dist")
            if kind == 'O' and (rig.aim != 'TRACK' or rig.track_target is None):
                w = mv.row()
                w.label(text="Orbit needs Aim ▸ Track To", icon='ERROR')
        if sh.move != 'NONE':
            col.prop(sh, "curve")
            if sh.curve == 'EASE':
                col.prop(sh, "ease_in")
                col.prop(sh, "ease_out")
            else:
                col.prop(sh, "easing")
            col.prop(sh, "hold")
            col.prop(sh, "move_frames")
            r = mv.row(); r.enabled = False
            # ⚠ Panel labels TRUNCATE, they do not wrap — keep this short or the numbers
            # it exists to show are the first thing lost.
            r.label(text="%s f%d\u2192f%d   avg %.3f/f"
                         % ("Fly" if fly else "Move", h_end, m_end,
                            _move_speed(scene, shots, i)),
                    icon='IPO_EASE_IN_OUT' if fly else 'CON_FOLLOWPATH')
            # ⚠ the leftover is DERIVED, never a control — that is what "just a duration"
            # buys: set when the move starts and how long it runs, and dwell falls out
            left = max(0, last_f - m_end)
            if left:
                q = mv.row(); q.enabled = False
                q.label(text="then %df still" % left, icon='BLANK1')
            if sh.move_frames > 0 and h_end + sh.move_frames > cap_f:
                w = mv.row()
                w.label(text="Timing clipped to %df" % max(0, cap_f - h_end),
                        icon='ERROR')
            if rig.use_path and sh.move in _MOVE_TRANSLATES:
                w = mv.row()
                w.label(text="Path drives position - this move cannot run here",
                        icon='ERROR')
        else:
            r = mv.row(); r.enabled = False
            r.label(text="Holds this framing, then cuts" if nxt_f is not None
                         else "Holds this framing to the end", icon='IPO_CONSTANT')

        # --- what this shot does while we are ON it -------------------------------
        tb = box.box()
        col = _split(tb)
        col.prop(sh, "zoom")
        if i > 0 and shots[i - 1].move != 'NONE' and sh.move not in {'NONE', 'FLY_NEXT'}:
            # a match reads only across a CUT, which is what a non-Fly move leaves behind
            if shots[i - 1].move != 'FLY_NEXT':
                a_sp = _move_speed(scene, shots, i)
                b_sp = _move_speed(scene, shots, i - 1)
                r = tb.row(); r.enabled = False
                r.label(text="out %.3f/f  \u2190 in %.3f/f" % (a_sp, b_sp),
                        icon='IPO_LINEAR')
                if b_sp > 1e-9 and abs(a_sp - b_sp) > max(0.002, b_sp * 0.02):
                    tb.row().operator("camerawerks.move_match", icon='SNAP_ON')
                if shots[i - 1].ease_out or sh.ease_in:
                    w = tb.row()
                    w.label(text="Ease stops the move at the edit", icon='ERROR')











def _rig_section(parent, context, label, icon, toggle):
    """One labelled section inside the Rig box.

    ⚠ SECTIONS, NOT SUB-PANELS since beta.11. Rob: "I think Rig can be uncollapsable and a
    darker panel." That makes Rig the exact counterpart of Actions in the cue box — a darker
    nested box holding labelled blocks — instead of a collapsible panel owning four child
    panels, and it is what makes the two modes read the same way.
    ⚠ The heading stays enabled while the body may not: the switch that turns a section back
    ON lives on that heading, so greying it with the body would lock the section off.
    """
    row = parent.row(align=True)
    on = True
    if toggle:
        on = getattr(context.scene.mw_camrig, toggle)
        row.prop(context.scene.mw_camrig, toggle, text="")
    # ⚠ NO ICON on a section heading. Rob: "Maybe Rig should have an icon and Aim, Focus,
    # Shake, Path don't." Four icons inside one box competed with the box's own title for
    # what the block is; the box wears one and the sections are just names.
    row.label(text=label)
    body = parent.column()
    body.enabled = on
    return body


def _draw_rig_aim(parent, context):
    rig = context.scene.mw_camrig
    layout = _rig_section(parent, context, 'Aim', 'CON_TRACKTO', '')

    box = layout.box()
    box.row().prop(rig, "aim", expand=True)
    if rig.aim == 'TRACK':
        col = _split(box)
        col.prop(rig, "track_target", text="Target")
        box.operator("camerawerks.add_track_empty",
                     text=_helper_label(context, "Aim at", "Target"),
                     icon='EMPTY_DATA')
        if rig.track_target is None:
            w = box.row()
            w.label(text="Pick a target or the camera keeps its shot framing",
                    icon='ERROR')
        else:
            w = box.row(); w.enabled = False
            w.label(text="Shot framing sets position only", icon='INFO')


def _draw_rig_focus(parent, context):
    rig = context.scene.mw_camrig
    layout = _rig_section(parent, context, 'Focus', 'CON_CAMERASOLVER', '')

    box = layout.box()
    box.row().prop(rig, "focus_mode", expand=True)
    if rig.focus_mode == 'OBJECT':
        col = _split(box)
        col.prop(rig, "focus_target", text="Focus On")
        box.operator("camerawerks.add_focus_empty",
                     text=_helper_label(context, "Focus on", "Focus Empty"),
                     icon='EMPTY_DATA')
        if rig.focus_target is None:
            w = box.row()
            w.label(text="Pick an object to hold focus on", icon='ERROR')
    elif rig.focus_mode == 'DISTANCE':
        col = _split(box)
        col.prop(rig, "focus_target", text="Subject")
        box.operator("camerawerks.add_focus_empty",
                     text=_helper_label(context, "Focus on", "Focus Empty"),
                     icon='EMPTY_DATA')
        fallback = rig.track_target if rig.aim == 'TRACK' else None
        if rig.focus_target is None and fallback is None:
            col.prop(rig, "focus_auto")
            if not rig.focus_auto:
                col.prop(rig, "focus_distance")
        w = box.row(); w.enabled = False
        if rig.focus_target is not None:
            w.label(text="Tracks %s — Snap is per shot" % rig.focus_target.name,
                    icon='INFO')
        elif fallback is not None:
            w.label(text="Using the aim target (%s)" % fallback.name, icon='INFO')
        elif rig.focus_auto:
            w.label(text="Measured per shot — Snap is per shot", icon='INFO')
        else:
            w.label(text="Fixed distance — Snap is per shot", icon='INFO')
        sub = _split(box)
        sub.prop(rig, "focus_breathe")
        if rig.focus_breathe:
            sub.prop(rig, "focus_breathe_speed", text="Speed")


def _draw_rig_path(parent, context):
    rig = context.scene.mw_camrig
    layout = _rig_section(parent, context, 'Path', 'CURVE_BEZCURVE', 'use_path')
    if not rig.use_path:
        w = layout.row(); w.enabled = False
        w.label(text="Straight moves between shots", icon='INFO')
        return

    row = layout.row(align=True)
    row.operator("camerawerks.path_smooth", text="Smooth",
                 icon='SMOOTHCURVE').style = 'AUTO'
    row.operator("camerawerks.path_smooth", text="Angular",
                 icon='SHARPCURVE').style = 'VECTOR'
    layout.operator("camerawerks.path_select", icon='CURVE_BEZCURVE')
    _split(layout).prop(rig, "path_resolution")
    layout.operator("camerawerks.path_reset", icon='LOOP_BACK')
    hint = layout.column(align=True)
    hint.enabled = False
    hint.label(text="The path decides the route now —", icon='INFO')
    hint.label(text="shape it and the shots become waypoints.")


def _draw_rig_shake(parent, context):
    rig = context.scene.mw_camrig
    layout = _rig_section(parent, context, 'Shake', 'FORCE_TURBULENCE', 'use_shake')
    layout.prop(rig, "shake_preset", text="")
    col = _split(layout)
    col.prop(rig, "shake_strength")
    col.prop(rig, "shake_rot")
    col.prop(rig, "shake_scale")
    hint = layout.row(); hint.enabled = False
    hint.label(text="Presets set the values — tweak freely after", icon='INFO')


class MWCAM_PT_rig(_MWCamChild, bpy.types.Panel):
    """Everything true of the WHOLE sequence, drawn as one uncollapsable darker box.

    ⚠ Was a collapsible panel with four child panels until beta.11. Now it mirrors the cue
    panel's Actions box exactly, which is the point — Rob: "Let's match Camera's hierarchy so
    when you switch panels, they feel similar."
    """
    bl_label = "Rig"
    bl_idname = "MWCAM_PT_rig"
    bl_order = 11
    bl_options = {'HIDE_HEADER'}

    @classmethod
    def extra_poll(cls, context):
        return context.scene.mw_camrig.camera is not None

    def draw(self, context):
        rig = context.scene.mw_camrig
        box = self.layout.box()
        # ⚠ The FOCUS icon, on Rob's call — it reads as "camera settings" better than any of
        # the alternatives, and its own section no longer needs it.
        box.label(text="Rig", icon='CON_CAMERASOLVER')
        # ⚠ THE CAMERA FIELD LIVES HERE, not at the top of the panel. Rob: "Do we need a
        # camera selector?" — yes, but rarely: it exists to adopt a camera you made yourself
        # or to clear one. At the top it made the least-used control the most prominent, and
        # it is a RIG property, so this is where it belongs. Look Through was the daily half
        # of that row and has moved to the shot list's side column.
        # ⚠ HEADING ABOVE THE FIELD, matching Aim / Focus / Shake. `_split` put "Camera" in
        # the left property column, so it read as a form row inside a box whose every other
        # block is a heading with its control full-width underneath.
        box.label(text="Camera")
        box.prop(rig, "camera", text="")
        # ⚠ NO separator between sections. Rob: "Lots of extra space in the Rig section." Each
        # section already opens with its own heading row, so a separator on top of that was
        # spacing doing a job the heading had done.
        _draw_rig_aim(box, context)
        _draw_rig_focus(box, context)
        # ⚠ Path needs somewhere to go: a curve through one waypoint is meaningless. This
        # was MWCAM_PT_path.extra_poll before the four panels became sections.
        if len(rig.shots) > 1:
            _draw_rig_path(box, context)
        _draw_rig_shake(box, context)


class MWCAM_PT_remove(_MWCamChild, bpy.types.Panel):
    """Just a button.

    ⚠ NO HEADER, and it is a PANEL rather than rows at the end of MWCAM_PT_main. Rob: "Delete
    Camerawerks Camera should not be red, and should not be in a subheading." Dropping it
    inline satisfied the second half and broke the first: **Blender draws child panels AFTER
    the parent's own content**, so the button appeared above Path, Aim, Focus and Shake — a
    destructive action sitting on top of everything you reach for routinely. `HIDE_HEADER`
    keeps it a panel, so it still sorts LAST, while drawing nothing but its contents.

    ⚠ Copied from Mographwerks' MG_PT_remove, which Rob had already steered to this exact
    shape ("Remove Cloner doesn't need to be in a header. Can just be a button"). The lesson
    is that the answer to this instruction already existed — read the model before inventing.

    No red: `delete_all` is behind `invoke_confirm`, which is the real guard.
    """
    bl_label = ""
    bl_options = {'HIDE_HEADER'}
    bl_order = 16

    @classmethod
    def extra_poll(cls, context):
        rig = context.scene.mw_camrig
        return rig.camera is not None or len(rig.shots) > 0

    def draw(self, context):
        rig = context.scene.mw_camrig
        layout = self.layout
        row = layout.row()
        row.scale_y = 1.2
        row.operator("camerawerks.delete_all", icon='TRASH')
        n = layout.column(align=True)
        n.enabled = False
        n.label(text="Deletes the camera, path, helpers,", icon='INFO')
        n.label(text="every shot and the animation.", icon='BLANK1')
        if rig.camera is not None and not rig.camera.get("mw_camrig"):
            n.label(text="'%s' is yours — kept" % rig.camera.name, icon='CHECKMARK')




_MW_SIG = {}
_MW_CUE_SIG = {}
_MW_BUSY = False


def _marker_sig(scene):
    """Frames of every marker a shot follows — the only thing that can move a shot without
    touching a Camerawerks property."""
    rig = getattr(scene, "mw_camrig", None)
    if rig is None:
        return None
    names = {sh.marker for sh in rig.shots if sh.marker}
    if not names:
        return ()
    return tuple(sorted((m.name, m.frame) for m in scene.timeline_markers
                        if m.name in names))


def _cue_marker_sig(scene):
    """(name, frame) for every marker a CUE follows — the cue-side twin of _marker_sig."""
    names = {c.get("mw_marker", "") for c in _cue_colls(scene)}
    names.discard("")
    if not names:
        return ()
    return tuple(sorted((m.name, m.frame) for m in scene.timeline_markers
                        if m.name in names))


def _watch_cue_markers(scene):
    """Live Sync: retime cues when a marker they follow moves.

    ⚠ ONLY the cues whose marker actually changed FRAME are touched. The signature is
    per-marker so the diff is exact, which makes the live path CHEAPER than the Sync
    button even though it runs at 4 Hz — the button walks every cue every time.

    ⚠ The first signature seen is a BASELINE, never a move. Otherwise switching Live Sync
    on would silently rewrite keyframes to catch up with markers moved while it was off.
    Catching up is what the Sync button is for; turning a toggle on should write nothing.
    """
    if not getattr(scene, "mw_live_sync", False):
        return
    sig = _cue_marker_sig(scene)
    prev = _MW_CUE_SIG.get(scene.name)
    if prev == sig:
        return
    _MW_CUE_SIG[scene.name] = sig
    if prev is None:
        return
    was = dict(prev)
    moved = {n for n, f in sig if was.get(n) != f}
    if moved:
        _sync_cues(bpy.context, only=moved)


def _watch_shot_markers(scene):
    """The Camerawerks half — same behaviour as before, just no longer able to gate cues."""
    rig = getattr(scene, "mw_camrig", None)
    if rig is None or not rig.live_markers or not len(rig.shots) or rig.camera is None:
        return
    sig = _marker_sig(scene)
    if _MW_SIG.get(scene.name) == sig:
        return
    _MW_SIG[scene.name] = sig
    _rebuild_camera(bpy.context)


@bpy.app.handlers.persistent
def _mw_marker_watch(scene, depsgraph=None):
    """Rebuild/retime when a followed marker MOVES.

    ⚠ A shot's frame is read from its marker LIVE, but the BAKED KEYFRAMES are not: moving a
    cue changes no Camerawerks property, so nothing regenerated the track and the animation
    silently went stale (measured — marker 60->140 left keys at 59/60). This closes the gap
    so cues and cameras behave identically with no Sync step.

    ⚠⚠ THE TWO HALVES ARE INDEPENDENT. This used to early-out unless a camera rig existed
    WITH shots AND a camera — so a scene with cues and no camera would have skipped the cue
    half entirely. Splitting them is what makes cue Live Sync possible at all.

    ⚠ RE-ENTRANCY: the work writes keyframes, which fires another depsgraph update. By then
    the signature is unchanged so it would early-out anyway — the flag makes that guaranteed
    rather than incidental, and stops half-written data being read.

    ⚠ Must be CHEAP: this runs on every depsgraph update AND on a 4 Hz timer. Everything
    before the signature comparison is a handful of attribute reads.
    """
    global _MW_BUSY
    if _MW_BUSY:
        return
    if scene is not getattr(bpy.context, "scene", None):
        return                      # a background scene has no viewport to keep in step
    _MW_BUSY = True
    try:
        _watch_cue_markers(scene)
        _watch_shot_markers(scene)
    except Exception:
        pass                        # never let a handler raise into Blender's update loop
    finally:
        _MW_BUSY = False


def _mw_marker_timer():
    """⚠ A TIMER, not just a depsgraph handler.

    Timeline markers are scene metadata, NOT evaluated data — dragging one fires no
    depsgraph update, so `depsgraph_update_post` alone never saw it. My first test only
    "passed" because it called `view_layer.update()` by hand, which manufactured the very
    event that does not happen in real use. The handler stays (it is free and catches
    changes that DO tick the depsgraph); this poll is what actually notices a marker move.

    The work is a signature comparison — a few attribute reads — so a 4 Hz poll is nothing.
    """
    scene = getattr(bpy.context, "scene", None)
    if scene is not None:
        try:
            _mw_marker_watch(scene)
        except Exception:
            pass
    return 0.25


classes = (
    MW_ItemPG, MW_PresetPG, MW_MaterialPG, MW_DrivePG,
    MW_ShotPG, MW_CamRigPG,
    MW_OT_cue_add, MW_OT_populate, MW_OT_cue_remove,
    MW_OT_cue_object_move, MW_OT_cue_objects_add, MW_OT_cue_object_remove,
    MW_OT_cue_apply, MW_OT_sync,
    MW_OT_preset_save,
    MW_OT_item_preset_pick, MW_OT_item_reset, MW_OT_items_apply_preset,
    MWCAM_OT_shot_add,
    MWCAM_OT_move_add,
    MWCAM_OT_move_match, MWCAM_OT_markers_from_shots,
    MWCAM_OT_shot_retake, MWCAM_OT_shot_remove,
    MWCAM_OT_add_track_empty, MWCAM_OT_add_focus_empty,
    MWCAM_OT_path_smooth, MWCAM_OT_path_reset, MWCAM_OT_path_select,
    MWCAM_OT_frame_start, MWCAM_OT_frame_cancel, MWCAM_OT_delete_all,
    MWCAM_OT_shot_jump, MWCAM_OT_look_through, MWCAM_OT_rebuild,
    MWCAM_UL_shots,
    MW_OT_drive_add, MW_OT_drive_bind, MW_OT_drive_remove,
    MW_OT_action_select, MW_OT_action_toggle_all,
    MW_UL_cues, MW_UL_objects, MW_UL_drives,
    # ⚠⚠ SIDEBAR TAB ORDER IS PANEL REGISTRATION ORDER. Blender exposes no sort key for
    # sidebar categories — a tab lands wherever its FIRST panel registered — so the only
    # lever is this tuple. Measured, not assumed: re-enabling the four add-ons in a chosen
    # order reordered every tab to match.
    # ⚠ Since 2026-08-07 there is only ONE tab, so this no longer decides which of ours comes
    # first — but MW_PT_main must still register before its children, and the add-on's
    # position among the OTHER -werks tabs is still set here.
    # ⚠ ONLY THE PANELS MOVED. Operators, UILists and PropertyGroups keep their original
    # positions, because registration order there is a real dependency (a PointerProperty
    # needs its PropertyGroup registered first) and reordering it to fix a cosmetic tab
    # would be trading a UI nicety for a registration bug.
    MW_PT_main, MW_PT_cues,
    # ⚠ A PANEL PARENT MUST REGISTER BEFORE ITS CHILDREN or register_class raises
    # "parent '<id>' for '<child>' not found" and the whole add-on fails to enable. Paid for
    # once when MWCAM_PT_rig still had four child panels; they are sections inside it now,
    # but MW_PT_main must still come before everything that names it.
    MWCAM_PT_main, MWCAM_PT_rig, MWCAM_PT_remove,
)


@bpy.app.handlers.persistent
def _mw_load_post(dummy):
    for scene in bpy.data.scenes:
        _ensure_builtin_presets(scene)


def _mw_seed_timer():
    """One-shot: seed built-ins into current scenes. Runs after register(), when
    bpy.data is no longer restricted. Returns None so it fires only once."""
    for scene in bpy.data.scenes:
        _ensure_builtin_presets(scene)
    return None


# ⚠ Blender writes bl_* back onto the Python class during (un)register, so a hot reload
# leaves STALE values that silently override the source — bl_order comes back 0 across the
# board and tied sub-panels then order ALPHABETICALLY by label. That is exactly why these
# panels read as arbitrary before v3.2. Snapshot the intent at import, while the classes are
# fresh from source, and re-assert it every register. Ported from Werkbench, where the same
# bug cost two debugging rounds.
_PANEL_INTENT = {c.__name__: (getattr(c, "bl_category", None), c.__dict__.get("bl_order"))
                 for c in classes if issubclass(c, bpy.types.Panel)}


def _hook_marker_watch(add):
    """⚠ Remove by __name__: after a hot reload the old function OBJECT is a different one,
    so `list.remove(func)` misses it and handlers stack up, each rebuilding in turn."""
    hs = bpy.app.handlers.depsgraph_update_post
    for h in list(hs):
        if getattr(h, "__name__", "") == "_mw_marker_watch":
            hs.remove(h)
    if add:
        hs.append(_mw_marker_watch)
    try:
        if bpy.app.timers.is_registered(_mw_marker_timer):
            bpy.app.timers.unregister(_mw_marker_timer)
    except Exception:
        pass
    if add:
        bpy.app.timers.register(_mw_marker_timer, first_interval=0.5, persistent=True)


def register():
    _hook_marker_watch(True)
    for c in classes:
        intent = _PANEL_INTENT.get(c.__name__)
        if intent is not None:
            if intent[0] is not None:
                c.bl_category = intent[0]
            if intent[1] is not None:
                c.bl_order = intent[1]
        bpy.utils.register_class(c)
    bpy.types.Collection.mw_items = bpy.props.CollectionProperty(type=MW_ItemPG)
    bpy.types.Collection.mw_active_item = bpy.props.IntProperty(default=0, min=0)
    # Per-cue settings (registered on Collection so the Motion panel edits them directly).
    bpy.types.Collection.mw_motion = bpy.props.PointerProperty(type=MW_PresetPG)
    bpy.types.Collection.mw_material = bpy.props.PointerProperty(type=MW_MaterialPG)
    bpy.types.Scene.mw_camrig = bpy.props.PointerProperty(type=MW_CamRigPG)
    # ⚠ PER-SCENE, like Mographwerks' mg_tab. It is a view preference, not project data, but
    # a Scene prop is what a panel can draw and what survives a save — a WindowManager prop
    # would reset every load and a preference would be shared across scenes.
    bpy.types.Scene.mw_tab = bpy.props.EnumProperty(
        name="Mode", default='CUES',
        description="Which half of Motionwerks the panel shows",
        items=[('CUES', "Cues", "Phase objects on voiceover markers", 'SEQUENCE', 0),
               ('CAMERA', "Camera", "Shot-based camera moves (Camerawerks)",
                'VIEW_CAMERA', 1)])
    bpy.types.Collection.mw_drives = bpy.props.CollectionProperty(type=MW_DrivePG)
    bpy.types.Collection.mw_drives_active = bpy.props.IntProperty(default=0, min=0)
    bpy.types.Collection.mw_action_active = bpy.props.StringProperty(default='MOTION')
    bpy.types.Collection.mw_detail_open = bpy.props.BoolProperty(
        name="Motion Detail", default=False)
    bpy.types.Collection.mw_duration = bpy.props.IntProperty(
        name="Duration", default=0, min=0, soft_max=480, update=_on_duration_change,
        description="Overall build duration: frames from the cue's marker until the last "
                    "object finishes. Editing it re-times each item")
    bpy.types.Collection.mw_timing = bpy.props.IntProperty(
        name="Timing", default=0, min=0, soft_max=480, update=_on_timing_change,
        description="Each object's keyframe duration in frames — scales its scale/move/"
                    "rotation together")
    bpy.types.Collection.mw_spacing = bpy.props.IntProperty(
        name="Spacing", default=6, min=0, soft_max=60, update=_on_timing_change,
        description="Frames of spacing between consecutive objects")
    bpy.types.Collection.mw_source = bpy.props.StringProperty(
        default="", description="Preset the cue's settings were last loaded from / saved as")
    bpy.types.Scene.mw_live_sync = bpy.props.BoolProperty(
        name="Live Sync", default=False,
        description="Retime cues automatically when a marker they follow moves, so there is no Sync step. Only the cue whose marker moved is touched")
    bpy.types.Scene.motionwerks_active = bpy.props.StringProperty(default="")
    # ⚠ THE active cue since 2026-08-07 — motionwerks_active is now derived from it.
    bpy.types.Scene.mw_cue_active = bpy.props.IntProperty(
        default=0, min=0, update=_cue_active_update)
    # Same idea, same default and near-enough the same words as the shot list's sync_view.
    bpy.types.Scene.mw_cue_follow = bpy.props.BoolProperty(
        name="Follow Selection", default=True,
        description="Selecting a cue moves the playhead to its marker, so you see the "
                    "moment you are editing")
    bpy.types.Scene.motionwerks_presets = bpy.props.CollectionProperty(type=MW_PresetPG)

    if _mw_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_mw_load_post)
    # Seed built-ins after register — bpy.data is restricted during register itself.
    if not bpy.app.timers.is_registered(_mw_seed_timer):
        bpy.app.timers.register(_mw_seed_timer, first_interval=0.0)
    bpy.types.UI_MT_button_context_menu.append(_drive_context_menu)

def unregister():
    _hook_marker_watch(False)
    _MW_SIG.clear()
    _MW_CUE_SIG.clear()
    try:
        bpy.types.UI_MT_button_context_menu.remove(_drive_context_menu)
    except Exception:
        pass
    if bpy.app.timers.is_registered(_mw_seed_timer):
        try:
            bpy.app.timers.unregister(_mw_seed_timer)
        except Exception:
            pass
    if _mw_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_mw_load_post)
    # Defensive: tolerate a partial/reloaded state so update-in-place stays clean.
    for owner, prop in ((bpy.types.Scene, "mw_tab"),
                        (bpy.types.Scene, "mw_cue_active"),
                        (bpy.types.Scene, "mw_cue_follow"),
                        (bpy.types.Scene, "motionwerks_presets"),
                        (bpy.types.Scene, "motionwerks_active"),
                        (bpy.types.Collection, "mw_source"),
                        (bpy.types.Collection, "mw_spacing"),
                        (bpy.types.Collection, "mw_timing"),
                        (bpy.types.Collection, "mw_duration"),
                        (bpy.types.Collection, "mw_detail_open"),
                        (bpy.types.Collection, "mw_action_active"),
                        (bpy.types.Collection, "mw_drives_active"),
                        (bpy.types.Scene, "mw_camrig"),
                        (bpy.types.Collection, "mw_drives"),
                        (bpy.types.Collection, "mw_material"),
                        (bpy.types.Collection, "mw_motion"),
                        (bpy.types.Collection, "mw_active_item"),
                        (bpy.types.Collection, "mw_items")):
        if hasattr(owner, prop):
            try:
                delattr(owner, prop)
            except Exception:
                pass
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass


if __name__ == "__main__":
    register()
