"""Mographwerks — a C4D-style cloner for Blender.

⚠ A cloner is just clones. Motion is an effector you choose. Timing is a field.
   See _dev/MOGRAPHWERKS_REBUILD.md before changing anything structural.
"""

bl_info = {
    "name": "Mographwerks",
    "author": "Vivinel",
    "version": (1, 0, 0),
    "warning": "Beta 2",
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > Mographwerks",
    "description": "C4D-style cloner: cloners, effectors and fields",
    "doc_url": "https://www.vivinel.com/",
    "category": "Werks",
}

from . import ng, props          # noqa: F401  (props is the seam other modules import)
from . import fields, fracture, cloner, effectors, ui  # noqa: F401

# ⚠ fields FIRST: it registers the Object properties the panels draw and the operators
# write, so anything registering before it would draw controls that do not exist yet.
_MODULES = (fields, cloner, effectors, ui)


def register():
    # ⚠ DO NOT TOUCH bpy.data HERE. During addon registration Blender substitutes
    # `_RestrictData`, which has no `node_groups` — appending the node groups at register
    # time raises AttributeError and the addon silently fails to enable. Groups are appended
    # LAZILY instead, by `ng.ensure()`, the first time an operator actually needs them.
    # ⚠ Only enabling the addon for real catches this: a test that calls register() from a
    # script runs with bpy.data fully available and sees nothing wrong.
    for m in _MODULES:
        m.register()


def unregister():
    for m in reversed(_MODULES):
        m.unregister()
