"""Panels. Four of them: Source · Distribute · Effectors · Remove.

⚠ THERE IS NO BUILD OR SEQUENCE PANEL and there must never be one again. Sequence became a
FIELD TYPE, which reproduced the old build exactly and collapsed a whole panel — and a whole
concept a C4D artist had no name for — into one entry in the falloff dropdown.
"""

import bpy

from . import cloner, effectors, fields, ng, props

# ⚠ ONE LIST, read by the panel to DRAW the settings and again to hand them to the button —
# two lists would be two places for a new setting to be forgotten, and a forgotten one is a
# control that visibly does nothing.
VORONOI_SETTINGS = ("pieces", "seed", "grid", "jitter", "cell_scale",
                    "margin", "interior_material", "animate")

# ⚠ WHAT EACH METHOD ACTUALLY NEEDS SET BEFORE IT RUNS. `grid` is not in either bake list —
# it is implied by which METHOD you picked, and drawing it as well would be two controls for
# one decision. Live and Pieces are modifiers: everything they have is adjustable afterwards.
METHOD_SETTINGS = {
    'GRID': ("pieces", "seed", "jitter", "cell_scale", "margin", "interior_material",
             "animate"),
    'VORONOI': ("pieces", "seed", "cell_scale", "margin", "interior_material", "animate"),
    'LIVE': (),
    'PIECES': (),
}

HINTS = {
    'LIVE': "Stays adjustable — its settings live on the modifier",
    'PIECES': "Uses the mesh's existing loose parts",
}


class _Panel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # ⚠ THE PLAIN NAME. The "2" existed only so this could sit beside v0.65.0 while the two
    # were compared; v0.65.0 was retired 2026-08-05 and the name came back with it.
    bl_category = "Mographwerks"


class MG_PT_main(_Panel, bpy.types.Panel):
    bl_label = "Mographwerks"
    bl_idname = "MG_PT_main"

    def draw(self, context):
        layout = self.layout
        car = cloner.active(context)
        if car is None:
            # ⚠ TWO FRONT DOORS, ONE PIPELINE. The tab picks WHAT YOU ARE MAKING; everything
            # below — Source, Distribute, Effectors — is identical either way, which is the
            # point and is worth the panel showing rather than explaining.
            layout.prop(context.scene, "mg_tab", expand=True)
            box = layout.box()
            if context.scene.mg_tab == 'CLONE':
                # ⚠ THE HEADING AND THE ICONS ARE v0.65.0's, kept deliberately: the grid
                # SHOWS the vocabulary instead of hiding it in a dropdown, and pressing
                # Radial GETS you a radial cloner rather than a grid to re-mode.
                box.label(text="Add a Cloner", icon='OUTLINER_OB_POINTCLOUD')
                grid = box.grid_flow(row_major=True, columns=2, even_columns=True,
                                     align=True)
                grid.scale_y = 1.2
                for mode, label, icon, _d in ng.CLONER_ITEMS:
                    grid.operator("mographwerks.add_cloner",
                                  text=label, icon=icon).mode = mode
            else:
                box.label(text="Fracture", icon='MOD_EXPLODE')
                # ⚠ FOUR TABS, THEN ONE ACTION. The methods differ in what they need set
                # BEFORE they run — a bake cannot be adjusted afterwards — so choosing and
                # then acting is the honest shape. ANIMAX's, and it earns its place here.
                # ⚠ THE SAME TWO-UP GRID AS THE CLONER MODES. `expand=True` stacks four
                # items VERTICALLY in a sidebar, which is a list, not a set of tabs — and the
                # add screen already established two-up as the house shape.
                # ⚠ READING ORDER, NOT ENUM ORDER: the two BAKES on top, the two MODIFIERS
                # below. `prop_enum` draws one item at a time, so the layout is free to group
                # them by what they are rather than by how the enum happens to be declared.
                # ⚠ VORONOI LEADS because it is the DEFAULT and the general case — Grid is the
                # same bake constrained to a lattice, so it reads as the variant of the two.
                mgrid = box.grid_flow(row_major=True, columns=2, even_columns=True,
                                      align=True)
                mgrid.scale_y = 1.2
                for meth in ('VORONOI', 'GRID', 'LIVE', 'PIECES'):
                    mgrid.prop_enum(context.scene, "mg_fracture_method", meth)
                method = context.scene.mg_fracture_method
                s = context.scene.mg_voronoi
                col = box.column()
                col.use_property_split = True
                col.use_property_decorate = False
                for n in METHOD_SETTINGS[method]:
                    col.prop(s, n)
                # ⚠ THE TWO MODIFIER METHODS HAVE NOTHING TO SET BEFOREHAND, and saying so is
                # better than an empty gap that reads as a missing panel.
                if method in HINTS:
                    hint = box.column()
                    hint.enabled = False
                    hint.label(text=HINTS[method])
                row = box.row()
                row.scale_y = 1.4
                op = row.operator("mographwerks.fracture", text="Fracture", icon='MOD_EXPLODE')
            return
        layout.label(text=car.name)


class MG_PT_source(_Panel, bpy.types.Panel):
    bl_label = "Source"
    bl_parent_id = "MG_PT_main"
    bl_order = 0

    @classmethod
    def poll(cls, context):
        return cloner.active(context) is not None

    def draw(self, context):
        m = cloner.cloner_mod(cloner.active(context))
        if m is None:
            return
        col = self.layout.column()
        col.use_property_split = True
        # ⚠ OBJECT ABOVE COLLECTION, and both named for WHAT THEY ARE. They used to read
        # "Source" and "Sources" — one letter apart, in two different panels, which is not a
        # distinction anyone can see. Rob: "each should be named Object & Collection".
        # ⚠ BOTH ARE DRAWN NOW, deliberately reversing the earlier "one or the other, never
        # both" rule. The operators still only ever SET one — a cloner built from a single
        # object has no collection — but repointing an existing cloner is a real thing to want,
        # and a field that is simply absent cannot be repointed.
        for sock, label in (("Source", "Object"), ("Sources", "Collection")):
            h = props.holder(m, sock)
            if h is not None:
                col.prop(h, "value", text=label)

        srcs = props.get(m, "Sources")
        if srcs is not None:
            h = props.holder(m, "Clone Mode")
            if h is not None:
                col.prop(h, "value", text="Clone Mode")
            # ⚠ Seed only means something where something is random. On the other two modes
            # it would be a control that does nothing.
            if props.get(m, "Clone Mode") == "Pick Random":
                h = props.holder(m, "Seed")
                if h is not None:
                    col.prop(h, "value", text="Seed")
            # ⚠ THE TOGGLE DRIVES `exclude`, which is not a property we can draw directly —
            # it lives on the LayerCollection, one per view layer. So it is an operator.
            lcs = cloner._layer_collections(srcs.name)
            row = col.row()
            row.operator("mographwerks.toggle_hide_source",
                         text="Show Source" if (lcs and lcs[0].exclude) else "Hide Source",
                         icon='HIDE_ON' if (lcs and lcs[0].exclude) else 'HIDE_OFF')


class MG_PT_distribute(_Panel, bpy.types.Panel):
    bl_label = "Distribute"
    bl_parent_id = "MG_PT_main"
    bl_order = 1

    @classmethod
    def poll(cls, context):
        return cloner.active(context) is not None

    def draw(self, context):
        m = cloner.cloner_mod(cloner.active(context))
        if m is None:
            return
        layout = self.layout
        mode = ng.mode_of(m)
        # ⚠ A DROPDOWN, NOT A ROW OF BUTTONS. Six modes across a sidebar truncates — Rob's
        # screenshot shows "Hone..." — and a truncated label is not a label. The ADD screen
        # keeps its grid because there the point is to SHOW the vocabulary; here you already
        # know which one you picked and only occasionally change it.
        label, icon = ng.item_of(mode)
        layout.menu("MG_MT_mode", text=label, icon=icon)
        col = layout.column()
        col.use_property_split = True
        # ⚠ draw whatever THIS mode has, by name — the modes deliberately do not share a
        # socket set, and hardcoding a list here would silently drop a mode's own controls.
        # ⚠ THE SOURCE SOCKETS BELONG TO THE SOURCE PANEL, not here. This loop draws whatever
        # the mode exposes, and the source set is on every mode — so without this skip the
        # same Collection, Clone Mode and Seed appear in two panels at once, which is exactly
        # what put "Sources" up here and "Source" at the bottom of the tab.
        for s in m.node_group.interface.items_tree:
            if (getattr(s, "in_out", "") != 'INPUT'
                    or s.name in {"Geometry", "Source", "Sources", "Clone Mode", "Seed"}):
                continue
            h = props.holder(m, s.name)
            if h is not None and hasattr(h, "value"):
                col.prop(h, "value", text=s.name)


class MG_MT_add(bpy.types.Menu):
    """The Shift+A doorway.

    ⚠ A MoGraph ARTIST REACHES FOR ADD, not a sidebar tab. v0.65.0 called this "the C4D
    doorway" and it is the same argument: the vocabulary should be where the muscle memory is.
    ⚠ ONE SHARED TABLE with the panel, so the two can never drift — v0.65.0 hand-listed the
    fracture entries in both surfaces and they promptly disagreed, with Live Fracture in the
    panel and not in the menu.
    """

    bl_idname = "MG_MT_add"
    bl_label = "Mographwerks"

    def draw(self, context):
        layout = self.layout
        for mode, label, icon, _d in ng.CLONER_ITEMS:
            layout.operator("mographwerks.add_cloner", text=label, icon=icon).mode = mode
        layout.separator()
        # ⚠ THE BAKES NAME THEIR METHOD; the two modifier fractures are generator modes.
        for meth, label, icon in (('VORONOI', "Voronoi Fracture", 'MOD_REMESH'),
                                  ('GRID', "Grid Fracture", 'MESH_GRID')):
            layout.operator("mographwerks.fracture", text=label, icon=icon).method = meth
        for mode, label, icon, _d in ng.FRACTURE_ITEMS:
            layout.operator("mographwerks.add_cloner",
                            text="%s Fracture" % label, icon=icon).mode = mode


def _add_menu(self, context):
    self.layout.menu("MG_MT_add", icon='OUTLINER_OB_POINTCLOUD')


class MG_MT_mode(bpy.types.Menu):
    """The generator's own family of modes.

    ⚠ ONLY THE FAMILY IT BELONGS TO. Offering Grid beside Live Fracture would imply they are
    interchangeable; swapping one for the other drops every socket the new group does not
    share — which between those two is all of them.
    ⚠ A MENU RATHER THAN `operator_menu_enum`, because that draws EVERY item of the operator's
    enum and the operator has to accept all eight modes. Filtering is the whole job here.
    """

    bl_idname = "MG_MT_mode"
    bl_label = "Mode"

    def draw(self, context):
        m = cloner.cloner_mod(cloner.active(context))
        current = ng.mode_of(m)
        for mode, label, icon, _d in ng.family_items(current):
            op = self.layout.operator("mographwerks.set_mode", text=label, icon=icon)
            op.mode = mode


def _ease_params(col, fobj, curve):
    """The curve parameters that this curve actually uses.

    ⚠ THE SET IS MoTools' EASE FALLOFF, MEASURED FROM IT: Exponent, Base, Size, Bounces,
    Mirror. Rob: "We should mirror the settings from the Ease node with the Penner settings,
    disregard our previous settings." Amplitude and Decay belonged to the damped-sine model
    that these curves replaced and no longer exist.
    ⚠ DRAWN PER CURVE from ng's measured tables, so a slider never appears where it does
    nothing — Size on Sine moved nothing at all, which is exactly what a dead control is.
    """
    if curve in ng.USES_EXP:
        col.prop(fobj, "mg_field_exp")
    if curve in ng.USES_BASE:
        col.prop(fobj, "mg_field_base")
    if curve in ng.USES_SIZE:
        col.prop(fobj, "mg_field_size")
    if curve in ng.USES_BOUNCES:
        col.prop(fobj, "mg_field_freq")
    col.prop(fobj, "mg_field_mirror")


def _draw_field_row(box, mod, index, slot, blend, fobj):
    rb = box.box()
    row = rb.row(align=True)
    row.prop(fobj, "name", text="")
    if blend is not None:
        h = props.holder(mod, blend)
        if h is not None:
            row.prop(h, "value", text="")
    # ⚠ ON THE ROW, beside the field it acts on — one field can be re-fitted without touching
    # the others, and a panel-level button could not say WHICH.
    op = row.operator("mographwerks.fit_field", text="", icon='SHADING_BBOX')
    op.mod_name = mod.name
    op.index = index
    op = row.operator("mographwerks.remove_field", text="", icon='X')
    op.mod_name = mod.name
    op.index = index
    col = rb.column()
    col.use_property_split = True
    col.prop(fobj, "mg_field_type", text="Falloff")
    ftype = fobj.mg_field_type
    if ftype == 'SEQUENCE':
        # ⚠ Progress lives on the EFFECTOR, not the field — one clock per effector, so two
        # Sequence fields on one stack cannot disagree about what time it is.
        h = props.holder(mod, "Progress")
        if h is not None:
            col.prop(h, "value", text="Progress", slider=True)
        # ⚠ AXIS REPLACES AIMING THE GIZMO. Sequence has no falloff and does not read its
        # own transform, so this dropdown is the only thing that sets the build direction.
        col.prop(fobj, "mg_field_axis")
        col.prop(fobj, "mg_field_spread")
        col.prop(fobj, "mg_field_ease")
        col.prop(fobj, "mg_field_dir")
        _ease_params(col, fobj, fobj.mg_field_ease)
    else:
        # ⚠ Invert is deliberately absent for Sequence: it would flip the ramp before the
        # timing maths and run the build backwards. Direction comes from rotating the gizmo.
        col.prop(fobj, "mg_field_invert")
        # ⚠ Inner only means something where u is a distance from a centre or along a
        # sweep. RING measures distance from its BAND and RADIAL measures an ANGLE, so a
        # nested inner shape says nothing there; Random and the textures have no centre at
        # all. Drawing it for those would be a control that does nothing.
        if ftype in {'SPHERE', 'BOX', 'LINEAR'}:
            col.prop(fobj, "mg_field_inner")
        # ⚠ Shape curves the RAMP, so it means nothing for types with no ramp — Random and
        # the textures read a value per clone rather than falling off across a distance.
        if ftype not in {'RANDOM', 'VORONOI', 'WAVES', 'NOISE'}:
            col.prop(fobj, "mg_field_shape")
            # ⚠ SHAPE AND EASE ARE THE SAME CURVE SET on two different inputs — Ease reads
            # time on a Sequence, Shape reads distance across the falloff — so they take the
            # same parameters and draw through the same helper. Direction is one of them:
            # leaving it off here left In/Out/InOut silently stuck on the stamped default.
            col.prop(fobj, "mg_field_dir")
            _ease_params(col, fobj, fobj.mg_field_shape)
        col.prop(fobj, "mg_field_bias")
        if ftype == 'RING':
            col.prop(fobj, "mg_field_width")
        if ftype in {'RANDOM', 'VORONOI', 'NOISE'}:
            col.prop(fobj, "mg_field_seed")
        if ftype in {'VORONOI', 'WAVES', 'NOISE'}:
            col.prop(fobj, "mg_field_scale")
        if ftype == 'NOISE':
            col.prop(fobj, "mg_field_detail")


class MG_PT_effectors(_Panel, bpy.types.Panel):
    bl_label = "Effectors"
    bl_parent_id = "MG_PT_main"
    bl_order = 2

    @classmethod
    def poll(cls, context):
        return cloner.active(context) is not None

    def draw(self, context):
        layout = self.layout
        car = cloner.active(context)
        layout.operator_menu_enum("mographwerks.add_effector", "eff_type",
                                  text="Add Effector", icon='ADD')
        effs = effectors.stack(car)
        if not effs:
            r = layout.row()
            r.enabled = False
            r.label(text="No effectors — nothing will move", icon='INFO')
            return
        for mod in effs:
            box = layout.box()
            hdr = box.row(align=True)
            hdr.prop(mod, "show_expanded", text="", emboss=False)
            # ⚠ EMBOSSED. Drawn flat this reads as a label and the name cannot be edited —
            # Rob: "I'm clicking on the Effector name in the N panel and I can't rename it".
            # ⚠ BLENDER'S OWN MODIFIER HEADER ORDER: expand, icon, name, viewport, render,
            # reorder, delete. Matching it is the whole point — a stack that reads like the
            # modifier stack needs no explaining, and every Blender user already knows which
            # icon does what.
            hdr.label(text="", icon=ng.EFFECTOR_ICONS.get(props.get(mod, "Type"), 'BLANK1'))
            hdr.prop(mod, "name", text="")
            sub = hdr.row(align=True)
            # ⚠ THE RENDER TOGGLE, which we never exposed: muting an effector in renders while
            # keeping it in the viewport is a real thing to want, and Blender draws the right
            # monitor/camera icons for these two on its own when the text is blank.
            sub.prop(mod, "show_viewport", text="")
            sub.prop(mod, "show_render", text="")
            op = sub.operator("mographwerks.move_effector", text="", icon='TRIA_UP')
            op.mod_name = mod.name
            op.dir = -1
            op = sub.operator("mographwerks.move_effector", text="", icon='TRIA_DOWN')
            op.mod_name = mod.name
            op.dir = 1
            sub.operator("mographwerks.remove_effector", text="",
                         icon='X').mod_name = mod.name
            if not mod.show_expanded:
                continue
            col = box.column()
            col.use_property_split = True
            for nm in ("Type",):
                h = props.holder(mod, nm)
                if h is not None:
                    col.prop(h, "value", text=nm)
            # ⚠ Seed only means something for Random — the others do not roll anything, so
            # drawing it there would be a control that does nothing.
            if props.get(mod, "Type") == "Random":
                h = props.holder(mod, "Seed")
                if h is not None:
                    col.prop(h, "value", text="Seed")
            # ⚠ PUSH APART DRAWS A DIFFERENT SET. It computes its own offset from the
            # neighbours, so the typed Offset means nothing to it, and it deliberately does
            # not rotate or scale — the node group forces both to identity so that hiding
            # them here does not leave a control secretly still applying.
            if props.get(mod, "Type") == ng.PUSH_APART:
                rows = ("Radius", "Use Clone Size", "Iterations", "Strength")
            else:
                rows = ("Offset", "Rotation", "Scale", "Strength")
            for nm in rows:
                h = props.holder(mod, nm)
                if h is not None:
                    col.prop(h, "value", text=nm)
            fbox = box.box()
            rws = effectors.rows(mod)
            filled = [r for r in rws if r[2] is not None]
            hdr = fbox.row(align=True)
            hdr.enabled = len(filled) < len(rws)
            # ⚠ the target is set on the ROW, so it is scoped to this button and resolved
            # when the menu opens — not stashed during draw, where the last panel wins.
            hdr.context_pointer_set("mg_field_stack", mod)
            hdr.menu("MG_MT_add_field", text="Add Field", icon='ADD')
            if not filled:
                r = fbox.row()
                r.enabled = False
                r.label(text="No fields — applies everywhere", icon='INFO')
            for i, (slot, blend, fobj) in enumerate(rws):
                if fobj is not None:
                    _draw_field_row(fbox, mod, i, slot, blend, fobj)


class MG_PT_remove(_Panel, bpy.types.Panel):
    """Just a button.

    ⚠ NO HEADER. Rob: "Remove Cloner doesn't need to be in a header. Can just be a button."
    `HIDE_HEADER` keeps it a panel — so it still sorts last under the parent — while drawing
    nothing but its contents. A plain button in the PARENT's draw would appear ABOVE every
    department, because Blender draws child panels after the parent's own content, and a
    destructive action at the top of the panel is the wrong place for it.
    """

    bl_label = ""
    bl_parent_id = "MG_PT_main"
    bl_options = {'HIDE_HEADER'}
    bl_order = 4

    @classmethod
    def poll(cls, context):
        return cloner.active(context) is not None

    def draw(self, context):
        row = self.layout.row()
        row.scale_y = 1.2
        row.operator("mographwerks.remove_cloner", text="Remove Cloner", icon='TRASH')


CLASSES = (MG_MT_add, MG_MT_mode, MG_PT_main, MG_PT_source, MG_PT_distribute, MG_PT_effectors,
           MG_PT_remove)


# ⚠⚠ SNAPSHOT THE PANEL INTENT AT IMPORT, while the classes are fresh from source. Blender
# writes `bl_*` back onto the Python class during (un)register, so repeated reload cycles leave
# STALE values that silently override this file — every `bl_order` comes back 0 and Blender
# then sorts tied sub-panels ALPHABETICALLY. That is how Source (order 0) ended up drawn last.
# ⚠ This is Werkbench's fix, ported. It was written there in v2.4.1 and noted as "worth porting
# to Motionwerks and Mographwerks"; the note was never acted on, which is why Werkbench healed
# itself after a restart and this did not.
_PANEL_INTENT = {c.__name__: (c.__dict__.get("bl_category", _Panel.bl_category),
                              c.__dict__.get("bl_order"))
                 for c in CLASSES if issubclass(c, bpy.types.Panel)}


def register():
    for c in CLASSES:
        intent = _PANEL_INTENT.get(c.__name__)
        if intent is not None:
            c.bl_category = intent[0]
            if intent[1] is not None:
                c.bl_order = intent[1]
        bpy.utils.register_class(c)
    bpy.types.VIEW3D_MT_add.append(_add_menu)


def unregister():
    # ⚠ REMOVE THE APPEND FIRST, and guard it: a reload that leaves the draw function on
    # VIEW3D_MT_add pointing at an unregistered menu makes Shift+A raise for the whole scene,
    # not just for us.
    try:
        bpy.types.VIEW3D_MT_add.remove(_add_menu)
    except Exception:
        pass
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
