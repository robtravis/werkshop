"""Field objects: the gizmo you select, move and keyframe.

⚠ FIELDS ARE OBJECTS AND MUST STAY OBJECTS. Considered and rejected: a matrix socket driven
by a native transform gizmo. A MATRIX modifier input has no `value` property at all — it
cannot be written, drawn or keyframed — so a field on a socket could never be animated.
Rob: *"Selecting the gizmo in the viewport is a big thing. Otherwise how would you change
and animate its position?"*

⚠ A GIZMO MESH IS UNIT-SIZED AND THE OBJECT'S SCALE IS THE REGION. The falloff reads clone
position in the field's LOCAL space, so a mesh built at radius 1.5 with scale 1 still
describes a unit region and everything outside it clamps — which reads as "the field does
nothing".

⚠ THE MESH CARRIES THE SETTINGS. Every parameter is stamped as a point attribute so the
node group can read it per field (see `ng.FIELD_ATTRS`). That is what lets an effector's
slot be nothing but an object and a blend mode instead of eight more sockets.
"""

import math

import bpy

from . import ng, props

# ⚠ (id, label, description, icon, number) — FIVE elements. A 4-tuple is read as
# (id, label, desc, number), so an icon without the trailing number becomes the enum VALUE
# and every item collapses onto the same one.
# ⚠ The number IS the stored `mg_type`, and it must match ng.FALLOFF_TYPES' order.
FIELD_ITEMS = (
    ('LINEAR', "Linear", "A straight sweep along the arrow", 'EMPTY_SINGLE_ARROW', 0),
    ('SPHERE', "Sphere", "A sweep outward from the centre", 'MESH_UVSPHERE', 1),
    ('BOX', "Box", "A sweep outward in square rings", 'MESH_CUBE', 2),
    ('RANDOM', "Random", "No direction — every clone gets its own place", 'RNDCURVE', 3),
    ('RING', "Ring", "An expanding ring", 'MESH_CIRCLE', 4),
    ('RADIAL', "Radial", "A sweep around the axis, like a clock hand", 'FORCE_VORTEX', 5),
    ('VORONOI', "Voronoi", "Cell noise — irregular patches", 'MOD_TRIANGULATE', 6),
    ('WAVES', "Waves", "Parallel bands sweeping across", 'MOD_WAVE', 7),
    ('NOISE', "Noise", "Soft fractal blotches", 'MOD_NOISE', 8),
    # ⚠ SEQUENCE REPLACES THE SHAPE. It is a clock, not a falloff: the gizmo gives the order
    # and Progress plays it. Every other type is animated by moving the gizmo; this one by
    # keyframing a slider — which is the whole difference.
    ('SEQUENCE', "Sequence", "A keyframable build along the gizmo", 'TIME', 9),
)

TYPE_INT = {ident: num for ident, _l, _d, _i, num in FIELD_ITEMS}

EASE_ITEMS = tuple((n.upper().replace(" ", "_"), n, ng.CURVE_DESC.get(n, ""), i)
                   for i, n in enumerate(ng.EASE_TYPES))

# ⚠ An EnumProperty READS BACK ITS IDENTIFIER, not the number in its items tuple. The
# number only sets the stored value; `obj.mg_field_ease` is the string 'EASE_IN'. Every
# enum that has to reach a socket as an int needs a map like this one — `TYPE_INT` has it,
# and forgetting it here crashed the stamp the first time a field was created.
EASE_INT = {ident: num for ident, _l, _d, num in EASE_ITEMS}

SHAPE_ITEMS = tuple((n.upper().replace(" ", "_"), n, ng.CURVE_DESC.get(n, ""), i)
                    for i, n in enumerate(ng.SHAPE_TYPES))
SHAPE_INT = {ident: num for ident, _l, _d, num in SHAPE_ITEMS}

DIR_ITEMS = tuple((d.upper(), d, "", i) for i, d in enumerate(ng.EASE_DIRS))
DIR_INT = {ident: num for ident, _l, _d, num in DIR_ITEMS}

# ⚠ THE SIGN IS PART OF THE AXIS, not a separate Reverse toggle. A negative axis vector
# swaps which clone the reduction sees as first, so running the build backwards is the same
# maths — and it keeps Sequence to ONE control instead of two.
AXIS_ITEMS = tuple((a, a, "", i) for i, a in enumerate(ng.SEQ_AXES))
AXIS_INT = {ident: num for ident, _l, _d, num in AXIS_ITEMS}


# --------------------------------------------------------------------------- gizmo meshes
def _ring(n=32, r=1.0, axis='Z'):
    vs, es = [], []
    for i in range(n):
        a = 2.0 * math.pi * i / n
        c, s = math.cos(a) * r, math.sin(a) * r
        vs.append({'Z': (c, s, 0.0), 'Y': (c, 0.0, s), 'X': (0.0, c, s)}[axis])
        es.append((i, (i + 1) % n))
    return vs, es


def _shift(vs, es, off):
    return vs, [(a + off, b + off) for a, b in es]


def _combine(*parts):
    vs, es = [], []
    for pv, pe in parts:
        pv, pe = _shift(pv, pe, len(vs))
        vs += pv
        es += pe
    return vs, es


def _arrow():
    """A line along +Z with a head — the ramp runs along the gizmo's +Z."""
    vs = [(0, 0, -1), (0, 0, 1), (0.12, 0, 0.75), (-0.12, 0, 0.75),
          (0, 0.12, 0.75), (0, -0.12, 0.75)]
    es = [(0, 1), (1, 2), (1, 3), (1, 4), (1, 5)]
    return vs, es


def _plane(z):
    """A square in XY at height `z` — one end of the ramp."""
    return ([(-1, -1, z), (1, -1, z), (1, 1, z), (-1, 1, z)],
            [(0, 1), (1, 2), (2, 3), (3, 0)])


def _linear(inner=0.0):
    """C4D's linear field: two planes with the arrow running between them.

    ⚠ THE PLANES ARE NOT DECORATION — they sit exactly where u = 0 and u = 1. The ramp maps
    local Z from -1..+1 onto 0..1, so the near plane is where the falloff starts and the far
    plane is where it finishes. An arrow alone shows direction but says nothing about REACH,
    which is what makes a linear field hard to judge. Rob: *"It might give you a better idea
    of scale."*
    """
    # ⚠ THE INNER PLANE SLIDES between the two. u=0 is the near plane and u=1 the far one,
    # so Inner marks where the solid region ends and the falloff BAND begins — both are
    # visible at once, which is the whole point of drawing it.
    parts = [_plane(-1.0), _plane(1.0), _arrow()]
    if inner > 0.001:
        parts.append(_plane(-1.0 + 2.0 * inner))
    return _combine(*parts)


def _cube(r=1.0):
    v = [(x * r, y * r, z * r) for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)]
    e = [(0, 1), (0, 2), (0, 4), (1, 3), (1, 5), (2, 3), (2, 6),
         (3, 7), (4, 5), (4, 6), (5, 7), (6, 7)]
    return v, e


def _box(inner=0.0):
    """Outer box plus, when Inner is set, the solid box nested inside it — C4D's two shapes.

    ⚠ THE INNER CANNOT BE DRAWN DARKER. A wireframe object draws in ONE outline colour and
    Blender has no per-edge colour, so the two are told apart by SHAPE and nesting only.
    """
    if inner > 0.001:
        return _combine(_cube(1.0), _cube(inner))
    return _cube(1.0)


def _sphere(inner=0.0):
    parts = [_ring(axis='Z'), _ring(axis='Y'), _ring(axis='X')]
    if inner > 0.001:
        # ⚠ fewer segments on the inner ring: with no colour to differentiate them, a
        # coarser silhouette is what makes the two readable apart.
        parts += [_ring(16, inner, 'Z'), _ring(16, inner, 'Y')]
    return _combine(*parts)


# ------------------------------------------------------------------------- custom curve
CURVE_N = ng.CURVE_SAMPLES


def curve_host(obj, create=False):
    """The node tree holding this field's custom curve, or None.

    ⚠ A NODE TREE ONLY BECAUSE A CurveMapping HAS NOWHERE ELSE TO LIVE. `bpy.props` has no
    curve type and there is no curve SOCKET type, so a Float Curve node is the only container
    Blender offers — and `template_curve_mapping` is the only way to draw one.
    ⚠ REFERENCED BY A REAL PointerProperty, not by name. That makes it a tracked user, so the
    tree is written into the .blend, survives a round trip, and drops to zero users when the
    field is deleted — verified, including that the orphan is purged on the next save.
    """
    tree = obj.mg_field_curve
    if tree is None and create:
        tree = bpy.data.node_groups.new("MG_Curve_" + obj.name, 'ShaderNodeTree')
        tree.nodes.new('ShaderNodeFloatCurve')
        obj.mg_field_curve = tree
    return tree


def curve_node(obj, create=False):
    tree = curve_host(obj, create)
    if tree is None:
        return None
    return next((n for n in tree.nodes if n.bl_idname == 'ShaderNodeFloatCurve'), None)


def curve_values(obj):
    """The curve sampled into `CURVE_N` values, or None if this field has no curve."""
    node = curve_node(obj)
    if node is None:
        return None
    m = node.mapping
    # ⚠ `update()` BEFORE evaluating, or the mapping evaluates against its previous state and
    # the LUT lags the widget by one edit.
    m.update()
    return [m.evaluate(m.curves[0], i / (CURVE_N - 1.0)) for i in range(CURVE_N)]


def curve_fingerprint(obj):
    """A cheap signature of the curve's control points.

    ⚠ EDITING A CurveMapping FIRES NO DEPSGRAPH UPDATE — measured, the handler saw nothing at
    all — so there is no event to hang a re-stamp on. This is what a poll compares instead;
    it costs about 3 microseconds.
    """
    node = curve_node(obj)
    if node is None:
        return None
    c = node.mapping.curves[0]
    return tuple((round(p.location[0], 6), round(p.location[1], 6), p.handle_type)
                 for p in c.points)


def _write_curve(me, obj):
    """Bake the field's curve onto the strip, and stamp where the strip starts."""
    n = len(me.vertices)
    base = max(n - CURVE_N, 0)
    _write(me, "mg_lut_base", 'INT', base)
    vals = curve_values(obj)
    if vals is None or n < CURVE_N:
        return
    at = me.attributes.get("mg_curve")
    if at is None or at.data_type != 'FLOAT' or at.domain != 'POINT':
        if at is not None:
            me.attributes.remove(at)
        at = me.attributes.new("mg_curve", 'FLOAT', 'POINT')
    for i in range(CURVE_N):
        at.data[base + i].value = vals[i]


def _marker():
    """For types with no spatial shape of their own — Random and the textures."""
    return ([(-0.3, 0, 0), (0.3, 0, 0), (0, -0.3, 0), (0, 0.3, 0), (0, 0, -0.3), (0, 0, 0.3)],
            [(0, 1), (2, 3), (4, 5)])


# ⚠ every shape function takes `inner` so the gizmo can DRAW it; most ignore it.
_SHAPES = {
    'LINEAR': _linear,
    # ⚠ Sequence gets the SAME two planes on purpose: spatially it IS the linear ramp, and
    # looking like one is the clearest way to say so. The ring at its centre is what tells
    # the two apart — that one is a clock.
    # ⚠ NO PLANES AND NO ARROW. Sequence has no falloff to draw and its transform is not
    # read, so a linear-looking gizmo would be a lie in three ways at once — it would imply a
    # reach, a direction and a scale, none of which exist. What is left is a marker saying
    # "the clock lives here"; the direction is the Axis dropdown, which cannot be misread.
    'SEQUENCE': lambda inner=0.0: _combine(_ring(24, 0.5, 'Z'), _ring(16, 0.25, 'X'),
                                           _marker()),
    'SPHERE': _sphere,
    'BOX': _box,
    # ⚠ Ring's two circles are its WIDTH band, not an inner/outer pair.
    'RING': lambda inner=0.0: _combine(_ring(48), _ring(48, 0.75)),
    'RADIAL': lambda inner=0.0: _combine(_ring(48), ([(0, 0, 0), (1, 0, 0)], [(0, 1)])),
    'RANDOM': lambda inner=0.0: _marker(),
    'VORONOI': lambda inner=0.0: _marker(),
    'WAVES': lambda inner=0.0: _marker(),
    'NOISE': lambda inner=0.0: _marker(),
}


def rebuild_gizmo(obj):
    """Reshape the gizmo mesh to match its type, keeping the object and its transform."""
    shape = _SHAPES.get(obj.mg_field_type)
    vs, es = shape(obj.mg_field_inner) if shape else _marker()
    # ⚠⚠ THE CURVE LUT RIDES ON THE GIZMO MESH, as a strip APPENDED after the shape. It is
    # rebuilt here because this function throws the mesh away and remakes it whenever the
    # field's type changes.
    # ⚠ EVERY STRIP VERTEX IS COINCIDENT WITH VERTEX 0, never loose at the origin: bounding
    # box, dimensions, edge and face counts then match a gizmo without it (verified), so
    # nothing new is drawn and picking is unchanged.
    # ⚠ APPENDED, NOT PREPENDED, so the shape's edge indices are untouched — and the offset is
    # STAMPED (`mg_lut_base`) rather than assumed, because vertex counts differ per type.
    vs = list(vs) + [vs[0]] * CURVE_N
    me = obj.data
    me.clear_geometry()
    me.from_pydata(vs, es, [])
    me.update()
    stamp(obj)


# ------------------------------------------------------------------------------ stamping
def _write(me, name, kind, value):
    """Stamp one scalar onto the gizmo, at VERTEX 0.

    ⚠ VERTEX 0 ONLY, not every vertex. Measured on the built node group: of the 42 Sample
    Index nodes in MG_Falloff, 38 read at the default index 0 and the only 4 with a computed
    index are the curve-LUT taps. Every scalar is therefore read at index 0 and writing the
    same number to the other vertices was always redundant.
    ⚠ IT STOPPED BEING FREE when the curve LUT added 128 vertices to the gizmo: 18 attributes
    across 142 vertices measured at 0.808 ms per stamp against 0.025 ms for one vertex, and
    stamping runs on every parameter change. Same values, 32x less work.
    ⚠ The other vertices keep the attribute's default (0). Anything that ever samples a field
    scalar at another index would read that zero — so if a future graph needs one, write it
    there deliberately rather than reinstating the blanket loop.
    """
    at = me.attributes.get(name)
    if at is None or at.data_type != kind or at.domain != 'POINT':
        if at is not None:
            me.attributes.remove(at)
        at = me.attributes.new(name, kind, 'POINT')
    if len(me.vertices):
        at.data[0].value = value


def stamp(obj):
    """Write the object's settings onto its mesh, where the node group reads them.

    ⚠ Every attribute in `ng.FIELD_ATTRS` must be written. A field whose mesh lacks one
    falls back to the effector's socket for that parameter — which looks like the control
    doing nothing, not like a missing stamp.
    """
    me = getattr(obj, "data", None)
    if me is None or not hasattr(me, "attributes") or not len(me.vertices):
        return
    _write(me, "mg_type", 'INT', TYPE_INT.get(obj.mg_field_type, 0))
    _write(me, "mg_invert", 'BOOLEAN', bool(obj.mg_field_invert))
    _write(me, "mg_bias", 'FLOAT', obj.mg_field_bias)
    _write(me, "mg_seed", 'INT', obj.mg_field_seed)
    _write(me, "mg_width", 'FLOAT', obj.mg_field_width)
    _write(me, "mg_scale", 'FLOAT', obj.mg_field_scale)
    _write(me, "mg_detail", 'FLOAT', obj.mg_field_detail)
    _write(me, "mg_spread", 'FLOAT', obj.mg_field_spread)
    _write(me, "mg_ease", 'INT', EASE_INT.get(obj.mg_field_ease, 0))
    _write(me, "mg_inner", 'FLOAT', obj.mg_field_inner)
    _write(me, "mg_shape", 'INT', SHAPE_INT.get(obj.mg_field_shape, 1))
    _write(me, "mg_freq", 'INT', obj.mg_field_freq)
    _write(me, "mg_dir", 'INT', DIR_INT.get(obj.mg_field_dir, 1))
    _write(me, "mg_exp", 'FLOAT', obj.mg_field_exp)
    _write(me, "mg_base", 'FLOAT', obj.mg_field_base)
    _write(me, "mg_size", 'FLOAT', obj.mg_field_size)
    _write(me, "mg_mirror", 'BOOLEAN', bool(obj.mg_field_mirror))
    _write(me, "mg_axis", 'INT', AXIS_INT.get(obj.mg_field_axis, 0))
    # ⚠ THE CURVE IS THE ONE PER-VERTEX VALUE. Everything above is a single number repeated;
    # this is a lookup table, one sample per vertex, read at a computed index.
    _write_curve(me, obj)
    # ⚠ TAG, OR THE CHANGE DOES NOT LAND. Writing attribute values through `attribute.data`
    # does not mark the mesh dirty, so the depsgraph keeps handing every cloner the PREVIOUS
    # evaluation — the field looks inert until some unrelated edit forces a re-evaluate.
    # Rob: "adding a field requires an effector parameter change for it to take effect."
    me.update()
    obj.update_tag(refresh={'DATA'})
    _retrigger(obj)


def _retrigger(field):
    """Nudge every cloner whose stack uses this field.

    ⚠ The modifier depends on the field OBJECT, but a change to the object's mesh
    ATTRIBUTES does not always propagate on its own. Tag the consumers explicitly rather
    than relying on it — the cost is one tag per cloner, and the alternative is a control
    that silently does nothing until you touch something else.
    """
    from . import cloner, effectors
    for obj in bpy.data.objects:
        if not obj.get("mg_cloner"):
            continue
        for m in effectors.stack(obj):
            for slot in effectors.SLOTS:
                if props.get(m, slot) is field:
                    obj.update_tag()
                    break


def _upd_type(self, context):
    rebuild_gizmo(self)


def _upd(self, context):
    # ⚠ PICKING Custom IS WHAT CREATES THE CURVE, lazily — a field that never uses one never
    # carries a node tree, so ordinary fields cost nothing.
    if 'CUSTOM' in (self.mg_field_shape, self.mg_field_ease):
        curve_host(self, create=True)
    stamp(self)


# ------------------------------------------------------------------------- live updating
_curve_seen = {}


def _poll_curves():
    """Re-stamp any field whose curve has been edited.

    ⚠ A TIMER, BECAUSE THERE IS NO EVENT. Editing a CurveMapping fires no depsgraph update
    at all (measured), so `_on_depsgraph` never sees it and the field would sit on a stale
    LUT until something unrelated forced a re-stamp.
    ⚠ The fingerprint is what keeps this cheap: about 3 microseconds per field, and a
    re-stamp only happens when the control points actually moved.
    """
    try:
        for obj in bpy.data.objects:
            if not obj.get("mg_field") or obj.mg_field_curve is None:
                continue
            fp = curve_fingerprint(obj)
            if _curve_seen.get(obj.name) != fp:
                _curve_seen[obj.name] = fp
                stamp(obj)
    except Exception:
        # ⚠ NEVER let a timer raise — Blender unregisters it and live updating dies silently
        # for the rest of the session.
        pass
    return 0.2


def is_field(obj):
    return bool(obj and obj.type == 'MESH' and obj.get("mg_field"))


# ------------------------------------------------------------------------------- creating
def create(context, field_type, name_base="Field", location=None, collection=None):
    """A new field gizmo: unit-sized, wireframe, never rendered.

    ⚠ IT IS FILED WITH ITS CLONER. Rob: "Cloner and Fields get collected in a new collection
    in the root of where the object was." A gizmo left at the scene root while its cloner
    sits in a collection is the outliner clutter that collection exists to prevent.
    """
    me = bpy.data.meshes.new("%s.%s" % (name_base, field_type.title()))
    obj = bpy.data.objects.new(me.name, me)
    obj["mg_field"] = True
    obj.mg_field_type = field_type
    # ⚠ WIRE + no render. A field is a control, not geometry — it must never appear in a
    # render, and `display_type` keeps it readable in a busy viewport.
    obj.display_type = 'WIRE'
    obj.hide_render = True
    obj.show_in_front = True
    if location is not None:
        obj.location = location
    (collection or context.scene.collection).objects.link(obj)
    rebuild_gizmo(obj)
    return obj


def fit_to(obj, points):
    """Place, aim and scale a new gizmo so it already reads across these points.

    ⚠ A gizmo mesh is UNIT-SIZED and the object's SCALE is the region, so fitting means
    setting the transform — not building a bigger mesh.
    ⚠ LINEAR ramps along +Z. Left unrotated over a flat grid every clone reads the same
    value, which looks exactly like a broken field.
    ⚠ SEQUENCE IS NOT AIMED OR SIZED. Its order comes from the Axis dropdown and a reduction
    over the clones, so the gizmo is only a marker — it gets centred and left at identity.
    Rotating or scaling it changes nothing, and pretending otherwise is what made it read as
    a linear falloff in the first place.
    """
    from mathutils import Vector
    if not points:
        obj.scale = (2.0, 2.0, 2.0)
        return obj
    lo = Vector((min(p.x for p in points), min(p.y for p in points),
                 min(p.z for p in points)))
    hi = Vector((max(p.x for p in points), max(p.y for p in points),
                 max(p.z for p in points)))
    centre = (lo + hi) * 0.5
    size = hi - lo
    if obj.mg_field_type == 'SEQUENCE':
        obj.location = centre
        obj.rotation_euler = (0.0, 0.0, 0.0)
        obj.scale = (max(max(size) * 0.25, 0.001),) * 3
    elif obj.mg_field_type == 'LINEAR':
        # aim +Z down the LONGEST extent, and span it: the sweep then runs the length of
        # the distribution instead of across its thickness
        axis = max(range(3), key=lambda i: size[i])
        half = max(size[axis] * 0.55, 0.001)
        obj.location = centre
        rot = [(0.0, math.pi / 2.0, 0.0), (-math.pi / 2.0, 0.0, 0.0), (0.0, 0.0, 0.0)][axis]
        obj.rotation_euler = rot
        obj.scale = (half, half, half)
    else:
        obj.location = centre
        half = max(max(size) * 0.62, 0.001)
        obj.scale = (half, half, half)
    return obj


# ------------------------------------------------------------------------ live updates
_BUSY = False


@bpy.app.handlers.persistent
def _on_depsgraph(scene, depsgraph):
    """Re-tag a cloner when a field it uses changes.

    ⚠ WHY A HANDLER AND NOT JUST A DEPENDENCY. The modifier references the field OBJECT, so
    Blender knows they are related — but moving, scaling or reshaping the gizmo did not
    reliably re-evaluate the cloner, and the field sat inert until some unrelated edit forced
    it. Rob hit this twice on first use: "adding a field requires an effector parameter
    change for it to take effect. Same thing with adjusting the field's size."

    ⚠ Property-update callbacks cannot cover it: `f.scale` and `f.location` are native
    Object properties with no hook of ours on them. The handler is the only place that sees
    a transform change.

    ⚠ GUARDED against recursion — tagging inside a depsgraph handler re-enters it.
    """
    global _BUSY
    if _BUSY:
        return
    touched = [u.id.original for u in depsgraph.updates
               if isinstance(u.id, bpy.types.Object) and u.id.original.get("mg_field")]
    if not touched:
        return
    _BUSY = True
    try:
        for fld in touched:
            _retrigger(fld)
    finally:
        _BUSY = False


def register():
    if _on_depsgraph not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph)
    if not bpy.app.timers.is_registered(_poll_curves):
        bpy.app.timers.register(_poll_curves, persistent=True)
    O = bpy.types.Object
    O.mg_field_type = bpy.props.EnumProperty(
        name="Falloff", items=list(FIELD_ITEMS), default='LINEAR', update=_upd_type,
        description="The shape of this field's falloff")
    # ⚠ A POINTER so Blender tracks it as a user: the tree is then saved with the file and
    # freed when the field goes. A name would be an untracked link and silently break.
    O.mg_field_curve = bpy.props.PointerProperty(
        type=bpy.types.NodeTree, name="Curve",
        description="Node tree holding this field's custom falloff curve")
    O.mg_field_invert = bpy.props.BoolProperty(
        name="Invert", default=True, update=_upd,
        description="Flip the falloff. A Sphere reads 0 at its centre, so an un-inverted "
                    "mask would apply the effector OUTSIDE the sphere")
    O.mg_field_bias = bpy.props.FloatProperty(
        name="Bias", default=0.0, min=-1.0, max=1.0, subtype='FACTOR', update=_upd,
        description="Skew the falloff without changing its shape")
    O.mg_field_seed = bpy.props.IntProperty(
        name="Seed", default=0, min=0, update=_upd,
        description="Re-roll a Random, Voronoi or Noise field")
    O.mg_field_width = bpy.props.FloatProperty(
        name="Width", default=0.25, min=0.01, max=4.0, update=_upd,
        description="How thick the Ring is. Cannot reach zero — a zero-width ring would "
                    "put every clone on it")
    O.mg_field_scale = bpy.props.FloatProperty(
        name="Scale", default=5.0, min=0.0, soft_max=40.0, update=_upd,
        description="How fine the pattern is, in the FIELD's own space — so scaling the "
                    "gizmo scales the pattern with it")
    O.mg_field_detail = bpy.props.FloatProperty(
        name="Detail", default=2.0, min=0.0, max=15.0, update=_upd,
        description="Extra octaves of finer variation")
    # ⚠ THIS IS MoTools' PARAMETER SET, and it is the whole set: Type, Direction, Exponent,
    # Base, Size, Bounces, Mirror. Rob: "We should mirror the settings from the Ease node
    # with the Penner settings, disregard our previous settings." Amplitude and Decay were
    # ours, belonged to a damped-sine model that no longer exists, and are gone.
    O.mg_field_freq = bpy.props.IntProperty(
        name="Bounces", default=4, min=0, max=12, update=_upd,
        description="How many swings Elastic and Bounce make. 0 is not off — it leaves a "
                    "single quarter-swing")
    O.mg_field_base = bpy.props.FloatProperty(
        name="Base", default=10.0, min=1.0001, max=100.0, update=_upd,
        description="How hard Expo and Elastic are weighted toward the end. Higher holds "
                    "back longer and then moves faster")
    O.mg_field_size = bpy.props.FloatProperty(
        name="Size", default=1.70158, min=0.0, max=10.0, update=_upd,
        description="How far Back pulls past the ends. It still lands exactly on target at "
                    "any size")
    O.mg_field_axis = bpy.props.EnumProperty(
        name="Axis", items=list(AXIS_ITEMS), default='+X', update=_upd,
        description="Which way the build runs. The order is measured across the clones "
                    "themselves in the cloner's own space, so there is nothing to aim or "
                    "size — and a negative axis simply runs it backwards")
    O.mg_field_mirror = bpy.props.BoolProperty(
        name="Mirror", default=False, update=_upd,
        description="Play the curve out and back, so it returns to where it started")
    O.mg_field_dir = bpy.props.EnumProperty(
        name="Direction", items=list(DIR_ITEMS), default='OUT', update=_upd,
        description="In eases at the start, Out at the end, InOut at both. Out is what "
                    "most motion wants — it arrives and settles")
    O.mg_field_exp = bpy.props.FloatProperty(
        name="Exponent", default=2.0, min=0.1, max=10.0, update=_upd,
        description="How steep the Power curve is. 2 is quadratic, 3 cubic, higher is sharper")
    O.mg_field_shape = bpy.props.EnumProperty(
        name="Shape", items=list(SHAPE_ITEMS), default='SINE', update=_upd,
        description="How the falloff ramps between the inner shape and the outer edge. "
                    "Smooth is the usual default; Linear is the raw ramp")
    O.mg_field_inner = bpy.props.FloatProperty(
        # ⚠ 0.3, NOT 0. At 0 a field is a pure gradient from its centre and the inner shape
        # is not drawn at all — the feature arrives invisible, which is very nearly the same
        # as not having it. Rob: "I'm not seeing the new fields." A non-zero default also
        # matches C4D, where enclosing your clones means they are solidly affected.
        name="Inner", default=0.3, min=0.0, max=0.99, subtype='FACTOR', update=_upd_type,
        description="How much of the region is FULLY affected before the falloff starts. "
                    "At 0 the field is a pure gradient from its centre; raise it for a "
                    "solid core with a soft edge, like C4D's inner shape")
    O.mg_field_spread = bpy.props.FloatProperty(
        name="Spread", default=0.6, min=0.0, max=0.95, update=_upd,
        description="How much the clones overlap in time. At 0.95 the window is nearly "
                    "gone and they move almost together")
    O.mg_field_ease = bpy.props.EnumProperty(
        name="Ease", items=list(EASE_ITEMS), default='SINE', update=_upd,
        description="The curve each clone follows over its own part of the build")


def unregister():
    if _on_depsgraph in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph)
    if bpy.app.timers.is_registered(_poll_curves):
        bpy.app.timers.unregister(_poll_curves)
    for p in ("mg_field_curve", "mg_field_dir", "mg_field_exp", "mg_field_base", "mg_field_size", "mg_field_mirror", "mg_field_axis", "mg_field_freq", "mg_field_shape", "mg_field_inner", "mg_field_type", "mg_field_invert", "mg_field_bias", "mg_field_seed",
              "mg_field_width", "mg_field_scale", "mg_field_detail",
              "mg_field_spread", "mg_field_ease"):
        if hasattr(bpy.types.Object, p):
            delattr(bpy.types.Object, p)
