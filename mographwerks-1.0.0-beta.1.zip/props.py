"""The modifier-value seam.

⚠ THIS IS THE ONLY PLACE THAT TOUCHES `mod.properties.inputs`. That API changed shape
between Blender 4.x (`mod["Socket_2"]`) and 5.x, and it is the surface most likely to move
again — so every read and write in the addon goes through here. Keeping it thin is the
point; if it grows helpers that know about cloners or effectors, it is in the wrong file.

⚠ Inputs are addressed by socket IDENTIFIER, not name, and identifiers are creation-ordered.
Resolve by NAME every time and let this module do the lookup. Never cache an index.
"""

_MISSING = object()


def sid(ng, name):
    """The identifier of an INPUT socket, or None if the group has no such socket."""
    if ng is None:
        return None
    for s in ng.interface.items_tree:
        if getattr(s, "in_out", "") == 'INPUT' and s.name == name:
            return s.identifier
    return None


def holder(mod, name):
    """The live PropertyGroup for one modifier input, so a panel can draw it directly.

    That is what makes these native, keyframable controls rather than addon state that has
    to be pushed — the panel draws the socket itself.
    """
    if mod is None or mod.node_group is None:
        return None
    ident = sid(mod.node_group, name)
    if ident is None:
        return None
    return getattr(mod.properties.inputs, ident, None)


def get(mod, name, default=None):
    h = holder(mod, name)
    if h is None:
        return default
    try:
        return h.value
    except AttributeError:
        # ⚠ Not every socket type exposes `value`. A MATRIX input has only `name` and
        # `type` — it cannot be read, written or keyframed, which is why a field's
        # transform can never live on a socket. See MOGRAPHWERKS_REBUILD.md §6.1.
        return default


def set(mod, name, value):
    """Write a modifier input. Returns True if it landed, False if there was no such socket.

    ⚠ Returns a BOOL rather than failing silently. The old `_set` swallowed everything, so a
    renamed socket meant a control that appeared in the panel and quietly did nothing —
    twice. Callers that care should check.
    """
    h = holder(mod, name)
    if h is None:
        return False
    try:
        h.value = value
        return True
    except (AttributeError, TypeError):
        return False


def is_animatable(mod, name):
    """Whether this input can carry a keyframe — not all socket types can."""
    h = holder(mod, name)
    if h is None:
        return False
    prop = type(h).bl_rna.properties.get("value")
    return bool(prop and prop.is_animatable)
