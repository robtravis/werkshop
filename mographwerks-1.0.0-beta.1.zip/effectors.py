"""The effector stack, and the field stack each effector carries.

⚠ EFFECTORS ARE MODIFIERS. They ARE the list — there is no parallel PropertyGroup to keep
in sync, so reorder, mute and rename come free from the modifier stack.

⚠ THEY COMPOSE THROUGH THE GEOMETRY STREAM. Each takes geometry in and hands transformed
geometry out, so stacking is just chaining modifiers. The old design had every effector
write named attributes for a sibling to read back, which cost a FLAT ~0.3 ms per effector
regardless of clone count — 100 cloners x 3 effectors was about 11 fps.
"""

import bpy

from . import cloner, fields, ng, props

EFFECTOR_NG = "MG_Effector"

# ⚠ Slot 1 is the BASE and has no blend mode — the others fold into it in order.
SLOTS = ("Field", "Field 2", "Field 3", "Field 4")
BLENDS = (None, "Blend 2", "Blend 3", "Blend 4")


def stack(obj):
    """Effector modifiers in stack order."""
    if obj is None:
        return []
    return [m for m in obj.modifiers
            if m.type == 'NODES' and m.node_group is not None
            and m.node_group.name == EFFECTOR_NG]


def rows(mod):
    """(slot name, blend name or None, field object or None) per slot, in order."""
    out = []
    for i, slot in enumerate(SLOTS):
        if props.holder(mod, slot) is None:
            break
        out.append((slot, BLENDS[i], props.get(mod, slot)))
    return out


def clone_positions(car, undisplaced=True):
    """Where the clones sit, so a new field can be fitted to them.

    ⚠ MEASURE THEM UNDISPLACED. Fitting to where the clones currently ARE means fitting to
    a moving target: the effectors have already shifted them, so a field created on a stack
    with an offset lands centred on the displaced cloud and reads nothing. Mute the stack,
    measure the distribution, put it back exactly as it was.
    """
    import bpy as _b
    muted = []
    if undisplaced:
        for m in stack(car):
            if m.show_viewport:
                muted.append(m)
                m.show_viewport = False
    try:
        car.update_tag()
        _b.context.view_layer.update()
        dg = _b.context.evaluated_depsgraph_get()
        return [i.matrix_world.translation.copy() for i in dg.object_instances
                if i.is_instance and i.parent is not None and i.parent.original is car]
    finally:
        for m in muted:
            m.show_viewport = True
        car.update_tag()
        _b.context.view_layer.update()


def first_empty(mod):
    """The first free slot, 1-based, or 0 if the stack is full."""
    for i, slot in enumerate(SLOTS):
        h = props.holder(mod, slot)
        if h is not None and props.get(mod, slot) is None:
            return i + 1
    return 0


class MG_OT_add_effector(bpy.types.Operator):
    bl_idname = "mographwerks.add_effector"
    bl_label = "Add Effector"
    bl_description = "Add an effector. Effectors stack — each adds its offset, rotation "\
                     "and scale on top of the others"
    bl_options = {'REGISTER', 'UNDO'}

    # ⚠ the type is chosen UP FRONT so the effector can be NAMED for what it is. Spawning a
    # Plain one to re-type afterwards leaves auto-naming with nothing sensible to do.
    eff_type: bpy.props.EnumProperty(
        name="Type", default='PLAIN',
        # ⚠ (id, label, description, icon, number) — FIVE elements. A 4-tuple is read as
        # (id, label, desc, number), so an icon without the trailing number becomes the enum
        # VALUE and every item collapses onto the same one. Same trap as FIELD_ITEMS.
        items=[(n.upper().replace(" ", "_"), n, d, i, k)
               for k, (n, d, i) in enumerate(ng.EFFECTOR_ITEMS)])

    def execute(self, context):
        car = cloner.active(context)
        if car is None:
            return {'CANCELLED'}
        group = bpy.data.node_groups.get(EFFECTOR_NG) or ng.ensure()[EFFECTOR_NG]
        name = ng.EFFECTOR_IDENTS[self.eff_type]
        m = car.modifiers.new(name, 'NODES')
        m.node_group = group
        props.set(m, "Type", name)
        # ⚠ THE DEFAULT HAS TO SUIT THE TYPE. Random multiplies the Offset PER AXIS, so a
        # Z-only default could only ever scatter vertically — which reads as a messier Plain.
        # Rob: "Random just seems to be a Plain effector." Plain and Step want a lift; Random
        # wants a scatter in all three.
        # ⚠ PUSH APART IGNORES the typed Offset entirely — it computes its own from where
        # the neighbours are — so it gets none, and the panel does not draw one.
        if name != ng.PUSH_APART:
            props.set(m, "Offset", (1.0, 1.0, 1.0) if self.eff_type == 'RANDOM'
                      else (0.0, 0.0, 2.0))
        return {'FINISHED'}


class MG_OT_remove_effector(bpy.types.Operator):
    bl_idname = "mographwerks.remove_effector"
    bl_label = "Remove Effector"
    bl_options = {'REGISTER', 'UNDO'}
    mod_name: bpy.props.StringProperty()

    def execute(self, context):
        car = cloner.active(context)
        m = car.modifiers.get(self.mod_name) if car else None
        if m is None:
            return {'CANCELLED'}
        # ⚠ take the gizmos with it, but only the ones nothing else still points at
        owned = {props.get(m, s).name for s in SLOTS if props.get(m, s) is not None}
        car.modifiers.remove(m)
        for name in owned:
            f = bpy.data.objects.get(name)
            if f is not None and f.get("mg_field") and cloner.cloner_using(f) is None:
                bpy.data.objects.remove(f)
        return {'FINISHED'}


class MG_OT_move_effector(bpy.types.Operator):
    bl_idname = "mographwerks.move_effector"
    bl_label = "Move Effector"
    bl_options = {'REGISTER', 'UNDO'}
    mod_name: bpy.props.StringProperty()
    dir: bpy.props.IntProperty(default=1)

    def execute(self, context):
        car = cloner.active(context)
        if car is None or car.modifiers.get(self.mod_name) is None:
            return {'CANCELLED'}
        i = car.modifiers.find(self.mod_name)
        j = i + self.dir
        if 0 <= j < len(car.modifiers):
            car.modifiers.move(i, j)
        return {'FINISHED'}


class MG_OT_add_field(bpy.types.Operator):
    bl_idname = "mographwerks.add_field"
    bl_label = "Add Field"
    bl_description = "Add a field to this effector. The gizmo is a wireframe drawing of "\
                     "the falloff itself — it never renders, and scaling it scales the region"
    bl_options = {'REGISTER', 'UNDO'}

    mod_name: bpy.props.StringProperty()
    # ⚠ 0 means FIRST EMPTY, resolved in execute(). One menu serves every effector, so it
    # cannot know which slot is free — and having it guess from draw-time state is exactly
    # the stash bug that made every field land on the wrong stack.
    slot: bpy.props.IntProperty(default=0, min=0, max=4)
    field_type: bpy.props.EnumProperty(name="Type", default='LINEAR',
                                       items=list(fields.FIELD_ITEMS))

    def execute(self, context):
        car = cloner.active(context)
        if car is None:
            return {'CANCELLED'}
        mod = car.modifiers.get(self.mod_name)
        if mod is None:
            self.report({'ERROR'}, "No effector called '%s'" % self.mod_name)
            return {'CANCELLED'}
        # ⚠ RESOLVE THE DESTINATION BEFORE CREATING ANYTHING. Building the gizmo first and
        # validating after leaked an orphan field into the scene on every failed add.
        slot = self.slot or first_empty(mod)
        if not slot:
            self.report({'WARNING'}, "Four fields is the maximum")
            return {'CANCELLED'}
        f = fields.create(context, self.field_type,
                          name_base=car.name.replace(".Cloner", ""),
                          collection=cloner.group_of(car))
        # ⚠ AIM AND SIZE IT AT THE CLONES. A Linear field's ramp runs along its own +Z, so a
        # default-oriented gizmo over a flat grid gives EVERY clone the same value and the
        # field looks broken. Rob, on first use: "Linear field is pointing up on Z and
        # doesn't seem to be doing anything." Fitting it is the difference between a field
        # that does nothing and one that already reads.
        fields.fit_to(f, clone_positions(car))
        props.set(mod, SLOTS[slot - 1], f)
        # ⚠ tag AFTER the socket is set and the gizmo is fitted, so the first evaluation
        # already sees the finished field rather than an unfitted one
        car.update_tag()
        for o in context.selected_objects:
            o.select_set(False)
        f.select_set(True)
        context.view_layer.objects.active = f
        return {'FINISHED'}


class MG_OT_remove_field(bpy.types.Operator):
    bl_idname = "mographwerks.remove_field"
    bl_label = "Remove Field"
    bl_description = "Take this field off the effector and delete its gizmo"
    bl_options = {'REGISTER', 'UNDO'}
    mod_name: bpy.props.StringProperty()
    index: bpy.props.IntProperty()

    def execute(self, context):
        car = cloner.active(context)
        mod = car.modifiers.get(self.mod_name) if car else None
        if mod is None:
            return {'CANCELLED'}
        gone = props.get(mod, SLOTS[self.index])
        # ⚠ shift the rest UP so the stack never shows a hole: occupancy is what switches a
        # blend on, so a gap would silently disable everything below it.
        for i in range(self.index, len(SLOTS) - 1):
            props.set(mod, SLOTS[i], props.get(mod, SLOTS[i + 1]))
            if BLENDS[i] and BLENDS[i + 1]:
                props.set(mod, BLENDS[i], props.get(mod, BLENDS[i + 1]))
        props.set(mod, SLOTS[-1], None)
        if gone is not None and gone.get("mg_field") and cloner.cloner_using(gone) is None:
            bpy.data.objects.remove(gone)
        return {'FINISHED'}


class MG_OT_fit_field(bpy.types.Operator):
    """Re-fit a field's gizmo to the clones it is masking.

    ⚠ DEFERRED UNTIL THE UI WAS DIALLED IN, on Rob's call, and now it is. A field is created
    fitted, but the cloner grows and moves afterwards — a Linear field aimed at a 4x4 grid
    reads nothing once that grid becomes 12x12 and twice the size, and re-aiming it by hand is
    the fiddliest thing in the addon.
    ⚠ IT MEASURES THE CLONES UNDISPLACED, which `clone_positions` already handles: fitting to
    where the clones currently ARE means fitting to a moving target, because the effectors
    have already shifted them.
    """

    bl_idname = "mographwerks.fit_field"
    bl_label = "Fit to Clones"
    bl_description = "Re-aim and re-size this field so it spans the clones again"
    bl_options = {'REGISTER', 'UNDO'}

    mod_name: bpy.props.StringProperty()
    index: bpy.props.IntProperty()

    def execute(self, context):
        car = cloner.active(context)
        mod = car.modifiers.get(self.mod_name) if car else None
        if mod is None:
            return {'CANCELLED'}
        f = props.get(mod, SLOTS[self.index])
        if f is None:
            return {'CANCELLED'}
        pts = clone_positions(car)
        if not pts:
            self.report({'WARNING'}, "No clones to fit to")
            return {'CANCELLED'}
        fields.fit_to(f, pts)
        # ⚠ tag AFTER the transform, or the cloner keeps handing out the previous evaluation
        # and the field looks inert until some unrelated edit forces a re-evaluate.
        f.update_tag()
        car.update_tag()
        return {'FINISHED'}


class MG_MT_add_field(bpy.types.Menu):
    """The field type list.

    ⚠ THE TARGET COMES FROM THE LAYOUT CONTEXT, never a stash. One menu serves every
    effector, so it has to learn which stack opened it. Parking that on the window manager
    during draw() meant the LAST panel drawn won, and every field landed on the wrong
    effector. `context_pointer_set` resolves at CLICK time and is scoped to the row.
    ⚠ No pointer = offer NOTHING. Falling back to "the first effector" is the old bug.
    """
    bl_idname = "MG_MT_add_field"
    bl_label = "Add Field"

    def draw(self, context):
        layout = self.layout
        mod = getattr(context, "mg_field_stack", None)
        if mod is None:
            r = layout.row()
            r.enabled = False
            r.label(text="No effector — reopen the panel", icon='ERROR')
            return
        for ident, label, _desc, icon, _n in fields.FIELD_ITEMS:
            op = layout.operator("mographwerks.add_field", text=label, icon=icon)
            op.field_type = ident
            op.slot = 0
            op.mod_name = mod.name


CLASSES = (MG_OT_add_effector, MG_OT_remove_effector, MG_OT_move_effector,
           MG_OT_add_field, MG_OT_remove_field, MG_OT_fit_field, MG_MT_add_field)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
