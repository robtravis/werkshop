"""Voronoi fracture: real cells, cut out of the real mesh.

⚠ THIS IS THE STANDARD ALGORITHM, implemented from it — not from anyone's source. A Voronoi
cell is the intersection of half-spaces, so you get it by taking a box that certainly contains
the cell and slicing it with the perpendicular bisector plane between the seed and each of its
neighbours. Blender's own Cell Fracture works this way; so does every other implementation.

⚠ WHY IT REPLACED BOTH THE HULL AND THE CELL FRACTURE BUTTON:

    Live (convex hulls of sampled points)   ~54% of the volume, seams everywhere, and the
                                            piece count only approximate
    Blender's Cell Fracture                 watertight, but its own window, its own presets,
                                            and it emits objects we then have to gather up
    this                                    exact cells, exact count, watertight, our settings

⚠ IT IS A BAKE, not a live modifier. The result is real geometry, joined into one mesh and
handed to the Pieces generator — which is what puts the shards on the effector stack.
"""

import random

import bmesh
import bpy
from mathutils import Vector
from mathutils.kdtree import KDTree

# ⚠ A CELL'S FACES ONLY EVER COME FROM NEARBY SEEDS, so bisecting against the whole cloud is
# wasted work. 24 neighbours is far past what a 3D Voronoi cell can have (the average is about
# 15) and keeps a 200-piece fracture quick.
NEIGHBOURS = 24


def _grid_points(ob, count, jitter, seed):
    """`count`-ish points on a lattice inside the mesh — regular breaks, brick and tile.

    ⚠ THE LATTICE IS PROPORTIONED TO THE OBJECT, not a cube root per axis. A wall is thin in
    one axis, and an even nx=ny=nz split would put the same number of cuts through its
    thickness as along its length — long thin slabs where you asked for bricks.
    ⚠ THE COUNT IS APPROXIMATE HERE and exact for Random, because a lattice can only land on
    products of three integers. Jitter 0 is a true grid; 1 pushes each point up to half a cell
    and reads as natural stonework.
    """
    rng = random.Random(seed)
    lo = Vector((min(v[0] for v in ob.bound_box), min(v[1] for v in ob.bound_box),
                 min(v[2] for v in ob.bound_box)))
    hi = Vector((max(v[0] for v in ob.bound_box), max(v[1] for v in ob.bound_box),
                 max(v[2] for v in ob.bound_box)))
    # ⚠⚠ A FLAT OBJECT HAS NO VOLUME, and a volume-derived cell edge then collapses toward
    # zero — `dims / edge` becomes millions of cells and the fracture HANGS. A plane is the
    # ordinary case here, not an edge case. Treat a degenerate axis as a small fraction of the
    # largest so the lattice stays 2D-ish instead of exploding.
    dims = Vector((max(hi[i] - lo[i], 1e-6) for i in range(3)))
    big = max(dims)
    eff = Vector((max(dims[i], big * 0.05) for i in range(3)))
    edge = (eff.x * eff.y * eff.z / max(count, 1)) ** (1.0 / 3.0)
    res = [max(1, int(round(eff[i] / edge))) for i in range(3)]
    # ⚠ AND CAP THE TOTAL. Rounding up on three axes multiplies, so a modest count can still
    # ask for far more cells than intended; trim the longest axis until it is close.
    while res[0] * res[1] * res[2] > max(count, 1) * 2:
        res[res.index(max(res))] -= 1
    step = Vector((dims[i] / res[i] for i in range(3)))
    pts = []
    lattice = []
    for ix in range(res[0]):
        for iy in range(res[1]):
            for iz in range(res[2]):
                p = Vector((lo[i] + step[i] * ((ix, iy, iz)[i] + 0.5) for i in range(3)))
                if jitter:
                    p += Vector((rng.uniform(-0.5, 0.5) * step[i] * jitter for i in range(3)))
                lattice.append(p)
                ok, loc, nor, _idx = ob.closest_point_on_mesh(p)
                if ok and nor.dot(p - loc) < 0.0:
                    pts.append(p)
    # ⚠ FALL BACK TO THE WHOLE LATTICE IF NOTHING TESTS AS INSIDE. An OPEN mesh — a plane, a
    # wall modelled as a single quad, half of what gets imported — has no interior at all, so
    # the inside test rejects every point and Grid CANCELLED with "no shards" while Voronoi
    # carried on. Rob: "Grid currently does not fracture anything."
    # ⚠ The random seeder always had this fallback and the lattice one did not; the asymmetry
    # is the whole bug. The boolean clips the cells to whatever the mesh actually is, so an
    # open mesh gives flat shards rather than nothing.
    return pts or lattice


def _seed_points(ob, count, seed):
    """`count` points INSIDE the mesh, in its local space.

    ⚠ INSIDE, not just in the bounding box. A seed floating outside the mesh has its cell
    clipped away to nothing by the boolean, so the fracture quietly comes back short — the
    same shortfall that dogged the hull-based version for four rounds.
    """
    rng = random.Random(seed)
    lo = Vector((min(v[0] for v in ob.bound_box), min(v[1] for v in ob.bound_box),
                 min(v[2] for v in ob.bound_box)))
    hi = Vector((max(v[0] for v in ob.bound_box), max(v[1] for v in ob.bound_box),
                 max(v[2] for v in ob.bound_box)))
    pts = []
    # ⚠ BOUND THE ATTEMPTS. A thin shell has almost no interior, so a naive loop would spin
    # forever; falling back to bounding-box points keeps it responsive and merely approximate.
    for _ in range(count * 60):
        if len(pts) >= count:
            break
        p = Vector((rng.uniform(lo[i], hi[i]) for i in range(3)))
        ok, loc, nor, _idx = ob.closest_point_on_mesh(p)
        if ok and nor.dot(p - loc) < 0.0:
            pts.append(p)
    while len(pts) < count:
        pts.append(Vector((rng.uniform(lo[i], hi[i]) for i in range(3))))
    return pts


def _box_bmesh(lo, hi, pad):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    c = (lo + hi) * 0.5
    s = (hi - lo) + Vector((pad, pad, pad))
    bmesh.ops.scale(bm, vec=s, verts=bm.verts)
    bmesh.ops.translate(bm, vec=c, verts=bm.verts)
    return bm


def _carve_cell(bm, me, others, margin, interior, scale):
    """Slice `bm` down to the Voronoi cell of `me` against `others`."""
    for other in others:
        d = other - me
        length = d.length
        if length < 1e-9:
            continue
        # ⚠ CELL SCALE IS A CHANGE OF METRIC, and the bisector stays a PLANE under it. Under
        # d(x) = |(x - p)/S| the bisector between two seeds is the plane through their
        # midpoint with normal (p2 - p1)/S^2 — squashing S makes cells long in that axis,
        # which is how you get planks and slabs. Scaling the finished shards instead would
        # move them apart and break the fit.
        n = Vector((d[i] / (scale[i] * scale[i]) for i in range(3)))
        if n.length < 1e-12:
            continue
        n.normalize()
        # ⚠ MARGIN IS AN OFFSET ON THE BISECTOR, not a scale afterwards. Moving the plane
        # `margin/2` back from the midpoint insets every shared face by the same distance, so
        # the gap between two shards is exactly `margin` wherever they meet — a scale about
        # the centre instead leaves big shards with big gaps and small ones with slivers.
        co = (me + other) * 0.5 - n * (margin * 0.5)
        geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
        ret = bmesh.ops.bisect_plane(bm, geom=geom, dist=1e-5,
                                     plane_co=co, plane_no=n, clear_outer=True)
        cut = [e for e in ret['geom_cut'] if isinstance(e, bmesh.types.BMEdge)]
        if not cut:
            continue
        # ⚠ FILL THE CUT or the cell is an open shell, and an open shell has no volume for
        # the boolean to intersect against — every shard would come back empty.
        fill = bmesh.ops.holes_fill(bm, edges=cut)
        for f in fill.get('faces', ()):
            f[interior] = 1
    return bm


def voronoi_shards(context, ob, count, seed, margin, interior_mat,
                   grid=False, jitter=0.0, scale=(1.0, 1.0, 1.0)):
    """Cut `ob` into Voronoi shards. Returns the new objects."""
    scale = Vector((max(abs(s), 1e-4) for s in scale))
    pts = _grid_points(ob, count, jitter, seed) if grid else _seed_points(ob, count, seed)
    if not pts:
        return []
    kd = KDTree(len(pts))
    for i, p in enumerate(pts):
        kd.insert(p, i)
    kd.balance()

    lo = Vector((min(v[0] for v in ob.bound_box), min(v[1] for v in ob.bound_box),
                 min(v[2] for v in ob.bound_box)))
    hi = Vector((max(v[0] for v in ob.bound_box), max(v[1] for v in ob.bound_box),
                 max(v[2] for v in ob.bound_box)))
    pad = (hi - lo).length * 0.1

    made = []
    for i, p in enumerate(pts):
        bm = _box_bmesh(lo, hi, pad)
        interior = bm.faces.layers.int.new("mg_interior")
        for f in bm.faces:
            f[interior] = 0
        near = [pts[idx] for (_co, idx, _d) in kd.find_n(p, NEIGHBOURS + 1) if idx != i]
        _carve_cell(bm, p, near, margin, interior, scale)
        if not bm.faces:
            bm.free()
            continue
        me = bpy.data.meshes.new("%s.Shard" % ob.name)
        bm.to_mesh(me)
        bm.free()
        shard = bpy.data.objects.new(me.name, me)
        shard.matrix_world = ob.matrix_world.copy()
        context.collection.objects.link(shard)
        # ⚠ THE BOOLEAN IS WHAT MAKES IT FOLLOW THE REAL SURFACE. Without it every shard is
        # a flat-faced chunk of the bounding box — the cells are exact, but the outside of
        # the fracture would be a box rather than the object.
        mod = shard.modifiers.new("mg_cut", 'BOOLEAN')
        mod.object = ob
        mod.operation = 'INTERSECT'
        mod.solver = 'EXACT'
        made.append(shard)

    # ⚠ APPLY EVERY BOOLEAN FROM ONE EVALUATED DEPSGRAPH, then drop the modifier. Applying
    # them one at a time through the operator re-evaluates the whole scene per shard.
    context.view_layer.update()
    dg = context.evaluated_depsgraph_get()
    out = []
    for shard in made:
        ev = shard.evaluated_get(dg)
        me = bpy.data.meshes.new_from_object(ev)
        shard.modifiers.clear()
        old = shard.data
        shard.data = me
        bpy.data.meshes.remove(old)
        if not len(me.polygons):
            # the cell fell outside the mesh — nothing to keep
            bpy.data.objects.remove(shard)
            continue
        # ⚠ THE INTERIOR FACES ARE THE ONES THE CUTS MADE, and the flag SURVIVES the boolean
        # (measured) — the faces the boolean adds from the source's own surface come back 0.
        # That is what lets broken concrete read as broken rather than as a shape split up.
        if ob.data.materials:
            for slot in ob.data.materials:
                if slot is not None and slot.name not in [m.name for m in me.materials if m]:
                    me.materials.append(slot)
            lay = me.attributes.get("mg_interior")
            if lay is not None and interior_mat < len(me.materials):
                for poly, flag in zip(me.polygons, lay.data):
                    if flag.value:
                        poly.material_index = interior_mat
        out.append(shard)
    return out
